package com.savran.bahis

enum class CriterionStatus(val tr: String) {
    USED("Kullanıldı"),
    PARTIAL("Kısmen"),
    NO_DATA("Veri alınamadı"),
    NOT_USED("Kullanılmadı")
}

data class Criterion(val name: String, val status: CriterionStatus, val note: String)

data class CriteriaInput(
    val modelUsed: Boolean,
    val manual: Boolean,          // beklenen gol elle girildi
    val formUsed: Boolean,
    val rotationKnown: Boolean,
    val historyUsed: Boolean,
    val tableSource: String?,
    val season: Int?,
    val derived: Boolean = false,   // puan durumu yerine bitmiş maç sonuçlarından hesaplanan tablo
    val newsState: Int = 1,         // 0 kapalı, 1 haber yok/araştırılmadı, 2 yalnızca bilgi, 3 hesaba katıldı
    val cup: Boolean = false        // UEFA kupası maçı
)

/** Bu analizde GERÇEKTEN kullanılan ve kullanılamayan kriterler. Veri yoksa kriter hesaba katılmaz. */
object Criteria {
    /** Modelin desteklediği 3 temel kriterden (iç saha/deplasman, goller, form) kullanılanın oranı. */
    fun coverage(i: CriteriaInput): Double {
        if (!i.modelUsed) return 0.0
        val base = if (i.manual) 0 else 2
        return (base + (if (i.formUsed) 1 else 0)) / 3.0
    }

    fun build(i: CriteriaInput): List<Criterion> {
        val table = i.modelUsed && !i.manual
        val src = i.tableSource ?: "sezon tablosu"
        fun tableCriterion(name: String, okNote: String): Criterion = when {
            table -> Criterion(name, CriterionStatus.USED, okNote)
            i.manual -> Criterion(name, CriterionStatus.NOT_USED, "Beklenen gol elle girildi; tablo verisi hesaba katılmadı.")
            else -> Criterion(name, CriterionStatus.NO_DATA, "Sezon tablosu alınamadı veya takımlar eşleşmedi.")
        }
        return listOf(
            tableCriterion("İç saha / deplasman performansı", "Takımın kendi liginin (kupada turnuvanın) iç saha ve deplasman gol istatistikleri ($src${i.season?.let { ", $it sezonu" } ?: ""})."),
            tableCriterion("Atılan ve yenilen goller (maç başı)", "Maç başına ortalamalar küçük örnek için lige doğru yumuşatılarak kullanıldı."),
            tableCriterion("Hücum ve savunma gücü", "Takım hücumu/savunması lig ortalamasına oranlandı; rakibin zayıf/güçlü yanıyla çarpıldı."),
            tableCriterion("Lig gol ortalaması", "Ligin iç saha ve deplasman gol ortalaması baz alındı."),
            if (table) Criterion("Rakip güç seviyesi", CriterionStatus.PARTIAL, "Rakibin hücum/savunma gücü hesaba katıldı; ayrıca rakip kalitesine göre düzeltme yok.")
            else Criterion("Rakip güç seviyesi", CriterionStatus.NO_DATA, "Tablo verisi yok."),
            if (i.cup) Criterion("Takımların lig gücü / ligler arası fark", CriterionStatus.NOT_USED, "Avrupa kupası: hesap yalnızca bu turnuvadaki maçlardan yapılır; takımların ligdeki gücü ve ligler arası fark modele girmez. Güven en fazla Orta.")
            else Criterion("Takımların lig gücü / ligler arası fark", CriterionStatus.PARTIAL, "Takım kendi liginin tablosuyla değerlendirilir."),
            when {
                i.formUsed -> Criterion("Son 5 maç formu", CriterionStatus.USED, "Form, sezon ortalamasından sapma olarak en fazla ±%6 ağırlıkla eklendi (kalibrasyon bekliyor).")
                table -> Criterion("Son 5 maç formu", CriterionStatus.NO_DATA, "Kaynak form dizisi vermedi veya 3 maçtan az.")
                else -> Criterion("Son 5 maç formu", CriterionStatus.NO_DATA, "Tablo verisi yok.")
            },
            Criterion("Son 10 maç formu", CriterionStatus.NOT_USED, "Modele katılmadı; yalnızca son 5 maç formu kullanılır."),
            Criterion("xG ve xGA", CriterionStatus.NO_DATA, "Veri alınamadı: bağlı kaynaklardan çekilmiyor."),
            Criterion("Şut ve isabetli şut", CriterionStatus.NO_DATA, "Veri alınamadı: bağlı kaynaklardan çekilmiyor."),
            Criterion("Korner istatistikleri", CriterionStatus.NO_DATA, "Veri alınamadı: bağlı kaynaklardan çekilmiyor; korner için tahmin üretilmez."),
            Criterion("Karşılıklı maç geçmişi", CriterionStatus.NOT_USED, "Çekilmiyor; modele katılmadı."),
            when (i.newsState) {
                3 -> Criterion("Sakat ve cezalı oyuncular", CriterionStatus.USED, "Doğrulanmış haberlerden (taze, söylenti değil); gol beklentisine en fazla ±%6 yansıdı.")
                2 -> Criterion("Sakat ve cezalı oyuncular", CriterionStatus.PARTIAL, "Haber bulundu ama doğrulanmadı veya etkisiz; yalnızca bilgi olarak gösterildi, hesaba katılmadı.")
                else -> Criterion("Sakat ve cezalı oyuncular", CriterionStatus.NOT_USED, "Modele katılmadı. Haber araştırması sonuç vermedi/yapılmadı; sakat-cezalı listesi API-Football'dan maç ekranında çekilebilir.")
            },
            when (i.newsState) {
                0 -> Criterion("Güncel haberler (teknik direktör, ilk 11, yorgunluk)", CriterionStatus.NOT_USED, "Haber araştırması Ayarlar'dan kapatıldı.")
                1 -> Criterion("Güncel haberler (teknik direktör, ilk 11, yorgunluk)", CriterionStatus.NO_DATA, "Haber bulunamadı veya henüz araştırılmadı (maç ekranı açılınca araştırılır).")
                else -> Criterion("Güncel haberler (teknik direktör, ilk 11, yorgunluk)", CriterionStatus.PARTIAL, "Tarih ve kaynakla gösterilir; yalnızca doğrulanmış kaleci/forvet/savunma eksikleri hesaba katılır.")
            },
            if (i.rotationKnown) Criterion("Takım rotasyonu", CriterionStatus.PARTIAL, "Yalnızca güven seviyesine yansıdı; beklenen golü değiştirmez.")
            else Criterion("Takım rotasyonu", CriterionStatus.NO_DATA, "Rotasyon analizi yapılmadı (maç ekranından başlatılır)."),
            if (i.historyUsed) Criterion("Modelin geçmiş performansı", CriterionStatus.PARTIAL, "Yalnızca güven seviyesine yansıdı.")
            else Criterion("Modelin geçmiş performansı", CriterionStatus.NO_DATA, "Güvene yansıtmak için yeterli sonuçlanmış tahmin yok.")
        )
    }
}
