package com.savran.bahis

import java.io.File
import java.time.LocalDate

/** ClubElo'dan bir kulübün Elo puanı. */
data class EloEntry(val club: String, val country: String, val elo: Double)

/** ClubElo CSV ayrıştırıcı. Başlık sırasına bağlı değildir; bozuk satırlar atlanır, hiçbir zaman istisna fırlatmaz. */
object ClubEloParser {
    fun parse(csv: String): List<EloEntry> {
        val lines = csv.lineSequence().map { it.trim() }.filter { it.isNotEmpty() }.toList()
        if (lines.size < 2) return emptyList()
        val header = lines[0].split(",").map { it.trim().lowercase() }
        val ci = header.indexOf("club")
        val ei = header.indexOf("elo")
        val ni = header.indexOf("country")
        if (ci < 0 || ei < 0) return emptyList()
        val out = ArrayList<EloEntry>()
        for (l in lines.drop(1)) {
            val p = l.split(",")
            if (p.size <= maxOf(ci, ei)) continue
            val elo = p[ei].trim().toDoubleOrNull() ?: continue
            val club = p[ci].trim()
            if (club.isEmpty() || elo < 500.0 || elo > 3000.0) continue
            out.add(EloEntry(club, if (ni in p.indices) p[ni].trim() else "", elo))
        }
        return out
    }
}

/**
 * Elo farkından küçük ve SINIRLI bir güç düzeltmesi (yalnızca Avrupa kupası maçlarında; takımların lig gücü farkını
 * tahminen yansıtır). Kalibrasyonla doğrulanmadığı için etkisi en fazla ±%7.5 (ev/deplasman λ'sı ters yönde).
 */
object EloAdjust {
    const val MAX_LOG = 0.15

    /** (ev çarpanı, deplasman çarpanı). */
    fun factors(homeElo: Double, awayElo: Double): Pair<Double, Double> {
        val d = homeElo - awayElo
        val f = (d / 400.0 * 0.25).coerceIn(-MAX_LOG, MAX_LOG)
        return Math.exp(f / 2.0) to Math.exp(-f / 2.0)
    }

    /** Takım adına en uygun Elo kaydı; belirsiz veya bulunamazsa null (uydurma eşleştirme yok). */
    fun find(name: String, table: List<EloEntry>): EloEntry? {
        val best = TeamMatcher.bestMatch(name, table.map { it.club }) ?: return null
        return table.firstOrNull { it.club == best }
    }
}

/** Günlük önbellekli ClubElo istemcisi. Anahtar gerekmez. Hata durumunda null döner ve durum metni saklanır. */
class ClubEloSource(private val dir: File) {
    @Volatile var status: String = "Henüz denenmedi"
        private set
    @Volatile private var mem: Pair<String, List<EloEntry>>? = null
    @Volatile private var failedAt = 0L

    private fun file(date: String) = File(dir, "clubelo_$date.csv")

    fun table(today: LocalDate): List<EloEntry>? {
        val key = today.toString()
        mem?.let { if (it.first == key) return it.second }
        // Başarısız denemeden sonra 10 dk tekrar denenmez (her maçta ağ zaman aşımı beklenmesin).
        if (failedAt != 0L && System.currentTimeMillis() - failedAt < 10 * 60_000L) return null
        try {
            dir.mkdirs()
            val f = file(key)
            if (f.exists()) {
                val cached = ClubEloParser.parse(f.readText())
                if (cached.isNotEmpty()) {
                    mem = key to cached
                    status = "Önbellekten okundu (${cached.size} kulüp)"
                    return cached
                }
            }
            val r = Http.get("https://api.clubelo.com/$key")
            if (r.code !in 200..299) {
                status = "İstek başarısız (HTTP ${r.code})"
                failedAt = System.currentTimeMillis()
                return null
            }
            val parsed = ClubEloParser.parse(r.body)
            if (parsed.isEmpty()) {
                status = "Yanıt okunamadı veya boş"
                failedAt = System.currentTimeMillis()
                return null
            }
            f.writeText(r.body)
            mem = key to parsed
            status = "Alındı (${parsed.size} kulüp)"
            return parsed
        } catch (e: kotlinx.coroutines.CancellationException) {
            throw e
        } catch (e: Exception) {
            status = "Ulaşılamadı (${e.javaClass.simpleName})"
            failedAt = System.currentTimeMillis()
            return null
        }
    }
}
