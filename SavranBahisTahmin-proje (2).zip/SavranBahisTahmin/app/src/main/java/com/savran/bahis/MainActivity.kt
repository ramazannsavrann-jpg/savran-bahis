package com.savran.bahis

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.compose.animation.Crossfade
import androidx.compose.animation.core.tween
import androidx.compose.runtime.Composable
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.remember

sealed interface Screen {
    object Home : Screen
    data class Matches(val dayOffset: Int, val title: String) : Screen
    data class Detail(val match: Match) : Screen
    data class AddOdds(val match: Match) : Screen
    object AddMatch : Screen
    object Opportunities : Screen
    object Coupons : Screen
    object History : Screen
    object Performance : Screen
    object Settings : Screen
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val repo = Repository(applicationContext)
        setContent {
            SavranTheme {
                AppRoot(repo)
            }
        }
    }
}

@Composable
fun AppRoot(repo: Repository) {
    val stack = remember { mutableStateListOf<Screen>(Screen.Home) }
    val push: (Screen) -> Unit = { stack.add(it) }
    val pop: () -> Unit = { if (stack.size > 1) stack.removeAt(stack.lastIndex) }

    BackHandler(enabled = stack.size > 1) { pop() }

    Crossfade(targetState = stack.last(), animationSpec = tween(180), label = "nav") { s ->
        when (s) {
            is Screen.Home -> HomeScreen(repo, push)
            is Screen.Matches -> MatchesScreen(repo, s.dayOffset, s.title, push, pop)
            is Screen.Detail -> DetailScreen(repo, s.match, push, pop)
            is Screen.AddOdds -> AddOddsScreen(repo, s.match, pop)
            is Screen.AddMatch -> AddMatchScreen(repo, pop)
            is Screen.Opportunities -> OpportunitiesScreen(repo, push, pop)
            is Screen.Coupons -> CouponsScreen(repo, pop)
            is Screen.History -> HistoryScreen(repo, pop)
            is Screen.Performance -> PerformanceScreen(repo, pop)
            is Screen.Settings -> SettingsScreen(repo, pop)
        }
    }
}
