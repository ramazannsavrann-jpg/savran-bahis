package com.savran.bahis

/** Bahis Fırsatları filtresi: yalnızca modelin gerçekten tahmin ürettiği ve oynanabilir pazarlar listelenir. */
data class FilterGroup(val id: String, val label: String, val test: (String) -> Boolean)

object MarketFilters {
    val groups: List<FilterGroup> = listOf(
        FilterGroup("1x2", "Maç sonucu") { it == "1x2" },
        FilterGroup("dc", "Çifte şans") { it == "dc" },
        FilterGroup("goals", "Toplam gol") { it.startsWith("ou_") },
        FilterGroup("btts", "Karşılıklı gol") { it == "btts" },
        FilterGroup("home", "Ev sahibi gol") { it.startsWith("home_ou_") },
        FilterGroup("away", "Deplasman gol") { it.startsWith("away_ou_") },
        FilterGroup("ht1x2", "İlk yarı sonucu") { it == "ht_1x2" || it == "ht_dc" },
        FilterGroup("htgoals", "İlk yarı gol") { it.startsWith("ht_ou_") },
        FilterGroup("htbtts", "İlk yarı KG") { it == "ht_btts" },
        FilterGroup("htft", "Devre/Maç") { it == "htft" },
        FilterGroup("hcp", "Handikap") { it.startsWith("hcp_") },
        FilterGroup("combo", "Kombinasyon") { it.startsWith("combo_") },
        FilterGroup("cs", "Doğru skor") { it == "cs" }
    )

    fun group(id: String): FilterGroup? = groups.firstOrNull { it.id == id }

    /** Kısa, okunur seçenek adı: "Üst 2.5", "KG Var", "Ev Üst 1.5", "İY 1X"... */
    fun shortLabel(mk: String, sk: String): String {
        val sel = MarketCatalog.selectionLabel(mk, sk)
        val line = mk.substringAfterLast('_')
        return when {
            mk == "1x2" || mk == "dc" || mk == "htft" -> sk
            mk == "cs" -> sel
            mk.startsWith("ou_") -> "$sel $line"
            mk.startsWith("home_ou_") -> "Ev $sel $line"
            mk.startsWith("away_ou_") -> "Dep $sel $line"
            mk.startsWith("ht_ou_") -> "İY $sel $line"
            mk == "ht_btts" -> "İY $sel"
            mk == "ht_1x2" || mk == "ht_dc" -> "İY $sk"
            mk.startsWith("hcp_") -> MarketCatalog.marketTitle(mk).removePrefix("Handikaplı MS ") + " " + sk
            mk.startsWith("combo_") -> sel
            else -> sel
        }
    }

    private fun order(mk: String, sk: String): Int {
        val mi = MarketCatalog.all.indexOfFirst { it.key == mk }.let { if (it < 0) 9999 else it }
        val si = MarketCatalog.find(mk)?.selections?.indexOfFirst { it.key == sk }?.let { if (it < 0) 99 else it } ?: 99
        return mi * 100 + si
    }

    /** Yalnızca oynanabilir tahminler. */
    fun playable(list: List<Forecast>): List<Forecast> = list.filter { ForecastEngine.isPlayable(it.marketKey, it.selectionKey) }

    /** Bahis Fırsatları'nda gösterilen liste: her maçın her pazarında en yüksek olasılıklı seçenek. */
    fun shown(list: List<Forecast>): List<Forecast> = ForecastEngine.bahisFirsatlari(list)

    /** Elde tahmini olan gruplar (boş grup gösterilmez). */
    fun availableGroups(list: List<Forecast>): List<FilterGroup> {
        val p = shown(list)
        return groups.filter { g -> p.any { g.test(it.marketKey) } }
    }

    /** Grup içindeki seçenekler (yalnızca gerçekten tahmini olanlar), katalog sırasıyla. */
    fun options(group: FilterGroup, list: List<Forecast>): List<Pair<String, String>> =
        shown(list).filter { group.test(it.marketKey) }
            .map { it.marketKey to it.selectionKey }.distinct()
            .sortedBy { order(it.first, it.second) }

    fun apply(list: List<Forecast>, group: FilterGroup?, option: Pair<String, String>?): List<Forecast> {
        var out = shown(list)
        if (group != null) out = out.filter { group.test(it.marketKey) }
        if (option != null) out = out.filter { it.marketKey == option.first && it.selectionKey == option.second }
        return out
    }
}
