@file:OptIn(ExperimentalMaterial3Api::class)

package com.savran.bahis

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.launch
import java.util.Locale

private fun f2(x: Double): String = "%.2f".format(Locale.US, x)

@Composable
fun DetailScreen(repo: Repository, match: Match, push: (Screen) -> Unit, pop: () -> Unit) {
    val scope = rememberCoroutineScope()
    var m by remember { mutableStateOf(match) }
    var odds by remember { mutableStateOf<List<OddsEntry>>(emptyList()) }
    var analysis by remember { mutableStateOf<AnalysisResult?>(null) }
    var loading by remember { mutableStateOf(true) }
    var tick by remember { mutableStateOf(0) }
    var message by remember { mutableStateOf<String?>(null) }
    var busy by remember { mutableStateOf<String?>(null) }
    var injuries by remember { mutableStateOf<List<String>?>(null) }
    var rotations by remember { mutableStateOf<Map<Int, RotationInfo>>(emptyMap()) }
    var confirmDelete by remember { mutableStateOf(false) }
    var newsBusy by remember { mutableStateOf(false) }
    var newsTried by remember { mutableStateOf(false) }

    LaunchedEffect(tick) {
        loading = true
        try {
            odds = repo.oddsFor(m.id)
            analysis = repo.analyze(m)
            val rots = HashMap<Int, RotationInfo>()
            for (id in listOf(m.homeId, m.awayId)) {
                if (id > 0) repo.cachedRotation(id, m.kickoff)?.let { rots[id] = it }
            }
            rotations = rots
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            message = "Analiz sırasında hata: ${e.message ?: e.javaClass.simpleName}"
        }
        loading = false
        // Haber araştırması analizden sonra, ekranı bekletmeden çalışır; yeni haber gelirse analiz yenilenir.
        if (repo.settings.newsEnabled && !newsTried) {
            newsTried = true
            newsBusy = true
            try {
                if (repo.refreshNews(m)) analysis = repo.analyze(m)
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                // haber hatası istatistiksel analizi etkilemez
            }
            newsBusy = false
        }
    }

    Scaffold(topBar = {
        AppBar(m.home + " - " + m.away, pop) {
            TextButton(onClick = { tick++ }) { Text("Yenile") }
        }
    }) { pad ->
        Column(
            Modifier.padding(pad).fillMaxSize().verticalScroll(rememberScrollState()).padding(12.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            // ---- Başlık
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(m.leagueName + " · " + kickoffText(m, repo), fontSize = 12.sp, color = MutedText)
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        TeamLogo(m.homeLogo); Spacer(Modifier.width(8.dp))
                        Text(m.home, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f), maxLines = 2, overflow = TextOverflow.Ellipsis)
                        Text(m.homeGoals?.toString() ?: "", fontWeight = FontWeight.Bold, fontSize = 20.sp)
                    }
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        TeamLogo(m.awayLogo); Spacer(Modifier.width(8.dp))
                        Text(m.away, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f), maxLines = 2, overflow = TextOverflow.Ellipsis)
                        Text(m.awayGoals?.toString() ?: "", fontWeight = FontWeight.Bold, fontSize = 20.sp)
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Tag(StatusText.tr(m.statusShort) + (m.elapsed?.let { " $it'" } ?: ""), if (StatusText.isLive(m.statusShort)) GreenOk else MutedText)
                        Tag("Kaynak: " + m.source, MutedText)
                        Tag(if (odds.isEmpty()) "Oransız analiz" else "Oranlı analiz", if (odds.isEmpty()) MutedText else GreenOk)
                    }
                }
            }

            val b = busy
            if (b != null) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    CircularProgressIndicator(Modifier.width(22.dp))
                    Text(b, fontSize = 13.sp)
                }
            }
            val msg = message
            if (msg != null) InfoCard("Bilgi", msg)
            if (loading) Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.Center) { CircularProgressIndicator() }

            // ---- Model
            val a = analysis
            if (a != null) {
                SectionTitle("Model olasılıkları")
                val lh = a.lambdaHome
                val la = a.lambdaAway
                if (lh != null && la != null) {
                    Card(Modifier.fillMaxWidth()) {
                        Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                            Text("Beklenen gol: ev ${f2(lh)} · deplasman ${f2(la)}", fontWeight = FontWeight.Bold)
                            Text("Veri kalitesi: ${pct(a.dataQuality)}", fontSize = 13.sp)
                            Text(a.modelNote, fontSize = 12.sp, color = MutedText)
                            a.core.forEach { c ->
                                Row {
                                    Text(c.label, modifier = Modifier.weight(1f))
                                    Text(pct(c.prob), fontWeight = FontWeight.Bold)
                                }
                            }
                            if (a.topScores.isNotEmpty()) {
                                Text(
                                    "En olası skorlar: " + a.topScores.joinToString(" · ") { "${it.first}-${it.second} ${pct(it.third)}" },
                                    fontSize = 12.sp, color = MutedText
                                )
                            }
                            Text("Hesaplamada gerçekten kullanılan ve kullanılamayan kriterler aşağıdaki \"Bu analizde kullanılan kriterler\" bölümünde listelenir.", fontSize = 11.sp, color = MutedText)
                        }
                    }
                } else {
                    InfoCard("Model çalışmadı", a.modelNote, warn = true)
                }

                // Elle beklenen gol
                var lhText by remember { mutableStateOf(repo.settings.manualLambdas(m.id)?.first?.toString() ?: "") }
                var laText by remember { mutableStateOf(repo.settings.manualLambdas(m.id)?.second?.toString() ?: "") }
                Card(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Text("Beklenen golü elle gir (isteğe bağlı)", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            OutlinedTextField(lhText, { lhText = it }, label = { Text("Ev") }, singleLine = true,
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal), modifier = Modifier.weight(1f))
                            OutlinedTextField(laText, { laText = it }, label = { Text("Dep.") }, singleLine = true,
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal), modifier = Modifier.weight(1f))
                        }
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Button(onClick = {
                                val h = lhText.trim().replace(',', '.').toDoubleOrNull()
                                val aw = laText.trim().replace(',', '.').toDoubleOrNull()
                                if (h == null || aw == null || h !in 0.05..6.0 || aw !in 0.05..6.0) {
                                    message = "Beklenen gol 0.05 ile 6 arasında iki sayı olmalı."
                                } else {
                                    repo.settings.setManualLambdas(m.id, h, aw)
                                    message = null
                                    tick++
                                }
                            }) { Text("Kaydet") }
                            OutlinedButton(onClick = {
                                repo.settings.setManualLambdas(m.id, null, null)
                                lhText = ""; laText = ""
                                tick++
                            }) { Text("Temizle") }
                        }
                    }
                }
            }

            // ---- Kullanılan kriterler
            if (a != null && a.criteria.isNotEmpty()) {
                SectionTitle("Bu analizde kullanılan kriterler")
                CriteriaCard(a.criteria)
            }

            // ---- Güncel haberler ve kadro
            if (a != null && repo.settings.newsEnabled) {
                SectionTitle("Güncel haberler ve kadro")
                NewsSection(a, newsBusy, System.currentTimeMillis() / 1000)
            }

            // ---- Tahminler (oran gerekmez)
            if (a != null) {
                SectionTitle("Tahminler")
                ForecastSection(a, odds.isNotEmpty())
            }

            // ---- Oranlar
            SectionTitle("Oranlar (${odds.size})")
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(onClick = { push(Screen.AddOdds(m)) }) { Text("+ Oran ekle") }
                if (repo.externalOddsAvailable(m.leagueId)) {
                    OutlinedButton(onClick = {
                        scope.launchSafe(onError = { message = "Hata: $it" }, onDone = { busy = null }) {
                            busy = "Harici oranlar alınıyor…"
                            when (val r = repo.importExternalOdds(m)) {
                                is ApiResult.Ok -> message = "${r.value} oran alındı (The Odds API, kendi etiketiyle)."
                                is ApiResult.Err -> message = r.message
                            }
                            busy = null
                            tick++
                        }
                    }) { Text("Harici oran çek") }
                }
            }
            if (odds.isEmpty()) {
                InfoCard("Oran girilmedi", "Bu maç oransız analiz ediliyor: yukarıdaki tahminler istatistikten gelir. EV ve değer analizi için \"+ Oran ekle\" ile gerçek oranı kaynağıyla birlikte gir; oran uydurulmaz.")
            }
            val byMarket = odds.groupBy { it.marketKey }
            val orderedKeys = byMarket.keys.sortedBy { k -> MarketCatalog.all.indexOfFirst { it.key == k }.let { if (it < 0) 999 else it } }
            val now = System.currentTimeMillis()
            for (mk in orderedKeys) {
                val entries = byMarket[mk].orEmpty()
                val market = MarketCatalog.find(mk)
                Card(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Text(MarketCatalog.marketTitle(mk), fontWeight = FontWeight.Bold)
                        entries.sortedBy { e -> market?.selections?.indexOfFirst { it.key == e.selectionKey } ?: 0 }.forEach { e ->
                            val stale = OddsFreshness.isStale(e.updatedAt, now, m.kickoff)
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Column(Modifier.weight(1f)) {
                                    Text(MarketCatalog.selectionLabel(mk, e.selectionKey), fontSize = 14.sp)
                                    Text(
                                        "${e.origin} · ${e.bookmaker} · ${OddsFreshness.ageLabel(e.updatedAt, now)}" + if (stale) " · ESKİ" else "",
                                        fontSize = 11.sp, color = if (stale) AmberWarn else MutedText
                                    )
                                    Text("Piyasa zımni olasılığı ${pct(OddsMath.impliedProbability(e.odds))} (marj dahil)", fontSize = 11.sp, color = MutedText)
                                }
                                Text(odd2(e.odds), fontWeight = FontWeight.Bold, fontSize = 18.sp)
                                TextButton(onClick = {
                                    scope.launchSafe(onError = { message = "Hata: $it" }) { repo.deleteOdds(e.id); tick++ }
                                }) { Text("Sil") }
                            }
                        }
                        if (market != null && market.exhaustive) {
                            entries.groupBy { it.origin + " · " + it.bookmaker }.forEach { (label, es) ->
                                val complete = market.selections.all { s -> es.any { it.selectionKey == s.key } }
                                if (complete) {
                                    val list = market.selections.map { s -> es.first { it.selectionKey == s.key }.odds }
                                    val margin = OddsMath.overround(list) * 100
                                    Text("Bahis şirketi marjı ($label): %" + "%.1f".format(Locale.US, margin), fontSize = 11.sp, color = MutedText)
                                }
                            }
                        }
                    }
                }
            }

            // ---- Değerlendirme
            if (a != null && odds.isNotEmpty()) {
                SectionTitle("Bahis değerlendirmesi")
                val evals = a.evaluations.sortedWith(
                    compareByDescending<Evaluation> { it.decision == Decision.RECOMMEND }.thenByDescending { it.quality ?: -1 }
                )
                val rec = evals.count { it.decision == Decision.RECOMMEND }
                if (rec == 0) {
                    InfoCard(
                        "Bu maçta öneri yok",
                        "Girilen oranlar arasında yeterli beklenen değer, kalite ve veri güvenilirliği bulunamadı. Mutlaka bahis çıkarmak zorunda değiliz.",
                        warn = true
                    )
                }
                evals.take(60).forEach { EvalCard(it, repo, m.kickoff) }
                if (evals.size > 60) Text("İlk 60 değerlendirme gösteriliyor.", fontSize = 11.sp, color = MutedText)
                if (a.recorded > 0) Text("${a.recorded} yeni tahmin kaydı Tahmin Geçmişi'ne eklendi.", fontSize = 11.sp, color = MutedText)
            }

            // ---- Kaynak doğrulama
            SectionTitle("Veri doğrulama")
            VerificationCard(repo, m)

            // ---- Canlı, sakatlık, rotasyon
            SectionTitle("Ek veriler (API-Football kotası harcar)")
            val isApi = m.id.startsWith("api-")
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(enabled = isApi && busy == null, onClick = {
                    scope.launchSafe(onError = { message = "Hata: $it" }, onDone = { busy = null }) {
                        busy = "Canlı veri alınıyor…"
                        when (val r = repo.liveRefresh(m)) {
                            is ApiResult.Ok -> { m = r.value; message = null }
                            is ApiResult.Err -> message = r.message
                        }
                        busy = null
                    }
                }) { Text("Canlı skor") }
                OutlinedButton(enabled = isApi && busy == null, onClick = {
                    scope.launchSafe(onError = { message = "Hata: $it" }, onDone = { busy = null }) {
                        busy = "Sakat/cezalı listesi alınıyor…"
                        when (val r = repo.injuries(m)) {
                            is ApiResult.Ok -> { injuries = r.value; message = null }
                            is ApiResult.Err -> message = r.message
                        }
                        busy = null
                    }
                }) { Text("Sakat/cezalı") }
            }
            val lhv = a?.lambdaHome
            val lav = a?.lambdaAway
            val el = m.elapsed
            val gh = m.homeGoals
            val ga = m.awayGoals
            if (StatusText.isLive(m.statusShort) && lhv != null && lav != null && el != null && gh != null && ga != null) {
                val v = LiveModel.view(lhv, lav, el, gh, ga)
                InfoCard(
                    "Canlı model ($el'. dakika)",
                    "Ev kazanır ${pct(v.win)} · Beraberlik ${pct(v.draw)} · Deplasman ${pct(v.lose)}\n2.5 Üst ${pct(v.over25)} · KG Var ${pct(v.btts)}\n(Kalan süreye göre basit model; kırmızı kart vb. hesaba katılmaz.)"
                )
            }
            injuries?.let { list ->
                InfoCard(
                    "Sakat / cezalı",
                    if (list.isEmpty()) "API-Football bu maç için sakat/cezalı kaydı döndürmedi (bu, eksik olmadığı anlamına gelmez)." else list.joinToString("\n")
                )
            }

            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf("Ev" to m.homeId, "Dep." to m.awayId).forEach { (label, id) ->
                    OutlinedButton(enabled = id > 0 && busy == null, onClick = {
                        scope.launchSafe(onError = { message = "Hata: $it" }, onDone = { busy = null }) {
                            busy = "Rotasyon analizi başlıyor…"
                            when (val r = repo.rotationFor(id, m.kickoff) { p -> busy = p }) {
                                is ApiResult.Ok -> { rotations = rotations + (id to r.value); message = null }
                                is ApiResult.Err -> message = r.message
                            }
                            busy = null
                        }
                    }) { Text("Rotasyon: $label") }
                }
            }
            if (m.homeId <= 0) Text("Rotasyon yalnızca API-Football maçlarında kullanılabilir.", fontSize = 11.sp, color = MutedText)
            rotations.forEach { (id, r) ->
                val teamName = if (id == m.homeId) m.home else m.away
                InfoCard(
                    "Rotasyon: $teamName — risk ${r.risk}",
                    r.note + (r.avgChanges?.let { "\nOrtalama ilk 11 değişikliği: ${f2(it)}" } ?: ""),
                    warn = r.risk == "Yüksek"
                )
            }

            // ---- Elle sonuç / silme (yalnızca elle eklenen maçlar)
            if (m.source == "Manuel") {
                SectionTitle("Elle eklenen maç")
                var fh by remember { mutableStateOf("") }
                var fa by remember { mutableStateOf("") }
                var hh by remember { mutableStateOf("") }
                var ha by remember { mutableStateOf("") }
                Card(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Text("Sonucu gir (tahminlerin değerlendirilmesi için)", fontSize = 13.sp)
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            OutlinedTextField(fh, { fh = it }, label = { Text("Ev skor") }, singleLine = true,
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), modifier = Modifier.weight(1f))
                            OutlinedTextField(fa, { fa = it }, label = { Text("Dep. skor") }, singleLine = true,
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), modifier = Modifier.weight(1f))
                        }
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            OutlinedTextField(hh, { hh = it }, label = { Text("İY ev (ops.)") }, singleLine = true,
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), modifier = Modifier.weight(1f))
                            OutlinedTextField(ha, { ha = it }, label = { Text("İY dep. (ops.)") }, singleLine = true,
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), modifier = Modifier.weight(1f))
                        }
                        Button(onClick = {
                            val x = fh.trim().toIntOrNull()
                            val y = fa.trim().toIntOrNull()
                            val hx = hh.trim().toIntOrNull()
                            val hy = ha.trim().toIntOrNull()
                            if (x == null || y == null || x < 0 || y < 0) {
                                message = "Maç sonu skorunu iki sayı olarak gir."
                            } else if ((hh.isNotBlank() || ha.isNotBlank()) && (hx == null || hy == null)) {
                                message = "İlk yarı skorunu ya iki alanı birden doldur ya da boş bırak."
                            } else {
                                scope.launchSafe(onError = { message = "Hata: $it" }) {
                                    repo.saveManualResult(m, x, y, hx, hy)
                                    m = m.copy(statusShort = "FT", homeGoals = x, awayGoals = y, homeHt = hx, awayHt = hy)
                                    message = "Sonuç kaydedildi. Tahmin Geçmişi'nden sonuçları güncelleyebilirsin."
                                }
                            }
                        }) { Text("Sonucu kaydet") }
                        OutlinedButton(onClick = { confirmDelete = true }) { Text("Maçı ve oranlarını sil") }
                    }
                }
            }
            Spacer(Modifier.width(1.dp))
        }
    }

    if (confirmDelete) {
        AlertDialog(
            onDismissRequest = { confirmDelete = false },
            title = { Text("Maç silinsin mi?") },
            text = { Text("Bu maç ve girdiğin oranlar silinir. Geçmiş tahmin kayıtları korunur.") },
            confirmButton = {
                TextButton(onClick = {
                    confirmDelete = false
                    scope.launchSafe(onError = { message = "Hata: $it" }) { repo.deleteManualMatch(m.id); pop() }
                }) { Text("Sil") }
            },
            dismissButton = { TextButton(onClick = { confirmDelete = false }) { Text("Vazgeç") } }
        )
    }
}
