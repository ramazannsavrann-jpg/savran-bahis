package com.savran.bahis

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONException
import org.json.JSONObject
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import java.time.LocalDate

sealed class ApiResult<out T> {
    data class Ok<T>(val value: T) : ApiResult<T>()
    data class Err(val message: String) : ApiResult<Nothing>()
}

/** Maç verisi sağlayıcısı. İleride başka sağlayıcılar aynı arayüzle eklenebilir. */
interface FixtureProvider {
    val id: String
    val displayName: String
    suspend fun fixtures(date: LocalDate): ApiResult<List<Match>>
}

/** Oran sağlayıcısı. Aşama 1'de yalnızca elle giriş; API'li sağlayıcılar sonra eklenir. */
interface OddsProvider {
    val id: String
    val displayName: String
    suspend fun oddsFor(matchId: String): List<OddsEntry>
}

class ManualOddsProvider(private val store: LocalStore) : OddsProvider {
    override val id = "manual"
    override val displayName = "Manuel giriş"
    override suspend fun oddsFor(matchId: String): List<OddsEntry> = store.oddsForMatch(matchId)
}

class ApiFootballFixtureProvider(val settings: AppSettings) : FixtureProvider {
    override val id = "api-football"
    override val displayName = "API-Football"

    internal val base = "https://v3.football.api-sports.io"

    override suspend fun fixtures(date: LocalDate): ApiResult<List<Match>> = withContext(Dispatchers.IO) {
        val key = settings.apiKey ?: return@withContext ApiResult.Err("API anahtarı girilmedi.")
        val now = System.currentTimeMillis()
        if (!Quota.canSpend(settings.usedToday(now), settings.remainingKnown(now))) {
            return@withContext ApiResult.Err("Günlük istek sınırına yaklaşıldı (son ${Quota.RESERVE} istek yedekte). Yarın otomatik açılır.")
        }
        val url = URL("$base/fixtures?date=$date&timezone=Europe/Istanbul")
        val result = request(url, key, countsAgainstQuota = true)
        when (result) {
            is ApiResult.Err -> result
            is ApiResult.Ok -> parseFixtures(result.value)
        }
    }

    /** /status isteği kotadan düşmez. */
    suspend fun status(): ApiResult<String> = withContext(Dispatchers.IO) {
        val key = settings.apiKey ?: return@withContext ApiResult.Err("API anahtarı girilmedi.")
        when (val r = request(URL("$base/status"), key, countsAgainstQuota = false)) {
            is ApiResult.Err -> r
            is ApiResult.Ok -> try {
                val resp = JSONObject(r.value).getJSONObject("response")
                val plan = resp.optJSONObject("subscription")?.optString("plan", "?") ?: "?"
                val req = resp.optJSONObject("requests")
                val current = req?.optInt("current", -1) ?: -1
                val limit = req?.optInt("limit_day", -1) ?: -1
                if (current >= 0 && limit >= 0) {
                    settings.setRemaining(System.currentTimeMillis(), limit - current)
                    ApiResult.Ok("Plan: $plan • Bugün kullanılan: $current / $limit")
                } else {
                    ApiResult.Ok("Plan: $plan")
                }
            } catch (e: JSONException) {
                ApiResult.Err("Durum yanıtı okunamadı.")
            }
        }
    }

    internal fun request(url: URL, key: String, countsAgainstQuota: Boolean): ApiResult<String> {
        val conn = url.openConnection() as HttpURLConnection
        return try {
            conn.requestMethod = "GET"
            conn.connectTimeout = 15000
            conn.readTimeout = 20000
            conn.setRequestProperty("x-apisports-key", key)
            val code = conn.responseCode
            val remaining = conn.getHeaderField("x-ratelimit-requests-remaining")?.trim()?.toIntOrNull()
            if (countsAgainstQuota) settings.recordRequest(System.currentTimeMillis(), remaining)
            val stream = if (code in 200..299) conn.inputStream else conn.errorStream
            val body = stream?.bufferedReader()?.use { it.readText() } ?: ""
            when {
                code == 429 -> ApiResult.Err("Çok fazla istek (429). Biraz bekle.")
                code in 200..299 -> ApiResult.Ok(body)
                else -> ApiResult.Err("Sunucu hatası ($code).")
            }
        } catch (e: IOException) {
            ApiResult.Err("İnternet bağlantısı yok veya sunucuya ulaşılamadı.")
        } finally {
            conn.disconnect()
        }
    }

    internal fun parseFixtures(body: String): ApiResult<List<Match>> {
        return try {
            val root = JSONObject(body)
            val errors = root.opt("errors")
            val msg: String? = when (errors) {
                is JSONObject -> if (errors.length() > 0) errors.keys().asSequence().map { errors.optString(it) }.joinToString("; ") else null
                is JSONArray -> if (errors.length() > 0) (0 until errors.length()).joinToString("; ") { errors.optString(it) } else null
                else -> null
            }
            if (msg != null) return ApiResult.Err("API mesajı: $msg")

            val arr = root.optJSONArray("response") ?: return ApiResult.Err("Beklenmeyen API yanıtı.")
            val out = ArrayList<Match>()
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                val league = o.getJSONObject("league")
                val lid = league.getInt("id")
                val known = Leagues.byId(lid) ?: continue   // yalnızca desteklenen 6 lig
                val fx = o.getJSONObject("fixture")
                val teams = o.getJSONObject("teams")
                val goals = o.optJSONObject("goals")
                val home = teams.getJSONObject("home")
                val away = teams.getJSONObject("away")
                out.add(
                    Match(
                        id = "api-${fx.getInt("id")}",
                        leagueId = lid,
                        leagueName = known.nameTr,
                        home = home.getString("name"),
                        away = away.getString("name"),
                        kickoff = fx.getLong("timestamp"),
                        statusShort = fx.optJSONObject("status")?.optString("short", "NS") ?: "NS",
                        homeGoals = if (goals == null || goals.isNull("home")) null else goals.getInt("home"),
                        awayGoals = if (goals == null || goals.isNull("away")) null else goals.getInt("away"),
                        homeLogo = if (home.isNull("logo")) null else home.getString("logo"),
                        awayLogo = if (away.isNull("logo")) null else away.getString("logo"),
                        source = displayName,
                        homeId = home.optInt("id", 0),
                        awayId = away.optInt("id", 0),
                        homeHt = o.optJSONObject("score")?.optJSONObject("halftime")?.let { if (it.isNull("home")) null else it.getInt("home") },
                        awayHt = o.optJSONObject("score")?.optJSONObject("halftime")?.let { if (it.isNull("away")) null else it.getInt("away") },
                        elapsed = fx.optJSONObject("status")?.let { if (it.isNull("elapsed")) null else it.getInt("elapsed") }
                    )
                )
            }
            ApiResult.Ok(out.sortedBy { it.kickoff })
        } catch (e: JSONException) {
            ApiResult.Err("API yanıtı okunamadı.")
        }
    }
}
