@file:OptIn(ExperimentalMaterial3Api::class)

package com.savran.bahis

import androidx.compose.foundation.background
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.DateRange
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.List
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.Icon
import androidx.compose.material3.Shapes
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.unit.Dp
import kotlin.math.cos
import kotlin.math.sin
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import java.time.Instant
import java.time.format.DateTimeFormatter
import java.util.Locale
import kotlin.math.roundToInt

val GreenOk = Color(0xFF34D399)
val AmberWarn = Color(0xFFFBBF24)
val RedBad = Color(0xFFF87171)
val MutedText = Color(0xFF94A3B8)
val AccentBlue = Color(0xFF38BDF8)
val BrandGradient: Brush = Brush.linearGradient(listOf(Color(0xFF0B2A4A), Color(0xFF0F766E), Color(0xFF15803D)))
val BarGradient: Brush = Brush.horizontalGradient(listOf(Color(0xFF0B2A4A), Color(0xFF0E4F5C)))

@Composable
fun SavranTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = GreenOk,
            onPrimary = Color(0xFF04210F),
            background = Color(0xFF0A1220),
            onBackground = Color(0xFFE8EEF6),
            surface = Color(0xFF121C2E),
            onSurface = Color(0xFFE8EEF6),
            surfaceVariant = Color(0xFF192741),
            onSurfaceVariant = Color(0xFFB6C3D4),
            secondary = AccentBlue,
            tertiary = AmberWarn,
            error = RedBad
        ),
        shapes = Shapes(
            small = RoundedCornerShape(10.dp),
            medium = RoundedCornerShape(18.dp),
            large = RoundedCornerShape(24.dp)
        )
    ) {
        Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) { content() }
    }
}

/** Savran Analiz logosu: gradient zemin, futbol topu ve yükselen analiz çubukları (launcher ikonuyla aynı tasarım). */
@Composable
fun SavranLogo(size: Dp = 56.dp) {
    Canvas(Modifier.size(size)) {
        val s = this.size.minDimension
        drawRoundRect(
            brush = Brush.linearGradient(listOf(Color(0xFF0B2A4A), Color(0xFF0F766E)), start = Offset(0f, 0f), end = Offset(s, s)),
            cornerRadius = CornerRadius(s * 0.26f, s * 0.26f)
        )
        val bw = s * 0.14f
        val base = s * 0.84f
        val xs = listOf(s * 0.22f, s * 0.43f, s * 0.64f)
        val hs = listOf(s * 0.14f, s * 0.24f, s * 0.34f)
        for (i in xs.indices) {
            drawRoundRect(
                brush = Brush.verticalGradient(listOf(Color(0xFF6EE7B7), Color(0xFF10B981)), startY = base - hs[i], endY = base),
                topLeft = Offset(xs[i], base - hs[i]), size = Size(bw, hs[i]), cornerRadius = CornerRadius(bw * 0.3f, bw * 0.3f)
            )
        }
        val c = Offset(s * 0.50f, s * 0.34f)
        val r = s * 0.17f
        drawCircle(Color.White, r, c)
        val path = Path()
        for (k in 0 until 5) {
            val ang = -Math.PI / 2 + k * 2 * Math.PI / 5
            val px = c.x + (r * 0.55f * cos(ang)).toFloat()
            val py = c.y + (r * 0.55f * sin(ang)).toFloat()
            if (k == 0) path.moveTo(px, py) else path.lineTo(px, py)
        }
        path.close()
        drawPath(path, Color(0xFF0B1B33))
    }
}

fun pct(p: Double): String = "%" + (p * 100).roundToInt()
fun odd2(o: Double): String = "%.2f".format(Locale.US, o)

private val timeFmt: DateTimeFormatter = DateTimeFormatter.ofPattern("d MMM HH:mm", Locale.forLanguageTag("tr"))
val dayFmt: DateTimeFormatter = DateTimeFormatter.ofPattern("d MMM", Locale.forLanguageTag("tr"))
val hourFmt: DateTimeFormatter = DateTimeFormatter.ofPattern("HH:mm")

fun kickoffText(m: Match, repo: Repository): String =
    Instant.ofEpochSecond(m.kickoff).atZone(repo.zone).format(timeFmt)

fun clockText(epochMs: Long, repo: Repository): String =
    Instant.ofEpochMilli(epochMs).atZone(repo.zone).format(hourFmt)

@Composable
fun AppBar(title: String, onBack: (() -> Unit)?, actions: @Composable RowScope.() -> Unit = {}) {
    Box(Modifier.fillMaxWidth().background(BarGradient)) {
        TopAppBar(
            title = { Text(title, maxLines = 1, overflow = TextOverflow.Ellipsis, fontSize = 19.sp, fontWeight = FontWeight.Bold) },
            navigationIcon = {
                if (onBack != null) IconButton(onClick = onBack) {
                    Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Geri")
                }
            },
            actions = actions,
            colors = TopAppBarDefaults.topAppBarColors(
                containerColor = Color.Transparent,
                titleContentColor = Color.White,
                navigationIconContentColor = Color.White,
                actionIconContentColor = Color.White
            )
        )
    }
}

@Composable
fun InfoCard(title: String, text: String, warn: Boolean = false) {
    Card(
        Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = if (warn) Color(0xFF3A2E14) else MaterialTheme.colorScheme.surfaceVariant)
    ) {
        Column(Modifier.padding(12.dp)) {
            Text(title, fontWeight = FontWeight.Bold, color = if (warn) AmberWarn else MaterialTheme.colorScheme.onSurface)
            Spacer(Modifier.height(4.dp))
            Text(text, fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

@Composable
fun SectionTitle(text: String) {
    Row(Modifier.padding(top = 10.dp), verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.width(4.dp).height(18.dp).background(GreenOk, RoundedCornerShape(2.dp)))
        Spacer(Modifier.width(8.dp))
        Text(text, fontWeight = FontWeight.Bold, fontSize = 17.sp, color = Color(0xFFE8EEF6))
    }
}

@Composable
fun <T> ChipRow(items: List<T>, selected: T?, label: (T) -> String, onSelect: (T) -> Unit) {
    Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        items.forEach { item ->
            FilterChip(selected = item == selected, onClick = { onSelect(item) }, label = { Text(label(item), maxLines = 1) })
        }
    }
}

@Composable
fun TeamLogo(url: String?) {
    if (url != null) {
        AsyncImage(model = url, contentDescription = null, modifier = Modifier.size(24.dp))
    } else {
        Box(Modifier.size(24.dp).background(Color(0xFF2B3E52), CircleShape))
    }
}

@Composable
fun Tag(text: String, color: Color) {
    Text(
        text, color = color, fontSize = 12.sp, fontWeight = FontWeight.Bold, maxLines = 1,
        modifier = Modifier.background(color.copy(alpha = 0.15f), CircleShape).padding(horizontal = 10.dp, vertical = 3.dp)
    )
}

fun decisionColor(d: Decision): Color = when (d) {
    Decision.RECOMMEND -> GreenOk
    Decision.LOW_EDGE, Decision.STALE_ODDS -> AmberWarn
    Decision.LOW_ODDS, Decision.NO_DATA -> MutedText
}

@Composable
fun EvalCard(e: Evaluation, repo: Repository, kickoff: Long, title: String? = null) {
    var open by remember { mutableStateOf(false) }
    val now = System.currentTimeMillis()
    Card(Modifier.fillMaxWidth().clickable { open = !open }) {
        Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            if (title != null) Text(title, fontSize = 12.sp, color = MutedText, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    MarketCatalog.marketTitle(e.marketKey) + " · " + MarketCatalog.selectionLabel(e.marketKey, e.selectionKey),
                    fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f), maxLines = 2, overflow = TextOverflow.Ellipsis
                )
                Spacer(Modifier.width(8.dp))
                Text(odd2(e.odds), fontWeight = FontWeight.Bold, fontSize = 18.sp)
            }
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Tag(e.decision.tr, decisionColor(e.decision))
                if (e.highRisk) Tag("Yüksek risk", RedBad)
                Spacer(Modifier.weight(1f))
                if (e.quality != null) Text("Kalite ${e.quality}/100", fontSize = 13.sp, fontWeight = FontWeight.Bold)
            }
            if (e.adjProb != null) {
                val ev = e.ev?.let { " · EV " + (if (it >= 0) "+" else "") + "%.1f".format(Locale.US, it * 100) + "%" } ?: ""
                Text("Model ${pct(e.modelProb ?: e.adjProb)} · Ayarlı ${pct(e.adjProb)} · Oran zımni ${pct(e.impliedProb)}$ev", fontSize = 13.sp)
            }
            Text(e.reason, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            if (open) {
                val stale = OddsFreshness.isStale(e.updatedAt, now, kickoff)
                Text(
                    "Kaynak: ${e.origin} · ${e.bookmaker} · ${OddsFreshness.ageLabel(e.updatedAt, now)} (${clockText(e.updatedAt, repo)})" +
                        if (stale) " · ESKİ" else "",
                    fontSize = 12.sp, color = if (stale) AmberWarn else MutedText
                )
                if (e.modelProb != null) Text("Ham model olasılığı ${pct(e.modelProb)}" + (e.fairProb?.let { " · Marjsız piyasa ${pct(it)}" } ?: " · Piyasa doğrulaması yok"), fontSize = 12.sp, color = MutedText)
                e.breakdown?.let { b ->
                    Text(
                        "Kalite dağılımı: EV ${b.ev.roundToInt()}/30 · Avantaj ${b.edge.roundToInt()}/15 · Olasılık ${b.prob.roundToInt()}/10 · " +
                            "Veri ${b.data.roundToInt()}/15 · Güncellik ${b.fresh.roundToInt()}/10 · Pazar ${b.market.roundToInt()}/10 · " +
                            "Model geçmişi ${b.history.roundToInt()}/10 · Ceza -${b.penalty.roundToInt()}",
                        fontSize = 12.sp, color = MutedText
                    )
                }
                Text("Kalite puanı kazanma olasılığı değildir; yüksek puan kazanç garantisi vermez.", fontSize = 11.sp, color = MutedText)
            }
        }
    }
}

// ------------------------------------------------------------------------- Ana ekran

private data class Tile(val title: String, val sub: String, val icon: ImageVector, val target: Screen)

@Composable
private fun HomeTile(t: Tile, modifier: Modifier, onClick: () -> Unit) {
    Card(modifier.clickable { onClick() }) {
        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Box(
                Modifier.size(42.dp).background(
                    Brush.linearGradient(listOf(Color(0xFF0E7490), Color(0xFF10B981))), RoundedCornerShape(14.dp)
                ),
                contentAlignment = Alignment.Center
            ) {
                Icon(t.icon, contentDescription = null, tint = Color.White)
            }
            Text(t.title, fontWeight = FontWeight.Bold, fontSize = 15.sp, maxLines = 2)
            Text(t.sub, fontSize = 12.sp, color = MutedText, maxLines = 3)
        }
    }
}

@Composable
fun HomeScreen(repo: Repository, push: (Screen) -> Unit) {
    val tiles = listOf(
        Tile("Bugünün Maçları", "Bugün ve yarın · 6 lig", Icons.Filled.DateRange, Screen.Matches(0, "Bugünün Maçları")),
        Tile("Maç Analizi", "Maç seç; tahminler, güven, kriterler", Icons.Filled.Search, Screen.Matches(0, "Analiz için maç seç")),
        Tile("Bahis Fırsatları", "Güçlü tahminler + pazar filtresi", Icons.Filled.Star, Screen.Opportunities),
        Tile("Kupon Laboratuvarı", "Dengeli · Sürpriz · Yüksek Risk", Icons.Filled.List, Screen.Coupons),
        Tile("Tahmin Geçmişi", "Kayıtlı tahminler ve sonuçları", Icons.Filled.Info, Screen.History),
        Tile("Model Performansı", "Başarı, Brier, kalibrasyon", Icons.Filled.CheckCircle, Screen.Performance),
        Tile("API ve Veri Kaynakları", "7 kaynak: anahtar, durum, test", Icons.Filled.Settings, Screen.Settings)
    )
    Scaffold(topBar = { AppBar("Savran Analiz", null) }) { pad ->
        LazyColumn(
            Modifier.padding(pad).fillMaxSize(),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item {
                Box(Modifier.fillMaxWidth().background(BrandGradient, RoundedCornerShape(24.dp)).padding(18.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                        SavranLogo(60.dp)
                        Column {
                            Text("Savran Analiz", fontWeight = FontWeight.Bold, fontSize = 24.sp, color = Color.White)
                            Text("İstatistik temelli futbol analizi", fontSize = 13.sp, color = Color(0xFFD1FAE5))
                        }
                    }
                }
            }
            item {
                val fixtureSources = listOf(
                    SourceId.API_FOOTBALL, SourceId.FOOTBALL_DATA, SourceId.API_NINJAS, SourceId.THESPORTSDB, SourceId.OPENLIGADB
                )
                val active = fixtureSources.count { repo.settings.isActive(it) }
                if (active == 0) {
                    InfoCard(
                        "Etkin veri kaynağı yok",
                        "API ve Veri Kaynakları bölümünden bir kaynağı aktif et ve anahtarını gir, ya da maçları elle ekle.",
                        warn = true
                    )
                } else {
                    Text("Veri: $active maç kaynağı aktif · oran girmeden de analiz yapılır", fontSize = 12.sp, color = MutedText)
                }
            }
            items(tiles.chunked(2)) { pair ->
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    pair.forEach { t -> HomeTile(t, Modifier.weight(1f)) { push(t.target) } }
                    if (pair.size == 1) Spacer(Modifier.weight(1f))
                }
            }
            item {
                Text(
                    "Bu uygulama analiz ve karar desteğidir. Kesin kazanç, garanti kupon veya kayıpsız bahis iddiası taşımaz. Bahis kararı ve riski sana aittir.",
                    fontSize = 11.sp, color = MutedText
                )
            }
        }
    }
}

// ------------------------------------------------------------------------- Maç listesi

@Composable
fun MatchesScreen(repo: Repository, initialOffset: Int, title: String, push: (Screen) -> Unit, pop: () -> Unit) {
    var offset by remember { mutableStateOf(initialOffset) }
    var leagueFilter by remember { mutableStateOf<Int?>(null) }
    var data by remember { mutableStateOf<DayMatches?>(null) }
    var counts by remember { mutableStateOf<Map<String, Int>>(emptyMap()) }
    var loading by remember { mutableStateOf(false) }
    var tick by remember { mutableStateOf(0) }
    var force by remember { mutableStateOf(false) }

    LaunchedEffect(offset, tick) {
        loading = true
        val f = force
        force = false
        try {
            data = repo.matchesForDate(repo.today().plusDays(offset.toLong()), f)
            counts = repo.oddsCounts()
        } catch (e: kotlinx.coroutines.CancellationException) {
            throw e
        } catch (e: Exception) {
            // Beklenmeyen hata listeyi çökertmesin; mevcut liste korunur.
        } finally {
            loading = false
        }
    }

    Scaffold(topBar = {
        AppBar(title, pop) {
            TextButton(onClick = { force = true; tick++ }) { Text("Yenile") }
            TextButton(onClick = { push(Screen.AddMatch) }) { Text("+ Maç") }
        }
    }) { pad ->
        Column(Modifier.padding(pad).fillMaxSize().padding(horizontal = 12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            ChipRow(listOf(-1, 0, 1, 2, 3), offset, { o ->
                when (o) {
                    -1 -> "Dün"
                    0 -> "Bugün"
                    1 -> "Yarın"
                    else -> repo.today().plusDays(o.toLong()).format(dayFmt)
                }
            }) { offset = it }
            ChipRow(listOf<Int?>(null) + Leagues.supported.map { it.id }, leagueFilter, { id ->
                if (id == null) "Tümü" else Leagues.byId(id)?.nameTr ?: "Lig"
            }) { leagueFilter = it }

            val d = data
            if (loading) Box(Modifier.fillMaxWidth().padding(16.dp), contentAlignment = Alignment.Center) { CircularProgressIndicator() }
            if (d?.notice != null) InfoCard("Bilgi", d.notice, warn = true)
            if (d?.fetchedAt != null) {
                Text(
                    "Maç listesi: ${clockText(d.fetchedAt, repo)}" + if (d.fromCache) " (önbellek)" else "",
                    fontSize = 11.sp, color = MutedText
                )
            }
            val list = d?.matches.orEmpty().filter { leagueFilter == null || it.leagueId == leagueFilter }
            if (!loading && d != null && list.isEmpty() && d.notice == null) {
                Text("Bu gün için maç bulunamadı (6 lig). İstersen \"+ Maç\" ile elle ekleyebilirsin.", color = MutedText)
            }
            LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp), contentPadding = PaddingValues(bottom = 16.dp)) {
                items(list, key = { it.id }) { m -> MatchRow(m, repo, counts[m.id] ?: 0) { push(Screen.Detail(m)) } }
            }
        }
    }
}

@Composable
fun MatchRow(m: Match, repo: Repository, oddsCount: Int, onClick: () -> Unit) {
    Card(Modifier.fillMaxWidth().clickable(onClick = onClick)) {
        Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(m.leagueName, fontSize = 12.sp, color = MutedText, modifier = Modifier.weight(1f), maxLines = 1, overflow = TextOverflow.Ellipsis)
                val status = when {
                    StatusText.isLive(m.statusShort) -> "${StatusText.tr(m.statusShort)}${m.elapsed?.let { " $it'" } ?: ""}"
                    StatusText.isFinished(m.statusShort) -> "Bitti"
                    m.statusShort == "NS" -> kickoffText(m, repo)
                    else -> StatusText.tr(m.statusShort)
                }
                Text(status, fontSize = 12.sp, color = if (StatusText.isLive(m.statusShort)) GreenOk else MutedText, maxLines = 1)
            }
            Row(verticalAlignment = Alignment.CenterVertically) {
                TeamLogo(m.homeLogo); Spacer(Modifier.width(8.dp))
                Text(m.home, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f), maxLines = 1, overflow = TextOverflow.Ellipsis)
                Text(m.homeGoals?.toString() ?: "", fontWeight = FontWeight.Bold)
            }
            Row(verticalAlignment = Alignment.CenterVertically) {
                TeamLogo(m.awayLogo); Spacer(Modifier.width(8.dp))
                Text(m.away, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f), maxLines = 1, overflow = TextOverflow.Ellipsis)
                Text(m.awayGoals?.toString() ?: "", fontWeight = FontWeight.Bold)
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                if (oddsCount > 0) Tag("$oddsCount oran", GreenOk) else Tag("oran yok", MutedText)
                if (m.source == "Manuel") Tag("Manuel", AmberWarn)
                val nSrc = FixtureMerge.sources(m).size
                if (m.source != "Manuel" && nSrc > 1) Tag("$nSrc kaynak", GreenOk)
            }
        }
    }
}
