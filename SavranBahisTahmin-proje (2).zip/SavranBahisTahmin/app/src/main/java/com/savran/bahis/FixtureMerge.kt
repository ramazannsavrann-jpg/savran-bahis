package com.savran.bahis

import kotlin.math.abs

/**
 * Birden fazla kaynaktan gelen maç listelerini tek listede birleştirir.
 * Aynı maç = aynı lig + kickoff farkı ≤ 3 saat + iki takım adı benzer.
 * Ana listedeki (öncelikli) maç korunur; yalnızca eksik logo ve "kaynak" listesi tamamlanır.
 * Canlı/skor verisi iki kaynaktan karıştırılmaz.
 */
object FixtureMerge {
    private const val MAX_DIFF_SEC = 3 * 3600L
    const val SEP = " + "

    fun sameMatch(a: Match, b: Match): Boolean {
        if (a.leagueId != b.leagueId) return false
        if (abs(a.kickoff - b.kickoff) > MAX_DIFF_SEC) return false
        return TeamMatcher.isSame(a.home, b.home) && TeamMatcher.isSame(a.away, b.away)
    }

    fun sources(m: Match): List<String> = m.source.split(SEP).map { it.trim() }.filter { it.isNotEmpty() }

    fun merge(base: List<Match>, extras: List<Match>): List<Match> {
        val out = base.toMutableList()
        for (e in extras) {
            val i = out.indexOfFirst { sameMatch(it, e) }
            if (i < 0) out.add(e) else out[i] = enrich(out[i], e)
        }
        return out.sortedBy { it.kickoff }
    }

    private fun enrich(a: Match, b: Match): Match {
        val names = (sources(a) + sources(b)).distinct().joinToString(SEP)
        var r = a.copy(source = names, homeLogo = a.homeLogo ?: b.homeLogo, awayLogo = a.awayLogo ?: b.awayLogo)
        // Ana kaynakta maç hâlâ "başlamadı" görünüyor ama diğer kaynakta bitmişse, bitmiş veriyi bir bütün olarak al.
        if (!StatusText.isFinished(a.statusShort) && StatusText.isFinished(b.statusShort)) {
            r = r.copy(
                statusShort = b.statusShort, homeGoals = b.homeGoals, awayGoals = b.awayGoals,
                homeHt = b.homeHt ?: r.homeHt, awayHt = b.awayHt ?: r.awayHt
            )
        }
        return r
    }
}
