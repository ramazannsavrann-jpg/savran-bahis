@file:OptIn(ExperimentalMaterial3Api::class)

package com.savran.bahis

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Card
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.util.Locale

@Composable
private fun PerfLine(label: String, value: String) {
    Row(Modifier.fillMaxWidth()) {
        Text(label, modifier = Modifier.weight(1f), fontSize = 13.sp)
        Text(value, fontWeight = FontWeight.Bold, fontSize = 13.sp)
    }
}

@Composable
private fun GroupLines(list: List<GroupStat>) {
    if (list.isEmpty()) Text("Bu dönemde sonuçlanmış tahmin yok.", fontSize = 12.sp, color = MutedText)
    list.forEach { PerfLine("${it.label} · n=${it.n}", "${it.correct} doğru · ${pct(it.rate)}") }
}

@Composable
fun PerformanceScreen(repo: Repository, pop: () -> Unit) {
    var report by remember { mutableStateOf<Report?>(null) }
    var records by remember { mutableStateOf<List<PredictionRecord>>(emptyList()) }
    var learning by remember { mutableStateOf<LearningState?>(null) }
    var period by remember { mutableStateOf(Period.WEEK) }

    LaunchedEffect(Unit) {
        // Öğrenme yerel hesaplanır (ağ yok): yeterli veri yoksa hiçbir şey değişmez.
        try {
            learning = repo.learnNow()
            records = repo.predictionList()
            report = repo.report()
        } catch (e: kotlinx.coroutines.CancellationException) {
            throw e
        } catch (e: Exception) {
            // Okuma/öğrenme hatası ekranı çökertmesin; veri yoksa ekran boş durumu gösterir.
        }
    }

    Scaffold(topBar = { AppBar("Model Performansı", pop) }) { pad ->
        Column(
            Modifier.padding(pad).fillMaxSize().verticalScroll(rememberScrollState()).padding(12.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            val r = report
            if (r == null) {
                Box(Modifier.fillMaxWidth().padding(16.dp), contentAlignment = Alignment.Center) { CircularProgressIndicator() }
            } else {
                // ---- Dönemsel rapor
                ChipRow(Period.values().toList(), period, { it.tr }) { period = it }
                val pr = PeriodReports.build(records, period, System.currentTimeMillis(), repo.zone)
                Card(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        PerfLine("Kayıtlı tahmin", "${pr.total}")
                        PerfLine("Sonuçlanan", "${pr.settled}")
                        PerfLine("Doğru", "${pr.correct}")
                        PerfLine("Yanlış", "${pr.wrong}")
                        PerfLine("Genel başarı", pr.hitRate?.let { pct(it) } ?: "-")
                        PerfLine(
                            "Önceki dönem",
                            if (pr.previous.settled == 0) "veri yok" else "${pr.previous.settled} tahmin · ${pct(pr.previous.hitRate ?: 0.0)}"
                        )
                        Text("Başarı yalnızca sonucu belli olan tahminlerden hesaplanır.", fontSize = 11.sp, color = MutedText)
                    }
                }
                SectionTitle("Bahis türlerine göre")
                GroupLines(pr.byMarket)
                pr.best?.let { Text("En başarılı: ${it.label} (${pct(it.rate)}, n=${it.n})", fontSize = 12.sp, color = GreenOk) }
                pr.worst?.let { Text("En başarısız: ${it.label} (${pct(it.rate)}, n=${it.n})", fontSize = 12.sp, color = AmberWarn) }
                SectionTitle("Liglere göre")
                GroupLines(pr.byLeague)

                SectionTitle("Motorun değerlendirmesi")
                InfoCard("Otomatik değerlendirme", PeriodReports.commentary(pr, learning))

                // ---- Öğrenme durumu (kalıcı kayıtlardan)
                SectionTitle("Öğrenme durumu")
                val ls = learning
                if (ls == null || (ls.samples.isEmpty() && ls.events.isEmpty())) {
                    Text(
                        "Henüz sonuçlanmış tahmin yok; öğrenme başlamadı. Kalibrasyon için bir pazar grubunda en az ${Calibration.MIN_N} sonuçlanmış tahmin (en az ${Calibration.MIN_MATCHES} farklı maç) gerekir.",
                        fontSize = 12.sp, color = MutedText
                    )
                } else {
                    ls.samples.entries.sortedBy { it.key }.forEach { (g, n) ->
                        val cal = ls.groups[g]
                        val status = when {
                            cal != null -> "kalibrasyon aktif"
                            n < Calibration.MIN_N -> "veri yetersiz (${Calibration.MIN_N} gerekir)"
                            else -> "doğrulamada iyileşme yok, değiştirilmedi"
                        }
                        PerfLine(Calibration.groupLabel(g) + " · n=" + n, status)
                    }
                    if (ls.weak.isNotEmpty()) {
                        Text("Zayıf pazar (güven düşürülüyor): " + ls.weak.joinToString(", ") { Calibration.groupLabel(it) }, fontSize = 12.sp, color = AmberWarn)
                    }
                    ls.events.takeLast(5).reversed().forEach { e ->
                        Text(
                            "${Calibration.groupLabel(e.group)} (n=${e.n}): Brier ${"%.4f".format(Locale.US, e.brierBefore)} → ${"%.4f".format(Locale.US, e.brierAfter)} · " +
                                (if (e.adopted) "devreye alındı" else "devreye alınmadı"),
                            fontSize = 11.sp, color = MutedText
                        )
                    }
                }
                Text(
                    "Öğrenme kontrollüdür: tek bir yanlış tahmin hiçbir şeyi değiştirmez; yalnızca yeterli sonuç birikince ve doğrulama kümesinde Brier skoru iyileşirse kalibrasyon devreye girer. Veriler kalıcıdır.",
                    fontSize = 11.sp, color = MutedText
                )

                // ---- Tüm zamanlar
                SectionTitle("Tüm zamanlar")
                Card(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        PerfLine("Toplam tahmin", "${r.total}")
                        PerfLine("Sonuçlanan", "${r.settled}")
                        PerfLine("Doğru / Yanlış", "${r.correct} / ${r.wrong}")
                        PerfLine("Başarı oranı", r.hitRate?.let { pct(it) } ?: "-")
                        PerfLine("Brier skoru (düşük iyi)", r.brier?.let { "%.3f".format(Locale.US, it) } ?: "-")
                        PerfLine("Log loss (düşük iyi)", r.logLoss?.let { "%.3f".format(Locale.US, it) } ?: "-")
                        Text("Referans: hep %50 diyen modelin Brier skoru 0.250'dir.", fontSize = 11.sp, color = MutedText)
                    }
                }
                if (r.settled < Metrics.MIN_FOR_HISTORY_SCORE) {
                    InfoCard(
                        "Örnek sayısı az",
                        "${r.settled} sonuçlanmış tahminle model başarısı hakkında sağlam bir şey söylenemez. Anlamlı değerlendirme için en az ${Metrics.MIN_FOR_HISTORY_SCORE} sonuçlanmış tahmin gerekir.",
                        warn = true
                    )
                }
                SectionTitle("Son tahminler")
                r.recent.forEach { w ->
                    PerfLine(
                        "Son ${w.window} (n=${w.n})",
                        if (w.n == 0 || w.hitRate == null) "-" else pct(w.hitRate) + " · Brier " + "%.3f".format(Locale.US, w.brier ?: 0.0)
                    )
                }
                Text("Birden fazla seçenek aynı maçtan kaydedildiği için son N tahmin, N farklı maç değildir.", fontSize = 11.sp, color = MutedText)
                Text(
                    "Başarı oranı yalnızca modelin önerdiği (Bahis Fırsatları) seçimlerden hesaplanır; elle girilen beklenen golle üretilen tahminler ayrı tutulur" +
                        (if (r.manualSettled > 0) " (${r.manualSettled} sonuçlanmış manuel kayıt hariç)." else "."),
                    fontSize = 11.sp, color = MutedText
                )

                SectionTitle("Kalibrasyon (olasılık grupları)")
                if (r.bins.isEmpty()) Text("Henüz sonuçlanmış tahmin yok.", fontSize = 12.sp, color = MutedText)
                r.bins.forEach { b -> PerfLine("${b.label} · n=${b.count}", "tahmin ${pct(b.meanPredicted)} → gerçek ${pct(b.hitRate)}") }
                Text("İyi kalibre model %70 dediği tahminlerin yaklaşık %70'inde haklı çıkar.", fontSize = 11.sp, color = MutedText)

                SectionTitle("Gerçek oranlarla geçmiş getiri")
                Card(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        PerfLine("Oranı olan sonuçlanmış tahmin", "${r.roiN}")
                        PerfLine("Birim getiri (1 birim/bahis)", r.unitReturn?.let { (if (it >= 0) "+" else "") + "%.2f".format(Locale.US, it) } ?: "-")
                        PerfLine("ROI", r.roi?.let { (if (it >= 0) "+" else "") + "%.1f".format(Locale.US, it * 100) + "%" } ?: "-")
                        Text("Geçmiş ölçümdür; para, bakiye veya sanal kupon takibi değildir ve kazancı garanti etmez.", fontSize = 11.sp, color = MutedText)
                    }
                }
            }
        }
    }
}
