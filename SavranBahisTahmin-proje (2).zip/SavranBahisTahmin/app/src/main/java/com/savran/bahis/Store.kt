package com.savran.bahis

import org.json.JSONArray
import org.json.JSONObject
import java.io.File

private fun JSONObject.strOrNull(k: String): String? = if (isNull(k)) null else getString(k)
private fun JSONObject.intOrNull(k: String): Int? = if (isNull(k)) null else getInt(k)

internal object Codec {
    fun matchToJson(m: Match): JSONObject = JSONObject()
        .put("id", m.id).put("leagueId", m.leagueId).put("leagueName", m.leagueName)
        .put("home", m.home).put("away", m.away).put("kickoff", m.kickoff)
        .put("statusShort", m.statusShort)
        .put("homeGoals", m.homeGoals ?: JSONObject.NULL)
        .put("awayGoals", m.awayGoals ?: JSONObject.NULL)
        .put("homeLogo", m.homeLogo ?: JSONObject.NULL)
        .put("awayLogo", m.awayLogo ?: JSONObject.NULL)
        .put("source", m.source).put("homeId", m.homeId).put("awayId", m.awayId)
        .put("homeHt", m.homeHt ?: JSONObject.NULL).put("awayHt", m.awayHt ?: JSONObject.NULL)
        .put("elapsed", m.elapsed ?: JSONObject.NULL)

    fun matchFromJson(o: JSONObject): Match = Match(
        id = o.getString("id"), leagueId = o.getInt("leagueId"), leagueName = o.getString("leagueName"),
        home = o.getString("home"), away = o.getString("away"), kickoff = o.getLong("kickoff"),
        statusShort = o.getString("statusShort"),
        homeGoals = o.intOrNull("homeGoals"), awayGoals = o.intOrNull("awayGoals"),
        homeLogo = o.strOrNull("homeLogo"), awayLogo = o.strOrNull("awayLogo"),
        source = o.getString("source"),
        homeId = o.optInt("homeId", 0), awayId = o.optInt("awayId", 0),
        homeHt = o.intOrNull("homeHt"), awayHt = o.intOrNull("awayHt"), elapsed = o.intOrNull("elapsed")
    )

    fun oddsToJson(e: OddsEntry): JSONObject = JSONObject()
        .put("id", e.id).put("matchId", e.matchId).put("marketKey", e.marketKey)
        .put("selectionKey", e.selectionKey).put("odds", e.odds)
        .put("bookmaker", e.bookmaker).put("origin", e.origin).put("updatedAt", e.updatedAt)

    fun oddsFromJson(o: JSONObject): OddsEntry = OddsEntry(
        id = o.getString("id"), matchId = o.getString("matchId"), marketKey = o.getString("marketKey"),
        selectionKey = o.getString("selectionKey"), odds = o.getDouble("odds"),
        bookmaker = o.getString("bookmaker"), origin = o.getString("origin"), updatedAt = o.getLong("updatedAt")
    )

    fun <T> listToJson(list: List<T>, f: (T) -> JSONObject): JSONArray {
        val a = JSONArray()
        list.forEach { a.put(f(it)) }
        return a
    }

    fun <T> listFromJson(a: JSONArray?, f: (JSONObject) -> T): List<T> {
        if (a == null) return emptyList()
        return (0 until a.length()).map { f(a.getJSONObject(it)) }
    }
}

internal fun atomicWrite(file: File, text: String) {
    file.parentFile?.mkdirs()
    val tmp = File(file.parentFile, file.name + ".tmp")
    tmp.writeText(text)
    if (!tmp.renameTo(file)) {
        file.writeText(text)
        tmp.delete()
    }
}

/** Elle eklenen maçlar ve girilen tüm oranlar. Uygulama kapanınca da korunur. */
class LocalStore(private val dir: File) {
    private val file = File(dir, "user_data.json")

    @Synchronized
    private fun read(): Pair<MutableList<Match>, MutableList<OddsEntry>> {
        if (!file.exists()) return Pair(mutableListOf(), mutableListOf())
        return try {
            val root = JSONObject(file.readText())
            Pair(
                Codec.listFromJson(root.optJSONArray("matches"), Codec::matchFromJson).toMutableList(),
                Codec.listFromJson(root.optJSONArray("odds"), Codec::oddsFromJson).toMutableList()
            )
        } catch (e: Exception) {
            // Bozuk dosya: silme, yedekle
            file.renameTo(File(dir, "user_data.corrupt.json"))
            Pair(mutableListOf(), mutableListOf())
        }
    }

    @Synchronized
    private fun write(matches: List<Match>, odds: List<OddsEntry>) {
        val root = JSONObject()
            .put("matches", Codec.listToJson(matches, Codec::matchToJson))
            .put("odds", Codec.listToJson(odds, Codec::oddsToJson))
        atomicWrite(file, root.toString())
    }

    @Synchronized fun matches(): List<Match> = read().first
    @Synchronized fun allOdds(): List<OddsEntry> = read().second
    @Synchronized fun oddsForMatch(matchId: String): List<OddsEntry> = read().second.filter { it.matchId == matchId }

    @Synchronized
    fun addMatch(m: Match) {
        val (ms, os) = read()
        ms.removeAll { it.id == m.id }
        ms.add(m)
        write(ms, os)
    }

    @Synchronized
    fun deleteMatch(matchId: String) {
        val (ms, os) = read()
        ms.removeAll { it.id == matchId }
        os.removeAll { it.matchId == matchId }
        write(ms, os)
    }

    /** Aynı maç + pazar + seçenek + şirket için eski oran güncellenir (yenisi yazılır). */
    @Synchronized
    fun upsertOdds(entries: List<OddsEntry>) {
        val (ms, os) = read()
        entries.forEach { n -> os.removeAll { it.id == n.id } }
        os.addAll(entries)
        write(ms, os)
    }

    @Synchronized
    fun deleteOdds(id: String) {
        val (ms, os) = read()
        os.removeAll { it.id == id }
        write(ms, os)
    }
}

data class CachedDay(val fetchedAt: Long, val matches: List<Match>)

/** API-Football'dan gelen günlük maç listesi önbelleği (istek tasarrufu için). */
class FixtureCache(private val dir: File) {
    private fun f(date: String) = File(dir, "fixtures_$date.json")

    fun read(date: String): CachedDay? {
        val file = f(date)
        if (!file.exists()) return null
        return try {
            val root = JSONObject(file.readText())
            CachedDay(root.getLong("fetchedAt"), Codec.listFromJson(root.optJSONArray("matches"), Codec::matchFromJson))
        } catch (e: Exception) {
            file.delete()
            null
        }
    }

    fun write(date: String, fetchedAt: Long, matches: List<Match>) {
        val root = JSONObject().put("fetchedAt", fetchedAt)
            .put("matches", Codec.listToJson(matches, Codec::matchToJson))
        atomicWrite(f(date), root.toString())
    }

    fun clear() {
        dir.listFiles()?.forEach { it.delete() }
    }
}
