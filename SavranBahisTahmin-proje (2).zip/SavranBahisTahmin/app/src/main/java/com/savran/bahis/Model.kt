package com.savran.bahis

import kotlin.math.exp
import kotlin.math.max
import kotlin.math.min

object Poisson {
    fun pmf(lambda: Double, maxK: Int): DoubleArray {
        val r = DoubleArray(maxK + 1)
        r[0] = exp(-lambda)
        for (k in 1..maxK) r[k] = r[k - 1] * lambda / k
        return r
    }
}

/**
 * Bağımsız Poisson skor modeli. Tam maç ve ilk yarı skor matrisleri ile
 * devre/maç ortak dağılımı aynı λ'lardan türetilir (tutarlıdır).
 */
class ScoreModel(val lambdaHome: Double, val lambdaAway: Double, val htShare: Double = 0.45) {
    companion object { const val N = 10 }

    val ft: Array<DoubleArray> = matrix(lambdaHome, lambdaAway)
    val ht: Array<DoubleArray> by lazy { matrix(lambdaHome * htShare, lambdaAway * htShare) }

    /** "1/1", "1/X" ... ilk yarı sonucu / maç sonucu ortak olasılıkları. */
    val htft: Map<String, Double> by lazy {
        val h2 = matrix(lambdaHome * (1 - htShare), lambdaAway * (1 - htShare))
        val out = HashMap<String, Double>()
        for (a in 0..N) for (b in 0..N) {
            val p1 = ht[a][b]
            if (p1 < 1e-9) continue
            for (c in 0..N) for (d in 0..N) {
                val key = Outcomes.res(a - b) + "/" + Outcomes.res(a + c - (b + d))
                out[key] = (out[key] ?: 0.0) + p1 * h2[c][d]
            }
        }
        val total = out.values.sum()
        out.mapValues { it.value / total }
    }

    private fun matrix(lh: Double, la: Double): Array<DoubleArray> {
        val ph = Poisson.pmf(lh, N)
        val pa = Poisson.pmf(la, N)
        val m = Array(N + 1) { h -> DoubleArray(N + 1) { a -> ph[h] * pa[a] } }
        var total = 0.0
        for (row in m) for (v in row) total += v
        for (row in m) for (i in row.indices) row[i] = row[i] / total
        return m
    }

    fun sum(m: Array<DoubleArray>, pred: (Int, Int) -> Boolean): Double {
        var s = 0.0
        for (h in 0..N) for (a in 0..N) if (pred(h, a)) s += m[h][a]
        return s
    }

    /** En olası skorlar (tam maç). */
    fun topScores(n: Int): List<Triple<Int, Int, Double>> {
        val all = ArrayList<Triple<Int, Int, Double>>()
        for (h in 0..N) for (a in 0..N) all.add(Triple(h, a, ft[h][a]))
        return all.sortedByDescending { it.third }.take(n)
    }
}

/** Bir bahis seçeneğinin gerçek skora göre kazanıp kazanmadığı. Desteklenmeyen pazar: null. */
object Outcomes {
    fun res(d: Int): String = if (d > 0) "1" else if (d == 0) "X" else "2"

    private fun dcSet(sk: String): Set<String>? = when (sk) {
        "1X" -> setOf("1", "X")
        "12" -> setOf("1", "2")
        "X2" -> setOf("X", "2")
        else -> null
    }

    private fun overUnder(total: Int, line: Double, sk: String): Boolean? = when (sk) {
        "over" -> total > line
        "under" -> total < line
        else -> null
    }

    fun eval(mk: String, sk: String, fh: Int, fa: Int, hh: Int?, ha: Int?): Boolean? {
        val line = mk.substringAfterLast('_').toDoubleOrNull()
        return when {
            mk == "1x2" -> res(fh - fa) == sk
            mk == "dc" -> dcSet(sk)?.contains(res(fh - fa))
            mk.startsWith("ou_") && line != null -> overUnder(fh + fa, line, sk)
            mk.startsWith("home_ou_") && line != null -> overUnder(fh, line, sk)
            mk.startsWith("away_ou_") && line != null -> overUnder(fa, line, sk)
            mk == "btts" -> (fh > 0 && fa > 0) == (sk == "yes")
            mk == "ht_1x2" -> if (hh == null || ha == null) null else res(hh - ha) == sk
            mk == "ht_dc" -> if (hh == null || ha == null) null else dcSet(sk)?.contains(res(hh - ha))
            mk.startsWith("ht_ou_") && line != null -> if (hh == null || ha == null) null else overUnder(hh + ha, line, sk)
            mk == "ht_btts" -> if (hh == null || ha == null) null else (hh > 0 && ha > 0) == (sk == "yes")
            mk == "htft" -> if (hh == null || ha == null) null else sk == res(hh - ha) + "/" + res(fh - fa)
            mk == "cs" -> if (sk == "other") (fh > 3 || fa > 3) else sk == "$fh-$fa"
            mk == "combo_1x2_ou25" -> {
                val p = sk.split("_")
                if (p.size != 2) null else res(fh - fa) == p[0] && ((fh + fa) > 2.5) == (p[1] == "over")
            }
            mk == "combo_1x2_btts" -> {
                val p = sk.split("_")
                if (p.size != 2) null else res(fh - fa) == p[0] && (fh > 0 && fa > 0) == (p[1] == "yes")
            }
            mk == "hcp_home_minus1" -> res(fh - 1 - fa) == sk
            mk == "hcp_home_plus1" -> res(fh + 1 - fa) == sk
            else -> null   // korner, kart vb.: istatistik/model yok
        }
    }
}

object MarketProb {
    /** null = bu pazar için modelimiz yok (veri yetersiz). Sahte olasılık üretilmez. */
    fun prob(m: ScoreModel, mk: String, sk: String): Double? {
        if (Outcomes.eval(mk, sk, 0, 0, 0, 0) == null) return null
        return when {
            mk == "htft" -> m.htft[sk] ?: 0.0
            mk.startsWith("ht_") -> m.sum(m.ht) { h, a -> Outcomes.eval(mk, sk, 0, 0, h, a) == true }
            else -> m.sum(m.ft) { h, a -> Outcomes.eval(mk, sk, h, a, null, null) == true }
        }
    }
}

/** Puan tablosundan (iç saha/deplasman gol istatistikleri) takım güçleri ve beklenen goller. */
object FormUtil {
    /** "WWDLW" veya "W,D,L,W,W" biçimindeki form dizisinden (puan/maç, maç sayısı). En az 3 sonuç yoksa null. */
    fun ppg(form: String): Pair<Double, Int>? {
        val r = form.filter { it == 'W' || it == 'D' || it == 'L' }.takeLast(5)
        if (r.length < 3) return null
        var pts = 0
        for (c in r) pts += if (c == 'W') 3 else if (c == 'D') 1 else 0
        return pts.toDouble() / r.length to r.length
    }
}

object Strength {
    data class Lambdas(
        val home: Double, val away: Double, val dataQuality: Double,
        val formUsed: Boolean = false, val homeGames: Int = 0, val awayGames: Int = 0
    )

    /** Form ayarı en fazla ±%6 etkiler (kalibrasyon yeterli veriyle doğrulanana kadar düşük tutulur). */
    const val FORM_WEIGHT = 0.06

    /** Takımın son maç formu ile sezon ortalaması arasındaki fark, -1..1 aralığında. Veri yetersizse null. */
    fun formAdjust(h: TeamRow, a: TeamRow): Pair<Double, Double>? {
        val fh = FormUtil.ppg(h.form) ?: return null
        val fa = FormUtil.ppg(a.form) ?: return null
        if (h.all.played <= 0 || a.all.played <= 0) return null
        val sh = h.points.toDouble() / h.all.played
        val sa = a.points.toDouble() / a.all.played
        return ((fh.first - sh) / 3.0).coerceIn(-1.0, 1.0) to ((fa.first - sa) / 3.0).coerceIn(-1.0, 1.0)
    }

    private const val SHRINK_K = 5.0

    private fun shrink(x: Double, n: Int): Double = if (n <= 0) 1.0 else (n * x + SHRINK_K) / (n + SHRINK_K)

    fun lambdas(rows: List<TeamRow>, homeId: Int, awayId: Int): Lambdas? {
        val h = rows.firstOrNull { it.teamId == homeId } ?: return null
        val a = rows.firstOrNull { it.teamId == awayId } ?: return null
        val homeGames = rows.sumOf { it.home.played }
        val awayGames = rows.sumOf { it.away.played }
        if (homeGames <= 0 || awayGames <= 0) return null
        val avgHome = rows.sumOf { it.home.goalsFor }.toDouble() / homeGames
        val avgAway = rows.sumOf { it.away.goalsFor }.toDouble() / awayGames
        if (avgHome <= 0.0 || avgAway <= 0.0) return null

        fun rate(goals: Int, played: Int, avg: Double) = if (played <= 0) 1.0 else (goals.toDouble() / played) / avg
        val attH = shrink(rate(h.home.goalsFor, h.home.played, avgHome), h.home.played)
        val defH = shrink(rate(h.home.goalsAgainst, h.home.played, avgAway), h.home.played)
        val attA = shrink(rate(a.away.goalsFor, a.away.played, avgAway), a.away.played)
        val defA = shrink(rate(a.away.goalsAgainst, a.away.played, avgHome), a.away.played)

        var lhRaw = avgHome * attH * defA
        var laRaw = avgAway * attA * defH
        val adj = formAdjust(h, a)
        if (adj != null) {
            lhRaw *= (1 + 0.5 * FORM_WEIGHT * adj.first) * (1 - 0.5 * FORM_WEIGHT * adj.second)
            laRaw *= (1 + 0.5 * FORM_WEIGHT * adj.second) * (1 - 0.5 * FORM_WEIGHT * adj.first)
        }
        val lh = lhRaw.coerceIn(0.2, 4.0)
        val la = laRaw.coerceIn(0.2, 4.0)
        val dq = min(1.0, min(h.home.played, a.away.played) / 8.0)
        return Lambdas(lh, la, dq, formUsed = adj != null, homeGames = h.home.played, awayGames = a.away.played)
    }
}

/** Canlı maç: kalan süreye göre kalan beklenen goller + mevcut skor. (Zaman düzgün dağılımı varsayımı.) */
object LiveModel {
    data class View(val win: Double, val draw: Double, val lose: Double, val over25: Double, val btts: Double, val remainingFraction: Double)

    fun view(lh: Double, la: Double, elapsed: Int, gh: Int, ga: Int): View {
        val frac = max(0, 90 - elapsed) / 90.0
        val rem = ScoreModel(lh * frac, la * frac)
        fun p(pred: (Int, Int) -> Boolean) = rem.sum(rem.ft) { r1, r2 -> pred(gh + r1, ga + r2) }
        return View(
            win = p { h, a -> h > a },
            draw = p { h, a -> h == a },
            lose = p { h, a -> h < a },
            over25 = p { h, a -> h + a > 2.5 },
            btts = p { h, a -> h > 0 && a > 0 },
            remainingFraction = frac
        )
    }
}
