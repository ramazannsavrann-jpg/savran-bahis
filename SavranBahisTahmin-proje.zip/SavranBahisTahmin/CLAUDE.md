# Savran Analiz – Çalışma Kuralları

Kişisel, reklamsız Android futbol analiz uygulaması (Kotlin + Compose, `com.savran.bahis`). Kullanıcı: Türkçe konuşur, yalnızca Android telefonu var, yeni başlayan; derleme GitHub Actions ile. Yanıtlar Türkçe, sade, adım adım. Detaylı proje haritası ve değiştirilemez kurallar: `.claude/skills/savran-project/SKILL.md`.

## Çok ajanlı çalışma düzeni
Ana ajan yönetir; uzmanlar `.claude/agents/` altındadır:
football-analyst, statistics-expert, data-researcher, prediction-expert, coupon-analyst, backtesting-expert, code-reviewer.

1. Ana ajan işi böler, bağımsız analizleri **paralel** çalıştırır.
2. Uzmanlar alt ajan çağıramaz. Çapraz kontrolü ana ajan yürütür: bir uzmanın sonucunu, "Başka ajanın kontrol etmesi gerekenler" başlığına göre başka bir uzmana kontrol ettirir (örn. tahminleri statistics-expert doğrular; kupon seçimlerini prediction-expert ve coupon-analyst kontrol eder; her kod değişikliğini code-reviewer denetler).
3. Çelişki çıkarsa ana ajan iki gerekçeyi de gösterir, kaynak ve tarihe göre değerlendirir; çözülemezse çelişkiyi raporda açıkça yazar, birini seçip gizlemez.
4. Eksik veya doğrulanmamış veriden kesin tahmin üretilmez. Olasılık, güven ve veri kalitesi ayrı yazılır.
5. Nihai karar ve rapor yalnızca ana ajandan çıkar.
6. Her ajan yapılandırmasında `skills:` ile gereken beceriler ayrıca listelenir (ajanlar ana oturum becerilerini devralmaz). Yeni ajan/skill eklenince bu dosya ve ajan dosyası birlikte güncellenir.
7. Machina Sports Football Data becerisi: football-analyst, statistics-expert, data-researcher. Ağ yoksa kurulamaz; çalıştırılmadan "çalıştı" denmez.

## Kod ve teslim kuralları
- Çalışan sistemi bozma; projeyi baştan yazma; önce mevcut kodu incele.
- API anahtarlarını koda veya repoya yazma (Ayarlar'da şifreli saklanır).
- Ücretli servis kullanmadan önce kullanıcıdan onay al.
- Yasak: değer kuponu, sanal kupon takibi, Nesine entegrasyonu, uydurma veri/istatistik.
- "Derlendi", "test edildi", "APK hazır" yalnızca gerçekten derleme/çalıştırma yapıldıysa söylenir. Sandbox'ta Gradle yoktur; derleme sonucu GitHub Actions'tan gelir. Çalıştırılamayan testler raporda ayrı yazılır.
- Her teslimde tam proje ZIP'i verilir (yalnızca değişen dosyalar değil). Kullanıcı ZIP'i GitHub'a yükler.
- GitHub Actions workflow dosyaları **her zaman** `push` tetikleyicisi + `workflow_dispatch` içerir (kullanıcı telefondan "Run workflow" menüsünü bulamıyor).

## APK güncelleme standardı
- Aynı `applicationId` (`com.savran.bahis`).
- Her sürümde aynı release keystore ve imza; keystore ve şifreler yalnızca GitHub Secrets'ta, repoya asla girmez.
- Her sürümde `versionCode` artırılır (şu an 10, `versionName` 0.5.5).
- Kullanıcı verisi ve ayarlar korunur (veri şeması değişirse migrasyon).
- Her APK için üzerine kurulum uyumluluğu test edilir; test edilmediyse "test edilmedi" yazılır.
- Mevcut durum (0.5.0): `app/build.gradle.kts` sabit imzayı ortam değişkenlerinden okur (`SAVRAN_KEYSTORE`, `SAVRAN_KEYSTORE_PASSWORD`, alias `savran`). Workflow bunları GitHub Secrets `SAVRAN_KEYSTORE_B64` + `SAVRAN_KEYSTORE_PASSWORD`'tan üretir; secret yoksa geçici debug imzasına düşer. Keystore yedeği yalnızca kullanıcıda. Workflow son yüklenen ZIP'i seçer ve birim testlerini (APK'yı engellemeden) çalıştırır.
