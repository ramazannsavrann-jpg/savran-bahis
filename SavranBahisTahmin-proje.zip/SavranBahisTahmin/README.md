# Savran Bahis Tahmin

Kişisel futbol analiz ve değer bulma uygulaması (Android, Kotlin + Jetpack Compose).
Reklam yok, hesap yok, bahis otomasyonu yok. Kesin kazanç iddiası yoktur.

## APK'yı telefondan derletme
1. GitHub'da yeni bir depo aç (public olabilir; içinde API anahtarı YOK).
2. Bu ZIP'in içindeki tüm dosyaları depoya yükle. `.github/workflows/build-apk.yml` dosyasının yüklendiğinden emin ol.
3. Yükleme (push) olunca derleme otomatik başlar. Actions sekmesinden "APK Derle" çalışmasını aç.
4. Yeşil tik gelince çalışmanın altındaki **Artifacts** bölümünden `SavranBahisTahmin-debug-apk` dosyasını indir, ZIP'ten çıkar, APK'yı kur.
5. Kırmızı çarpı gelirse hata günlüğünü (log) bana gönder; düzeltirim.

## İlk kullanım
Ayarlar → API-Football anahtarını gir (anahtar yalnızca telefonda şifreli saklanır).
Maç listesi boşsa "+ Maç" ile elle maç ekle; maç detayında "+ Oran ekle" ile gerçek oranı kaynağıyla gir.

## Veri ve sınırlar
- Maç/puan durumu/sakatlık/kadro: API-Football (ücretsiz plan, günde 100 istek; uygulama son 5 isteği yedekte tutar, önbellek kullanır).
- Oranlar: elle giriş (kaynak adı + zaman damgası ile) veya isteğe bağlı The Odds API. Hiçbir oran uydurulmaz.
- Ücretsiz plan güncel sezon/tarih kısıtı uygulayabilir; kısıt olursa API'nin mesajı ekranda aynen gösterilir.
- Model: puan durumu gol istatistiklerinden Poisson modeli. xG, sakatlık ve taktik verisi modele girmez; korner/kart pazarları için model yoktur (oranı kaydedilir, değerlendirilmez).
