# Savran Analiz

Kişisel futbol analiz ve değer bulma uygulaması (Android, Kotlin + Jetpack Compose).
Reklam yok, hesap yok, bahis otomasyonu yok. Kesin kazanç iddiası yoktur.

## Veri kaynakları (Ayarlar > API ve Veri Kaynakları)
| Kaynak | Anahtar | Bizim liglerden kapsadıkları | Kullanım |
|---|---|---|---|
| API-Football | gerekli | 6 lig (plana bağlı sezon kısıtı olabilir) | ana maç listesi, puan durumu, canlı, sakatlık, rotasyon |
| Football-Data.org | gerekli | PL, Bundesliga, La Liga, Ligue 1 | maç listesi, iç saha/deplasman puan durumu (yedek), doğrulama |
| API Ninjas Football | gerekli | PL, Bundesliga, La Liga, Ligue 1 | maç listesi (bugün/yarın), doğrulama |
| The Odds API | gerekli | Süper Lig, PL, Bundesliga, La Liga, Ligue 1 | 1X2 ve toplam gol oranları |
| TheSportsDB | ortak anahtar 123 | Süper Lig, PL, Bundesliga, La Liga, Ligue 1 | maç listesi, doğrulama |
| OpenLigaDB | yok | yalnızca Bundesliga | maç listesi, doğrulama |
| StatsBomb Open Data | yok | yalnızca seçili geçmiş sezonlar | yalnızca erişim/kapsam testi |

Her kaynak ayrı açılıp kapatılır, ayrı test edilir; biri hata verirse diğerleri etkilenmez.
Kaynağın sunmadığı veri uygulamada varmış gibi gösterilmez.

## APK'yı telefondan derletme
1. Depodaki eski `SavranBahisTahmin-proje.zip` yerine aynı adla yeni ZIP'i yükle (üzerine yazılır).
2. Yükleme (push) olunca "Zipten APK Derle" otomatik başlar. Actions sekmesinden izle.
3. Yeşil tik gelince **Artifacts** bölümünden APK'yı indir, ZIP'ten çıkar, kur.
4. Kırmızı çarpı gelirse HATA ÖZETİ bölümünün ekran görüntüsünü gönder.

## Analiz, güven ve kriterler
- Oran girilmesi gerekmez: başlamamış her maç için modelin desteklediği pazarlarda tahmin üretilir (veri yeterliyse). Ev sahibinin iç saha maçı veya deplasman takımının deplasman maçı 2'den azsa tahmin üretilmez ve nedeni yazılır.
- Model (poisson-v2): iç saha/deplasman gol istatistikleri, lig ortalaması, hücum/savunma gücü ve (veri varsa) son 5 maç formu (en fazla ±%6 ağırlık).
- Maç analizinde "Bu analizde kullanılan kriterler" bölümü yalnızca gerçekten kullanılanları "Kullanıldı" gösterir; xG, şut, korner, son 10 maç, sakatlık gibi çekilmeyen veriler "Veri alınamadı / Kullanılmadı" yazar ve hesaba katılmaz.
- Güven seviyesi (Yüksek/Orta/Düşük) olasılıktan ayrıdır: veri kalitesi, veri kapsamı, pazar güvenilirliği, rotasyon riski ve model geçmişinden gelir.

## Bahis Fırsatları
Güçlü tahminler + pazar filtresi (Maç sonucu, Çifte şans, Toplam gol, KG, Ev/Deplasman gol, İlk yarı, Devre/Maç, Handikap, Kombinasyon, Doğru skor). Yalnızca modelin tahmin ürettiği, oynanabilir pazarlar listelenir. Toplam Gol 0.5 Üst ve 4.5 Alt listelenmez.

## Kupon Laboratuvarı (3 tür)
- Dengeli: makul risk; tek tek olasılık %50-75 bandı, çok düşük oranlı favorilerden kaçınır.
- Sürpriz: modelce desteklenen (%35-55) seçimler; hedef tahmini gerçekleşme ≈%19 (adil oran ≈5.25).
- Yüksek Riskli: daha cesur (%22-45) ama istatistiksel desteği olan seçimler; hedef ≈%6.
- Oran gerekmez. Gerçek oran girilmemiş seçim varsa toplam oran ve potansiyel kazanç gösterilmez. Değer kuponu yoktur.

## Bilinen sınırlar
- xG, şut, korner, sakatlık ve taktik verisi modele girmez (kaynaklardan çekilmiyor).
- Korner/kart pazarları için model yoktur (oranı kaydedilir, değerlendirilmez).
- Derlenmemiş kod: ilk derlemede küçük hatalar çıkabilir.
