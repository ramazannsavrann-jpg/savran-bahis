# Savran Analiz

Kişisel futbol analiz ve değer bulma uygulaması (Android, Kotlin + Jetpack Compose).
Reklam yok, hesap yok, bahis otomasyonu yok. Kesin kazanç iddiası yoktur.

## Veri kaynakları (Ayarlar > API ve Veri Kaynakları)
| Kaynak | Anahtar | Bizim liglerden kapsadıkları | Kullanım |
|---|---|---|---|
| API-Football | gerekli | 6 lig (plana bağlı sezon kısıtı olabilir) | ana maç listesi, puan durumu, canlı, sakatlık, rotasyon |
| Football-Data.org | gerekli | PL, Bundesliga, La Liga, Ligue 1 | maç listesi, iç saha/deplasman puan durumu (yedek), doğrulama |
| API Ninjas Football | gerekli | PL, Bundesliga, La Liga, Ligue 1 | maç listesi (bugün/yarın), doğrulama |
| The Odds API | gerekli | Süper Lig, PL, Bundesliga, La Liga, Ligue 1 | 1X2 ve toplam gol oranları |
| TheSportsDB | ortak anahtar 123 | Süper Lig, PL, Bundesliga, La Liga, Ligue 1 | maç listesi, doğrulama |
| OpenLigaDB | yok | yalnızca Bundesliga | maç listesi, doğrulama |
| StatsBomb Open Data | yok | yalnızca seçili geçmiş sezonlar | yalnızca erişim/kapsam testi |

Her kaynak ayrı açılıp kapatılır, ayrı test edilir; biri hata verirse diğerleri etkilenmez.
Kaynağın sunmadığı veri uygulamada varmış gibi gösterilmez.

## APK'yı telefondan derletme
1. Depodaki eski `SavranBahisTahmin-proje.zip` yerine aynı adla yeni ZIP'i yükle (üzerine yazılır).
2. Yükleme (push) olunca "Zipten APK Derle" otomatik başlar. Actions sekmesinden izle.
3. Yeşil tik gelince **Artifacts** bölümünden APK'yı indir, ZIP'ten çıkar, kur.
4. Kırmızı çarpı gelirse HATA ÖZETİ bölümünün ekran görüntüsünü gönder.

## Oransız analiz ve güven seviyeleri
- Oran girilmesi gerekmez: başlamamış her maç için modelin desteklediği tüm pazarlarda tahmin üretilir (veri yeterliyse).
- Güven seviyesi (Yüksek/Orta/Düşük) olasılıktan ayrıdır; veri kalitesi, pazar güvenilirliği, rotasyon riski ve model geçmişinden gelir.
- Veri çok azsa (≈2 maçtan az) tahmin üretilmez ve nedeni yazılır.
- EV/değer analizi yalnızca gerçek oran girilmiş seçimlerde yapılır.
- Kupon Laboratuvarı oransız seçimleri de kullanır; oransız seçim varsa toplam oran, potansiyel kazanç ve beklenen kazanç gösterilmez.

## Bilinen sınırlar
- Model puan durumundaki gol istatistiklerine dayanır; xG, taktik ve sakatlık verisi modele girmez.
- Korner/kart pazarları için model yoktur (oranı kaydedilir, değerlendirilmez).
- Derlenmemiş kod: ilk derlemede küçük hatalar çıkabilir.
