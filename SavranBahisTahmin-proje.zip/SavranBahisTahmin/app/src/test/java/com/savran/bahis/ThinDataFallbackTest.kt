package com.savran.bahis

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test

class ThinDataFallbackTest {
    private fun row(id: Int, allP: Int, homeP: Int, awayP: Int) =
        TeamRow(id, "T$id", id, allP, SplitStats(allP, allP * 2, allP), SplitStats(homeP, homeP * 2, homeP), SplitStats(awayP, awayP, awayP), "")

    @Test
    fun thinSplitFallsBackToOverallWhenTwoGamesExist() {
        val rows = listOf(row(1, 2, 1, 1), row(2, 2, 1, 1), row(3, 2, 1, 1), row(4, 2, 1, 1))
        val l = Strength.lambdas(rows, 1, 2)
        assertNotNull(l)
        assertTrue(l!!.overallFallback)
        assertEquals(0.25, l.dataQuality, 1e-9)
        assertTrue(l.dataQuality >= ForecastEngine.MIN_DATA_QUALITY)
    }

    @Test
    fun enoughSplitDoesNotUseFallback() {
        val rows = listOf(row(1, 8, 4, 4), row(2, 8, 4, 4))
        val l = Strength.lambdas(rows, 1, 2)!!
        assertTrue(!l.overallFallback)
        assertEquals(0.5, l.dataQuality, 1e-9)
    }

    @Test
    fun oneTotalGameStillProducesNoForecast() {
        val rows = listOf(row(1, 1, 1, 0), row(2, 1, 0, 1))
        val l = Strength.lambdas(rows, 1, 2)
        assertTrue(l == null || l.dataQuality < ForecastEngine.MIN_DATA_QUALITY)
    }

    @Test
    fun lowConfidenceShownOnlyWhenNothingStrongerExists() {
        val low = Forecast("m", "1x2", "1", 0.6, Confidence.LOW, 40, null, null, null, null, "")
        assertTrue(ForecastEngine.bahisFirsatlari(listOf(low)).isEmpty())
        assertEquals(1, ForecastEngine.shownWithFallback(listOf(low)).size)
        val mid = low.copy(marketKey = "dc", selectionKey = "1X", confidence = Confidence.MEDIUM)
        assertEquals(listOf(mid), ForecastEngine.shownWithFallback(listOf(low, mid)))
    }

    private fun totalsRow(id: Int, played: Int, gf: Int, ga: Int) =
        TeamRow(id, "T$id", -id, 0, SplitStats(played, gf, ga), SplitStats(0, 0, 0), SplitStats(0, 0, 0), "")

    @Test
    fun totalsOnlyTableStillGivesForecastInputs() {
        val rows = listOf(totalsRow(-1, 3, 6, 2), totalsRow(-2, 3, 2, 5), totalsRow(-3, 3, 4, 4), totalsRow(-4, 3, 3, 3))
        val l = Strength.lambdas(rows, -1, -2)
        assertNotNull(l)
        assertTrue(l!!.overallFallback)
        assertTrue(l.home > l.away)
        assertTrue(l.dataQuality >= ForecastEngine.MIN_DATA_QUALITY)
    }

    @Test
    fun totalsOnlyWithOneGameGivesNothing() {
        val rows = listOf(totalsRow(-1, 1, 2, 0), totalsRow(-2, 1, 0, 2))
        assertTrue(Strength.lambdas(rows, -1, -2) == null)
    }

    @Test
    fun fewGamesNeverReachMediumConfidence() {
        val thin = AnalysisContext(ScoreModel(1.6, 1.1), 0.375, false, null, 1.0, 3, 3)
        val f = ForecastEngine.generate("m", thin, emptyList())
        assertTrue(f.isNotEmpty())
        assertTrue(f.all { it.confidence == Confidence.LOW })
        val enough = AnalysisContext(ScoreModel(1.6, 1.1), 1.0, false, null, 1.0, 8, 8)
        assertTrue(ForecastEngine.generate("m", enough, emptyList()).any { it.confidence.rank >= Confidence.MEDIUM.rank })
    }

    @Test
    fun thinDataPenaltyLowersScore() {
        val a = AnalysisContext(ScoreModel(1.6, 1.1), 1.0, false, null, 1.0, 8, 8)
        val b = a.copy(thinData = true)
        val sa = ForecastEngine.generate("m", a, emptyList()).first().confidenceScore
        val sb = ForecastEngine.generate("m", b, emptyList()).first().confidenceScore
        assertEquals(ForecastEngine.THIN_DATA_PENALTY, sa - sb)
    }

    @Test
    fun cupShrinkConstantIsMoreConservative() {
        assertTrue(Strength.SHRINK_K_CUP > 5.0)
        val rows = listOf(row(1, 6, 3, 3), row(2, 6, 3, 3), row(3, 6, 3, 3), row(4, 6, 3, 3))
        val a = Strength.lambdas(rows, 1, 2, 5.0)!!
        val b = Strength.lambdas(rows, 1, 2, Strength.SHRINK_K_CUP)!!
        assertEquals(a.dataQuality, b.dataQuality, 1e-12)
    }

    @Test
    fun obviousPicksAreHiddenFromListsAndCoupons() {
        val obvious = Forecast("m", "ou_1.5", "over", 0.92, Confidence.HIGH, 90, null, null, null, null, "")
        val normal = Forecast("m", "btts", "yes", 0.70, Confidence.HIGH, 90, null, null, null, null, "")
        val shown = ForecastEngine.bahisFirsatlari(listOf(obvious, normal))
        assertEquals(listOf(normal), shown)
        assertTrue(ForecastEngine.shownWithFallback(listOf(obvious)).isEmpty())
        val m = Match("x", 39, "PL", "A", "B", 1000L, "NS", null, null, null, null, "X")
        assertTrue(!CouponLab.eligible(CouponPick(m, obvious, null)))
        assertTrue(CouponLab.eligible(CouponPick(m, normal, null)))
    }
}
