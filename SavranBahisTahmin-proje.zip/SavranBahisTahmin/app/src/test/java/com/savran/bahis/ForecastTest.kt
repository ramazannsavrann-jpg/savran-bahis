package com.savran.bahis

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

private fun ctx(dq: Double, model: ScoreModel? = ScoreModel(1.6, 1.1), rot: Boolean = false, hist: Double? = null) =
    AnalysisContext(model, dq, rot, hist)

class ForecastEngineTest {
    @Test fun oddlessMatchGetsForecastsForManyMarkets() {
        val f = ForecastEngine.generate("m1", ctx(0.9), emptyList())
        assertTrue(f.isNotEmpty())
        assertTrue(f.all { it.odds == null && it.ev == null && it.decision == null })
        assertTrue(f.all { it.prob in 0.0..1.0 })
        listOf("1x2", "dc", "ou_1.5", "ou_2.5", "ou_3.5", "btts", "home_ou_0.5", "away_ou_1.5", "ht_1x2", "htft", "cs")
            .forEach { mk -> assertTrue(mk, f.any { it.marketKey == mk }) }
    }

    @Test fun noInventedForecastsForMarketsWithoutModel() {
        val f = ForecastEngine.generate("m1", ctx(0.9), emptyList())
        assertFalse(f.any { it.marketKey.startsWith("corners") || it.marketKey.contains("corners") || it.marketKey.startsWith("cards") || it.marketKey.startsWith("yellow") })
    }

    @Test fun overAndUnderAreComplementary() {
        val f = ForecastEngine.generate("m1", ctx(0.9), emptyList())
        val over = f.first { it.marketKey == "ou_2.5" && it.selectionKey == "over" }.prob
        val under = f.first { it.marketKey == "ou_2.5" && it.selectionKey == "under" }.prob
        assertEquals(1.0, over + under, 1e-3)
    }

    @Test fun tooLittleDataOrNoModelMeansNoForecastAndAReason() {
        assertTrue(ForecastEngine.generate("m1", ctx(0.2), emptyList()).isEmpty())
        assertTrue(ForecastEngine.generate("m1", ctx(0.9, model = null), emptyList()).isEmpty())
        assertNotNull(ForecastEngine.noForecastReason(ctx(0.2), "not"))
        assertNotNull(ForecastEngine.noForecastReason(ctx(0.9, model = null), "puan durumu alınamadı"))
        assertNull(ForecastEngine.noForecastReason(ctx(0.9), ""))
    }

    @Test fun confidenceDropsWithPartialData() {
        fun lvl(dq: Double, rel: Double = 1.0, rot: Boolean = false) =
            ForecastEngine.level(ForecastEngine.confidenceScore(dq, rel, null, rot))
        assertEquals(Confidence.HIGH, lvl(1.0))
        assertEquals(Confidence.MEDIUM, lvl(0.5))
        assertEquals(Confidence.LOW, lvl(0.25))
        assertEquals(Confidence.MEDIUM, lvl(1.0, rel = 0.4))      // doğru skor gibi riskli pazar
        assertTrue(ForecastEngine.confidenceScore(1.0, 1.0, null, true) < ForecastEngine.confidenceScore(1.0, 1.0, null, false))
        assertNull(ForecastEngine.level(34))
    }

    @Test fun confidenceIsIndependentOfProbability() {
        val f = ForecastEngine.generate("m1", ctx(0.9), emptyList())
        val a = f.first { it.marketKey == "ou_2.5" && it.selectionKey == "over" }
        val b = f.first { it.marketKey == "ou_0.5" && it.selectionKey == "over" }
        assertTrue(a.prob < b.prob)
        assertEquals(a.confidenceScore, b.confidenceScore)   // aynı pazar güvenilirliği, aynı veri kalitesi
    }

    @Test fun realOddsAreAttachedOnlyWhenEntered() {
        val e = Evaluation(
            "m1", "ou_2.5", "over", 1.90, "Kaynak", "Manuel", 0L, 0.6, 0.6, 1 / 1.9, null, 0.14, 70, null,
            Decision.RECOMMEND, "r", false
        )
        val f = ForecastEngine.generate("m1", ctx(0.9), listOf(e))
        val withOdds = f.first { it.marketKey == "ou_2.5" && it.selectionKey == "over" }
        assertEquals(1.90, withOdds.odds!!, 1e-9)
        assertEquals(0.14, withOdds.ev!!, 1e-9)
        assertNull(f.first { it.marketKey == "ou_1.5" && it.selectionKey == "over" }.odds)
    }

    @Test fun strongestPicksOnePerFamilyAndSkipsTrivialProbabilities() {
        val f = ForecastEngine.generate("m1", ctx(0.9), emptyList())
        val s = ForecastEngine.strongest(f, 8)
        assertTrue(s.size <= 8)
        assertTrue(s.all { it.prob < ForecastEngine.TRIVIAL_PROB })
        val fams = s.map { ForecastEngine.family(it.marketKey, it.selectionKey) }
        assertEquals(fams.size, fams.distinct().size)
        assertEquals(s, s.sortedByDescending { ForecastEngine.weighted(it) })
    }

    @Test fun laddersShowLinesSideBySide() {
        val f = ForecastEngine.generate("m1", ctx(0.9), emptyList())
        val l = ForecastEngine.ladders(f).first { it.title == "Toplam gol Üst" }
        assertEquals(5, l.items.size)
        // Çizgi yükseldikçe Üst olasılığı düşer
        assertEquals(l.items.map { it.second }, l.items.map { it.second }.sortedDescending())
    }
}

private fun mt(id: String) = Match(id, 39, "Premier League", "H$id", "A$id", 1000, "NS", null, null, null, null, "API-Football")

private fun fc(matchId: String, p: Double, conf: Confidence, mk: String = "ou_1.5", sk: String = "over") =
    Forecast(matchId, mk, sk, p, conf, when (conf) { Confidence.HIGH -> 90; Confidence.MEDIUM -> 65; Confidence.LOW -> 40 }, null, null, null, null, "t")

private fun ev(matchId: String, mk: String, sk: String, odds: Double, adj: Double, ev: Double, q: Int, d: Decision = Decision.RECOMMEND) =
    Evaluation(matchId, mk, sk, odds, "Kaynak", "Manuel", 0L, adj, adj, 1 / odds, null, ev, q, null, d, "r", false)

class CouponLabTest {
    @Test fun oddlessPicksBuildACouponWithoutTotalOdds() {
        val c = CouponLab.build(
            CouponType.BALANCED,
            listOf("a", "b", "c").map { CouponPick(mt(it), fc(it, 0.70, Confidence.HIGH), null) }
        ).coupon!!
        assertEquals(3, c.picks.size)
        assertNull(c.totalOdds)                    // gerçek oran yok -> toplam oran hesaplanmaz
        assertEquals(3, c.unpricedCount)
        assertEquals(Confidence.HIGH, c.level)
        assertEquals(0.343, c.probability, 1e-9)
        assertEquals(0, c.relaxedTier)
    }

    @Test fun criteriaRelaxInControlledTiersAndAreFlagged() {
        val picks = listOf(
            CouponPick(mt("a"), fc("a", 0.70, Confidence.HIGH), null),
            CouponPick(mt("b"), fc("b", 0.66, Confidence.MEDIUM), null),
            CouponPick(mt("c"), fc("c", 0.64, Confidence.MEDIUM), null)
        )
        val out = CouponLab.build(CouponType.BALANCED, picks)
        val c = out.coupon!!
        assertEquals(3, c.picks.size)
        assertEquals(Confidence.MEDIUM, c.level)
        assertEquals(1, c.relaxedTier)
        assertTrue(out.notes.any { it.contains("esnetildi") })
    }

    @Test fun lowConfidenceOnlyStillMakesAFlaggedCoupon() {
        val picks = listOf("a", "b").map { CouponPick(mt(it), fc(it, 0.60, Confidence.LOW), null) }
        val c = CouponLab.build(CouponType.BALANCED, picks).coupon!!
        assertEquals(2, c.lowConfidenceCount)
        assertEquals(Confidence.LOW, c.level)
        assertEquals(2, c.relaxedTier)
    }

    @Test fun notEnoughMatchesGivesNoCouponAndExplains() {
        val out = CouponLab.build(CouponType.BALANCED, listOf(CouponPick(mt("a"), fc("a", 0.70, Confidence.HIGH), null)))
        assertNull(out.coupon)
        assertTrue(out.notes.any { it.contains("en az") })
        val empty = CouponLab.build(CouponType.BALANCED, emptyList())
        assertNull(empty.coupon)
        assertTrue(empty.notes.isNotEmpty())
    }

    @Test fun lowProbabilityPicksAreNotAddedJustToFillACoupon() {
        val picks = listOf("a", "b", "c").map { CouponPick(mt(it), fc(it, 0.50, Confidence.HIGH), null) }
        assertNull(CouponLab.build(CouponType.BALANCED, picks).coupon)
    }

    @Test fun onlyOnePickPerMatch() {
        val picks = listOf(
            CouponPick(mt("a"), fc("a", 0.80, Confidence.HIGH, "ou_1.5"), null),
            CouponPick(mt("a"), fc("a", 0.70, Confidence.HIGH, "btts", "yes"), null),
            CouponPick(mt("b"), fc("b", 0.65, Confidence.HIGH), null)
        )
        val c = CouponLab.build(CouponType.BALANCED, picks).coupon!!
        assertEquals(2, c.picks.size)
        assertEquals(2, c.picks.map { it.match.id }.distinct().size)
    }

    @Test fun valueCouponNeedsRealOdds() {
        val picks = listOf("a", "b", "c").map { CouponPick(mt(it), fc(it, 0.70, Confidence.HIGH), null) }
        val out = CouponLab.build(CouponType.VALUE, picks)
        assertNull(out.coupon)
        assertTrue(out.notes.any { it.contains("oranı girilmiş") })
    }

    @Test fun totalOddsOnlyWhenEveryPickHasARealOdd() {
        val priced = listOf(Triple("a", 1.5, 0.08), Triple("b", 1.6, 0.08), Triple("c", 1.7, 0.08)).map { (id, o, e) ->
            CouponPick(mt(id), fc(id, 0.70, Confidence.HIGH), ev(id, "ou_1.5", "over", o, 0.70, e, 70))
        }
        val c = CouponLab.build(CouponType.VALUE, priced).coupon!!
        assertEquals(1.5 * 1.6 * 1.7, c.totalOdds!!, 1e-9)
        assertEquals(0, c.unpricedCount)

        val mixed = listOf(
            CouponPick(mt("a"), fc("a", 0.70, Confidence.HIGH), ev("a", "ou_1.5", "over", 1.5, 0.70, 0.08, 70)),
            CouponPick(mt("b"), fc("b", 0.66, Confidence.HIGH), null)
        )
        val m = CouponLab.build(CouponType.BALANCED, mixed).coupon!!
        assertNull(m.totalOdds)
        assertEquals(1, m.unpricedCount)
    }

    @Test fun surpriseCouponUsesModeratelyLikelySupportedPicks() {
        val picks = listOf("a", "b").map { CouponPick(mt(it), fc(it, 0.35, Confidence.MEDIUM, "1x2", "2"), null) }
        val c = CouponLab.build(CouponType.SURPRISE, picks).coupon!!
        assertEquals(2, c.picks.size)
        assertNull(c.totalOdds)
        assertEquals("Yüksek", c.risk)
    }
}

class RecentStatsTest {
    private fun rec(i: Int) = PredictionRecord(
        "id$i", "m$i", "A - B", 39, "PL", 1000L + i, "ou_2.5", "over", 0L, 0.5, 0.5, null, null, null,
        "t", "poisson-v1", false, i % 2 == 0, i.toLong(), "1-0"
    )

    @Test fun lastTenFiftyHundred() {
        val r = Metrics.recentStats((0 until 12).map { rec(it) })
        assertEquals(listOf(10, 50, 100), r.map { it.window })
        assertEquals(10, r[0].n)
        assertEquals(12, r[1].n)
        assertEquals(12, r[2].n)
        assertEquals(0.5, r[0].hitRate!!, 1e-9)
        assertEquals(0.25, r[0].brier!!, 1e-9)
        val empty = Metrics.recentStats(emptyList())
        assertNull(empty[0].hitRate)
        assertEquals(0, empty[0].n)
    }

    @Test fun reportIncludesRecentWindows() {
        val rep = Metrics.report((0 until 12).map { rec(it) })
        assertEquals(3, rep.recent.size)
        assertEquals(12, rep.settled)
    }
}
