package com.savran.bahis

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class OddsMathTest {
    @Test fun impliedProbability() = assertEquals(0.5556, OddsMath.impliedProbability(1.80), 1e-4)

    @Test fun expectedValueMatchesSpecExample() =
        assertEquals(0.17, OddsMath.expectedValue(0.65, 1.80), 1e-9)

    @Test fun overroundAndFairProbabilities() {
        val odds = listOf(1.9, 3.4, 4.2)
        assertEquals(0.0585, OddsMath.overround(odds), 1e-3)
        assertEquals(1.0, OddsMath.fairProbabilities(odds).sum(), 1e-9)
    }

    @Test fun parseOdds() {
        assertEquals(1.85, OddsMath.parseOdds("1,85")!!, 1e-9)
        assertEquals(2.0, OddsMath.parseOdds(" 2.0 ")!!, 1e-9)
        assertNull(OddsMath.parseOdds("abc"))
        assertNull(OddsMath.parseOdds("1.00"))
        assertNull(OddsMath.parseOdds("0.5"))
        assertNull(OddsMath.parseOdds("5000"))
        assertNull(OddsMath.parseOdds(""))
    }
}

class FreshnessAndCacheTest {
    private val hour = 3_600_000L

    @Test fun oddsAreStaleAfterKickoffOrSixHours() {
        val kickoffSec = 1_000_000L
        val updated = kickoffSec * 1000 - 2 * hour
        assertFalse(OddsFreshness.isStale(updated, kickoffSec * 1000 - hour, kickoffSec))
        assertTrue(OddsFreshness.isStale(updated, updated + 7 * hour, kickoffSec + 100_000))
        assertTrue(OddsFreshness.isStale(updated, kickoffSec * 1000 + 1, kickoffSec))
    }

    @Test fun ageLabels() {
        assertEquals("az önce", OddsFreshness.ageLabel(1000, 1000))
        assertEquals("5 dk önce", OddsFreshness.ageLabel(0, 5 * 60_000))
        assertEquals("3 sa önce", OddsFreshness.ageLabel(0, 3 * hour))
        assertEquals("2 gün önce", OddsFreshness.ageLabel(0, 48 * hour))
    }

    @Test fun cachePolicy() {
        assertTrue(CachePolicy.isFresh(0, 2 * hour, 0))
        assertFalse(CachePolicy.isFresh(0, 4 * hour, 0))
        assertTrue(CachePolicy.isFresh(0, 5 * hour, 1))
        assertTrue(CachePolicy.isFresh(0, 23 * hour, -1))
        assertFalse(CachePolicy.isFresh(0, 25 * hour, -1))
    }

    @Test fun quotaGuard() {
        assertTrue(Quota.canSpend(94, null))
        assertFalse(Quota.canSpend(95, null))
        assertTrue(Quota.canSpend(0, 6))
        assertFalse(Quota.canSpend(0, 5))
        assertEquals("1970-01-01", Quota.utcDay(0))
    }

    @Test fun parseTime() {
        assertNotNull(TimeUtil.parseTime("20:45"))
        assertNotNull(TimeUtil.parseTime("9:05"))
        assertNull(TimeUtil.parseTime("25:00"))
        assertNull(TimeUtil.parseTime("20:61"))
        assertNull(TimeUtil.parseTime("abc"))
    }
}

class MarketCatalogTest {
    @Test fun marketKeysAreUnique() =
        assertEquals(MarketCatalog.all.size, MarketCatalog.all.map { it.key }.distinct().size)

    @Test fun selectionKeysUniquePerMarket() {
        MarketCatalog.all.forEach { m ->
            assertEquals(m.key, m.selections.size, m.selections.map { it.key }.distinct().size)
        }
    }

    @Test fun everyGroupHasAMarket() {
        MarketCatalog.groups.forEach { g -> assertTrue(g, MarketCatalog.all.any { it.group == g }) }
    }

    @Test fun htftHasNineCombinations() = assertEquals(9, MarketCatalog.find("htft")!!.selections.size)

    @Test fun labelLookup() {
        assertEquals("KG Var", MarketCatalog.selectionLabel("btts", "yes"))
        assertEquals("Toplam Gol 2.5 Alt/Üst", MarketCatalog.marketTitle("ou_2.5"))
    }
}

class OutcomesTest {
    @Test fun matchResultAndGoals() {
        assertEquals(true, Outcomes.eval("1x2", "1", 2, 1, null, null))
        assertEquals(false, Outcomes.eval("1x2", "X", 2, 1, null, null))
        assertEquals(true, Outcomes.eval("ou_2.5", "over", 2, 1, null, null))
        assertEquals(true, Outcomes.eval("ou_3.5", "under", 2, 1, null, null))
        assertEquals(true, Outcomes.eval("btts", "yes", 2, 1, null, null))
        assertEquals(true, Outcomes.eval("combo_1x2_ou25", "1_over", 2, 1, null, null))
    }

    @Test fun halfTimeMarketsNeedHalfTimeScore() {
        assertNull(Outcomes.eval("ht_1x2", "1", 2, 1, null, null))
        assertEquals(true, Outcomes.eval("htft", "X/1", 2, 1, 0, 0))
    }

    @Test fun noModelForCornersAndCards() {
        assertNull(Outcomes.eval("corners_ou_9.5", "over", 2, 1, 1, 0))
        assertNull(Outcomes.eval("cards_ou_3.5", "over", 2, 1, 1, 0))
    }
}
