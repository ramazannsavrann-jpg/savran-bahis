package com.savran.bahis

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test
import java.time.ZoneOffset
import java.time.ZonedDateTime

private fun fcast(matchId: String, mk: String, sk: String, p: Double, conf: Confidence = Confidence.HIGH) =
    Forecast(matchId, mk, sk, p, conf, when (conf) { Confidence.HIGH -> 90; Confidence.MEDIUM -> 65; Confidence.LOW -> 40 }, null, null, null, null, "t", 0.9)

class BestPerMarketTest {
    @Test fun onlyTheHighestProbabilityAlternativeIsShown() {
        val list = listOf(
            fcast("m", "btts", "yes", 0.72), fcast("m", "btts", "no", 0.28),
            fcast("m", "ou_2.5", "over", 0.75), fcast("m", "ou_2.5", "under", 0.25),
            fcast("m", "1x2", "1", 0.60), fcast("m", "1x2", "X", 0.23), fcast("m", "1x2", "2", 0.17),
            fcast("m", "cs", "2-0", 0.24, Confidence.MEDIUM), fcast("m", "cs", "1-0", 0.17, Confidence.MEDIUM), fcast("m", "cs", "2-1", 0.15, Confidence.MEDIUM)
        )
        val shown = ForecastEngine.bahisFirsatlari(list)
        assertEquals(4, shown.size)
        assertEquals("yes", shown.first { it.marketKey == "btts" }.selectionKey)
        assertEquals("over", shown.first { it.marketKey == "ou_2.5" }.selectionKey)
        assertEquals("1", shown.first { it.marketKey == "1x2" }.selectionKey)
        assertEquals("2-0", shown.first { it.marketKey == "cs" }.selectionKey)      // doğru skorda yalnızca en olası skor
        assertFalse(shown.any { it.selectionKey == "no" || it.selectionKey == "under" })
    }

    @Test fun firstHalfOverUnder25UnderIsNeverShown() {
        val list = listOf(
            fcast("m", "ht_ou_2.5", "under", 0.97), fcast("m", "ht_ou_2.5", "over", 0.03),
            fcast("m", "ht_ou_1.5", "under", 0.62), fcast("m", "ht_ou_1.5", "over", 0.38),
            fcast("m", "ht_ou_0.5", "over", 0.70), fcast("m", "ht_ou_0.5", "under", 0.30)
        )
        val shown = ForecastEngine.bahisFirsatlari(list)
        assertFalse(shown.any { it.marketKey == "ht_ou_2.5" })          // yüksek olasılıkta bile; düşük alternatif de yok
        assertTrue(shown.any { it.marketKey == "ht_ou_1.5" })           // diğer ilk yarı seçenekleri normal
        assertTrue(shown.any { it.marketKey == "ht_ou_0.5" })
        // Hiçbir koşulda: yüksek güven, tek başına, filtre uygulanmış olsa da
        assertTrue(MarketFilters.apply(list, MarketFilters.group("htgoals"), null).none { it.marketKey == "ht_ou_2.5" })
    }

    @Test fun otherUnplayableLinesDropTheWholeMarket() {
        val list = listOf(
            fcast("m", "ou_0.5", "over", 0.95), fcast("m", "ou_0.5", "under", 0.05),
            fcast("m", "ou_4.5", "under", 0.90), fcast("m", "ou_4.5", "over", 0.10)
        )
        assertTrue(ForecastEngine.bahisFirsatlari(list).isEmpty())
    }

    @Test fun lowConfidenceAndCoinFlipsAreNotShownAndNothingFillsTheList() {
        val list = listOf(
            fcast("m", "btts", "yes", 0.80, Confidence.LOW), fcast("m", "btts", "no", 0.20, Confidence.LOW),
            fcast("m", "ou_2.5", "over", 0.52), fcast("m", "ou_2.5", "under", 0.48),
            fcast("m", "1x2", "1", 0.41), fcast("m", "1x2", "X", 0.30), fcast("m", "1x2", "2", 0.29)
        )
        val shown = ForecastEngine.bahisFirsatlari(list)
        assertEquals(listOf("1x2"), shown.map { it.marketKey })         // 3 seçenekli pazarda %41 normaldir; ikililer elenir
        assertTrue(ForecastEngine.bahisFirsatlari(emptyList()).isEmpty())
    }

    @Test fun marketsAndMatchesAreEvaluatedIndependently() {
        val list = listOf(
            fcast("a", "btts", "yes", 0.70), fcast("a", "btts", "no", 0.30),
            fcast("b", "btts", "yes", 0.35), fcast("b", "btts", "no", 0.65)
        )
        val shown = ForecastEngine.bahisFirsatlari(list)
        assertEquals(2, shown.size)
        assertEquals("yes", shown.first { it.matchId == "a" }.selectionKey)
        assertEquals("no", shown.first { it.matchId == "b" }.selectionKey)
    }

    @Test fun generatedForecastsHaveExactlyOneShownPickPerMarket() {
        val f = ForecastEngine.generate("m1", AnalysisContext(ScoreModel(2.0, 1.8), 0.9, false, null), emptyList())
        val shown = ForecastEngine.bahisFirsatlari(f)
        assertEquals(shown.size, shown.map { it.marketKey }.distinct().size)
        shown.forEach { s -> assertTrue(f.filter { it.marketKey == s.marketKey }.all { it.prob <= s.prob + 1e-12 }) }
        assertFalse(shown.any { it.marketKey == "ht_ou_2.5" })
    }
}

class ResultsTableTest {
    private val teams = listOf("Alpha", "Bravo", "Charlie", "Delta")

    private fun roundRobin(): List<FinishedResult> {
        val out = ArrayList<FinishedResult>()
        var t = 1000L
        for (h in teams.indices) for (a in teams.indices) if (h != a) {
            out.add(FinishedResult(teams[h], teams[a], (h + 2) % 4, (a + 1) % 3, t))
            t += 86400
        }
        return out
    }

    @Test fun tooFewResultsBuildNoTable() {
        assertNull(ResultsTable.build(roundRobin().take(9), 39, 2026, 0L, "Football-Data.org"))
    }

    @Test fun buildsHomeAwaySplitsPointsAndForm() {
        val res = roundRobin()
        val t = ResultsTable.build(res, 39, 2026, 5L, "Football-Data.org")!!
        assertEquals(4, t.rows.size)
        assertTrue(ResultsTable.isDerived(t))
        assertTrue(t.rows.all { it.teamId < 0 })
        assertTrue(t.rows.all { it.home.played == 3 && it.away.played == 3 && it.all.played == 6 })
        val decisive = res.count { it.homeGoals != it.awayGoals }
        val draws = res.size - decisive
        assertEquals(3 * decisive + 2 * draws, t.rows.sumOf { it.points })
        assertEquals(res.sumOf { it.homeGoals + it.awayGoals }, t.rows.sumOf { it.all.goalsFor })
        assertEquals(t.rows.sumOf { it.all.goalsFor }, t.rows.sumOf { it.all.goalsAgainst })
        assertTrue(t.rows.all { it.form.length == 5 && it.form.all { c -> c == 'W' || c == 'D' || c == 'L' } })
        assertEquals((1..4).toList(), t.rows.map { it.rank })
        assertTrue(t.rows.zipWithNext().all { (a, b) -> a.points >= b.points })
        assertEquals(ResultsTable.teamId("Alpha"), ResultsTable.teamId("Alpha"))
    }

    @Test fun analysisContinuesWithoutStandings() {
        val t = ResultsTable.build(roundRobin(), 39, 2026, 5L, "Football-Data.org")!!
        val l = Strength.lambdas(t.rows, t.rows[0].teamId, t.rows[1].teamId)
        assertNotNull(l)
        assertTrue(l!!.formUsed)                              // form sonuçlardan hesaplandı
        assertTrue(l.dataQuality >= ForecastEngine.MIN_DATA_QUALITY)
        val ctx = AnalysisContext(ScoreModel(l.home, l.away), l.dataQuality, false, null, 1.0, l.homeGames, l.awayGames)
        val f = ForecastEngine.generate("m", ctx, emptyList())
        assertTrue(f.isNotEmpty())
        assertTrue(ForecastEngine.bahisFirsatlari(f).all { it.prob in 0.0..1.0 })
    }
}

class LearningTest {
    private fun rec(i: Int, mk: String, sk: String, p: Double, hit: Boolean, version: String = OpportunityEngine.MODEL_VERSION) =
        PredictionRecord("id$i$mk$sk", "m$i", "A - B", 39, "PL", 1000L + i, mk, sk, 0L, p, p, null, null, null, "t", version, false, hit, i.toLong(), "1-0")

    @Test fun groupsOnlyCoverIndependentBinaryOrThreeWayMarkets() {
        assertEquals("total-gol", Calibration.group("ou_2.5"))
        assertEquals("btts", Calibration.group("btts"))
        assertEquals("1x2", Calibration.group("1x2"))
        assertEquals("takim-gol", Calibration.group("home_ou_1.5"))
        assertEquals("ilk-yari", Calibration.group("ht_btts"))
        listOf("dc", "ht_dc", "htft", "cs", "combo_1x2_btts", "hcp_home_minus1", "corners_ou_9.5").forEach { assertNull(it, Calibration.group(it)) }
    }

    @Test fun smallBinsBarelyMoveAndEmptyBinsDoNotMove() {
        val bins = Calibration.fit((0 until 100).map { 0.7 to (it % 2 == 0) })
        assertEquals(100, bins[Calibration.binOf(0.7)].n)
        assertEquals(0.557, Calibration.map(0.7, bins), 1e-3)
        assertEquals(0.3, Calibration.map(0.3, bins), 1e-12)          // veri yoksa değişmez
    }

    @Test fun notEnoughDataMeansNoLearningClaim() {
        val records = (0 until 30).map { rec(it, "ou_2.5", "over", 0.8, it % 2 == 0) }
        val s = Learner.run(records, null, OpportunityEngine.MODEL_VERSION, 1L)
        assertTrue(s.groups.isEmpty())
        assertTrue(s.events.isEmpty())
        assertEquals(30, s.samples["total-gol"])
    }

    @Test fun learnsCalibrationOnlyWhenValidationImproves() {
        val over = (0 until 200).map { rec(it, "ou_2.5", "over", 0.8, it % 2 == 0) }      // %80 diyor, %50 gerçekleşiyor
        val s = Learner.run(over, null, OpportunityEngine.MODEL_VERSION, 9L)
        assertTrue(s.groups.containsKey("total-gol"))
        val e = s.events.single()
        assertTrue(e.adopted)
        assertTrue(e.brierAfter < e.brierBefore)

        val calibrated = (0 until 200).map { rec(it, "ou_2.5", "over", 0.6, (it % 5) < 3) }   // zaten kalibre
        val s2 = Learner.run(calibrated, null, OpportunityEngine.MODEL_VERSION, 9L)
        assertTrue(s2.groups.isEmpty())
        assertFalse(s2.events.single().adopted)
    }

    @Test fun recordsOfOtherModelVersionsAreIgnored() {
        val old = (0 until 200).map { rec(it, "ou_2.5", "over", 0.8, it % 2 == 0, version = "poisson-v1") }
        val s = Learner.run(old, null, OpportunityEngine.MODEL_VERSION, 1L)
        assertTrue(s.groups.isEmpty() && s.events.isEmpty() && s.samples.isEmpty())
    }

    @Test fun calibratorKeepsProbabilitiesConsistentAndKeepsRawValue() {
        val over = (0 until 200).map { rec(it, "ou_2.5", "over", 0.8, it % 2 == 0) }
        val state = Learner.run(over, null, OpportunityEngine.MODEL_VERSION, 9L)
        val f = listOf(fcast("m", "ou_2.5", "under", 0.2), fcast("m", "ou_2.5", "over", 0.8))
        val out = Calibrator.apply(f, state)
        val o = out.first { it.selectionKey == "over" }
        val u = out.first { it.selectionKey == "under" }
        assertTrue(o.prob < 0.8)
        assertEquals(1.0, o.prob + u.prob, 1e-9)
        assertEquals(0.8, o.rawProb, 1e-12)                  // ham olasılık korunur (öğrenme için)
        assertEquals(f, Calibrator.apply(f, null))           // öğrenme yoksa değişiklik yok
    }

    @Test fun threeWayMarketStaysNormalized() {
        val bins = Calibration.fit((0 until 100).map { 0.62 to (it < 40) })
        val state = LearningState(OpportunityEngine.MODEL_VERSION, mapOf("1x2" to CalGroup("1x2", 100, bins, 1L, 0.3, 0.2)), emptyList(), emptySet(), emptyMap(), 1L)
        val f = listOf(fcast("m", "1x2", "1", 0.62), fcast("m", "1x2", "X", 0.20), fcast("m", "1x2", "2", 0.18))
        val out = Calibrator.apply(f, state)
        assertEquals(1.0, out.sumOf { it.prob }, 1e-9)
        assertTrue(out.first { it.selectionKey == "1" }.prob < 0.62)
    }

    @Test fun weakMarketGroupsLoseConfidence() {
        val weak = (0 until 100).map { rec(it, "btts", "yes", 0.6, (it % 5) >= 3) }        // %60 diyor, %40 gerçekleşiyor
        val state = Learner.run(weak, null, OpportunityEngine.MODEL_VERSION, 1L)
        assertTrue(state.weak.contains("btts"))
        val base = AnalysisContext(ScoreModel(2.0, 1.8), 0.9, false, null)
        val withLearning = base.copy(learning = state)
        val a = ForecastEngine.generate("m", base, emptyList()).first { it.marketKey == "btts" }
        val b = ForecastEngine.generate("m", withLearning, emptyList()).first { it.marketKey == "btts" }
        assertEquals(a.confidenceScore - ForecastEngine.WEAK_MARKET_PENALTY, b.confidenceScore)
        val other = ForecastEngine.generate("m", withLearning, emptyList()).first { it.marketKey == "1x2" }
        assertEquals(ForecastEngine.generate("m", base, emptyList()).first { it.marketKey == "1x2" }.confidenceScore, other.confidenceScore)
    }
}

class NewsTest {
    private val now = 1793466000L
    private fun item(title: String, source: String, ageH: Long, topics: Set<NewsTopic>, out: Boolean = true, rumor: Boolean = false, official: Boolean = false, team: String = "Alpha") =
        NewsItem(team, title, source, "https://x/" + title.hashCode(), now - ageH * 3600, now, topics, out, rumor, official)

    @Test fun foldAndClassify() {
        assertEquals("ilk 11", NewsText.fold("İlk 11"))
        val c = NewsText.classify("Fenerbahçe'de golcü sakat, derbide yok", null)
        assertTrue(c.topics.contains(NewsTopic.STRIKER) && c.topics.contains(NewsTopic.INJURY))
        assertTrue(c.out)
        assertFalse(c.rumor)
        val lineup = NewsText.classify("Galatasaray'da muhtemel 11 belli oldu", null)
        assertTrue(lineup.topics.contains(NewsTopic.LINEUP))
        assertTrue(lineup.rumor)                                         // ilk 11 kesinleşmediyse tahmin sayılır
        val off = NewsText.classify("Kulüpten resmi açıklama: kaleci sakatlandı", null)
        assertTrue(off.official && !off.rumor && off.topics.contains(NewsTopic.GOALKEEPER))
        assertTrue(NewsText.classify("Galatasaray kaleci sakat", "https://www.galatasaray.org/haber").official)
        assertTrue(NewsText.classify("Arsenal striker doubtful for derby", null).rumor)
    }

    @Test fun teamMentionRequiresAllNameParts() {
        assertTrue(NewsText.mentions("Manchester City injury news", "Manchester City"))
        assertFalse(NewsText.mentions("Manchester United injury news", "Manchester City"))
        assertTrue(NewsText.mentions("Galatasaray'da kaleci sakat", "Galatasaray"))
    }

    @Test fun rssIsParsedWithDateAndSource() {
        val xml = """
            <rss><channel>
            <item><title>Alpha'da kaleci sakat - Spor Haber</title><link>https://example.com/a</link>
            <pubDate>Sat, 31 Oct 2026 10:00:00 GMT</pubDate><source url="https://www.sporhaber.com">Spor Haber</source></item>
            <item><title><![CDATA[Başlık &amp; Test]]></title><link>https://example.com/b</link><pubDate>geçersiz tarih</pubDate></item>
            </channel></rss>
        """.trimIndent()
        val items = RssParser.parse(xml)
        assertEquals(2, items.size)
        assertEquals("Alpha'da kaleci sakat", items[0].title)
        assertEquals("Spor Haber", items[0].source)
        assertEquals(ZonedDateTime.of(2026, 10, 31, 10, 0, 0, 0, ZoneOffset.UTC).toEpochSecond(), items[0].published)
        assertEquals("Başlık & Test", items[1].title)
        assertNull(items[1].published)
    }

    @Test fun oldUndatedAndUnrelatedNewsAreDropped() {
        val pub = now - 3600
        val rss = listOf(
            RssItem("Alpha kaleci sakat", "l1", pub, "S1", null),
            RssItem("Alpha kaleci sakat eski", "l2", now - 9 * 24 * 3600, "S2", null),
            RssItem("Alpha tarihsiz", "l3", null, "S3", null),
            RssItem("Bravo kaleci sakat", "l4", pub, "S4", null)
        )
        val out = RssParser.toNewsItems("Alpha", rss, now)
        assertEquals(1, out.size)
        assertEquals(now, out[0].fetchedAt)
        assertEquals(pub, out[0].publishedAt)
    }

    @Test fun singleUnofficialSourceIsNotTrusted() {
        val e = NewsImpact.compute("Alpha", listOf(item("Alpha kalecisi sakat, derbide yok", "S1", 5, setOf(NewsTopic.GOALKEEPER))), "Bravo", emptyList(), now)
        assertEquals(1.0, e.homeFactor, 1e-12)
        assertEquals(1.0, e.awayFactor, 1e-12)
        assertTrue(e.applied.isEmpty())
        assertTrue(e.info.any { it.contains("doğrulanmadı") })
    }

    @Test fun twoIndependentStoriesApplyASmallEffect() {
        val items = listOf(
            item("Alpha kalecisi sakatlandı, derbide yok", "S1", 5, setOf(NewsTopic.GOALKEEPER)),
            item("Alpha'da kaleci krizi: eldivenleri bırakan isim forma giyemeyecek", "S2", 6, setOf(NewsTopic.GOALKEEPER))
        )
        val e = NewsImpact.compute("Alpha", items, "Bravo", emptyList(), now)
        assertEquals(1.0, e.homeFactor, 1e-12)
        assertEquals(1.03, e.awayFactor, 1e-12)                     // ev sahibi kalecisi yok -> rakibin gol beklentisi artar
        assertTrue(e.applied.isNotEmpty())
    }

    @Test fun repeatedStoryCountsOnce() {
        val t = "Alpha kalecisi sakatlandı, derbide yok"
        val items = listOf(item(t, "S1", 5, setOf(NewsTopic.GOALKEEPER)), item(t, "S2", 4, setOf(NewsTopic.GOALKEEPER)), item("$t!", "S3", 3, setOf(NewsTopic.GOALKEEPER)))
        assertEquals(1, NewsImpact.distinctStories(items).size)
        val e = NewsImpact.compute("Alpha", items, "Bravo", emptyList(), now)
        assertTrue(e.applied.isEmpty())                             // aynı haberin tekrarı bağımsız bilgi değildir
        assertEquals(1.0, e.awayFactor, 1e-12)
    }

    @Test fun officialStatementIsPrioritized() {
        val e = NewsImpact.compute(
            "Alpha", emptyList(), "Bravo",
            listOf(item("Bravo golcüsü sakat, resmen açıklandı", "Kulüp", 5, setOf(NewsTopic.STRIKER), official = true, team = "Bravo")), now
        )
        assertEquals(0.97, e.awayFactor, 1e-12)
        assertEquals(1.0, e.homeFactor, 1e-12)
    }

    @Test fun staleAndRumorNewsAreNotUsed() {
        val stale = item("Alpha kalecisi sakat, resmen açıklandı", "Kulüp", 100, setOf(NewsTopic.GOALKEEPER), official = true)
        val rumor = item("Alpha golcüsü sakat olabilir iddiası", "S9", 2, setOf(NewsTopic.STRIKER), rumor = true)
        val e = NewsImpact.compute("Alpha", listOf(stale, rumor), "Bravo", emptyList(), now)
        assertEquals(1.0, e.homeFactor, 1e-12)
        assertEquals(1.0, e.awayFactor, 1e-12)
        assertTrue(e.info.any { it.contains("72 saatten eski") })
        assertTrue(e.info.any { it.contains("söylenti") })
    }

    @Test fun effectsAreCapped() {
        val offs = listOf(NewsTopic.GOALKEEPER, NewsTopic.DEFENDER, NewsTopic.STRIKER).map {
            item("Alpha ${it.name} yok resmen", "Kulüp", 2, setOf(it), official = true)
        }
        val away = listOf(NewsTopic.GOALKEEPER, NewsTopic.DEFENDER).map {
            item("Bravo ${it.name} yok resmen", "Kulüp", 2, setOf(it), official = true, team = "Bravo")
        }
        val e = NewsImpact.compute("Alpha", offs, "Bravo", away, now)
        assertTrue(e.homeFactor in 0.94..1.06)
        assertTrue(e.awayFactor in 0.94..1.06)
    }

    @Test fun queryUrlTargetsRecentNews() {
        val u = RssParser.queryUrl("Galatasaray", true)
        assertTrue(u.startsWith("https://news.google.com/rss/search?q="))
        assertTrue(u.contains("when%3A7d"))
        assertTrue(u.contains("hl=tr"))
    }
}

class PeriodReportsTest {
    private val zone = ZoneOffset.UTC
    private val now = ZonedDateTime.of(2026, 10, 31, 15, 0, 0, 0, ZoneOffset.UTC).toInstant().toEpochMilli()
    private fun at(daysAgo: Int, hour: Int = 12): Long =
        ZonedDateTime.of(2026, 10, 31, hour, 0, 0, 0, ZoneOffset.UTC).minusDays(daysAgo.toLong()).toEpochSecond()

    private var n = 0
    private fun rec(kick: Long, mk: String, result: Boolean?, p: Double = 0.7, league: String = "Premier League") =
        PredictionRecord("id${n++}", "m$n", "A - B", 39, league, kick, mk, "over", 0L, p, p, null, null, null, "t", "poisson-v2", true, result, if (result == null) null else 1L, "1-0")

    private fun week(): List<PredictionRecord> =
        listOf(
            rec(at(1), "ou_2.5", true), rec(at(2), "ou_2.5", true), rec(at(3), "ou_2.5", true),
            rec(at(1), "btts", true), rec(at(2), "btts", false), rec(at(3), "btts", false),
            rec(at(1), "ou_1.5", null)                                                          // sonucu belli değil
        ) + (0 until 5).map { rec(at(8 + it), "ou_2.5", it == 0) }                              // önceki hafta: 1/5 doğru

    @Test fun windowsAndCountsOnlyUseSettledResults() {
        val (from, to) = PeriodReports.window(Period.DAY, now, zone)
        assertEquals(24L * 3600_000, to - from)
        val day = PeriodReports.build(week() + rec(at(0), "btts", true), Period.DAY, now, zone)
        assertEquals(1, day.settled)
        val r = PeriodReports.build(week(), Period.WEEK, now, zone)
        assertEquals(7, r.total)
        assertEquals(6, r.settled)
        assertEquals(4, r.correct)
        assertEquals(2, r.wrong)
        assertEquals(4.0 / 6.0, r.hitRate!!, 1e-12)
        assertEquals(5, r.previous.settled)
        assertEquals(0.2, r.previous.hitRate!!, 1e-12)
    }

    @Test fun bestAndWorstMarketsComeFromRealGroups() {
        val r = PeriodReports.build(week(), Period.WEEK, now, zone)
        assertEquals("Toplam gol", r.best!!.label)
        assertEquals(1.0, r.best!!.rate, 1e-12)
        assertEquals("Karşılıklı gol", r.worst!!.label)
        assertEquals(1.0 / 3.0, r.worst!!.rate, 1e-12)
        assertEquals(listOf("Premier League"), r.byLeague.map { it.label })
    }

    @Test fun commentaryIsBuiltFromRealNumbersOnly() {
        val r = PeriodReports.build(week(), Period.WEEK, now, zone)
        val text = PeriodReports.commentary(r, null)
        assertTrue(text.contains("%67"))
        assertTrue(text.contains("arttı"))                         // önceki hafta %20 -> bu hafta %67
        assertTrue(text.contains("Toplam gol"))
        assertTrue(text.contains("Karşılıklı gol"))
        assertTrue(text.contains("henüz birikmedi"))               // öğrenme için veri yok
        val empty = PeriodReports.build(emptyList(), Period.WEEK, now, zone)
        val none = PeriodReports.commentary(empty, null)
        assertTrue(none.contains("Yorum üretilmedi"))
        assertFalse(none.contains("%"))                            // uydurma yüzde yok
        assertNull(empty.hitRate)
    }

    @Test fun commentaryMentionsLearningOnlyWhenItHappened() {
        val r = PeriodReports.build(week(), Period.WEEK, now, zone)
        val bins = Calibration.fit(listOf(0.7 to true))
        val st = LearningState("v", mapOf("btts" to CalGroup("btts", 80, bins, 1L, 0.3, 0.25)), emptyList(), emptySet(), mapOf("btts" to 80), 1L)
        assertTrue(PeriodReports.commentary(r, st).contains("Karşılıklı gol (n=80)"))
    }
}

class LeaguesTest {
    @Test fun serieAAndEuropeanCupsAreSupported() {
        val ids = Leagues.supported.map { it.id }
        assertEquals(ids.size, ids.distinct().size)
        assertEquals("Serie A", Leagues.byId(135)?.nameTr)
        assertEquals("Şampiyonlar Ligi", Leagues.byId(2)?.nameTr)
        assertEquals("Avrupa Ligi", Leagues.byId(3)?.nameTr)
        assertEquals("Konferans Ligi", Leagues.byId(848)?.nameTr)
        assertEquals(10, Leagues.supported.size)
        assertTrue(Leagues.isCup(2) && Leagues.isCup(3) && Leagues.isCup(848))
        assertFalse(Leagues.isCup(39) || Leagues.isCup(135))
    }

    @Test fun everyLeagueIsCoveredByAtLeastOneFixtureSource() {
        val fixtureSources = listOf(SourceId.API_FOOTBALL, SourceId.FOOTBALL_DATA, SourceId.API_NINJAS, SourceId.THESPORTSDB, SourceId.OPENLIGADB)
        Leagues.supported.forEach { l ->
            assertTrue(l.nameTr, fixtureSources.any { SourceCatalog.info(it).leagues.contains(l.id) })
        }
    }

    @Test fun cupForecastsNeverReachHighConfidence() {
        val league = ForecastEngine.generate("m", AnalysisContext(ScoreModel(2.0, 1.8), 1.0, false, null), emptyList())
        val cup = ForecastEngine.generate("m", AnalysisContext(ScoreModel(2.0, 1.8), 1.0, false, null, cup = true), emptyList())
        assertTrue(league.any { it.confidence == Confidence.HIGH })
        assertTrue(cup.none { it.confidence == Confidence.HIGH })
        assertTrue(cup.all { it.confidenceScore <= ForecastEngine.CUP_MAX_SCORE })
        assertEquals(league.first { it.marketKey == "1x2" }.prob, cup.first { it.marketKey == "1x2" }.prob, 1e-12)   // olasılık aynı, yalnızca güven düşer
    }

    @Test fun cupCriteriaIsHonest() {
        val i = CriteriaInput(true, false, true, false, false, "Football-Data.org", 2026, false, 1, true)
        val c = Criteria.build(i).first { it.name.startsWith("Takımların lig gücü") }
        assertEquals(CriterionStatus.NOT_USED, c.status)
    }
}
