package com.savran.bahis

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class GapFillTest {
    @Test
    fun seasonCodeFormat() {
        assertEquals("2627", FootballDataCoUkSource.seasonCode(2026))
        assertEquals("9900", FootballDataCoUkSource.seasonCode(1999))
    }

    @Test
    fun parsesCsvAndSkipsBadRows() {
        val csv = "﻿Div,Date,Time,HomeTeam,AwayTeam,FTHG,FTAG,FTR\n" +
            "T1,08/08/2026,19:00,Galatasaray,Goztep,3,1,H\n" +
            "T1,09/08/26,,Fenerbahce,Rizespor,2,2,D\n" +
            "T1,bad,19:00,A,B,1,0,H\n" +
            "T1,10/08/2026,19:00,C,D,,,\n"
        val r = FootballDataCoUkSource.parse(csv)
        assertEquals(2, r.size)
        assertEquals("Galatasaray", r[0].home)
        assertEquals(3, r[0].homeGoals)
        assertEquals(2, r[1].awayGoals)
    }

    @Test
    fun missingColumnsGiveNothing() {
        assertTrue(FootballDataCoUkSource.parse("Div,Date,HomeTeam\nT1,01/01/2026,X").isEmpty())
    }

    private fun row(id: Int, hp: Int, hf: Int, ap: Int, af: Int) =
        TeamRow(id, "T$id", id, 0, SplitStats(hp + ap, hf + af, 0), SplitStats(hp, hf, 0), SplitStats(ap, af, 0), "")

    @Test
    fun leagueAverageUsesHomeAwaySplit() {
        val rows = (1..4).map { row(it, 2, 3, 2, 2) }   // ev 12 gol/8 maç, dep 8/8
        val avg = Strength.leagueAverage(rows)!!
        assertEquals(1.5, avg.first, 1e-9)
        assertEquals(1.0, avg.second, 1e-9)
    }

    @Test
    fun leagueAverageNullWithoutGames() {
        assertNull(Strength.leagueAverage(listOf(row(1, 0, 0, 0, 0))))
    }

    @Test
    fun veryThinStillForecastsButLowAndOutOfCoupons() {
        val ctx = AnalysisContext(ScoreModel(1.5, 1.0), 0.0, false, null, veryThin = true)
        val f = ForecastEngine.generate("m", ctx, emptyList())
        assertTrue(f.isNotEmpty())
        assertTrue(f.all { it.confidence == Confidence.LOW && it.confidenceScore <= ForecastEngine.VERY_THIN_MAX_SCORE })
        assertNull(ForecastEngine.noForecastReason(ctx, ""))
        assertTrue(f.all { it.dataQuality < ForecastEngine.MIN_DATA_QUALITY })   // buildCoupons bunları dışarıda bırakır
    }

    @Test
    fun withoutVeryThinFlagLowDataStillBlocked() {
        val ctx = AnalysisContext(ScoreModel(1.5, 1.0), 0.1, false, null)
        assertTrue(ForecastEngine.generate("m", ctx, emptyList()).isEmpty())
    }
}
