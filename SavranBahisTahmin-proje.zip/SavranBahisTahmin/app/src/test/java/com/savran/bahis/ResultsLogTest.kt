package com.savran.bahis

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import java.nio.file.Files

class ResultsLogTest {
    private fun m(id: String, lg: Int, st: String, hg: Int?, ag: Int?) =
        Match(id, lg, "L", "H$id", "A$id", 1_000L, st, hg, ag, null, null, "t")

    @Test
    fun recordsOnlyFinishedDomesticAndMarksDay() {
        val dir = Files.createTempDirectory("rl").toFile()
        val log = ResultsLog(dir)
        val n = log.record(listOf(m("1", 203, "FT", 2, 1), m("2", 203, "NS", null, null), m("3", 2, "FT", 1, 1), m("4", 203, "AWD", 3, 0)), "2026-11-01")
        assertEquals(1, n)
        assertEquals(1, log.results(203, 0).size)
        assertTrue("2026-11-01" in log.doneDays())
        assertEquals(0, log.record(listOf(m("1", 203, "FT", 2, 1))))   // tekrar eklenmez
        assertEquals(1, ResultsLog(dir).results(203, 0).size)          // dosyadan okunur
    }
}
