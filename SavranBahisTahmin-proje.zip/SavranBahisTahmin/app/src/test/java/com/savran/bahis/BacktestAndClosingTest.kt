package com.savran.bahis

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class BacktestAndClosingTest {
    private fun season(): List<FinishedResult> {
        val teams = (1..8).map { "T$it" }
        val out = ArrayList<FinishedResult>()
        var t = 1_000_000L
        repeat(3) { round ->
            for (h in teams) for (a in teams) if (h != a) {
                val hg = (h.hashCode() + round) % 4
                val ag = (a.hashCode() + 2 * round) % 3
                out.add(FinishedResult(h, a, hg, ag, t)); t += 3600
            }
        }
        return out
    }

    @Test
    fun backtestUsesOnlyPastAndProducesLines() {
        val r = Backtest.run(season(), "Test", "2526")
        assertEquals(168, r.matches)
        assertTrue(r.tested > 0)
        assertTrue(r.lines.isNotEmpty())
        assertTrue(r.lines.all { it.n == r.tested && it.brierModel in 0.0..1.0 && it.brierBase in 0.0..1.0 })
    }

    private fun rec(id: String, prob: Double, fair: Double?, res: Boolean?) = PredictionRecord(
        id, "m$id", "A - B", 39, "PL", 0, "1x2", "1", 0, prob, prob, null, null, null, "", "v", true,
        res, null, null, false, 1.0, fair, fair?.let { 1L }
    )

    @Test
    fun closingCompareNeedsSettledWithMarket() {
        val c = ClosingCompare.compute(listOf(rec("1", 0.7, null, true), rec("2", 0.6, 0.5, null)))!!
        assertEquals(0, c.n)
        val d = ClosingCompare.compute(listOf(rec("3", 0.8, 0.6, true), rec("4", 0.3, 0.5, false)))!!
        assertEquals(2, d.n)
        assertTrue(d.brierModel < d.brierMarket)
        assertTrue(ClosingCompare.text(d).contains("2/"))
    }
}
