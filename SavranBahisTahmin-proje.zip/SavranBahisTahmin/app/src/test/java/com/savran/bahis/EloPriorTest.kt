package com.savran.bahis

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class EloPriorTest {
    @Test
    fun equalEloGivesHomeEdgeAndKeepsTotal() {
        val (h, a) = EloPrior.lambdas(1700.0, 1700.0, 2.8)
        assertTrue(h > a)
        assertEquals(2.8, h + a, 1e-6)
    }

    @Test
    fun strongerAwayTeamGetsMoreGoals() {
        val (h, a) = EloPrior.lambdas(1550.0, 1900.0, 2.7)
        assertTrue(a > h)
    }

    @Test
    fun expectedMatchesPoissonResult() {
        val (h, a) = EloPrior.lambdas(1800.0, 1650.0, 2.6)
        val m = ScoreModel(h, a)
        val we = (MarketProb.prob(m, "1x2", "1") ?: 0.0) + (MarketProb.prob(m, "1x2", "X") ?: 0.0) / 2
        assertEquals(EloPrior.expected(1800.0, 1650.0), we, 0.01)
    }

    @Test
    fun blendWeightGrowsWithGames() {
        assertEquals(0.333, EloPrior.weight(3), 0.01)
        assertTrue(EloPrior.weight(12) > EloPrior.weight(3))
        val b = EloPrior.blend(2.0 to 1.0, 1.0 to 2.0, 0)
        assertEquals(1.0, b.first, 1e-9)
        assertEquals(2.0, b.second, 1e-9)
    }

    @Test
    fun eloPriorCanReachMediumButDisplayedDqUnchanged() {
        val ctx = AnalysisContext(ScoreModel(1.5, 1.1), 0.375, false, null, cup = true, eloPrior = true)
        val f = ForecastEngine.generate("m", ctx, emptyList())
        assertTrue(f.isNotEmpty())
        assertTrue(f.all { it.dataQuality == 0.375 && it.confidenceScore <= ForecastEngine.CUP_MAX_SCORE })
    }
}
