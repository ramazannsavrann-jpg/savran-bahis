package com.savran.bahis

import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test
import java.io.File

class SavranEloDataTest {
    private fun table(): List<EloEntry> {
        val f = listOf("src/main/assets/savran_elo.csv", "app/src/main/assets/savran_elo.csv").map { File(it) }.first { it.exists() }
        return ClubEloParser.parse(f.readText())
    }

    @Test
    fun assetParsesAndHasBigClubs() {
        val t = table()
        assertTrue(t.size > 300)
        assertNotNull(EloAdjust.find("Galatasaray", t))
        assertNotNull(EloAdjust.find("Arsenal", t))
        assertTrue(t.all { it.elo in 900.0..2300.0 })
    }
}
