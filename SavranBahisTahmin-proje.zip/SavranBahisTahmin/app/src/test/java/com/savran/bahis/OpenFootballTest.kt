package com.savran.bahis

import org.junit.Assert.assertEquals
import org.junit.Test

class OpenFootballTest {
    @Test
    fun seasonFolder() {
        assertEquals("2025-26", OpenFootballSource.seasonFolder(2025))
        assertEquals("2099-00", OpenFootballSource.seasonFolder(2099))
    }

    @Test
    fun parsesBothScoreShapesAndSkipsUnplayed() {
        val json = """{"name":"X","matches":[
            {"date":"2025-08-16","time":"12:30","team1":"A FC","team2":"B FC","score":{"ht":[0,0],"ft":[2,1]}},
            {"date":"2025-08-17","team1":"C","team2":"D","score":[0,0]},
            {"date":"2025-08-18","time":"20:00","team1":"E","team2":"F"},
            {"date":"bad","team1":"G","team2":"H","score":[1,1]}
        ]}"""
        val r = OpenFootballSource.parse(json)
        assertEquals(2, r.size)
        assertEquals(2, r[0].homeGoals)
        assertEquals("D", r[1].away)
    }

    @Test
    fun parsesRoundsShape() {
        val json = """{"rounds":[{"name":"1","matches":[{"date":"2025-08-16","team1":"A","team2":"B","score":{"ft":[1,3]}}]}]}"""
        assertEquals(3, OpenFootballSource.parse(json)[0].awayGoals)
    }
}
