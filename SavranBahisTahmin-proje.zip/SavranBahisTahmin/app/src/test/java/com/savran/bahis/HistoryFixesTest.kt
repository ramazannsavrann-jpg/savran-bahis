package com.savran.bahis

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test
import java.io.File
import java.nio.file.Files

private fun testRec(
    id: String, matchId: String = "m-$id", mk: String = "btts", sk: String = "yes", p: Double = 0.6,
    result: Boolean? = null, recommended: Boolean = true, kickoff: Long = 1000L,
    manual: Boolean = false, dq: Double? = 0.9, version: String = OpportunityEngine.MODEL_VERSION
) = PredictionRecord(
    id, matchId, "A - B", 39, "PL", kickoff, mk, sk, 0L, p, p, null, null, null, "t", version,
    recommended, result, if (result == null) null else 1L, if (result == null) null else "1-0", manual, dq
)

class OddsParsingSafetyTest {
    private fun event(commence: String) =
        """{"home_team":"A","away_team":"B","commence_time":"$commence","bookmakers":[]}"""

    @Test fun badDateSkipsOnlyThatEventAndDoesNotThrow() {
        val body = "[" + event("not-a-date") + "," + event("2026-11-05T19:00:00Z") + "]"
        val r = OddsApiClient.parseEvents(body)
        assertTrue(r is ApiResult.Ok)
        assertEquals(1, (r as ApiResult.Ok).value.size)
    }

    @Test fun allEventsBrokenGivesReadableErrorNotCrash() {
        val r = OddsApiClient.parseEvents("[" + event("zzz") + "," + event("") + "]")
        assertTrue(r is ApiResult.Err)
    }

    @Test fun notAnArrayAndMissingFieldsAreErrors() {
        assertTrue(OddsApiClient.parseEvents("{}") is ApiResult.Err)
        assertTrue(OddsApiClient.parseEvents("""[{"home_team":"A"}]""") is ApiResult.Err)
        assertTrue(OddsApiClient.parseEvents("[]") is ApiResult.Ok)
    }
}

class PredictionStoreSafetyTest {
    private fun store(): PredictionStore = PredictionStore(Files.createTempDirectory("pred").toFile())

    @Test fun updateByIdKeepsRecordsAddedAfterTheSnapshot() {
        val s = store()
        s.addIfAbsent(listOf(testRec("a"), testRec("b")))
        val snapshot = s.all()                               // settlePending'in başta okuduğu liste
        s.addIfAbsent(listOf(testRec("c")))                  // değerlendirme sürerken yeni analiz kaydı ekler
        val settledA = snapshot.first { it.id == "a" }.copy(result = true, settledAt = 5L, finalScore = "2-1")
        assertEquals(1, s.updateById(mapOf("a" to settledA)))
        val now = s.all().associateBy { it.id }
        assertEquals(setOf("a", "b", "c"), now.keys)         // "c" kaybolmadı (eski replaceAll bunu siliyordu)
        assertEquals(true, now.getValue("a").result)
        assertNull(now.getValue("b").result)
        assertNull(now.getValue("c").result)
    }

    @Test fun alreadySettledRecordsAreNeverOverwritten() {
        val s = store()
        s.addIfAbsent(listOf(testRec("a", result = true)))
        val other = testRec("a", result = false)
        assertEquals(0, s.updateById(mapOf("a" to other)))
        assertEquals(true, s.all().single().result)
        assertEquals(0, s.updateById(emptyMap()))
    }

    @Test fun manualFlagAndDataQualitySurviveSaveAndLoad() {
        val s = store()
        s.addIfAbsent(listOf(testRec("a", manual = true, dq = 0.6), testRec("b", manual = false, dq = 0.9)))
        val m = s.all().associateBy { it.id }
        assertTrue(m.getValue("a").manual)
        assertEquals(0.6, m.getValue("a").dq!!, 1e-12)
        assertFalse(m.getValue("b").manual)
    }

    @Test fun legacyFilesWithoutNewFieldsStillLoad() {
        val dir: File = Files.createTempDirectory("legacy").toFile()
        File(dir, "predictions.json").writeText(
            """{"items":[{"id":"x","matchId":"m","matchLabel":"A - B","leagueId":39,"leagueName":"PL","kickoff":1000,
            "marketKey":"btts","selectionKey":"yes","predictedAt":1,"modelProb":0.6,"prob":0.6,"odds":null,"bookmaker":null,
            "oddsUpdatedAt":null,"sources":"t","modelVersion":"v","recommended":false,"result":null,"settledAt":null,"finalScore":null}]}"""
        )
        val r = PredictionStore(dir).all().single()
        assertEquals("x", r.id)
        assertFalse(r.manual)
        assertNull(r.dq)
        assertFalse(File(dir, "predictions.corrupt.json").exists())
    }
}

class RecordBuilderTest {
    private val future = 2_000_000L                      // epoch saniye
    private val nowMs = 1_000_000_000L                   // = 1_000_000 sn < future
    private fun match(kick: Long = future, status: String = "NS") =
        Match("api-1", 39, "Premier League", "A", "B", kick, status, null, null, null, null, "API-Football")

    private fun forecasts(dq: Double = 0.9): Pair<ScoreModel, List<Forecast>> {
        val model = ScoreModel(1.9, 1.3)
        return model to ForecastEngine.generate("api-1", AnalysisContext(model, dq, false, null), emptyList())
    }

    private fun eval(mk: String, sk: String, p: Double = 0.7) = Evaluation(
        "api-1", mk, sk, 1.8, "Book", "Manuel", 1L, p, p, 0.55, 0.5, 0.1, 70, null, Decision.RECOMMEND, "t", false
    )

    @Test fun recordsOnlyPlayableMarketsAndFlagsRecommendedPicks() {
        val (model, f) = forecasts()
        val items = RecordBuilder.build(match(), model, 0.9, emptyList(), f, nowMs, manual = false)
        assertTrue(items.isNotEmpty())
        assertTrue(items.all { ForecastEngine.isPlayable(it.marketKey, it.selectionKey) })
        val recKeys = ForecastEngine.bahisFirsatlari(f).map { it.marketKey to it.selectionKey }.toSet()
        for (r in items) assertEquals((r.marketKey to r.selectionKey) in recKeys, r.recommended)
        assertTrue(items.any { it.recommended })
        assertTrue(items.any { !it.recommended })          // çekirdek karşı seçenekler önerilmiş sayılmaz
        assertTrue(items.all { !it.manual && it.dq == 0.9 })
    }

    @Test fun bannedMarketsAreNeverRecordedEvenWithOdds() {
        val (model, f) = forecasts()
        val evals = listOf(eval("ht_ou_2.5", "under", 0.9), eval("ou_0.5", "over", 0.95), eval("ou_4.5", "under", 0.9), eval("ou_2.5", "over", 0.6))
        val items = RecordBuilder.build(match(), model, 0.9, evals, f, nowMs, false)
        assertTrue(items.none { it.marketKey == "ht_ou_2.5" && it.selectionKey == "under" })
        assertTrue(items.none { it.marketKey == "ou_0.5" && it.selectionKey == "over" })
        assertTrue(items.none { it.marketKey == "ou_4.5" && it.selectionKey == "under" })
        assertNotNull(items.firstOrNull { it.marketKey == "ou_2.5" && it.selectionKey == "over" })
    }

    @Test fun lowDataQualityIsNotRecorded() {
        val (model, f) = forecasts()
        assertTrue(RecordBuilder.build(match(), model, 0.2, listOf(eval("ou_2.5", "over")), f, nowMs, false).isEmpty())
        assertTrue(RecordBuilder.build(match(), model, ForecastEngine.MIN_DATA_QUALITY, emptyList(), f, nowMs, false).isNotEmpty())
    }

    @Test fun startedMatchesAreNotRecorded() {
        val (model, f) = forecasts()
        assertTrue(RecordBuilder.build(match(kick = 500_000L), model, 0.9, emptyList(), f, nowMs, false).isEmpty())
        assertTrue(RecordBuilder.build(match(status = "1H"), model, 0.9, emptyList(), f, nowMs, false).isEmpty())
    }

    @Test fun manualLambdaRecordsAreMarkedAndExcludedFromAutomaticStats() {
        val (model, f) = forecasts(0.6)
        val items = RecordBuilder.build(match(), model, 0.6, emptyList(), f, nowMs, manual = true)
        assertTrue(items.isNotEmpty() && items.all { it.manual })
        val settled = items.map { it.copy(result = true, settledAt = 1L) }
        val rep = Metrics.report(settled)
        assertEquals(0, rep.settled)
        assertNull(rep.hitRate)
        assertEquals(settled.size, rep.manualSettled)
    }
}

class SuccessRateOnlyForRecommendedTest {
    @Test fun hitRateUsesOnlyRecommendedAutomaticPlayableRecords() {
        val recs = listOf(
            testRec("1", result = true),                                         // sayılır
            testRec("2", result = false),                                        // sayılır
            testRec("3", result = false, recommended = false),                   // önerilmeyen karşı seçenek: sayılmaz
            testRec("4", result = true, recommended = false),
            testRec("5", result = true, manual = true),                          // manuel λ: sayılmaz
            testRec("6", mk = "ou_0.5", sk = "over", result = true),             // yasaklı pazar: sayılmaz
            testRec("7", result = true, dq = 0.1),                               // düşük veri kalitesi: sayılmaz
            testRec("8", result = null)                                          // sonuç bekliyor
        )
        val rep = Metrics.report(recs)
        assertEquals(2, rep.settled)
        assertEquals(1, rep.correct)
        assertEquals(1, rep.wrong)
        assertEquals(0.5, rep.hitRate!!, 1e-12)
        assertEquals(3, rep.total)            // 1, 2 ve bekleyen 8
        assertEquals(1, rep.manualSettled)
        assertEquals(2, rep.recent[0].n)
    }

    @Test fun legacyRecordsWithUnknownDataQualityStillCountWhenRecommended() {
        val rep = Metrics.report(listOf(testRec("1", result = true, dq = null)))
        assertEquals(1, rep.settled)
    }

    @Test fun periodReportsUseTheSameRule() {
        val kick = 1_700_000_000L
        val now = kick * 1000 + 3_600_000
        val recs = listOf(
            testRec("1", result = true, kickoff = kick),
            testRec("2", result = false, kickoff = kick, recommended = false),
            testRec("3", result = false, kickoff = kick, manual = true)
        )
        val r = PeriodReports.build(recs, Period.WEEK, now, java.time.ZoneOffset.UTC)
        assertEquals(1, r.settled)
        assertEquals(1, r.correct)
    }
}

class LearnerFilteringAndSplitTest {
    private fun many(n: Int, make: (Int) -> PredictionRecord) = (0 until n).map(make)

    @Test fun manualBannedAndLowQualityRecordsNeverTeachTheModel() {
        val manual = many(200) { testRec("m$it", mk = "ou_2.5", sk = "over", p = 0.8, result = it % 2 == 0, kickoff = 1000L + it, manual = true) }
        assertTrue(Learner.run(manual, null, OpportunityEngine.MODEL_VERSION, 1L).let { it.groups.isEmpty() && it.samples.isEmpty() })
        val banned = many(200) { testRec("b$it", mk = "ou_4.5", sk = "under", p = 0.8, result = it % 2 == 0, kickoff = 1000L + it) }
        assertTrue(Learner.run(banned, null, OpportunityEngine.MODEL_VERSION, 1L).let { it.groups.isEmpty() && it.samples.isEmpty() })
        val lowDq = many(200) { testRec("q$it", mk = "ou_2.5", sk = "over", p = 0.8, result = it % 2 == 0, kickoff = 1000L + it, dq = 0.1) }
        assertTrue(Learner.run(lowDq, null, OpportunityEngine.MODEL_VERSION, 1L).let { it.groups.isEmpty() && it.samples.isEmpty() })
    }

    @Test fun automaticRecordsStillTeachTheModel() {
        val auto = many(200) { testRec("a$it", mk = "ou_2.5", sk = "over", p = 0.8, result = it % 2 == 0, kickoff = 1000L + it) }
        val s = Learner.run(auto, null, OpportunityEngine.MODEL_VERSION, 9L)
        assertEquals(200, s.samples["total-gol"])
        assertTrue(s.groups.containsKey("total-gol"))
    }

    @Test fun trainAndValidationNeverShareAMatchAndValidationIsLater() {
        // 40 maç × 3 kayıt (1/X/2): aynı maçın kayıtları aynı tarafa düşmeli.
        val recs = (0 until 40).flatMap { m ->
            listOf("1", "X", "2").mapIndexed { j, sk ->
                testRec("r$m$sk", matchId = "match$m", mk = "1x2", sk = sk, p = 0.33, result = j == m % 3, kickoff = 5000L + m)
            }
        }.shuffled(java.util.Random(7))
        val (train, valid) = Learner.splitByMatch(recs)
        assertEquals(120, train.size + valid.size)
        assertEquals(90, train.size)
        assertEquals(30, valid.size)
        assertTrue(train.map { it.matchId }.toSet().intersect(valid.map { it.matchId }.toSet()).isEmpty())
        assertTrue(train.maxOf { it.kickoff } <= valid.minOf { it.kickoff })
        // her maçın bütün kayıtları tek tarafta
        assertTrue(train.groupBy { it.matchId }.values.all { it.size == 3 })
        assertTrue(valid.groupBy { it.matchId }.values.all { it.size == 3 })
    }

    @Test fun belowMinimumSampleMeansNoLearningClaim() {
        // 19 maç × 3 kayıt = 57 < 60 (Calibration.MIN_N): öğrenme iddiası yok, model değişmez.
        val recs = (0 until 19).flatMap { m ->
            listOf("1", "X", "2").mapIndexed { j, sk ->
                testRec("r$m$sk", matchId = "match$m", mk = "1x2", sk = sk, p = 0.8, result = j == 0, kickoff = 5000L + m)
            }
        }
        val s = Learner.run(recs, null, OpportunityEngine.MODEL_VERSION, 1L)
        assertTrue(s.groups.isEmpty() && s.events.isEmpty())
    }
}
