package com.savran.bahis

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class ClubEloAndMergeTest {
    private val csv = "Rank,Club,Country,Level,Elo,From,To\nNone,Galatasaray,TUR,1,1650.5,2026-01-01,2026-12-31\nNone,Sporting,POR,1,1700,2026-01-01,2026-12-31\nbozuk satir\nNone,Hatali,XXX,1,abc,2026-01-01,2026-12-31"

    @Test fun parserSkipsBadRowsAndNeverThrows() {
        val l = ClubEloParser.parse(csv)
        assertEquals(2, l.size)
        assertEquals(1650.5, l[0].elo, 1e-9)
        assertTrue(ClubEloParser.parse("").isEmpty())
        assertTrue(ClubEloParser.parse("<html>hata</html>").isEmpty())
        assertTrue(ClubEloParser.parse("a,b\n1,2").isEmpty())
    }

    @Test fun eloAdjustIsBoundedAndSymmetric() {
        val (h, a) = EloAdjust.factors(2400.0, 1400.0)
        assertTrue(h <= Math.exp(EloAdjust.MAX_LOG / 2) + 1e-9)
        assertEquals(1.0, h * a, 1e-9)
        val (h0, a0) = EloAdjust.factors(1500.0, 1500.0)
        assertEquals(1.0, h0, 1e-9)
        assertEquals(1.0, a0, 1e-9)
    }

    @Test fun eloFindReturnsNullWhenUnknown() {
        val t = ClubEloParser.parse(csv)
        assertNotNull(EloAdjust.find("Galatasaray", t))
        assertNull(EloAdjust.find("Bilinmeyen Takim FK", t))
    }

    private fun m(id: String, h: String, a: String, k: Long = 1000L) =
        Match(id, 2, "Şampiyonlar Ligi", h, a, k, "NS", null, null, null, null, "X")

    @Test fun sameMatchWithDifferentSpellingIsMerged() {
        val a = m("1", "Shakhtar Donetsk", "Sporting CP")
        val b = m("2", "FK Shakhtar Donetsk", "Sporting Clube de Portugal", 1000L + 600)
        assertTrue(FixtureMerge.sameMatch(a, b))
        assertEquals(1, FixtureMerge.merge(listOf(a), listOf(b)).size)
    }

    @Test fun differentMatchesStayApart() {
        val a = m("1", "Galatasaray", "Stuttgart")
        val b = m("2", "Real Madrid", "Barcelona")
        assertTrue(!FixtureMerge.sameMatch(a, b))
        val far = m("3", "Galatasaray", "Stuttgart", 1000L + 5 * 3600)
        assertTrue(!FixtureMerge.sameMatch(a, far))
    }
}
