package com.savran.bahis

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class SourceCatalogTest {
    @Test fun everySourceHasInfo() {
        SourceId.values().forEach { id -> assertEquals(id, SourceCatalog.info(id).id) }
        assertEquals(7, SourceId.values().size)
    }

    @Test fun keyRules() {
        listOf(SourceId.API_FOOTBALL, SourceId.FOOTBALL_DATA, SourceId.API_NINJAS, SourceId.ODDS_API)
            .forEach { assertTrue(it.title, it.needsKey) }
        assertFalse(SourceId.THESPORTSDB.needsKey)
        assertEquals("123", SourceId.THESPORTSDB.keyDefault)
        assertTrue(SourceId.THESPORTSDB.keyEditable)
        assertFalse(SourceId.OPENLIGADB.keyEditable)
        assertFalse(SourceId.STATSBOMB.keyEditable)
        // Eski sürümle uyumlu saklama adları
        assertEquals("api_key", SourceId.API_FOOTBALL.prefKey)
        assertEquals("odds_api_key", SourceId.ODDS_API.prefKey)
    }

    @Test fun coverageDoesNotClaimMoreThanTheServicesOffer() {
        // Football-Data.org ücretsiz plan ve API Ninjas: Süper Lig / 1. Lig yok
        listOf(SourceId.FOOTBALL_DATA, SourceId.API_NINJAS).forEach {
            val l = SourceCatalog.info(it).leagues
            assertFalse(l.contains(203)); assertFalse(l.contains(204)); assertFalse(l.contains(848))
        }
        assertEquals(setOf(39, 78, 140, 61, 135, 2), SourceCatalog.info(SourceId.FOOTBALL_DATA).leagues)
        assertEquals(setOf(39, 78, 140, 61, 135, 2, 3), SourceCatalog.info(SourceId.API_NINJAS).leagues)
        assertFalse(SourceCatalog.info(SourceId.FOOTBALL_DATA).leagues.contains(3))     // Avrupa Ligi ücretsiz planda yok
        assertEquals(setOf(78), SourceCatalog.info(SourceId.OPENLIGADB).leagues)
        assertTrue(SourceCatalog.info(SourceId.STATSBOMB).leagues.isEmpty())
        assertFalse(SourceCatalog.info(SourceId.ODDS_API).leagues.contains(204))
        assertEquals(FootballDataClient.codes.keys, SourceCatalog.info(SourceId.FOOTBALL_DATA).leagues)
        assertEquals(ApiNinjasClient.leagues.keys, SourceCatalog.info(SourceId.API_NINJAS).leagues)
        assertFalse(TheSportsDbClient.leagueIds.containsKey(204))
        assertFalse(TheSportsDbClient.leagueIds.containsKey(848))
        assertTrue(SourceCatalog.info(SourceId.ODDS_API).leagues.containsAll(listOf(135, 2, 3, 848)))
    }

    @Test fun leagueNames() {
        assertEquals("yok", SourceCatalog.leagueNames(emptyList()))
        assertEquals("Süper Lig, La Liga", SourceCatalog.leagueNames(listOf(203, 140)))
    }
}

class SourceParsingTest {
    @Test fun parseUtcHandlesZAndNoZ() {
        val a = parseUtc("2026-10-31T17:00:00Z")
        assertEquals(a, parseUtc("2026-10-31T17:00:00"))
        assertEquals(1793466000L, a)
        assertNull(parseUtc(null))
        assertNull(parseUtc(""))
        assertNull(parseUtc("yarın akşam"))
    }

    @Test fun statusMapping() {
        assertEquals("FT", FootballDataClient.status("FINISHED"))
        assertEquals("NS", FootballDataClient.status("TIMED"))
        assertEquals("HT", FootballDataClient.status("PAUSED"))
        assertEquals("LIVE", ApiNinjasClient.status("in_progress"))
        assertEquals("FT", ApiNinjasClient.status("final"))
        assertEquals("FT", TheSportsDbClient.status("Match Finished"))
        assertEquals("NS", TheSportsDbClient.status(null))
    }
}

class FixtureMergeTest {
    private fun m(id: String, lid: Int, h: String, a: String, t: Long, src: String, status: String = "NS", gh: Int? = null, ga: Int? = null, logo: String? = null) =
        Match(id, lid, "Lig", h, a, t, status, gh, ga, logo, null, src)

    @Test fun sameMatchRules() {
        val a = m("api-1", 39, "Arsenal", "Chelsea", 1000, "API-Football")
        assertTrue(FixtureMerge.sameMatch(a, m("fd-1", 39, "Arsenal", "Chelsea", 1000 + 3600, "Football-Data.org")))
        assertFalse(FixtureMerge.sameMatch(a, m("fd-2", 78, "Arsenal", "Chelsea", 1000, "Football-Data.org")))
        assertFalse(FixtureMerge.sameMatch(a, m("fd-3", 39, "Arsenal", "Chelsea", 1000 + 5 * 3600, "Football-Data.org")))
        assertFalse(FixtureMerge.sameMatch(a, m("fd-4", 39, "Arsenal", "Everton", 1000, "Football-Data.org")))
    }

    @Test fun mergeKeepsPrimaryAndCombinesSources() {
        val primary = m("api-1", 39, "Arsenal", "Chelsea", 1000, "API-Football")
        val extra = m("fd-1", 39, "Arsenal", "Chelsea", 1000, "Football-Data.org", logo = "x.png")
        val other = m("fd-9", 39, "Liverpool", "Everton", 500, "Football-Data.org")
        val merged = FixtureMerge.merge(listOf(primary), listOf(extra, other))
        assertEquals(2, merged.size)
        assertEquals("fd-9", merged[0].id)          // kickoff sırası
        val kept = merged[1]
        assertEquals("api-1", kept.id)               // öncelikli kaynak korunur
        assertEquals(listOf("API-Football", "Football-Data.org"), FixtureMerge.sources(kept))
        assertEquals("x.png", kept.homeLogo)         // eksik logo tamamlanır
    }

    @Test fun finishedResultFromOtherSourceIsTakenAsAWhole() {
        val primary = m("api-1", 39, "Arsenal", "Chelsea", 1000, "API-Football")
        val extra = m("fd-1", 39, "Arsenal", "Chelsea", 1000, "Football-Data.org", status = "FT", gh = 2, ga = 1)
        val r = FixtureMerge.merge(listOf(primary), listOf(extra)).single()
        assertEquals("FT", r.statusShort)
        assertEquals(2, r.homeGoals)
        assertEquals(1, r.awayGoals)
    }

    @Test fun noSourcesDuplicateOnRepeat() {
        val primary = m("api-1", 39, "Arsenal", "Chelsea", 1000, "API-Football")
        val once = FixtureMerge.merge(listOf(primary), listOf(m("fd-1", 39, "Arsenal", "Chelsea", 1000, "Football-Data.org")))
        val twice = FixtureMerge.merge(once, listOf(m("fd-1", 39, "Arsenal", "Chelsea", 1000, "Football-Data.org")))
        assertEquals(listOf("API-Football", "Football-Data.org"), FixtureMerge.sources(twice.single()))
    }
}

class VerifierTest {
    private val ref = listOf(NamedTotals("Arsenal", 9, 20, 5, 25), NamedTotals("Chelsea", 9, 15, 10, 17))

    @Test fun equalTotalsMatch() {
        val other = listOf(NamedTotals("Arsenal", 9, 20, 5, 25), NamedTotals("Chelsea", 9, 15, 10, 17))
        val (st, _) = Verifier.compare(ref[0], ref[1], other, "Arsenal", "Chelsea")
        assertEquals(CheckStatus.MATCH, st)
    }

    @Test fun differenceIsReportedNotHidden() {
        val other = listOf(NamedTotals("Arsenal", 10, 21, 5, 28), NamedTotals("Chelsea", 9, 15, 10, 17))
        val (st, note) = Verifier.compare(ref[0], ref[1], other, "Arsenal", "Chelsea")
        assertEquals(CheckStatus.DIFF, st)
        assertTrue(note.contains("oynanan 9 / 10"))
        assertTrue(note.contains("atılan 20 / 21"))
    }

    @Test fun missingTeamAndMissingReference() {
        val other = listOf(NamedTotals("Arsenal", 9, 20, 5, 25))
        assertEquals(CheckStatus.NOT_FOUND, Verifier.compare(ref[0], ref[1], other, "Arsenal", "Chelsea").first)
        val full = listOf(NamedTotals("Arsenal", 9, 20, 5, 25), NamedTotals("Chelsea", 9, 15, 10, 17))
        assertEquals(CheckStatus.NO_REF, Verifier.compare(null, null, full, "Arsenal", "Chelsea").first)
    }
}
