package com.savran.bahis

enum class CheckStatus(val tr: String) {
    REFERENCE("Referans"),
    MATCH("Eşleşti"),
    DIFF("Fark var"),
    NO_REF("Karşılaştırma yok"),
    NOT_FOUND("Takım bulunamadı"),
    UNSUPPORTED("Kapsam dışı"),
    DISABLED("Pasif"),
    ERROR("Hata")
}

data class SourceCheck(val source: SourceId, val status: CheckStatus, val note: String)

/** Kaynakların aynı takım için verdiği toplam istatistikleri karşılaştırır (oynanan, atılan, yenilen gol). */
object Verifier {
    fun find(rows: List<NamedTotals>, name: String): NamedTotals? {
        val best = TeamMatcher.bestMatch(name, rows.map { it.name }) ?: return null
        return rows.firstOrNull { it.name == best }
    }

    private fun describe(t: NamedTotals) = "${t.played} maç ${t.gf}-${t.ga}"

    private fun diff(label: String, ref: NamedTotals, other: NamedTotals): String? {
        val parts = ArrayList<String>()
        if (ref.played != other.played) parts.add("oynanan ${ref.played} / ${other.played}")
        if (ref.gf != other.gf) parts.add("atılan ${ref.gf} / ${other.gf}")
        if (ref.ga != other.ga) parts.add("yenilen ${ref.ga} / ${other.ga}")
        return if (parts.isEmpty()) null else "$label: " + parts.joinToString(", ")
    }

    fun compare(
        refHome: NamedTotals?, refAway: NamedTotals?, otherRows: List<NamedTotals>,
        homeName: String, awayName: String
    ): Pair<CheckStatus, String> {
        val h = find(otherRows, homeName)
        val a = find(otherRows, awayName)
        if (h == null || a == null) {
            val missing = listOfNotNull(if (h == null) homeName else null, if (a == null) awayName else null)
            return CheckStatus.NOT_FOUND to "Tabloda eşleşmeyen takım: ${missing.joinToString(", ")}"
        }
        if (refHome == null || refAway == null) {
            return CheckStatus.NO_REF to "Ana kaynak tablosu yok. Bu kaynakta: ev ${describe(h)}, dep. ${describe(a)}"
        }
        val diffs = listOfNotNull(diff("Ev", refHome, h), diff("Dep.", refAway, a))
        return if (diffs.isEmpty()) {
            CheckStatus.MATCH to "Ev ${describe(h)}, dep. ${describe(a)} (ana kaynakla aynı)"
        } else {
            CheckStatus.DIFF to diffs.joinToString("; ") + ". Kaynaklar farklı anlarda güncellenmiş olabilir; ana kaynak (ilk değer) esas alınır."
        }
    }
}
