package com.savran.bahis

import android.app.AlarmManager
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build

/**
 * Maç öncesi hatırlatma: telefonun kendi alarm + bildirim sistemi (ücretsiz, internet gerekmez).
 * Maçtan [BEFORE_MIN] dakika önce bildirim gelir. Telefon yeniden başlatılırsa açılışta yeniden kurulur.
 */
object Reminders {
    const val BEFORE_MIN = 30L
    private const val CHANNEL = "mac_hatirlatma"

    private fun code(matchId: String) = matchId.hashCode()

    private fun intent(ctx: Context, matchId: String, title: String): PendingIntent {
        val i = Intent(ctx, ReminderReceiver::class.java)
            .putExtra("matchId", matchId).putExtra("title", title)
        return PendingIntent.getBroadcast(ctx, code(matchId), i, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
    }

    fun isSet(settings: AppSettings, matchId: String): Boolean = settings.reminders().any { it.startsWith("$matchId|") }

    /** true: kuruldu; false: maç zamanı geçmiş/çok yakın. */
    fun set(ctx: Context, settings: AppSettings, m: Match): Boolean {
        val at = (m.kickoff - BEFORE_MIN * 60) * 1000
        if (at <= System.currentTimeMillis()) return false
        val title = "${m.home} - ${m.away}"
        schedule(ctx, m.id, title, at)
        val list = settings.reminders().filterNot { it.startsWith("${m.id}|") } + "${m.id}|${m.kickoff}|${title.replace("|", " ")}"
        settings.setReminders(list)
        return true
    }

    fun cancel(ctx: Context, settings: AppSettings, matchId: String) {
        val am = ctx.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        am.cancel(intent(ctx, matchId, ""))
        settings.setReminders(settings.reminders().filterNot { it.startsWith("$matchId|") })
    }

    private fun schedule(ctx: Context, matchId: String, title: String, atMs: Long) {
        val am = ctx.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        // Kesin alarm izni gerekmesin diye 10 dakikalık pencere (bildirim en geç maçtan ~20 dk önce gelir).
        am.setWindow(AlarmManager.RTC_WAKEUP, atMs, 10 * 60 * 1000L, intent(ctx, matchId, title))
    }

    /** Açılışta (veya uygulama başlarken) geçmemiş hatırlatmaları yeniden kurar, geçmişleri siler. */
    fun restore(ctx: Context, settings: AppSettings) {
        val now = System.currentTimeMillis()
        val keep = ArrayList<String>()
        for (line in settings.reminders()) {
            val p = line.split('|')
            val kick = p.getOrNull(1)?.toLongOrNull() ?: continue
            val at = (kick - BEFORE_MIN * 60) * 1000
            if (kick * 1000 <= now) continue
            if (at > now) schedule(ctx, p[0], p.getOrElse(2) { "Maç" }, at)
            keep.add(line)
        }
        settings.setReminders(keep)
    }

    fun ensureChannel(ctx: Context) {
        if (Build.VERSION.SDK_INT >= 26) {
            val nm = ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            if (nm.getNotificationChannel(CHANNEL) == null) {
                nm.createNotificationChannel(NotificationChannel(CHANNEL, "Maç hatırlatma", NotificationManager.IMPORTANCE_DEFAULT))
            }
        }
    }

    fun notify(ctx: Context, matchId: String, title: String) {
        ensureChannel(ctx)
        val open = PendingIntent.getActivity(
            ctx, code(matchId), Intent(ctx, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val n = android.app.Notification.Builder(ctx, CHANNEL)
            .setSmallIcon(android.R.drawable.ic_popup_reminder)
            .setContentTitle("Maç yaklaşıyor")
            .setContentText("$title · yaklaşık $BEFORE_MIN dk sonra başlıyor. Analizi yenileyebilirsin.")
            .setContentIntent(open)
            .setAutoCancel(true)
            .build()
        val nm = ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        try { nm.notify(code(matchId), n) } catch (e: SecurityException) { /* bildirim izni yok */ }
    }
}

class ReminderReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        try {
            if (intent.action == Intent.ACTION_BOOT_COMPLETED) {
                Reminders.restore(context, AppSettings(context))
                return
            }
            val id = intent.getStringExtra("matchId") ?: return
            Reminders.notify(context, id, intent.getStringExtra("title") ?: "Maç")
            val s = AppSettings(context)
            s.setReminders(s.reminders().filterNot { it.startsWith("$id|") })
        } catch (e: Exception) {
            // hatırlatma hatası uygulamayı etkilemez
        }
    }
}
