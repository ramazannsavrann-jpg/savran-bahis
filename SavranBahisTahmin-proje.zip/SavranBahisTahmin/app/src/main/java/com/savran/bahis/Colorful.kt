package com.savran.bahis

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/** Renkli tasarım yardımcıları: lig renkleri, olasılık halkası, 1-X-2 şeridi. */
object Palette {
    val HomeC = Color(0xFF38BDF8)   // ev sahibi: mavi
    val DrawC = Color(0xFFA78BFA)   // beraberlik: mor
    val AwayC = Color(0xFFFB923C)   // deplasman: turuncu
    val Pink = Color(0xFFF472B6)
    val Teal = Color(0xFF2DD4BF)
    val Lime = Color(0xFFA3E635)
    val Indigo = Color(0xFF818CF8)
    val Gold = Color(0xFFFACC15)

    /** Her lige ayırt edici bir renk (yalnızca görsel; resmî logo/renk kullanılmaz). */
    fun league(id: Int): Color = when (id) {
        203 -> Color(0xFFEF4444)    // Süper Lig
        204 -> Color(0xFFF97316)    // 1. Lig
        39 -> Color(0xFFA855F7)     // Premier League
        78 -> Color(0xFFE11D48)     // Bundesliga
        140 -> Color(0xFFF59E0B)    // La Liga
        61 -> Color(0xFF3B82F6)     // Ligue 1
        135 -> Color(0xFF06B6D4)    // Serie A
        2 -> Color(0xFF6366F1)      // Şampiyonlar Ligi
        3 -> Color(0xFFFB923C)      // Avrupa Ligi
        848 -> Color(0xFF22C55E)    // Konferans Ligi
        else -> MutedText
    }
}

/** Lig adı önünde renkli nokta. */
@Composable
fun LeagueDot(id: Int, size: Dp = 8.dp) {
    Box(Modifier.size(size).clip(CircleShape).background(Palette.league(id)))
}

/** Yuvarlak olasılık halkası; rengi güven seviyesinden gelir, ortada yüzde yazar. */
@Composable
fun ProbRing(p: Double, color: Color, size: Dp = 52.dp) {
    val target = p.toFloat().coerceIn(0f, 1f)
    val frac by animateFloatAsState(targetValue = target, animationSpec = tween(600), label = "ring")
    Box(Modifier.size(size), contentAlignment = Alignment.Center) {
        Canvas(Modifier.size(size)) {
            val w = this.size.minDimension * 0.12f
            val inset = w / 2
            val arcSize = androidx.compose.ui.geometry.Size(this.size.width - w, this.size.height - w)
            val tl = androidx.compose.ui.geometry.Offset(inset, inset)
            drawArc(Color(0x26FFFFFF), -90f, 360f, false, tl, arcSize, style = Stroke(w))
            drawArc(color, -90f, 360f * frac, false, tl, arcSize, style = Stroke(w, cap = StrokeCap.Round))
        }
        Text(pct(p), fontWeight = FontWeight.Bold, fontSize = (size.value * 0.27f).sp, color = color)
    }
}

/** Ev / beraberlik / deplasman olasılıkları tek renkli şeritte. */
@Composable
fun OneXTwoStrip(home: Double, draw: Double, away: Double) {
    val sum = (home + draw + away).takeIf { it > 0 } ?: return
    val h = (home / sum).toFloat()
    val d = (draw / sum).toFloat()
    val a = (away / sum).toFloat()
    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
        Row(Modifier.fillMaxWidth().height(14.dp).clip(RoundedCornerShape(7.dp))) {
            if (h > 0f) Box(Modifier.weight(h).height(14.dp).background(Palette.HomeC))
            if (d > 0f) Box(Modifier.weight(d).height(14.dp).background(Palette.DrawC))
            if (a > 0f) Box(Modifier.weight(a).height(14.dp).background(Palette.AwayC))
        }
        Row(Modifier.fillMaxWidth()) {
            Text("1 ${pct(home)}", color = Palette.HomeC, fontSize = 12.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
            Text("X ${pct(draw)}", color = Palette.DrawC, fontSize = 12.sp, fontWeight = FontWeight.Bold)
            Text("2 ${pct(away)}", color = Palette.AwayC, fontSize = 12.sp, fontWeight = FontWeight.Bold,
                modifier = Modifier.weight(1f), textAlign = androidx.compose.ui.text.style.TextAlign.End)
        }
    }
}
