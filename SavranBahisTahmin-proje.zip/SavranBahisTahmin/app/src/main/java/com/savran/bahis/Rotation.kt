package com.savran.bahis

import org.json.JSONArray
import org.json.JSONObject

data class Lineup(
    val fixtureId: Int,
    val timestamp: Long,
    val teamId: Int,
    val coachId: Int?,
    val coachName: String?,
    val formation: String?,
    val players: Set<Int>
)

data class RotationInfo(
    val teamId: Int,
    val matchesUsed: Int,
    val avgChanges: Double?,
    val lastChanges: Int?,
    val coachChanges: Int,
    val restDays: Int?,
    val risk: String,       // Düşük / Orta / Yüksek / Veri yok
    val note: String
)

/** Teknik direktör rotasyon analizi: son maçlardaki ilk 11 değişiklikleri, TD değişimi, dinlenme süresi. */
object Rotation {
    fun changes(a: Set<Int>, b: Set<Int>): Int = maxOf(a.size, b.size) - a.intersect(b).size

    fun riskOf(avg: Double?): String = when {
        avg == null -> "Veri yok"
        avg >= 4.0 -> "Yüksek"
        avg >= 2.5 -> "Orta"
        else -> "Düşük"
    }

    /** lineupsNewestFirst: en yeni maç başta. matchKickoff: analiz edilen maçın saati (epoch sn). */
    fun analyze(teamId: Int, lineupsNewestFirst: List<Lineup>, matchKickoff: Long): RotationInfo {
        val l = lineupsNewestFirst.filter { it.teamId == teamId && it.players.isNotEmpty() }.sortedByDescending { it.timestamp }
        val changes = (0 until maxOf(0, l.size - 1)).map { changes(l[it].players, l[it + 1].players) }
        val avg = if (changes.isEmpty()) null else changes.average()
        val coachChanges = (0 until maxOf(0, l.size - 1)).count {
            val a = l[it].coachId
            val b = l[it + 1].coachId
            a != null && b != null && a != b
        }
        val rest = l.firstOrNull()?.let { ((matchKickoff - it.timestamp) / 86400).toInt() }
        var risk = riskOf(avg)
        val notes = ArrayList<String>()
        if (avg != null) notes.add("Son ${changes.size + 1} maçta ilk 11'de ortalama ${"%.1f".format(avg)} değişiklik.")
        if (changes.isNotEmpty()) notes.add("Son maçta ${changes.first()} değişiklik.")
        if (coachChanges > 0) { notes.add("Son maçlarda teknik direktör değişimi var."); if (risk == "Düşük") risk = "Orta" }
        if (rest != null && rest < 4) { notes.add("Dinlenme süresi kısa ($rest gün)."); if (risk == "Düşük") risk = "Orta" }
        if (notes.isEmpty()) notes.add("Yeterli kadro verisi yok.")
        return RotationInfo(teamId, l.size, avg, changes.firstOrNull(), coachChanges, rest, risk, notes.joinToString(" "))
    }

    fun lineupToJson(l: Lineup): JSONObject = JSONObject()
        .put("fx", l.fixtureId).put("ts", l.timestamp).put("team", l.teamId)
        .put("coachId", l.coachId ?: JSONObject.NULL).put("coach", l.coachName ?: JSONObject.NULL)
        .put("formation", l.formation ?: JSONObject.NULL)
        .put("players", JSONArray(l.players.toList()))

    fun lineupFromJson(o: JSONObject): Lineup {
        val pa = o.getJSONArray("players")
        return Lineup(
            o.getInt("fx"), o.getLong("ts"), o.getInt("team"),
            if (o.isNull("coachId")) null else o.getInt("coachId"),
            if (o.isNull("coach")) null else o.getString("coach"),
            if (o.isNull("formation")) null else o.getString("formation"),
            (0 until pa.length()).map { pa.getInt(it) }.toSet()
        )
    }

    /** /fixtures/lineups yanıtından verilen takımın ilk 11'i. */
    fun parseLineup(body: String, fixtureId: Int, ts: Long, teamId: Int): Lineup? {
        return try {
            val arr = JSONObject(body).optJSONArray("response") ?: return null
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                if (o.getJSONObject("team").getInt("id") != teamId) continue
                val xi = o.optJSONArray("startXI") ?: return null
                val players = (0 until xi.length()).mapNotNull { xi.getJSONObject(it).optJSONObject("player")?.optInt("id", 0)?.takeIf { id -> id > 0 } }.toSet()
                val coach = o.optJSONObject("coach")
                return Lineup(
                    fixtureId, ts, teamId,
                    coach?.let { if (it.isNull("id")) null else it.getInt("id") },
                    coach?.let { if (it.isNull("name")) null else it.getString("name") },
                    if (o.isNull("formation")) null else o.optString("formation"),
                    players
                )
            }
            null
        } catch (e: Exception) {
            null
        }
    }
}
