package com.savran.bahis

import java.util.Locale

/** Performans ekranındaki verileri, sohbete yapıştırılabilecek düz metne çevirir. Yalnızca gerçek kayıtlı veriler; hiçbir şey eklenmez. */
object PerformanceExport {
    private fun p(x: Double?): String = if (x == null) "-" else "%" + Math.round(x * 100)
    private fun f3(x: Double?): String = if (x == null) "-" else "%.3f".format(Locale.US, x)

    fun build(r: Report, pr: PeriodReport, learning: LearningState?, nowMs: Long, marketCompare: String? = null): String {
        val sb = StringBuilder()
        sb.appendLine("SAVRAN ANALİZ - PERFORMANS RAPORU")
        sb.appendLine("Oluşturulma (epoch ms): $nowMs · Model sürümü: ${OpportunityEngine.MODEL_VERSION}")
        sb.appendLine()
        sb.appendLine("== TÜM ZAMANLAR (yalnızca önerilen seçimler, otomatik model) ==")
        sb.appendLine("Toplam kayıt: ${r.total} · Sonuçlanan: ${r.settled} · Doğru/Yanlış: ${r.correct}/${r.wrong}")
        sb.appendLine("Başarı: ${p(r.hitRate)} · Brier: ${f3(r.brier)} (hep %50 diyen model 0.250) · LogLoss: ${f3(r.logLoss)}")
        sb.appendLine("Manuel λ ile sonuçlanan (hariç): ${r.manualSettled}")
        if (marketCompare != null) sb.appendLine("Model - piyasa (kapanış) kıyası: $marketCompare")
        if (r.settled < Metrics.MIN_FOR_HISTORY_SCORE) sb.appendLine("UYARI: örnek az (${r.settled} < ${Metrics.MIN_FOR_HISTORY_SCORE}); sonuç güvenilir değil.")
        sb.appendLine()
        sb.appendLine("== DÖNEM: ${pr.period.tr} ==")
        sb.appendLine("Kayıt: ${pr.total} · Sonuçlanan: ${pr.settled} · Doğru: ${pr.correct} · Yanlış: ${pr.wrong} · Başarı: ${p(pr.hitRate)}")
        sb.appendLine("Önceki dönem: ${pr.previous.settled} tahmin · ${p(pr.previous.hitRate)}")
        sb.appendLine("Pazara göre:")
        pr.byMarket.forEach { sb.appendLine("  ${it.label}: n=${it.n}, doğru=${it.correct}, ${p(it.rate)}") }
        sb.appendLine("Lige göre:")
        pr.byLeague.forEach { sb.appendLine("  ${it.label}: n=${it.n}, doğru=${it.correct}, ${p(it.rate)}") }
        sb.appendLine()
        sb.appendLine("== KALİBRASYON (tahmin → gerçek) ==")
        if (r.bins.isEmpty()) sb.appendLine("  veri yok")
        r.bins.forEach { sb.appendLine("  ${it.label}: n=${it.count}, tahmin ${p(it.meanPredicted)} → gerçek ${p(it.hitRate)}") }
        sb.appendLine()
        sb.appendLine("== SON TAHMİNLER ==")
        r.recent.forEach { sb.appendLine("  Son ${it.window}: n=${it.n}, başarı ${p(it.hitRate)}, Brier ${f3(it.brier)}") }
        sb.appendLine()
        sb.appendLine("== PAZAR GRUBU (tüm zamanlar) ==")
        r.byMarketGroup.entries.sortedBy { it.key }.forEach { (k, v) -> sb.appendLine("  $k: n=${v.first}, doğru=${v.second}, ${p(v.third)}") }
        sb.appendLine("== LİG (tüm zamanlar) ==")
        r.byLeague.entries.sortedBy { it.key }.forEach { (k, v) -> sb.appendLine("  $k: n=${v.first}, doğru=${v.second}, ${p(v.third)}") }
        sb.appendLine()
        sb.appendLine("== ÖĞRENME ==")
        if (learning == null || (learning.samples.isEmpty() && learning.events.isEmpty())) {
            sb.appendLine("  Henüz öğrenme verisi yok.")
        } else {
            learning.samples.entries.sortedBy { it.key }.forEach { (g, n) ->
                sb.appendLine("  ${Calibration.groupLabel(g)}: n=$n, " + (if (learning.groups[g] != null) "kalibrasyon aktif" else "kalibrasyon yok"))
            }
            if (learning.weak.isNotEmpty()) sb.appendLine("  Zayıf pazarlar: " + learning.weak.joinToString(", ") { Calibration.groupLabel(it) })
            learning.events.takeLast(5).forEach {
                sb.appendLine("  ${Calibration.groupLabel(it.group)} n=${it.n}: Brier ${"%.4f".format(Locale.US, it.brierBefore)} → ${"%.4f".format(Locale.US, it.brierAfter)} · " + (if (it.adopted) "devreye alındı" else "alınmadı"))
            }
        }
        sb.appendLine()
        sb.appendLine("== GETİRİ (gerçek oranı olanlar, geçmiş ölçüm) ==")
        sb.appendLine("  n=${r.roiN} · birim getiri: ${r.unitReturn?.let { "%.2f".format(Locale.US, it) } ?: "-"} · ROI: ${r.roi?.let { p(it) } ?: "-"}")
        return sb.toString()
    }
}
