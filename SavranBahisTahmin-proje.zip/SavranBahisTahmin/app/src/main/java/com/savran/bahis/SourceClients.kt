package com.savran.bahis

import org.json.JSONArray
import org.json.JSONObject
import java.time.Instant
import java.time.LocalDate
import java.time.ZoneId

/** Tüm kaynaklarda ortak: bir kaynağın tablodaki bir takımının toplam istatistiği (doğrulama için). */
data class NamedTotals(val name: String, val played: Int, val gf: Int, val ga: Int, val points: Int?)

private fun localDate(epochSec: Long, zone: ZoneId): LocalDate = Instant.ofEpochSecond(epochSec).atZone(zone).toLocalDate()

private fun splitStats(o: JSONObject) = SplitStats(o.getInt("playedGames"), o.getInt("goalsFor"), o.getInt("goalsAgainst"))

private fun leagueNameOf(id: Int) = Leagues.byId(id)?.nameTr ?: "Lig $id"

// ================================================================== Football-Data.org

class FootballDataClient(private val settings: AppSettings) {
    companion object {
        /** Ücretsiz planda kapsanan, bizim 6 ligimizden olanlar. Süper Lig ve 1. Lig bu kaynakta yok. */
        val codes = mapOf(39 to "PL", 78 to "BL1", 140 to "PD", 61 to "FL1", 135 to "SA", 2 to "CL")
        fun status(s: String): String = when (s) {
            "SCHEDULED", "TIMED" -> "NS"
            "IN_PLAY" -> "LIVE"
            "PAUSED" -> "HT"
            "FINISHED" -> "FT"
            "POSTPONED" -> "PST"
            "SUSPENDED" -> "SUSP"
            "CANCELLED" -> "CANC"
            "AWARDED" -> "AWD"
            else -> "NS"
        }
    }

    private val src = SourceId.FOOTBALL_DATA
    private val base = "https://api.football-data.org/v4"

    suspend fun fixtures(key: String, date: LocalDate, zone: ZoneId): ApiResult<List<Match>> = guarded(src) {
        Throttle.wait(src, 6500)
        // Tek gün yerine ±1 gün istenir, yerelde süzülür (saat dilimi kaymalarına karşı).
        val url = "$base/matches?dateFrom=${date.minusDays(1)}&dateTo=${date.plusDays(1)}&competitions=${codes.values.joinToString(",")}"
        val r = httpGet(settings, src, url, mapOf("X-Auth-Token" to key))
        if (r.code !in 200..299) return@guarded httpErr(src, r.code, r.body)
        ApiResult.Ok(parseMatches(r.body).filter { localDate(it.kickoff, zone) == date })
    }

    private fun parseMatches(body: String): List<Match> {
        val arr = JSONObject(body).optJSONArray("matches") ?: return emptyList()
        val out = ArrayList<Match>()
        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            val code = o.optJSONObject("competition")?.optString("code") ?: continue
            val lid = codes.entries.firstOrNull { it.value == code }?.key ?: continue
            val h = o.getJSONObject("homeTeam")
            val a = o.getJSONObject("awayTeam")
            val sc = o.optJSONObject("score")
            val ft = sc?.optJSONObject("fullTime")
            val ht = sc?.optJSONObject("halfTime")
            val kickoff = parseUtc(o.looseStr("utcDate")) ?: continue
            out.add(
                Match(
                    id = "fd-${o.getInt("id")}", leagueId = lid, leagueName = leagueNameOf(lid),
                    home = h.getString("name"), away = a.getString("name"), kickoff = kickoff,
                    statusShort = status(o.optString("status")),
                    homeGoals = ft?.looseInt("home"), awayGoals = ft?.looseInt("away"),
                    homeLogo = h.looseStr("crest")?.takeIf { it.endsWith(".png") },
                    awayLogo = a.looseStr("crest")?.takeIf { it.endsWith(".png") },
                    source = src.title,
                    homeHt = ht?.looseInt("home"), awayHt = ht?.looseInt("away")
                )
            )
        }
        return out
    }

    /** Güncel sezon puan durumu: genel, iç saha ve deplasman tabloları (model için gerekli). */
    suspend fun table(key: String, leagueId: Int, season: Int, now: Long): ApiResult<LeagueTable> = guarded(src) {
        val code = codes[leagueId] ?: return@guarded ApiResult.Err("${src.title}: bu lig kapsamında yok.")
        Throttle.wait(src, 6500)
        val r = httpGet(settings, src, "$base/competitions/$code/standings?season=$season", mapOf("X-Auth-Token" to key))
        if (r.code !in 200..299) return@guarded httpErr(src, r.code, r.body)
        parseTable(r.body, leagueId, season, now)
    }

    internal fun parseTable(body: String, leagueId: Int, season: Int, now: Long): ApiResult<LeagueTable> {
        val arr = JSONObject(body).optJSONArray("standings")
            ?: return ApiResult.Err("${src.title}: puan durumu yanıtı boş.")
        fun byType(type: String): Map<Int, JSONObject> {
            val out = LinkedHashMap<Int, JSONObject>()
            for (i in 0 until arr.length()) {
                val st = arr.getJSONObject(i)
                if (st.optString("type") != type) continue
                val t = st.getJSONArray("table")
                for (j in 0 until t.length()) {
                    val row = t.getJSONObject(j)
                    out[row.getJSONObject("team").getInt("id")] = row   // kupalarda tüm grupları birleştirir
                }
            }
            return out
        }
        val total = byType("TOTAL")
        val home = byType("HOME")
        val away = byType("AWAY")
        if (total.isEmpty()) return ApiResult.Err("${src.title}: bu sezon için puan durumu yok.")
        if (home.isEmpty() || away.isEmpty()) {
            return ApiResult.Err("${src.title}: iç saha/deplasman tabloları gelmedi; model için kullanılamaz.")
        }
        val rows = ArrayList<TeamRow>()
        for ((id, t) in total) {
            val h = home[id] ?: return ApiResult.Err("${src.title}: iç saha tablosu eksik.")
            val a = away[id] ?: return ApiResult.Err("${src.title}: deplasman tablosu eksik.")
            rows.add(
                TeamRow(
                    teamId = -id,   // negatif: API-Football takım no'larıyla asla çakışmaz, eşleşme ada göre yapılır
                    name = t.getJSONObject("team").getString("name"),
                    rank = t.getInt("position"), points = t.getInt("points"),
                    all = splitStats(t), home = splitStats(h), away = splitStats(a),
                    form = t.looseStr("form") ?: ""
                )
            )
        }
        return ApiResult.Ok(LeagueTable(leagueId, season, now, rows, SourceId.FOOTBALL_DATA.title))
    }

    /** Sezonun bitmiş maç sonuçları (tek istek). Puan durumu alınamadığında tablo bunlardan hesaplanır. */
    suspend fun finishedResults(key: String, leagueId: Int, season: Int): ApiResult<List<FinishedResult>> = guarded(src) {
        val code = codes[leagueId] ?: return@guarded ApiResult.Err("${src.title}: bu lig kapsamında yok.")
        Throttle.wait(src, 6500)
        val r = httpGet(settings, src, "$base/competitions/$code/matches?status=FINISHED&season=$season", mapOf("X-Auth-Token" to key))
        if (r.code !in 200..299) return@guarded httpErr(src, r.code, r.body)
        val arr = JSONObject(r.body).optJSONArray("matches") ?: return@guarded ApiResult.Err("${src.title}: sonuç listesi boş.")
        val out = ArrayList<FinishedResult>()
        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            val ft = o.optJSONObject("score")?.optJSONObject("fullTime") ?: continue
            val hg = ft.looseInt("home") ?: continue
            val ag = ft.looseInt("away") ?: continue
            val t = parseUtc(o.looseStr("utcDate")) ?: continue
            out.add(FinishedResult(o.getJSONObject("homeTeam").getString("name"), o.getJSONObject("awayTeam").getString("name"), hg, ag, t))
        }
        ApiResult.Ok(out)
    }

    suspend fun test(key: String): ApiResult<String> = guarded(src) {
        Throttle.wait(src, 6500)
        val r = httpGet(settings, src, "$base/competitions", mapOf("X-Auth-Token" to key))
        if (r.code !in 200..299) return@guarded httpErr(src, r.code, r.body)
        val arr = JSONObject(r.body).optJSONArray("competitions") ?: JSONArray()
        val avail = (0 until arr.length()).map { arr.getJSONObject(it).optString("code") }.toSet()
        val have = codes.filterValues { it in avail }.keys
        val missing = Leagues.supported.map { it.id }.filter { it !in have }
        ApiResult.Ok(
            "Bağlantı tamam. Anahtar ${avail.size} yarışmaya erişiyor. Kapsanan ligler: ${SourceCatalog.leagueNames(have)}. " +
                "Bu kaynakta olmayan: ${SourceCatalog.leagueNames(missing)}."
        )
    }
}

// ================================================================== API Ninjas Football

class ApiNinjasClient(private val settings: AppSettings) {
    companion object {
        val leagues = mapOf(39 to "epl", 78 to "bundesliga", 140 to "laliga", 61 to "ligue1", 135 to "seriea", 2 to "ucl", 3 to "uel")
        fun status(s: String): String = when (s) {
            "scheduled", "delayed" -> "NS"
            "in_progress" -> "LIVE"
            "final" -> "FT"
            "postponed" -> "PST"
            "canceled" -> "CANC"
            "suspended" -> "SUSP"
            else -> "NS"
        }
    }

    private val src = SourceId.API_NINJAS
    private val base = "https://api.api-ninjas.com/v1"

    /** Her lig için ayrı istek (4 istek). Tarih, ligin kendi saat dilimindeki maç günüdür. */
    suspend fun fixtures(key: String, date: LocalDate): ApiResult<List<Match>> = guarded(src) {
        val out = ArrayList<Match>()
        var firstErr: ApiResult.Err? = null
        for ((lid, code) in leagues) {
            Throttle.wait(src, 400)
            val r = httpGet(settings, src, "$base/soccermatches?league=$code&date=$date", mapOf("X-Api-Key" to key))
            if (r.code !in 200..299) {
                if (firstErr == null) firstErr = httpErr(src, r.code, r.body)
                if (r.code == 401 || r.code == 403 || r.code == 429) break
                continue
            }
            out.addAll(parseMatches(r.body, lid))
        }
        val e = firstErr
        if (out.isEmpty() && e != null) e else ApiResult.Ok(out)
    }

    private fun parseMatches(body: String, lid: Int): List<Match> {
        val arr = JSONArray(body)
        val out = ArrayList<Match>()
        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            val kickoff = parseUtc(o.looseStr("start_time")) ?: continue
            val ps = o.optJSONObject("period_scores")
            // Canlı maçta bu alanlar "yalnızca premium" metni döner; sayı değilse null kalır.
            val hHt = ps?.optJSONArray("home")?.let { if (it.length() > 0) (it.opt(0) as? Number)?.toInt() else null }
            val aHt = ps?.optJSONArray("away")?.let { if (it.length() > 0) (it.opt(0) as? Number)?.toInt() else null }
            out.add(
                Match(
                    id = "an-" + o.getString("game_id"), leagueId = lid, leagueName = leagueNameOf(lid),
                    home = o.getJSONObject("home_team").getString("name"),
                    away = o.getJSONObject("away_team").getString("name"),
                    kickoff = kickoff, statusShort = status(o.optString("status")),
                    homeGoals = o.looseInt("home_score"), awayGoals = o.looseInt("away_score"),
                    homeLogo = null, awayLogo = null, source = src.title,
                    homeHt = hHt, awayHt = aHt
                )
            )
        }
        return out
    }

    suspend fun standings(key: String, leagueId: Int, season: Int): ApiResult<List<NamedTotals>> = guarded(src) {
        val code = leagues[leagueId] ?: return@guarded ApiResult.Err("${src.title}: bu lig kapsamında yok.")
        Throttle.wait(src, 400)
        val r = httpGet(settings, src, "$base/soccerstandings?league=$code&season=$season", mapOf("X-Api-Key" to key))
        if (r.code !in 200..299) return@guarded httpErr(src, r.code, r.body)
        val arr = JSONArray(r.body)
        val rows = (0 until arr.length()).map {
            val o = arr.getJSONObject(it)
            NamedTotals(
                o.getJSONObject("team").getString("name"), o.optInt("games_played"),
                o.optInt("goals_for"), o.optInt("goals_against"), o.looseInt("points")
            )
        }
        if (rows.isEmpty()) ApiResult.Err("${src.title}: bu sezon için puan durumu boş.") else ApiResult.Ok(rows)
    }

    suspend fun test(key: String): ApiResult<String> = guarded(src) {
        Throttle.wait(src, 400)
        val r = httpGet(settings, src, "$base/soccerstandings?league=epl", mapOf("X-Api-Key" to key))
        if (r.code !in 200..299) return@guarded httpErr(src, r.code, r.body)
        val n = JSONArray(r.body).length()
        ApiResult.Ok(
            "Bağlantı tamam (Premier League tablosu: $n takım). Kapsanan ligler: ${SourceCatalog.leagueNames(leagues.keys)}. " +
                "Bu kaynakta olmayan: ${SourceCatalog.leagueNames(Leagues.supported.map { it.id }.filter { it !in leagues.keys })}. Ücretsiz planda yalnızca güncel sezon."
        )
    }
}

// ================================================================== TheSportsDB

class TheSportsDbClient(private val settings: AppSettings) {
    companion object {
        /** Bizim lig no -> TheSportsDB lig no. Bağlantı testi bu eşleşmeleri gerçekten doğrular. */
        val leagueIds = mapOf(203 to "4339", 39 to "4328", 78 to "4331", 140 to "4335", 61 to "4334", 135 to "4332", 2 to "4480", 3 to "4481", 848 to "5071")
        private val nameHint = mapOf(203 to "turk", 39 to "premier", 78 to "bundesliga", 140 to "liga", 61 to "ligue 1", 135 to "serie a", 2 to "champions", 3 to "europa league", 848 to "conference")
        fun status(s: String?): String {
            val t = (s ?: "").lowercase()
            return when {
                t.contains("finish") || t == "ft" -> "FT"
                t.contains("postpon") -> "PST"
                t.contains("cancel") -> "CANC"
                else -> "NS"
            }
        }
    }

    private val src = SourceId.THESPORTSDB
    private fun base(key: String) = "https://www.thesportsdb.com/api/v1/json/$key"
    private val memo = HashMap<String, Pair<Long, List<Match>>>()

    private suspend fun leagueEvents(key: String, lid: Int, withPast: Boolean): ApiResult<List<Match>> {
        val id = leagueIds[lid] ?: return ApiResult.Err("${src.title}: bu lig kapsamında yok.")
        val memoKey = "$key|$lid|$withPast"
        val now = System.currentTimeMillis()
        synchronized(memo) { memo[memoKey] }?.let { if (now - it.first < 3L * 3600 * 1000) return ApiResult.Ok(it.second) }
        val out = ArrayList<Match>()
        val endpoints = if (withPast) listOf("eventsnextleague.php", "eventspastleague.php") else listOf("eventsnextleague.php")
        for (ep in endpoints) {
            Throttle.wait(src, 2100)   // dakikada 30 istek
            val r = httpGet(settings, src, "${base(key)}/$ep?id=$id")
            if (r.code !in 200..299) return httpErr(src, r.code, r.body)
            val arr = JSONObject(r.body).optJSONArray("events") ?: continue
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                // Lig kimliği yanlış eşleşmişse başka ligin maçı bu lige yazılmasın: lig adı doğrulanır.
                val lname = o.looseStr("strLeague")?.lowercase()
                val hint = nameHint[lid]
                if (lname != null && hint != null && !lname.contains(hint)) continue
                val kickoff = parseUtc(o.looseStr("strTimestamp"))
                    ?: parseUtc((o.looseStr("dateEvent") ?: "") + "T" + (o.looseStr("strTime") ?: "00:00:00"))
                    ?: continue
                out.add(
                    Match(
                        id = "ts-" + o.getString("idEvent"), leagueId = lid, leagueName = leagueNameOf(lid),
                        home = o.getString("strHomeTeam"), away = o.getString("strAwayTeam"), kickoff = kickoff,
                        statusShort = status(o.looseStr("strStatus")),
                        homeGoals = o.looseInt("intHomeScore"), awayGoals = o.looseInt("intAwayScore"),
                        homeLogo = o.looseStr("strHomeTeamBadge"), awayLogo = o.looseStr("strAwayTeamBadge"),
                        source = src.title
                    )
                )
            }
        }
        synchronized(memo) { memo[memoKey] = now to out }
        return ApiResult.Ok(out)
    }

    suspend fun fixtures(key: String, date: LocalDate, zone: ZoneId, today: LocalDate): ApiResult<List<Match>> = guarded(src) {
        val out = ArrayList<Match>()
        var firstErr: ApiResult.Err? = null
        for (lid in leagueIds.keys) {
            when (val r = leagueEvents(key, lid, withPast = date.isBefore(today))) {
                is ApiResult.Ok -> out.addAll(r.value)
                is ApiResult.Err -> {
                    if (firstErr == null) firstErr = r
                    if (r.message.contains("429")) break
                }
            }
        }
        val e = firstErr
        if (out.isEmpty() && e != null) e else ApiResult.Ok(out.filter { localDate(it.kickoff, zone) == date })
    }

    suspend fun table(key: String, leagueId: Int, season: Int): ApiResult<List<NamedTotals>> = guarded(src) {
        val id = leagueIds[leagueId] ?: return@guarded ApiResult.Err("${src.title}: bu lig kapsamında yok.")
        Throttle.wait(src, 2100)
        val r = httpGet(settings, src, "${base(key)}/lookuptable.php?l=$id&s=$season-${season + 1}")
        if (r.code !in 200..299) return@guarded httpErr(src, r.code, r.body)
        val arr = JSONObject(r.body).optJSONArray("table")
            ?: return@guarded ApiResult.Err("${src.title}: bu lig/sezon için puan durumu dönmedi (ücretsiz anahtar kısıtlı olabilir).")
        val rows = (0 until arr.length()).map {
            val o = arr.getJSONObject(it)
            NamedTotals(
                o.getString("strTeam"), o.looseInt("intPlayed") ?: 0, o.looseInt("intGoalsFor") ?: 0,
                o.looseInt("intGoalsAgainst") ?: 0, o.looseInt("intPoints")
            )
        }
        if (rows.isEmpty()) ApiResult.Err("${src.title}: puan durumu boş.") else ApiResult.Ok(rows)
    }

    /** Her eşlenen lig kimliğini gerçekten sorgular; ad uyuşmuyorsa kapsam dışı sayar. */
    suspend fun test(key: String): ApiResult<String> = guarded(src) {
        val ok = ArrayList<Int>()
        val bad = ArrayList<Int>()
        for ((lid, id) in leagueIds) {
            Throttle.wait(src, 2100)
            val r = httpGet(settings, src, "${base(key)}/lookupleague.php?id=$id")
            if (r.code !in 200..299) return@guarded httpErr(src, r.code, r.body)
            val name = JSONObject(r.body).optJSONArray("leagues")?.optJSONObject(0)?.looseStr("strLeague")?.lowercase() ?: ""
            if (name.contains(nameHint[lid] ?: "?")) ok.add(lid) else bad.add(lid)
        }
        val note = if (key == "123") " Ortak ücretsiz anahtar (123) kullanılıyor; sonuç sayısı sınırlı." else ""
        ApiResult.Ok(
            "Bağlantı tamam. Doğrulanan ligler: ${SourceCatalog.leagueNames(ok)}." +
                (if (bad.isNotEmpty()) " Doğrulanamayan: ${SourceCatalog.leagueNames(bad)}." else "") +
                " 1. Lig bu kaynakta eşlenmedi.$note"
        )
    }
}

// ================================================================== OpenLigaDB (yalnızca Bundesliga)

class OpenLigaClient(private val settings: AppSettings) {
    private val src = SourceId.OPENLIGADB
    private val base = "https://api.openligadb.de"
    private val memo = HashMap<Int, Pair<Long, List<Match>>>()

    /** Bitmiş Bundesliga maçları (sezonun tamamı tek istekte; 3 saat önbellek). */
    suspend fun finishedResults(season: Int): ApiResult<List<FinishedResult>> {
        val a = fixturesAll(season)
        return when (a) {
            is ApiResult.Err -> a
            is ApiResult.Ok -> ApiResult.Ok(
                a.value.filter { it.statusShort == "FT" && it.homeGoals != null && it.awayGoals != null }
                    .map { FinishedResult(it.home, it.away, it.homeGoals ?: 0, it.awayGoals ?: 0, it.kickoff) }
            )
        }
    }

    private suspend fun fixturesAll(season: Int): ApiResult<List<Match>> = guarded(src) {
        val now = System.currentTimeMillis()
        val cached = synchronized(memo) { memo[season] }
        if (cached != null && now - cached.first < 3L * 3600 * 1000) return@guarded ApiResult.Ok(cached.second)
        Throttle.wait(src, 1000)
        val r = httpGet(settings, src, "$base/getmatchdata/bl1/$season")
        if (r.code !in 200..299) return@guarded httpErr(src, r.code, r.body)
        val parsed = parseMatches(r.body)
        synchronized(memo) { memo[season] = now to parsed }
        ApiResult.Ok(parsed)
    }

    suspend fun fixtures(date: LocalDate, zone: ZoneId, season: Int): ApiResult<List<Match>> = guarded(src) {
        val now = System.currentTimeMillis()
        val cached = synchronized(memo) { memo[season] }
        val all: List<Match> = if (cached != null && now - cached.first < 3L * 3600 * 1000) {
            cached.second
        } else {
            Throttle.wait(src, 1000)
            val r = httpGet(settings, src, "$base/getmatchdata/bl1/$season")
            if (r.code !in 200..299) return@guarded httpErr(src, r.code, r.body)
            val parsed = parseMatches(r.body)
            synchronized(memo) { memo[season] = now to parsed }
            parsed
        }
        ApiResult.Ok(all.filter { localDate(it.kickoff, zone) == date })
    }

    private fun parseMatches(body: String): List<Match> {
        val arr = JSONArray(body)
        val out = ArrayList<Match>()
        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            val raw = o.looseStr("matchDateTimeUTC") ?: continue
            val kickoff = parseUtc(if (raw.endsWith("Z")) raw else raw + "Z") ?: continue
            val t1 = o.getJSONObject("team1")
            val t2 = o.getJSONObject("team2")
            val finished = o.optBoolean("matchIsFinished", false)
            var ftH: Int? = null; var ftA: Int? = null; var htH: Int? = null; var htA: Int? = null
            val results = o.optJSONArray("matchResults")
            if (results != null) {
                for (j in 0 until results.length()) {
                    val rr = results.getJSONObject(j)
                    when (rr.optInt("resultTypeID")) {
                        2 -> { ftH = rr.looseInt("pointsTeam1"); ftA = rr.looseInt("pointsTeam2") }
                        1 -> { htH = rr.looseInt("pointsTeam1"); htA = rr.looseInt("pointsTeam2") }
                    }
                }
            }
            out.add(
                Match(
                    id = "ol-${o.getInt("matchID")}", leagueId = 78, leagueName = leagueNameOf(78),
                    home = t1.getString("teamName"), away = t2.getString("teamName"), kickoff = kickoff,
                    statusShort = if (finished) "FT" else "NS",
                    homeGoals = if (finished) ftH else null, awayGoals = if (finished) ftA else null,
                    homeLogo = t1.looseStr("teamIconUrl"), awayLogo = t2.looseStr("teamIconUrl"),
                    source = src.title, homeHt = if (finished) htH else null, awayHt = if (finished) htA else null
                )
            )
        }
        return out
    }

    suspend fun table(season: Int): ApiResult<List<NamedTotals>> = guarded(src) {
        Throttle.wait(src, 1000)
        val r = httpGet(settings, src, "$base/getbltable/bl1/$season")
        if (r.code !in 200..299) return@guarded httpErr(src, r.code, r.body)
        val arr = JSONArray(r.body)
        val rows = (0 until arr.length()).map {
            val o = arr.getJSONObject(it)
            NamedTotals(o.getString("teamName"), o.optInt("matches"), o.optInt("goals"), o.optInt("opponentGoals"), o.looseInt("points"))
        }
        if (rows.isEmpty()) ApiResult.Err("${src.title}: bu sezon için tablo boş.") else ApiResult.Ok(rows)
    }

    suspend fun test(season: Int): ApiResult<String> = guarded(src) {
        Throttle.wait(src, 1000)
        val r = httpGet(settings, src, "$base/getavailableleagues")
        if (r.code !in 200..299) return@guarded httpErr(src, r.code, r.body)
        val arr = JSONArray(r.body)
        var found = false
        var seasons = ""
        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            if (o.optString("leagueShortcut") == "bl1") {
                if (o.optInt("leagueSeason") == season) found = true
                seasons += (if (seasons.isEmpty()) "" else ", ") + o.optInt("leagueSeason")
            }
        }
        if (found) ApiResult.Ok("Bağlantı tamam. Bundesliga (bl1) $season sezonu mevcut. Bu kaynakta yalnızca Bundesliga var; diğer 5 lig kapsam dışı.")
        else ApiResult.Err("${src.title}: bağlantı tamam ama Bundesliga $season sezonu listede yok (mevcut: ${seasons.ifEmpty { "-" }}). Ayarlardan sezonu kontrol et.")
    }
}

// ================================================================== StatsBomb Open Data (geçmiş, statik)

class StatsBombClient(private val settings: AppSettings) {
    private val src = SourceId.STATSBOMB
    private val url = "https://raw.githubusercontent.com/statsbomb/open-data/master/data/competitions.json"

    /** Statik dosya erişimini ve 6 ligimizin geçmiş kapsamını gerçekten okuyup raporlar. */
    suspend fun test(): ApiResult<String> = guarded(src) {
        val r = httpGet(settings, src, url)
        if (r.code !in 200..299) return@guarded httpErr(src, r.code, r.body)
        val arr = JSONArray(r.body)
        val hints = listOf(
            "Süper Lig" to listOf("super lig", "süper lig"),
            "Premier League" to listOf("premier league"),
            "Bundesliga" to listOf("bundesliga"),
            "La Liga" to listOf("la liga"),
            "Ligue 1" to listOf("ligue 1")
        )
        val seasonsBy = HashMap<String, MutableSet<String>>()
        var latest = ""
        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            val name = o.optString("competition_name").lowercase()
            val season = o.optString("season_name")
            if (season > latest) latest = season
            for ((label, keys) in hints) {
                if (keys.any { name.contains(it) }) seasonsBy.getOrPut(label) { sortedSetOf<String>() }.add(season)
            }
        }
        val cover = hints.joinToString("; ") { (label, _) ->
            val s = seasonsBy[label]
            if (s == null) "$label: yok" else "$label: ${s.take(4).joinToString(", ")}" + if (s.size > 4) " …" else ""
        }
        ApiResult.Ok(
            "Bağlantı tamam: ${arr.length()} yarışma-sezon kaydı. Kapsam (yalnızca geçmiş sezonlar): $cover. " +
                "En yeni sezon kaydı: ${latest.ifEmpty { "-" }}. Güncel sezon yok; bu veri şu an tahmin modeline girmez."
        )
    }
}

// ================================================================== The Odds API bağlantı testi (kredi harcamaz)

suspend fun OddsApiClient.testConnection(settings: AppSettings, key: String): ApiResult<String> = guarded(SourceId.ODDS_API) {
    val r = httpGet(settings, SourceId.ODDS_API, "https://api.the-odds-api.com/v4/sports/?apiKey=$key")
    if (r.code !in 200..299) return@guarded httpErr(SourceId.ODDS_API, r.code, r.body)
    r.headers["x-requests-remaining"]?.let { settings.setOddsApiRemaining(it) }
    val arr = JSONArray(r.body)
    val active = HashSet<String>()
    for (i in 0 until arr.length()) {
        val o = arr.getJSONObject(i)
        if (o.optBoolean("active", false)) active.add(o.optString("key"))
    }
    val have = sportKeys.filterValues { it in active }.keys
    val missing = sportKeys.keys.filter { it !in have }
    ApiResult.Ok(
        "Bağlantı tamam (bu test kredi harcamaz). Aktif lig anahtarları: ${SourceCatalog.leagueNames(have)}." +
            (if (missing.isNotEmpty()) " Şu an listede aktif olmayan: ${SourceCatalog.leagueNames(missing)}." else "") +
            " Kalan kredi: ${r.headers["x-requests-remaining"] ?: "?"}. Bu uygulama yalnızca 1X2 ve toplam gol oranlarını çeker."
    )
}
