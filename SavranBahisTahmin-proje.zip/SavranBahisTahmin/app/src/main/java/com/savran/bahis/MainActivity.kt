package com.savran.bahis

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.compose.animation.Crossfade
import androidx.compose.animation.core.tween
import androidx.compose.runtime.Composable
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.setValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.launch

sealed interface Screen {
    object Home : Screen
    data class Matches(val dayOffset: Int, val title: String) : Screen
    data class Detail(val match: Match) : Screen
    data class AddOdds(val match: Match) : Screen
    object AddMatch : Screen
    object Opportunities : Screen
    object Coupons : Screen
    object History : Screen
    object Performance : Screen
    object DataHealth : Screen
    object Backtest : Screen
    object Settings : Screen
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val repo = Repository(applicationContext)
        // Güncelleme sonrası silinen alarmlar için: geçmemiş maç hatırlatmalarını yeniden kur.
        try { Reminders.restore(applicationContext, repo.settings) } catch (e: Exception) { }
        setContent {
            SavranTheme {
                AppRoot(repo)
            }
        }
    }
}

@Composable
fun AppRoot(repo: Repository) {
    val stack = remember { mutableStateListOf<Screen>(Screen.Home) }
    val push: (Screen) -> Unit = { stack.add(it) }
    val pop: () -> Unit = { if (stack.size > 1) stack.removeAt(stack.lastIndex) }

    BackHandler(enabled = stack.size > 1) { pop() }

    UpdateGate()

    Crossfade(targetState = stack.last(), animationSpec = tween(180), label = "nav") { s ->
        when (s) {
            is Screen.Home -> HomeScreen(repo, push)
            is Screen.Matches -> MatchesScreen(repo, s.dayOffset, s.title, push, pop)
            is Screen.Detail -> DetailScreen(repo, s.match, push, pop)
            is Screen.AddOdds -> AddOddsScreen(repo, s.match, pop)
            is Screen.AddMatch -> AddMatchScreen(repo, pop)
            is Screen.Opportunities -> OpportunitiesScreen(repo, push, pop)
            is Screen.Coupons -> CouponsScreen(repo, pop)
            is Screen.History -> HistoryScreen(repo, pop)
            is Screen.Performance -> PerformanceScreen(repo, pop)
            is Screen.DataHealth -> DataHealthScreen(repo, pop)
            is Screen.Backtest -> BacktestScreen(repo, pop)
            is Screen.Settings -> SettingsScreen(repo, pop)
        }
    }
}


/**
 * Açılışta güncelleme denetimi: yeni sürüm varsa arka planda indirilir, sonra "Şimdi kur" sorulur.
 * Android, Play Store dışı uygulamalarda kurulumu tek dokunuşla onaylatmayı şart koşar.
 */
@Composable
fun UpdateGate() {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var info by remember { mutableStateOf<Updater.Info?>(null) }
    var progress by remember { mutableStateOf(-1) }
    var file by remember { mutableStateOf<java.io.File?>(null) }
    var failed by remember { mutableStateOf(false) }
    var dismissed by remember { mutableStateOf(false) }
    var needPermission by remember { mutableStateOf(false) }

    suspend fun fetch() {
        failed = false; progress = 0
        file = Updater.download(ctx) { progress = it }
        if (file == null) failed = true
        progress = -1
    }

    LaunchedEffect(Unit) {
        Updater.cleanup(ctx)          // önceki güncellemeden kalan dosya
        val i = Updater.check(ctx) ?: return@LaunchedEffect
        info = i
        fetch()
    }

    val i = info ?: return
    if (dismissed) return
    AlertDialog(
        onDismissRequest = { if (progress < 0) dismissed = true },
        title = { Text("Yeni sürüm: ${i.name}") },
        text = {
            Column {
                Text("Yüklü sürüm: ${Updater.currentName(ctx)}. Verilerin ve ayarların korunur.")
                Spacer(Modifier.height(10.dp))
                when {
                    progress >= 0 -> {
                        Text("İndiriliyor… %$progress")
                        Spacer(Modifier.height(6.dp))
                        LinearProgressIndicator(progress = progress / 100f, modifier = Modifier.fillMaxWidth())
                    }
                    failed -> Text("İndirme başarısız. İnternet bağlantını kontrol edip tekrar dene.")
                    needPermission -> Text("Bir kereliğine izin gerekiyor: açılan ekranda \"Bu kaynaktan izin ver\" anahtarını aç, sonra geri dönüp \"Şimdi kur\"a bas.")
                    file != null -> Text("Güncelleme indirildi. \"Şimdi kur\"a bas, açılan Android ekranında \"Güncelle\"yi onayla.")
                }
            }
        },
        confirmButton = {
            when {
                progress >= 0 -> {}
                failed -> TextButton(onClick = { scope.launch { fetch() } }) { Text("Tekrar dene") }
                file != null -> TextButton(onClick = {
                    if (!Updater.canInstall(ctx)) { needPermission = true; Updater.openInstallPermission(ctx) }
                    else { needPermission = false; Updater.install(ctx, file!!) }
                }) { Text("Şimdi kur") }
            }
        },
        dismissButton = {
            if (progress < 0) TextButton(onClick = { dismissed = true }) { Text("Sonra") }
        }
    )
}
