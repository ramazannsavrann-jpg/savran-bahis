package com.savran.bahis

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.provider.Settings
import androidx.core.content.FileProvider
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.URL

/**
 * Uygulama içi güncelleme: her açılışta GitHub'daki apk dalında version.json'a bakar; daha yeni sürüm varsa APK'yı
 * uygulamanın kendi önbelleğine indirir ve Android kurulum ekranını açar. Android, Play Store dışı uygulamalarda
 * kurulumu kullanıcının onaylamasını şart koşar (tek dokunuş). Aynı imza olduğu için veriler silinmez.
 */
object Updater {
    private const val BASE = "https://raw.githubusercontent.com/ramazannsavrann-jpg/savran-bahis/apk"
    const val VERSION_URL = "$BASE/version.json"
    const val APK_URL = "$BASE/SavranAnaliz.apk"

    data class Info(val code: Long, val name: String)

    fun currentCode(ctx: Context): Long {
        val pi = ctx.packageManager.getPackageInfo(ctx.packageName, 0)
        @Suppress("DEPRECATION")
        return if (Build.VERSION.SDK_INT >= 28) pi.longVersionCode else pi.versionCode.toLong()
    }

    fun currentName(ctx: Context): String =
        try { ctx.packageManager.getPackageInfo(ctx.packageName, 0).versionName ?: "?" } catch (e: Exception) { "?" }

    /** Daha yeni sürüm varsa bilgisini döner; yoksa veya ulaşılamazsa null. */
    suspend fun check(ctx: Context): Info? = withContext(Dispatchers.IO) {
        try {
            val c = URL("$VERSION_URL?t=${System.currentTimeMillis() / 60000}").openConnection() as HttpURLConnection
            c.connectTimeout = 8000; c.readTimeout = 8000; c.useCaches = false
            if (c.responseCode !in 200..299) return@withContext null
            val o = JSONObject(c.inputStream.bufferedReader().use { it.readText() })
            val info = Info(o.getLong("versionCode"), o.optString("versionName", "?"))
            if (info.code > currentCode(ctx)) info else null
        } catch (e: Exception) { null }
    }

    private fun apkFile(ctx: Context) = File(File(ctx.cacheDir, "update").apply { mkdirs() }, "SavranAnaliz.apk")

    /** APK'yı indirir (ilerleme 0-100). Başarısızsa null. */
    suspend fun download(ctx: Context, onProgress: (Int) -> Unit): File? = withContext(Dispatchers.IO) {
        val out = apkFile(ctx)
        val tmp = File(out.parentFile, "dl.tmp")
        try {
            val c = URL("$APK_URL?t=${System.currentTimeMillis() / 60000}").openConnection() as HttpURLConnection
            c.connectTimeout = 15000; c.readTimeout = 30000; c.useCaches = false
            if (c.responseCode !in 200..299) return@withContext null
            val total = c.contentLengthLong
            var read = 0L
            c.inputStream.use { inp ->
                tmp.outputStream().use { os ->
                    val buf = ByteArray(64 * 1024)
                    var last = -1
                    while (true) {
                        val n = inp.read(buf)
                        if (n < 0) break
                        os.write(buf, 0, n)
                        read += n
                        if (total > 0) {
                            val p = (read * 100 / total).toInt()
                            if (p != last) { last = p; onProgress(p) }
                        }
                    }
                }
            }
            if (total > 0 && read != total) { tmp.delete(); return@withContext null }
            out.delete()
            if (!tmp.renameTo(out)) { tmp.copyTo(out, overwrite = true); tmp.delete() }
            out
        } catch (e: Exception) { tmp.delete(); null }
    }

    /** Bilinmeyen kaynaklardan yükleme izni verilmiş mi (bu uygulama için bir kez açılır). */
    fun canInstall(ctx: Context): Boolean =
        Build.VERSION.SDK_INT < 26 || ctx.packageManager.canRequestPackageInstalls()

    fun openInstallPermission(ctx: Context) {
        val i = Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES, Uri.parse("package:${ctx.packageName}"))
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        try { ctx.startActivity(i) } catch (e: Exception) { }
    }

    /** Android kurulum ekranını açar. */
    fun install(ctx: Context, file: File): Boolean = try {
        val uri = FileProvider.getUriForFile(ctx, "${ctx.packageName}.update", file)
        val i = Intent(Intent.ACTION_VIEW)
            .setDataAndType(uri, "application/vnd.android.package-archive")
            .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
        ctx.startActivity(i)
        true
    } catch (e: Exception) { false }

    /** Kurulumdan sonra eski indirme silinir. */
    fun cleanup(ctx: Context) { try { apkFile(ctx).delete() } catch (e: Exception) { } }
}
