package com.savran.bahis

import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import kotlin.math.ln

data class PredictionRecord(
    val id: String,
    val matchId: String,
    val matchLabel: String,
    val leagueId: Int,
    val leagueName: String,
    val kickoff: Long,
    val marketKey: String,
    val selectionKey: String,
    val predictedAt: Long,
    val modelProb: Double,
    val prob: Double,             // son (piyasa/belirsizlik ayarlı) olasılık
    val odds: Double?,
    val bookmaker: String?,
    val oddsUpdatedAt: Long?,
    val sources: String,
    val modelVersion: String,
    val recommended: Boolean,
    val result: Boolean?,         // null = sonuç bekleniyor
    val settledAt: Long?,
    val finalScore: String?,
    /** Elle girilen beklenen golle üretildi: otomatik model kaydı değildir, başarı/öğrenme dışında tutulur. */
    val manual: Boolean = false,
    /** Tahmin anındaki veri kalitesi (0-1). Eski kayıtlarda bilinmez (null). */
    val dq: Double? = null,
    /** Maça en yakın görülen piyasa olasılığı (oranın marjı ayıklanmış). Model ile piyasayı kıyaslamak için. */
    val closingFair: Double? = null,
    val closingAt: Long? = null
)

/**
 * Otomatik modelin ölçülebilir kaydı mı? Elle λ ile üretilenler, yasaklı pazarlar (ör. İlk Yarı 2.5 Alt)
 * ve veri kalitesi eşiğin altındaki kayıtlar başarı ölçümüne ve öğrenmeye girmez.
 */
fun PredictionRecord.isAutoTracked(): Boolean =
    !manual && ForecastEngine.isPlayable(marketKey, selectionKey) &&
        (dq == null || dq >= ForecastEngine.MIN_DATA_QUALITY)

class PredictionStore(private val dir: File) {
    private val file = File(dir, "predictions.json")

    private fun toJson(r: PredictionRecord) = JSONObject()
        .put("id", r.id).put("matchId", r.matchId).put("matchLabel", r.matchLabel)
        .put("leagueId", r.leagueId).put("leagueName", r.leagueName).put("kickoff", r.kickoff)
        .put("marketKey", r.marketKey).put("selectionKey", r.selectionKey).put("predictedAt", r.predictedAt)
        .put("modelProb", r.modelProb).put("prob", r.prob)
        .put("odds", r.odds ?: JSONObject.NULL).put("bookmaker", r.bookmaker ?: JSONObject.NULL)
        .put("oddsUpdatedAt", r.oddsUpdatedAt ?: JSONObject.NULL)
        .put("sources", r.sources).put("modelVersion", r.modelVersion).put("recommended", r.recommended)
        .put("result", r.result ?: JSONObject.NULL).put("settledAt", r.settledAt ?: JSONObject.NULL)
        .put("finalScore", r.finalScore ?: JSONObject.NULL)
        .put("manual", r.manual).put("dq", r.dq ?: JSONObject.NULL)
        .put("closingFair", r.closingFair ?: JSONObject.NULL).put("closingAt", r.closingAt ?: JSONObject.NULL)

    private fun fromJson(o: JSONObject) = PredictionRecord(
        id = o.getString("id"), matchId = o.getString("matchId"), matchLabel = o.getString("matchLabel"),
        leagueId = o.getInt("leagueId"), leagueName = o.getString("leagueName"), kickoff = o.getLong("kickoff"),
        marketKey = o.getString("marketKey"), selectionKey = o.getString("selectionKey"),
        predictedAt = o.getLong("predictedAt"), modelProb = o.getDouble("modelProb"), prob = o.getDouble("prob"),
        odds = if (o.isNull("odds")) null else o.getDouble("odds"),
        bookmaker = if (o.isNull("bookmaker")) null else o.getString("bookmaker"),
        oddsUpdatedAt = if (o.isNull("oddsUpdatedAt")) null else o.getLong("oddsUpdatedAt"),
        sources = o.getString("sources"), modelVersion = o.getString("modelVersion"),
        recommended = o.getBoolean("recommended"),
        result = if (o.isNull("result")) null else o.getBoolean("result"),
        settledAt = if (o.isNull("settledAt")) null else o.getLong("settledAt"),
        finalScore = if (o.isNull("finalScore")) null else o.getString("finalScore"),
        manual = o.optBoolean("manual", false),
        dq = if (!o.has("dq") || o.isNull("dq")) null else o.getDouble("dq"),
        closingFair = if (o.isNull("closingFair")) null else o.getDouble("closingFair"),
        closingAt = if (o.isNull("closingAt")) null else o.getLong("closingAt")
    )

    @Synchronized
    fun all(): List<PredictionRecord> {
        if (!file.exists()) return emptyList()
        return try {
            val a = JSONObject(file.readText()).getJSONArray("items")
            (0 until a.length()).map { fromJson(a.getJSONObject(it)) }
        } catch (e: Exception) {
            file.renameTo(File(dir, "predictions.corrupt.json"))
            emptyList()
        }
    }

    @Synchronized
    private fun save(list: List<PredictionRecord>) {
        val arr = JSONArray()
        list.forEach { arr.put(toJson(it)) }
        atomicWrite(file, JSONObject().put("items", arr).toString())
    }

    /** Aynı (maç, pazar, seçenek, model sürümü) için ilk kayıt korunur; sonradan değiştirilmez. */
    @Synchronized
    fun addIfAbsent(items: List<PredictionRecord>): Int {
        val cur = all().toMutableList()
        val ids = cur.map { it.id }.toHashSet()
        var added = 0
        for (r in items) if (ids.add(r.id)) { cur.add(r); added++ }
        if (added > 0) save(cur)
        return added
    }

    @Synchronized
    fun replaceAll(list: List<PredictionRecord>) = save(list)

    /**
     * Yalnızca sonucu hâlâ bekleyen kayıtları id ile günceller. Okuma ve yazma tek kilit altında yapılır:
     * değerlendirme sırasında (ağ beklerken) eklenen yeni kayıtlar silinmez, mevcut sonuçlar ezilmez.
     * Güncellenen kayıt sayısını döndürür.
     */
    @Synchronized
    fun updateById(changes: Map<String, PredictionRecord>): Int {
        if (changes.isEmpty()) return 0
        var n = 0
        val out = all().map { r ->
            val c = changes[r.id]
            if (c != null && r.result == null && c.result != null) { n++; c } else r
        }
        if (n > 0) save(out)
        return n
    }

    /**
     * Kapanış (maça en yakın) piyasa olasılığını yazar. Yalnızca sonucu bekleyen ve maçı başlamamış kayıtlar;
     * daha geç (maça daha yakın) değer eskisinin yerine geçer. Tahmin olasılığı DEĞİŞMEZ.
     */
    @Synchronized
    fun updateClosing(matchId: String, fair: Map<Pair<String, String>, Double>, now: Long): Int {
        if (fair.isEmpty()) return 0
        var n = 0
        val out = all().map { r ->
            val v = if (r.matchId == matchId && r.result == null && now < r.kickoff * 1000) fair[r.marketKey to r.selectionKey] else null
            if (v != null && (r.closingAt == null || now >= r.closingAt)) { n++; r.copy(closingFair = v, closingAt = now) } else r
        }
        if (n > 0) save(out)
        return n
    }

    fun idOf(matchId: String, mk: String, sk: String, version: String) = RecordBuilder.idOf(matchId, mk, sk, version)
}

/** Model mi piyasa mı daha iyi tahmin etti? Aynı sonuçlanmış seçimlerde Brier puanı (düşük = iyi). */
data class MarketCompare(val n: Int, val brierModel: Double, val brierMarket: Double)

object ClosingCompare {
    /** En az bu kadar kayıt olmadan karşılaştırma gösterilmez (gürültü). */
    const val MIN_N = 30

    fun compute(records: List<PredictionRecord>): MarketCompare? {
        val s = records.filter { it.isAutoTracked() && it.result != null && it.closingFair != null }
        if (s.isEmpty()) return MarketCompare(0, 0.0, 0.0)
        fun sq(p: Double, y: Boolean) = (p - if (y) 1.0 else 0.0).let { it * it }
        return MarketCompare(
            s.size,
            s.sumOf { sq(it.prob, it.result!!) } / s.size,
            s.sumOf { sq(it.closingFair!!, it.result!!) } / s.size
        )
    }

    fun text(c: MarketCompare?): String = when {
        c == null || c.n == 0 -> "Henüz piyasa oranı kaydedilmiş sonuçlanmış tahmin yok (The Odds API anahtarıyla maç öncesi analizde otomatik kaydedilir)."
        c.n < MIN_N -> "Model ile piyasa karşılaştırması için ${c.n}/$MIN_N kayıt var; sonuç için daha fazla maç gerekiyor."
        else -> {
            val f = { x: Double -> "%.3f".format(java.util.Locale.US, x) }
            "Model Brier ${f(c.brierModel)} · Piyasa Brier ${f(c.brierMarket)} (${c.n} seçim, düşük daha iyi). " +
                if (c.brierModel < c.brierMarket) "Model bu örneklemde piyasadan iyi." else "Piyasa bu örneklemde modelden iyi; modele körü körüne güvenme."
        }
    }
}

/**
 * Bir analizden kaydedilecek tahmin kayıtlarını üretir (saf mantık, test edilebilir).
 * Kurallar: başlamış maç kaydedilmez (sızıntı yok); veri kalitesi eşiğin altındaysa kaydedilmez;
 * yasaklı pazarlar kaydedilmez; "önerilen" = Bahis Fırsatları'nda gösterilen seçim; elle λ'lı kayıtlar işaretlenir.
 */
object RecordBuilder {
    fun idOf(matchId: String, mk: String, sk: String, version: String) = "$matchId|$mk|$sk|$version"

    fun build(
        match: Match, model: ScoreModel, dq: Double, evals: List<Evaluation>, forecasts: List<Forecast>,
        now: Long, manual: Boolean
    ): List<PredictionRecord> {
        if (match.statusShort != "NS" || match.kickoff * 1000 <= now) return emptyList()   // veri sızıntısını önle
        if (dq < ForecastEngine.MIN_DATA_QUALITY) return emptyList()
        val label = "${match.home} - ${match.away}"
        val version = OpportunityEngine.MODEL_VERSION
        val items = ArrayList<PredictionRecord>()
        val seen = HashSet<String>()
        val recommendedKeys = ForecastEngine.bahisFirsatlari(forecasts).map { it.marketKey to it.selectionKey }.toHashSet()
        for (e in evals) {
            if (!ForecastEngine.isPlayable(e.marketKey, e.selectionKey)) continue
            val pm = e.modelProb ?: continue
            val id = idOf(match.id, e.marketKey, e.selectionKey, version)
            if (!seen.add(id)) continue
            items.add(
                PredictionRecord(
                    id, match.id, label, match.leagueId, match.leagueName, match.kickoff,
                    e.marketKey, e.selectionKey, now, pm, e.adjProb ?: pm, e.odds, e.bookmaker, e.updatedAt,
                    "Model: puan durumu (${match.source}); oran: ${e.origin}/${e.bookmaker}",
                    version, (e.marketKey to e.selectionKey) in recommendedKeys, null, null, null,
                    manual, dq
                )
            )
        }
        // Oransız tahminler de kaydedilir: ekranda öne çıkan en güçlü seçenekler + çekirdek seçenekler.
        val shown = (ForecastEngine.bahisFirsatlari(forecasts) +
            forecasts.filter { (it.marketKey to it.selectionKey) in OpportunityEngine.coreSelections })
            .filter { ForecastEngine.isPlayable(it.marketKey, it.selectionKey) }
        for (f in shown) {
            val id = idOf(match.id, f.marketKey, f.selectionKey, version)
            if (!seen.add(id)) continue
            items.add(
                PredictionRecord(
                    id, match.id, label, match.leagueId, match.leagueName, match.kickoff,
                    f.marketKey, f.selectionKey, now, f.rawProb, f.prob, f.odds, f.bookmaker, null,
                    "Model: puan durumu (${match.source}); güven ${f.confidence.tr} (${f.confidenceScore}/100); " +
                        (if (f.odds == null) "oran yok" else "oran var") +
                        (if (kotlin.math.abs(f.rawProb - f.prob) > 1e-9) "; kalibre" else ""),
                    version, (f.marketKey to f.selectionKey) in recommendedKeys, null, null, null,
                    manual, dq
                )
            )
        }
        for ((mk, sk) in OpportunityEngine.coreSelections) {
            if (!ForecastEngine.isPlayable(mk, sk)) continue
            val id = idOf(match.id, mk, sk, version)
            if (!seen.add(id)) continue
            val p = MarketProb.prob(model, mk, sk) ?: continue
            items.add(
                PredictionRecord(
                    id, match.id, label, match.leagueId, match.leagueName, match.kickoff,
                    mk, sk, now, p, p, null, null, null,
                    "Model: puan durumu (${match.source}); oran yok",
                    version, (mk to sk) in recommendedKeys, null, null, null,
                    manual, dq
                )
            )
        }
        return items
    }
}

object Settler {
    /** Sonucu belli maç için kaydı değerlendirir. HT gerekip yoksa null (bekler). */
    fun settle(r: PredictionRecord, fh: Int, fa: Int, hh: Int?, ha: Int?, nowMs: Long): PredictionRecord? {
        val outcome = Outcomes.eval(r.marketKey, r.selectionKey, fh, fa, hh, ha) ?: return null
        return r.copy(result = outcome, settledAt = nowMs, finalScore = "$fh-$fa" + if (hh != null && ha != null) " (İY $hh-$ha)" else "")
    }
}

data class Bin(val label: String, val count: Int, val meanPredicted: Double, val hitRate: Double)

data class Report(
    val total: Int,
    val settled: Int,
    val correct: Int,
    val wrong: Int,
    val hitRate: Double?,
    val brier: Double?,
    val logLoss: Double?,
    val byMarketGroup: Map<String, Triple<Int, Int, Double>>,   // n, doğru, başarı
    val byLeague: Map<String, Triple<Int, Int, Double>>,
    val bins: List<Bin>,
    val roiN: Int,
    val unitReturn: Double?,
    val roi: Double?,
    val recent: List<RecentStat> = emptyList(),
    val manualSettled: Int = 0      // elle λ ile üretilen, sonuçlanmış kayıtlar (başarı oranına katılmaz)
)

data class RecentStat(val window: Int, val n: Int, val correct: Int, val hitRate: Double?, val brier: Double?)

object Metrics {
    /**
     * Başarı oranı ve ölçümler modelin her pazardaki SEÇİMİ (en olası seçenek) üzerinden hesaplanır; güveni düşük olanlar dahil.
     * Seçilmeyen karşı seçenekler (ör. 1/X/2'nin diğer iki ucu) yalnızca kalibrasyon öğrenmesinde kullanılır.
     */
    /**
     * Modelin seçimi: her maçın her pazarında kayıtlı seçenekler içinde en olası olanı (güven seviyesinden bağımsız).
     * İki seçenekli pazarda yalnızca bir taraf kayıtlıysa ve %50'nin altındaysa model aslında diğer tarafı seçmiştir: sayılmaz.
     * Doğru skor ve devre/maç gibi çok seçenekli, düşük olasılıklı pazarlar başarı oranını anlamsızlaştırdığı için hariç.
     */
    fun modelPickIds(records: List<PredictionRecord>): Set<String> =
        records.filter { it.isAutoTracked() && it.marketKey != "cs" && it.marketKey != "htft" }
            .groupBy { it.matchId + "|" + it.marketKey + "|" + it.modelVersion }
            .values.mapNotNull { l ->
                val top = l.maxByOrNull { it.prob } ?: return@mapNotNull null
                val binary = MarketCatalog.find(top.marketKey)?.selections?.size == 2
                if (binary && top.prob < 0.5) null else top.id
            }.toSet()

    fun report(records: List<PredictionRecord>): Report {
        val pickIds = modelPickIds(records)
        val picks = records.filter { it.id in pickIds }
        val manualSettled = records.count { it.manual && it.result != null }
        val settled = picks.filter { it.result != null }
        val correct = settled.count { it.result == true }
        val n = settled.size
        val brier = if (n == 0) null else settled.sumOf { val y = if (it.result == true) 1.0 else 0.0; (it.prob - y) * (it.prob - y) } / n
        val logLoss = if (n == 0) null else settled.sumOf {
            val p = it.prob.coerceIn(1e-6, 1 - 1e-6)
            if (it.result == true) -ln(p) else -ln(1 - p)
        } / n

        fun group(keyOf: (PredictionRecord) -> String): Map<String, Triple<Int, Int, Double>> =
            settled.groupBy(keyOf).mapValues { (_, l) ->
                val c = l.count { it.result == true }
                Triple(l.size, c, c.toDouble() / l.size)
            }

        val bins = (0 until 10).mapNotNull { i ->
            val lo = i / 10.0
            val hi = (i + 1) / 10.0
            val l = settled.filter { it.prob >= lo && (it.prob < hi || (i == 9 && it.prob <= 1.0)) }
            if (l.isEmpty()) null
            else Bin("%${i * 10}-${(i + 1) * 10}", l.size, l.map { it.prob }.average(), l.count { it.result == true }.toDouble() / l.size)
        }

        // Gerçek (kayıtlı) oranlarla birim getiri: yalnızca oranı olan ve ÖNERİLEN seçimler. Sanal kupon/bakiye değildir.
        val withOdds = settled.filter { it.odds != null && it.recommended }
        val unit = if (withOdds.isEmpty()) null else withOdds.sumOf { if (it.result == true) it.odds!! - 1.0 else -1.0 }
        return Report(
            total = picks.size, settled = n, correct = correct, wrong = n - correct,
            hitRate = if (n == 0) null else correct.toDouble() / n,
            brier = brier, logLoss = logLoss,
            byMarketGroup = group { MarketCatalog.find(it.marketKey)?.group ?: "Diğer" },
            byLeague = group { it.leagueName },
            bins = bins,
            roiN = withOdds.size, unitReturn = unit,
            roi = if (unit == null) null else unit / withOdds.size,
            recent = recentStats(settled),
            manualSettled = manualSettled
        )
    }

    /** Son 10/50/100 sonuçlanmış tahminin performansı (en yeni sonuç önce). */
    fun recentStats(settled: List<PredictionRecord>): List<RecentStat> {
        val ordered = settled.sortedByDescending { it.settledAt ?: it.kickoff }
        return listOf(10, 50, 100).map { w ->
            val l = ordered.take(w)
            val c = l.count { it.result == true }
            RecentStat(
                w, l.size, c,
                if (l.isEmpty()) null else c.toDouble() / l.size,
                if (l.isEmpty()) null else l.sumOf { val y = if (it.result == true) 1.0 else 0.0; (it.prob - y) * (it.prob - y) } / l.size
            )
        }
    }

    const val MIN_FOR_HISTORY_SCORE = 30

    /** Kalite puanındaki "model geçmişi" bileşeni: yeterli kayıt yoksa null (nötr). */
    fun historyScore(r: Report): Double? {
        val b = r.brier ?: return null
        if (r.settled < MIN_FOR_HISTORY_SCORE) return null
        return ((0.25 - b) / 0.10).coerceIn(0.0, 1.0)
    }
}
