package com.savran.bahis

import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import kotlin.math.ln

data class PredictionRecord(
    val id: String,
    val matchId: String,
    val matchLabel: String,
    val leagueId: Int,
    val leagueName: String,
    val kickoff: Long,
    val marketKey: String,
    val selectionKey: String,
    val predictedAt: Long,
    val modelProb: Double,
    val prob: Double,             // son (piyasa/belirsizlik ayarlı) olasılık
    val odds: Double?,
    val bookmaker: String?,
    val oddsUpdatedAt: Long?,
    val sources: String,
    val modelVersion: String,
    val recommended: Boolean,
    val result: Boolean?,         // null = sonuç bekleniyor
    val settledAt: Long?,
    val finalScore: String?
)

class PredictionStore(private val dir: File) {
    private val file = File(dir, "predictions.json")

    private fun toJson(r: PredictionRecord) = JSONObject()
        .put("id", r.id).put("matchId", r.matchId).put("matchLabel", r.matchLabel)
        .put("leagueId", r.leagueId).put("leagueName", r.leagueName).put("kickoff", r.kickoff)
        .put("marketKey", r.marketKey).put("selectionKey", r.selectionKey).put("predictedAt", r.predictedAt)
        .put("modelProb", r.modelProb).put("prob", r.prob)
        .put("odds", r.odds ?: JSONObject.NULL).put("bookmaker", r.bookmaker ?: JSONObject.NULL)
        .put("oddsUpdatedAt", r.oddsUpdatedAt ?: JSONObject.NULL)
        .put("sources", r.sources).put("modelVersion", r.modelVersion).put("recommended", r.recommended)
        .put("result", r.result ?: JSONObject.NULL).put("settledAt", r.settledAt ?: JSONObject.NULL)
        .put("finalScore", r.finalScore ?: JSONObject.NULL)

    private fun fromJson(o: JSONObject) = PredictionRecord(
        id = o.getString("id"), matchId = o.getString("matchId"), matchLabel = o.getString("matchLabel"),
        leagueId = o.getInt("leagueId"), leagueName = o.getString("leagueName"), kickoff = o.getLong("kickoff"),
        marketKey = o.getString("marketKey"), selectionKey = o.getString("selectionKey"),
        predictedAt = o.getLong("predictedAt"), modelProb = o.getDouble("modelProb"), prob = o.getDouble("prob"),
        odds = if (o.isNull("odds")) null else o.getDouble("odds"),
        bookmaker = if (o.isNull("bookmaker")) null else o.getString("bookmaker"),
        oddsUpdatedAt = if (o.isNull("oddsUpdatedAt")) null else o.getLong("oddsUpdatedAt"),
        sources = o.getString("sources"), modelVersion = o.getString("modelVersion"),
        recommended = o.getBoolean("recommended"),
        result = if (o.isNull("result")) null else o.getBoolean("result"),
        settledAt = if (o.isNull("settledAt")) null else o.getLong("settledAt"),
        finalScore = if (o.isNull("finalScore")) null else o.getString("finalScore")
    )

    @Synchronized
    fun all(): List<PredictionRecord> {
        if (!file.exists()) return emptyList()
        return try {
            val a = JSONObject(file.readText()).getJSONArray("items")
            (0 until a.length()).map { fromJson(a.getJSONObject(it)) }
        } catch (e: Exception) {
            file.renameTo(File(dir, "predictions.corrupt.json"))
            emptyList()
        }
    }

    @Synchronized
    private fun save(list: List<PredictionRecord>) {
        val arr = JSONArray()
        list.forEach { arr.put(toJson(it)) }
        atomicWrite(file, JSONObject().put("items", arr).toString())
    }

    /** Aynı (maç, pazar, seçenek, model sürümü) için ilk kayıt korunur; sonradan değiştirilmez. */
    @Synchronized
    fun addIfAbsent(items: List<PredictionRecord>): Int {
        val cur = all().toMutableList()
        val ids = cur.map { it.id }.toHashSet()
        var added = 0
        for (r in items) if (ids.add(r.id)) { cur.add(r); added++ }
        if (added > 0) save(cur)
        return added
    }

    @Synchronized
    fun replaceAll(list: List<PredictionRecord>) = save(list)

    fun idOf(matchId: String, mk: String, sk: String, version: String) = "$matchId|$mk|$sk|$version"
}

object Settler {
    /** Sonucu belli maç için kaydı değerlendirir. HT gerekip yoksa null (bekler). */
    fun settle(r: PredictionRecord, fh: Int, fa: Int, hh: Int?, ha: Int?, nowMs: Long): PredictionRecord? {
        val outcome = Outcomes.eval(r.marketKey, r.selectionKey, fh, fa, hh, ha) ?: return null
        return r.copy(result = outcome, settledAt = nowMs, finalScore = "$fh-$fa" + if (hh != null && ha != null) " (İY $hh-$ha)" else "")
    }
}

data class Bin(val label: String, val count: Int, val meanPredicted: Double, val hitRate: Double)

data class Report(
    val total: Int,
    val settled: Int,
    val correct: Int,
    val wrong: Int,
    val hitRate: Double?,
    val brier: Double?,
    val logLoss: Double?,
    val byMarketGroup: Map<String, Triple<Int, Int, Double>>,   // n, doğru, başarı
    val byLeague: Map<String, Triple<Int, Int, Double>>,
    val bins: List<Bin>,
    val roiN: Int,
    val unitReturn: Double?,
    val roi: Double?
)

object Metrics {
    fun report(records: List<PredictionRecord>): Report {
        val settled = records.filter { it.result != null }
        val correct = settled.count { it.result == true }
        val n = settled.size
        val brier = if (n == 0) null else settled.sumOf { val y = if (it.result == true) 1.0 else 0.0; (it.prob - y) * (it.prob - y) } / n
        val logLoss = if (n == 0) null else settled.sumOf {
            val p = it.prob.coerceIn(1e-6, 1 - 1e-6)
            if (it.result == true) -ln(p) else -ln(1 - p)
        } / n

        fun group(keyOf: (PredictionRecord) -> String): Map<String, Triple<Int, Int, Double>> =
            settled.groupBy(keyOf).mapValues { (_, l) ->
                val c = l.count { it.result == true }
                Triple(l.size, c, c.toDouble() / l.size)
            }

        val bins = (0 until 10).mapNotNull { i ->
            val lo = i / 10.0
            val hi = (i + 1) / 10.0
            val l = settled.filter { it.prob >= lo && (it.prob < hi || (i == 9 && it.prob <= 1.0)) }
            if (l.isEmpty()) null
            else Bin("%${i * 10}-${(i + 1) * 10}", l.size, l.map { it.prob }.average(), l.count { it.result == true }.toDouble() / l.size)
        }

        // Gerçek (kayıtlı) oranlarla birim getiri: yalnızca oranı olan ve ÖNERİLEN seçimler. Sanal kupon/bakiye değildir.
        val withOdds = settled.filter { it.odds != null && it.recommended }
        val unit = if (withOdds.isEmpty()) null else withOdds.sumOf { if (it.result == true) it.odds!! - 1.0 else -1.0 }
        return Report(
            total = records.size, settled = n, correct = correct, wrong = n - correct,
            hitRate = if (n == 0) null else correct.toDouble() / n,
            brier = brier, logLoss = logLoss,
            byMarketGroup = group { MarketCatalog.find(it.marketKey)?.group ?: "Diğer" },
            byLeague = group { it.leagueName },
            bins = bins,
            roiN = withOdds.size, unitReturn = unit,
            roi = if (unit == null) null else unit / withOdds.size
        )
    }

    const val MIN_FOR_HISTORY_SCORE = 30

    /** Kalite puanındaki "model geçmişi" bileşeni: yeterli kayıt yoksa null (nötr). */
    fun historyScore(r: Report): Double? {
        val b = r.brier ?: return null
        if (r.settled < MIN_FOR_HISTORY_SCORE) return null
        return ((0.25 - b) / 0.10).coerceIn(0.0, 1.0)
    }
}
