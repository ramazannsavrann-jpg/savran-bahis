package com.savran.bahis

/** Bitmiş bir maçın sonucu (kaynaktan bağımsız). Puan durumu alınamadığında tablo bunlardan hesaplanır. */
data class FinishedResult(val home: String, val away: String, val homeGoals: Int, val awayGoals: Int, val kickoff: Long)

/**
 * Puan durumu alınamadığında bitmiş maç sonuçlarından iç saha/deplasman/toplam istatistikleri ve son 5 maç formunu
 * hesaplar. Yalnızca gerçek sonuçlardan türetilir; eksik veri uydurulmaz.
 */
object ResultsTable {
    /** Bu kadar bitmiş maçtan azıyla tablo kurulmaz (veri yetersiz). */
    const val MIN_RESULTS = 10
    const val DERIVED_SUFFIX = " (maç sonuçlarından hesaplandı)"

    /** Negatif ve API-Football takım no'larından ayrı; ada göre kararlı. */
    fun teamId(name: String): Int = -((name.lowercase().hashCode() and 0x3fffffff) + 1_000_000)

    private class Acc(val name: String) {
        var pts = 0
        var allP = 0; var allF = 0; var allA = 0
        var hP = 0; var hF = 0; var hA = 0
        var aP = 0; var aF = 0; var aA = 0
        val results = ArrayList<Pair<Long, Char>>()
    }

    fun build(results: List<FinishedResult>, leagueId: Int, season: Int, now: Long, source: String): LeagueTable? {
        if (results.size < MIN_RESULTS) return null
        val teams = LinkedHashMap<String, Acc>()
        for (r in results.sortedBy { it.kickoff }) {
            val h = teams.getOrPut(r.home) { Acc(r.home) }
            val a = teams.getOrPut(r.away) { Acc(r.away) }
            val hr = if (r.homeGoals > r.awayGoals) 'W' else if (r.homeGoals == r.awayGoals) 'D' else 'L'
            val ar = if (hr == 'W') 'L' else if (hr == 'D') 'D' else 'W'
            h.allP++; h.allF += r.homeGoals; h.allA += r.awayGoals; h.hP++; h.hF += r.homeGoals; h.hA += r.awayGoals
            a.allP++; a.allF += r.awayGoals; a.allA += r.homeGoals; a.aP++; a.aF += r.awayGoals; a.aA += r.homeGoals
            h.pts += if (hr == 'W') 3 else if (hr == 'D') 1 else 0
            a.pts += if (ar == 'W') 3 else if (ar == 'D') 1 else 0
            h.results.add(r.kickoff to hr)
            a.results.add(r.kickoff to ar)
        }
        val sorted = teams.values.sortedWith(
            compareByDescending<Acc> { it.pts }.thenByDescending { it.allF - it.allA }.thenByDescending { it.allF }
        )
        val rows = sorted.mapIndexed { i, t ->
            TeamRow(
                teamId(t.name), t.name, i + 1, t.pts,
                SplitStats(t.allP, t.allF, t.allA), SplitStats(t.hP, t.hF, t.hA), SplitStats(t.aP, t.aF, t.aA),
                t.results.takeLast(5).map { it.second }.joinToString("")
            )
        }
        return LeagueTable(leagueId, season, now, rows, source + DERIVED_SUFFIX)
    }

    fun isDerived(t: LeagueTable): Boolean = t.source.endsWith(DERIVED_SUFFIX)
}
