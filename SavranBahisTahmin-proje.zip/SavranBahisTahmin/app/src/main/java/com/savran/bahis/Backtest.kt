package com.savran.bahis

/** Bir pazar için geri test sonucu. Brier düşük = iyi; "taban" = yalnızca ligin o ana kadarki ortalamasını söyleyen basit tahmin. */
data class BacktestLine(val label: String, val n: Int, val brierModel: Double, val brierBase: Double, val hitRate: Double)

data class BacktestReport(val league: String, val seasonCode: String, val matches: Int, val tested: Int, val lines: List<BacktestLine>)

/**
 * Geri test: geçmiş sezonun gerçek sonuçları üzerinde, her maçı YALNIZCA ondan önceki maçlarla kurulan tablodan
 * tahmin eder (gelecek bilgisi sızmaz). Aynı Poisson modeli ve aynı küçültme kullanılır.
 * Taban tahmin: ligde o ana kadarki gerçek sıklık (ör. 2.5 Üst oranı). Model tabanı yenemiyorsa o pazar zayıftır.
 */
object Backtest {
    /** Bir takımın tahmine girmesi için o ana kadar en az bu kadar maçı olmalı. */
    const val MIN_TEAM_GAMES = 4

    private class Acc(val label: String) {
        var n = 0; var bm = 0.0; var bb = 0.0; var hit = 0
        fun add(p: Double, base: Double, y: Boolean) {
            val t = if (y) 1.0 else 0.0
            n++; bm += (p - t) * (p - t); bb += (base - t) * (base - t)
            if ((p >= 0.5) == y) hit++
        }
        fun line() = if (n == 0) null else BacktestLine(label, n, bm / n, bb / n, hit.toDouble() / n)
    }

    fun run(results: List<FinishedResult>, league: String, seasonCode: String, priorRatings: Map<String, DoubleArray> = emptyMap()): BacktestReport {
        val sorted = results.sortedBy { it.kickoff }
        val o25 = Acc("2.5 Üst")
        val o15 = Acc("1.5 Üst")
        val btts = Acc("KG Var")
        val home = Acc("Ev sahibi kazanır")
        val away = Acc("Deplasman kazanır")
        var tested = 0
        for (i in sorted.indices) {
            val m = sorted[i]
            val prev = sorted.subList(0, i)
            if (prev.size < ResultsTable.MIN_RESULTS) continue
            val hg = prev.count { it.home == m.home || it.away == m.home }
            val ag = prev.count { it.home == m.away || it.away == m.away }
            if (hg < MIN_TEAM_GAMES || ag < MIN_TEAM_GAMES) continue
            val table = ResultsTable.build(prev, 0, 0, 0L, "geri test") ?: continue
            val prior = if (priorRatings.isEmpty()) null else Strength.priorFor(table.rows, priorRatings)
            val l = Strength.lambdas(table.rows, ResultsTable.teamId(m.home), ResultsTable.teamId(m.away), 5.0, prior) ?: continue
            val model = ScoreModel(l.home, l.away)
            // Uygulamadaki gibi: gol pazarları temkinli gol modelinden.
            val avg = Strength.leagueAverage(table.rows)
            val gm = if (avg != null) GoalModel.model(l.home, l.away,
                GoalModel.total(Strength.lambdas(table.rows, ResultsTable.teamId(m.home), ResultsTable.teamId(m.away), GoalModel.SHRINK_K), avg.first + avg.second)) else model
            val n = prev.size.toDouble()
            fun base(pred: (FinishedResult) -> Boolean) = (prev.count(pred) + 1.0) / (n + 2.0)   // gerçek sıklık (+1 düzeltme)
            val total = m.homeGoals + m.awayGoals
            MarketProb.prob(gm, "ou_2.5", "over")?.let { GoalModel.calibrate("ou_2.5", "over", it) }?.let { o25.add(it, base { it.homeGoals + it.awayGoals > 2 }, total > 2) }
            MarketProb.prob(gm, "ou_1.5", "over")?.let { GoalModel.calibrate("ou_1.5", "over", it) }?.let { o15.add(it, base { it.homeGoals + it.awayGoals > 1 }, total > 1) }
            MarketProb.prob(gm, "btts", "yes")?.let { GoalModel.calibrate("btts", "yes", it) }?.let { btts.add(it, base { it.homeGoals > 0 && it.awayGoals > 0 }, m.homeGoals > 0 && m.awayGoals > 0) }
            MarketProb.prob(model, "1x2", "1")?.let { home.add(it, base { it.homeGoals > it.awayGoals }, m.homeGoals > m.awayGoals) }
            MarketProb.prob(model, "1x2", "2")?.let { away.add(it, base { it.homeGoals < it.awayGoals }, m.homeGoals < m.awayGoals) }
            tested++
        }
        return BacktestReport(league, seasonCode, sorted.size, tested, listOfNotNull(home.line(), away.line(), o15.line(), o25.line(), btts.line()))
    }

    fun verdict(l: BacktestLine): String = when {
        l.n < 50 -> "örnek az"
        l.brierModel < l.brierBase - 0.003 -> "model tabandan iyi"
        l.brierModel > l.brierBase + 0.003 -> "model tabandan KÖTÜ"
        else -> "tabanla aynı"
    }
}
