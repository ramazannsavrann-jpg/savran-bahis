package com.savran.bahis

data class Selection(val key: String, val label: String)

/**
 * Bahis pazarı tanımı. Yeni pazar eklemek = aşağıdaki listeye bir satır eklemek.
 * exhaustive = true: seçenekler birlikte tüm olasılıkları kapsar (marj hesaplanabilir).
 */
data class Market(
    val key: String,
    val group: String,
    val title: String,
    val selections: List<Selection>,
    val exhaustive: Boolean = false
)

object MarketCatalog {
    val groups = listOf(
        "Maç Sonucu", "Gol", "KG", "İlk Yarı", "Devre/Maç",
        "Doğru Skor", "Korner", "Kart", "Kombinasyon", "Handikap"
    )

    private fun sels(vararg p: Pair<String, String>) = p.map { Selection(it.first, it.second) }

    private fun ou(key: String, group: String, title: String) = Market(
        key, group, title, sels("under" to "Alt", "over" to "Üst"), exhaustive = true
    )

    val all: List<Market> = buildList {
        // Maç sonucu
        add(Market("1x2", "Maç Sonucu", "Maç Sonucu", sels("1" to "Ev Sahibi (1)", "X" to "Beraberlik (X)", "2" to "Deplasman (2)"), true))
        add(Market("dc", "Maç Sonucu", "Çifte Şans", sels("1X" to "1-X", "12" to "1-2", "X2" to "X-2")))

        // Gol
        listOf("0.5", "1.5", "2.5", "3.5", "4.5").forEach { add(ou("ou_$it", "Gol", "Toplam Gol $it Alt/Üst")) }
        listOf("0.5", "1.5", "2.5").forEach {
            add(ou("home_ou_$it", "Gol", "Ev Sahibi Gol $it Alt/Üst"))
            add(ou("away_ou_$it", "Gol", "Deplasman Gol $it Alt/Üst"))
        }

        // KG
        add(Market("btts", "KG", "Karşılıklı Gol", sels("yes" to "KG Var", "no" to "KG Yok"), true))

        // İlk yarı
        add(Market("ht_1x2", "İlk Yarı", "İlk Yarı Sonucu", sels("1" to "Ev Sahibi (1)", "X" to "Beraberlik (X)", "2" to "Deplasman (2)"), true))
        add(Market("ht_dc", "İlk Yarı", "İlk Yarı Çifte Şans", sels("1X" to "1-X", "12" to "1-2", "X2" to "X-2")))
        listOf("0.5", "1.5", "2.5").forEach { add(ou("ht_ou_$it", "İlk Yarı", "İlk Yarı $it Alt/Üst")) }
        add(Market("ht_btts", "İlk Yarı", "İlk Yarı KG", sels("yes" to "KG Var", "no" to "KG Yok"), true))

        // Devre/Maç
        val htft = listOf("1/1", "1/X", "1/2", "X/1", "X/X", "X/2", "2/1", "2/X", "2/2")
        add(Market("htft", "Devre/Maç", "İlk Yarı / Maç Sonucu", htft.map { Selection(it, it) }, true))

        // Doğru skor
        val scores = listOf("0-0", "1-0", "0-1", "1-1", "2-0", "0-2", "2-1", "1-2", "2-2", "3-0", "0-3", "3-1", "1-3", "3-2", "2-3", "3-3")
        add(Market("cs", "Doğru Skor", "Doğru Skor", scores.map { Selection(it, it) } + Selection("other", "Diğer")))

        // Korner
        listOf("8.5", "9.5", "10.5", "11.5").forEach { add(ou("corners_ou_$it", "Korner", "Toplam Korner $it Alt/Üst")) }
        listOf("3.5", "4.5", "5.5").forEach {
            add(ou("home_corners_ou_$it", "Korner", "Ev Sahibi Korner $it Alt/Üst"))
            add(ou("away_corners_ou_$it", "Korner", "Deplasman Korner $it Alt/Üst"))
        }

        // Kart
        listOf("2.5", "3.5", "4.5", "5.5").forEach { add(ou("cards_ou_$it", "Kart", "Toplam Kart $it Alt/Üst")) }
        listOf("2.5", "3.5", "4.5").forEach { add(ou("yellow_ou_$it", "Kart", "Sarı Kart $it Alt/Üst")) }

        // Kombinasyon
        val resultSel = listOf("1" to "1", "X" to "X", "2" to "2")
        add(Market("combo_1x2_ou25", "Kombinasyon", "Maç Sonucu + 2.5 Alt/Üst",
            resultSel.flatMap { (rk, rl) ->
                listOf(Selection("${rk}_under", "$rl & Alt"), Selection("${rk}_over", "$rl & Üst"))
            }))
        add(Market("combo_1x2_btts", "Kombinasyon", "Maç Sonucu + KG",
            resultSel.flatMap { (rk, rl) ->
                listOf(Selection("${rk}_yes", "$rl & KG Var"), Selection("${rk}_no", "$rl & KG Yok"))
            }))

        // Handikap (sabit çizgiler; çizgi parametreli pazarlar Aşama 3'te)
        add(Market("hcp_home_minus1", "Handikap", "Handikaplı MS (Ev -1)", sels("1" to "1 (-1)", "X" to "X (-1)", "2" to "2 (-1)"), true))
        add(Market("hcp_home_plus1", "Handikap", "Handikaplı MS (Ev +1)", sels("1" to "1 (+1)", "X" to "X (+1)", "2" to "2 (+1)"), true))
    }

    private val byKey: Map<String, Market> = all.associateBy { it.key }

    fun find(key: String): Market? = byKey[key]
    fun marketTitle(key: String): String = byKey[key]?.title ?: key
    fun selectionLabel(marketKey: String, selectionKey: String): String =
        byKey[marketKey]?.selections?.firstOrNull { it.key == selectionKey }?.label ?: selectionKey
}
