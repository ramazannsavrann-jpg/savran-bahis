package com.savran.bahis

import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import java.time.LocalDate
import java.time.LocalTime
import java.time.ZoneId
import java.time.format.DateTimeFormatter

/**
 * football-data.co.uk: anahtarsız, ücretsiz CSV dosyaları (bitmiş maç sonuçları). Diğer kaynaklar puan durumu
 * veremediğinde yerli ligler için iç saha/deplasman tablosu bu gerçek sonuçlardan hesaplanır.
 * Avrupa kupaları bu kaynakta yoktur. Dosya 12 saat önbellekte tutulur.
 */
class FootballDataCoUkSource(private val dir: File) {
    @Volatile var status: String = "Henüz denenmedi"
        private set

    suspend fun results(leagueId: Int, season: Int): ApiResult<List<FinishedResult>> = withContext(Dispatchers.IO) {
        val div = divisions[leagueId] ?: return@withContext ApiResult.Err("football-data.co.uk bu ligi kapsamıyor.")
        val code = seasonCode(season)
        dir.mkdirs()
        val f = File(dir, "${div}_$code.csv")
        val now = System.currentTimeMillis()
        if (f.exists() && now - f.lastModified() < 12L * 3600 * 1000) {
            val r = parse(f.readText())
            status = "Önbellekten: $div $code (${r.size} maç)"
            return@withContext ApiResult.Ok(r)
        }
        var conn: HttpURLConnection? = null
        try {
            // Önce HTTPS; bağlantı kurulamazsa http (bu alan adı için cleartext ağ ayarında açık).
            var body: String? = null
            var lastCode = 0
            for (scheme in listOf("https", "http")) {
                try {
                    conn = URL("$scheme://www.football-data.co.uk/mmz4281/$code/$div.csv").openConnection() as HttpURLConnection
                    conn!!.connectTimeout = 15000
                    conn!!.readTimeout = 20000
                    conn!!.setRequestProperty("User-Agent", "Mozilla/5.0 (Android) SavranAnaliz")
                    val c = conn!!.responseCode
                    lastCode = c
                    if (c in 200..299) { body = conn!!.inputStream.bufferedReader(Charsets.ISO_8859_1).use { it.readText() }; break }
                } catch (e: IOException) {
                    if (scheme == "http") throw e
                } finally {
                    conn?.disconnect(); conn = null
                }
            }
            if (body == null) {
                status = "HTTP $lastCode ($div $code)"
                return@withContext staleOr(f, "football-data.co.uk hatası ($lastCode).")
            }
            val r = parse(body)
            if (r.isNotEmpty()) {
                val tmp = File(dir, f.name + ".tmp")
                tmp.writeText(body)
                if (!tmp.renameTo(f)) { f.delete(); tmp.renameTo(f) }
            }
            status = "Alındı: $div $code (${r.size} maç)"
            ApiResult.Ok(r)
        } catch (e: CancellationException) {
            throw e
        } catch (e: IOException) {
            status = "Ulaşılamadı"
            staleOr(f, "football-data.co.uk'a ulaşılamadı.")
        } catch (e: Exception) {
            status = "Okunamadı"
            staleOr(f, "football-data.co.uk dosyası okunamadı.")
        } finally {
            conn?.disconnect()
        }
    }

    private fun staleOr(f: File, msg: String): ApiResult<List<FinishedResult>> =
        if (f.exists()) ApiResult.Ok(parse(f.readText())) else ApiResult.Err(msg)

    companion object {
        /** API-Football lig no -> football-data.co.uk lig kodu. */
        val divisions = mapOf(203 to "T1", 39 to "E0", 78 to "D1", 140 to "SP1", 61 to "F1", 135 to "I1")

        /** 2026 -> "2627" (sezon başlangıç yılı). */
        fun seasonCode(season: Int): String = "%02d%02d".format(season % 100, (season + 1) % 100)

        private val london: ZoneId = ZoneId.of("Europe/London")
        private val d4 = DateTimeFormatter.ofPattern("dd/MM/yyyy")
        private val d2 = DateTimeFormatter.ofPattern("dd/MM/yy")

        /** CSV'den yalnızca skoru dolu satırları okur; bozuk satır atlanır. */
        fun parse(csv: String): List<FinishedResult> {
            val lines = csv.removePrefix("﻿").lines().filter { it.isNotBlank() }
            if (lines.isEmpty()) return emptyList()
            val head = lines[0].split(',').map { it.trim() }
            val iDate = head.indexOf("Date")
            val iTime = head.indexOf("Time")
            val iH = head.indexOf("HomeTeam")
            val iA = head.indexOf("AwayTeam")
            val iHG = head.indexOf("FTHG")
            val iAG = head.indexOf("FTAG")
            if (listOf(iDate, iH, iA, iHG, iAG).any { it < 0 }) return emptyList()
            val out = ArrayList<FinishedResult>()
            for (line in lines.drop(1)) {
                val c = line.split(',')
                if (c.size <= maxOf(iDate, iH, iA, iHG, iAG)) continue
                val hg = c[iHG].trim().toIntOrNull() ?: continue
                val ag = c[iAG].trim().toIntOrNull() ?: continue
                val home = c[iH].trim()
                val away = c[iA].trim()
                if (home.isEmpty() || away.isEmpty()) continue
                val ds = c[iDate].trim()
                val date = try { LocalDate.parse(ds, if (ds.length > 8) d4 else d2) } catch (e: Exception) { continue }
                val time = if (iTime >= 0 && iTime < c.size) try { LocalTime.parse(c[iTime].trim()) } catch (e: Exception) { LocalTime.NOON } else LocalTime.NOON
                out.add(FinishedResult(home, away, hg, ag, date.atTime(time).atZone(london).toEpochSecond()))
            }
            return out
        }
    }
}
