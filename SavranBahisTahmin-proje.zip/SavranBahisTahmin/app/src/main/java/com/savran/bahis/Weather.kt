package com.savran.bahis

import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.time.Instant
import java.time.ZoneOffset
import java.time.format.DateTimeFormatter
import kotlin.math.abs

data class MatchWeather(val city: String, val tempC: Double, val precipMm: Double, val windKmh: Double) {
    /** Kısa, dürüst not. Hava durumu MODELE katılmaz; yalnızca bilgi. */
    fun text(): String {
        val warn = when {
            precipMm >= 2.0 && windKmh >= 30 -> " Kuvvetli yağış ve rüzgar: gol sayısı genelde biraz düşebilir."
            precipMm >= 2.0 -> " Kuvvetli yağış bekleniyor."
            windKmh >= 35 -> " Kuvvetli rüzgar bekleniyor."
            else -> ""
        }
        return "$city, maç saati: ${Math.round(tempC)}°C · yağış ${"%.1f".format(java.util.Locale.US, precipMm)} mm · rüzgar ${Math.round(windKmh)} km/s.$warn"
    }
}

/**
 * Open-Meteo (ücretsiz, anahtarsız): stadın şehri için maç saatindeki hava tahmini.
 * Yalnızca 15 gün içindeki maçlar; şehir bilgisi yoksa hiçbir şey göstermez. Sonuç 3 saat önbellekte.
 */
class WeatherSource(private val dir: File) {
    suspend fun forMatch(m: Match): MatchWeather? = withContext(Dispatchers.IO) {
        val city = m.venueCity?.substringBefore(',')?.trim()?.takeIf { it.length >= 2 } ?: return@withContext null
        val now = System.currentTimeMillis() / 1000
        if (m.kickoff < now - 3 * 3600 || m.kickoff > now + 15L * 86400) return@withContext null
        dir.mkdirs()
        val cf = File(dir, "w_${m.id.replace(Regex("[^A-Za-z0-9_-]"), "_")}.json")
        try {
            if (cf.exists() && System.currentTimeMillis() - cf.lastModified() < 3L * 3600 * 1000) {
                val o = JSONObject(cf.readText())
                return@withContext MatchWeather(o.getString("c"), o.getDouble("t"), o.getDouble("p"), o.getDouble("w"))
            }
            val g = JSONObject(get("https://geocoding-api.open-meteo.com/v1/search?count=1&language=tr&name=" + URLEncoder.encode(city, "UTF-8")) ?: return@withContext null)
            val r = g.optJSONArray("results")?.optJSONObject(0) ?: return@withContext null
            val lat = r.getDouble("latitude")
            val lon = r.getDouble("longitude")
            val day = DateTimeFormatter.ISO_LOCAL_DATE.format(Instant.ofEpochSecond(m.kickoff).atOffset(ZoneOffset.UTC))
            val f = JSONObject(
                get("https://api.open-meteo.com/v1/forecast?latitude=$lat&longitude=$lon&hourly=temperature_2m,precipitation,wind_speed_10m&timezone=UTC&timeformat=unixtime&start_date=$day&end_date=$day")
                    ?: return@withContext null
            )
            val h = f.getJSONObject("hourly")
            val times = h.getJSONArray("time")
            var best = -1
            var bestD = Long.MAX_VALUE
            for (i in 0 until times.length()) {
                val d = abs(times.getLong(i) - m.kickoff)
                if (d < bestD) { bestD = d; best = i }
            }
            if (best < 0 || bestD > 2 * 3600) return@withContext null
            val t = h.getJSONArray("temperature_2m").optDouble(best, Double.NaN)
            val p = h.getJSONArray("precipitation").optDouble(best, Double.NaN)
            val w = h.getJSONArray("wind_speed_10m").optDouble(best, Double.NaN)
            if (t.isNaN() || p.isNaN() || w.isNaN()) return@withContext null
            val name = r.optString("name", city)
            cf.writeText(JSONObject().put("c", name).put("t", t).put("p", p).put("w", w).toString())
            MatchWeather(name, t, p, w)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            null
        }
    }

    private fun get(url: String): String? {
        val c = URL(url).openConnection() as HttpURLConnection
        return try {
            c.connectTimeout = 10000
            c.readTimeout = 15000
            if (c.responseCode !in 200..299) null else c.inputStream.bufferedReader().use { it.readText() }
        } finally {
            c.disconnect()
        }
    }
}
