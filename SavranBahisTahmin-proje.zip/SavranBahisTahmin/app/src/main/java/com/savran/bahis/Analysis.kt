package com.savran.bahis

enum class Decision(val tr: String) {
    RECOMMEND("Öneri"),
    LOW_EDGE("Avantaj yetersiz"),
    LOW_ODDS("Oran çok düşük"),
    STALE_ODDS("Oran eski"),
    NO_DATA("Veri yetersiz")
}

data class QualityBreakdown(
    val ev: Double, val edge: Double, val prob: Double, val data: Double,
    val fresh: Double, val market: Double, val history: Double, val penalty: Double
) {
    val total: Int get() = (ev + edge + prob + data + fresh + market + history - penalty).coerceIn(0.0, 100.0).toInt()
}

data class Evaluation(
    val matchId: String,
    val marketKey: String,
    val selectionKey: String,
    val odds: Double,
    val bookmaker: String,
    val origin: String,
    val updatedAt: Long,
    val modelProb: Double?,
    val adjProb: Double?,
    val impliedProb: Double,
    val fairProb: Double?,
    val ev: Double?,
    val quality: Int?,
    val breakdown: QualityBreakdown?,
    val decision: Decision,
    val reason: String,
    val highRisk: Boolean
)

data class AnalysisContext(
    val model: ScoreModel?,
    val dataQuality: Double,          // 0..1
    val rotationHigh: Boolean,
    val historyScore: Double?,        // 0..1, yeterli geçmiş yoksa null
    val coverage: Double = 1.0,       // modelin desteklediği kriterlerden kaçı gerçekten kullanıldı (0..1)
    val homeGames: Int? = null,       // ev sahibinin iç saha maç sayısı
    val awayGames: Int? = null,       // deplasman takımının deplasman maç sayısı
    val learning: LearningState? = null,  // öğrenilmiş kalibrasyon / zayıf pazar bilgisi
    val cup: Boolean = false,             // UEFA kupası maçı: lig gücü farkı modele girmez
    val thinData: Boolean = false,        // toplam maç istatistiğine geçildi (iç saha/deplasman ayrımı yok): güven puanı düşer
    val veryThin: Boolean = false,        // takım verisi neredeyse yok: lig ortalaması (+varsa Elo) ile "Çok az veri" tahmini; kupona/kayda girmez
    val eloPrior: Boolean = false,        // Avrupa kupası: az kupa maçı ClubElo uzun dönem gücüyle birleştirildi (güven hesabında veri tabanı genişler)
    val goalModel: ScoreModel? = null     // gol pazarları için temkinli model (GoalModel); yoksa ana model
) {
    fun modelFor(mk: String): ScoreModel? = if (GoalModel.isGoalMarket(mk)) goalModel ?: model else model
}

object OpportunityEngine {
    const val MODEL_VERSION = "poisson-v5"   // v4: geçen sezon önseli + gol kalibrasyonu (v3: temkinli gol modeli)
    const val MIN_EV = 0.04
    const val MIN_QUALITY = 55
    const val MIN_ODDS = 1.20
    const val MIN_DATA_QUALITY = 0.5

    private fun clamp01(x: Double) = x.coerceIn(0.0, 1.0)

    fun marketReliability(mk: String): Double = when {
        mk == "1x2" || mk == "dc" || mk.startsWith("ou_") || mk == "btts" -> 1.0
        mk.startsWith("home_ou_") || mk.startsWith("away_ou_") -> 0.9
        mk.startsWith("ht_") -> 0.8
        mk.startsWith("hcp_") -> 0.8
        mk.startsWith("combo_") -> 0.7
        mk == "htft" -> 0.6
        mk == "cs" -> 0.4
        else -> 0.3
    }

    fun quality(
        ev: Double, adj: Double, implied: Double, dq: Double, oddsAgeMs: Long,
        reliability: Double, history: Double?, rotationHigh: Boolean, hasFair: Boolean
    ): QualityBreakdown {
        val freshPts = when {
            oddsAgeMs < 2L * 3600 * 1000 -> 10.0
            oddsAgeMs < OddsFreshness.STALE_AFTER_MS -> 6.0
            else -> 0.0
        }
        var penalty = 0.0
        if (rotationHigh) penalty += 5.0
        if (!hasFair) penalty += 5.0
        return QualityBreakdown(
            ev = 30.0 * clamp01(ev / 0.15),
            edge = 15.0 * clamp01((adj - implied) / 0.10),
            prob = 10.0 * clamp01(adj / 0.8),
            data = 15.0 * clamp01(dq),
            fresh = freshPts,
            market = 10.0 * reliability,
            history = if (history == null) 5.0 else 10.0 * clamp01(history),
            penalty = penalty
        )
    }

    /** Tam kapsayan pazarlarda, aynı şirketin tüm seçenekleri varsa marjı çıkarılmış piyasa olasılığı. */
    fun fairProbabilities(entries: List<OddsEntry>): Map<Pair<String, String>, Double> {
        val out = HashMap<Pair<String, String>, MutableList<Double>>()
        entries.groupBy { it.marketKey }.forEach { (mk, list) ->
            val market = MarketCatalog.find(mk) ?: return@forEach
            if (!market.exhaustive) return@forEach
            list.groupBy { it.bookmaker.lowercase() }.forEach { (_, byBook) ->
                val bySel = byBook.associateBy { it.selectionKey }
                if (market.selections.all { bySel.containsKey(it.key) }) {
                    val odds = market.selections.map { bySel.getValue(it.key).odds }
                    val fair = OddsMath.fairProbabilities(odds)
                    market.selections.forEachIndexed { i, s ->
                        out.getOrPut(Pair(mk, s.key)) { mutableListOf() }.add(fair[i])
                    }
                }
            }
        }
        return out.mapValues { it.value.average() }
    }

    fun evaluate(odds: List<OddsEntry>, ctx: AnalysisContext, nowMs: Long, kickoffSec: Long): List<Evaluation> {
        val fairMap = fairProbabilities(odds)
        val result = ArrayList<Evaluation>()
        odds.groupBy { Pair(it.marketKey, it.selectionKey) }.forEach { (key, list) ->
            val fresh = list.filter { !OddsFreshness.isStale(it.updatedAt, nowMs, kickoffSec) }
            val best = (if (fresh.isNotEmpty()) fresh else list).maxByOrNull { it.odds } ?: return@forEach
            val stale = fresh.isEmpty()
            val (mk, sk) = key
            val implied = OddsMath.impliedProbability(best.odds)
            val fair = fairMap[key]
            val pModel = ctx.modelFor(mk)?.let { MarketProb.prob(it, mk, sk) }
                ?.let { if (GoalModel.isGoalMarket(mk)) GoalModel.calibrate(mk, sk, it) else it }

            fun make(decision: Decision, reason: String, adj: Double? = null, ev: Double? = null, q: QualityBreakdown? = null) =
                Evaluation(
                    best.matchId, mk, sk, best.odds, best.bookmaker, best.origin, best.updatedAt,
                    pModel, adj, implied, fair, ev, q?.total, q, decision, reason,
                    highRisk = mk == "cs" || best.odds >= 8.0
                )

            if (ctx.model == null) {
                result.add(make(Decision.NO_DATA, "Bu maç için takım verisi/model yok; değerlendirme yapılamadı."))
                return@forEach
            }
            if (pModel == null) {
                result.add(make(Decision.NO_DATA, "Bu pazar için güvenilir istatistik yok (ör. korner/kart); tahmin üretilmedi."))
                return@forEach
            }
            val w = 0.35 + 0.35 * clamp01(ctx.dataQuality)
            val adj = if (fair != null) w * pModel + (1 - w) * fair else pModel
            val ev = OddsMath.expectedValue(adj, best.odds)
            val q = quality(
                ev, adj, implied, ctx.dataQuality, nowMs - best.updatedAt,
                marketReliability(mk), ctx.historyScore, ctx.rotationHigh, fair != null
            )
            when {
                stale -> result.add(make(Decision.STALE_ODDS, "Oran eski (6 saatten eski veya maç başladı); güncelle.", adj, ev, q))
                best.odds < MIN_ODDS -> result.add(make(Decision.LOW_ODDS, "Oran ${"%.2f".format(best.odds)} çok düşük; olasılık yüksek olsa da değer yok sayıldı.", adj, ev, q))
                ctx.dataQuality < MIN_DATA_QUALITY -> result.add(make(Decision.LOW_EDGE, "Takım verisi az (sezon başı); öneri için yetersiz.", adj, ev, q))
                ev >= MIN_EV && q.total >= MIN_QUALITY -> result.add(make(Decision.RECOMMEND, reasonText(adj, implied, ev, fair != null), adj, ev, q))
                ev < MIN_EV -> result.add(make(Decision.LOW_EDGE, "Beklenen değer %${"%.1f".format(ev * 100)}; eşik %${"%.0f".format(MIN_EV * 100)} altında.", adj, ev, q))
                else -> result.add(make(Decision.LOW_EDGE, "Kalite puanı ${q.total}; eşik $MIN_QUALITY altında.", adj, ev, q))
            }
        }
        return result.sortedWith(compareByDescending<Evaluation> { it.decision == Decision.RECOMMEND }.thenByDescending { it.quality ?: -1 })
    }

    private fun reasonText(adj: Double, implied: Double, ev: Double, hasFair: Boolean): String {
        val base = "Tahmini olasılık %${"%.0f".format(adj * 100)}, oranın zımni olasılığı %${"%.0f".format(implied * 100)}; beklenen değer %${"%.1f".format(ev * 100)}."
        return if (hasFair) "$base Piyasa marjı çıkarılmış olasılıkla karşılaştırıldı."
        else "$base Piyasa doğrulaması yok (tek taraflı oran girişi); temkinli ol."
    }

    /** Oran girilmemiş olsa da model olasılığı kaydedilecek çekirdek seçenekler (kalibrasyon için). */
    val coreSelections: List<Pair<String, String>> = listOf(
        "1x2" to "1", "1x2" to "X", "1x2" to "2",
        "ou_2.5" to "over", "ou_2.5" to "under",
        "btts" to "yes", "btts" to "no"
    )
}
