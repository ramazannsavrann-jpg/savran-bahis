package com.savran.bahis

import android.content.Context
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Deferred
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.time.Instant
import java.time.LocalDate
import java.time.ZoneId
import java.time.temporal.ChronoUnit

data class DayMatches(
    val matches: List<Match>,
    val notice: String?,
    val fetchedAt: Long?,
    val fromCache: Boolean
)

data class CoreProb(val label: String, val prob: Double)

data class AnalysisResult(
    val match: Match,
    val lambdaHome: Double?,
    val lambdaAway: Double?,
    val dataQuality: Double,
    val modelNote: String,
    val evaluations: List<Evaluation>,
    val core: List<CoreProb>,
    val topScores: List<Triple<Int, Int, Double>>,
    val recorded: Int
)

class Repository(context: Context) {
    val settings = AppSettings(context)
    val zone: ZoneId = ZoneId.of("Europe/Istanbul")

    private val root = context.filesDir
    private val store = LocalStore(root)
    private val cache = FixtureCache(File(root, "cache"))
    private val tableCache = TableCache(File(root, "tables"))
    private val extDir = File(root, "ext_odds").apply { mkdirs() }
    private val rotationDir = File(root, "rotation").apply { mkdirs() }
    private val predictions = PredictionStore(root)
    private val fixtureProvider = ApiFootballFixtureProvider(settings)
    private val oddsApi = OddsApiClient(settings, extDir)
    private val oddsProviders: List<OddsProvider> = listOf(ManualOddsProvider(store))

    // Diğer veri kaynakları (her biri bağımsız; biri çökerse diğerleri etkilenmez)
    private val footballData = FootballDataClient(settings)
    private val apiNinjas = ApiNinjasClient(settings)
    private val theSportsDb = TheSportsDbClient(settings)
    private val openLiga = OpenLigaClient(settings)
    private val statsBomb = StatsBombClient(settings)
    private val extraCaches = mapOf(
        SourceId.FOOTBALL_DATA to FixtureCache(File(root, "cache_fd")),
        SourceId.API_NINJAS to FixtureCache(File(root, "cache_an")),
        SourceId.THESPORTSDB to FixtureCache(File(root, "cache_ts")),
        SourceId.OPENLIGADB to FixtureCache(File(root, "cache_ol"))
    )

    fun today(): LocalDate = LocalDate.now(zone)

    // ---------------------------------------------------------------- Maç listesi

    private data class ExtraResult(val id: SourceId, val matches: List<Match>, val error: String?, val fetched: Boolean)

    suspend fun matchesForDate(date: LocalDate, force: Boolean): DayMatches = withContext(Dispatchers.IO) {
        val now = System.currentTimeMillis()
        val offset = ChronoUnit.DAYS.between(today(), date).toInt()

        val manual = store.matches().filter {
            Instant.ofEpochSecond(it.kickoff).atZone(zone).toLocalDate() == date
        }
        val cached = cache.read(date.toString())
        var api: List<Match> = cached?.matches ?: emptyList()
        var fetchedAt: Long? = cached?.fetchedAt
        var fromCache = cached != null
        val notices = ArrayList<String>()

        val apiActive = settings.apiKey != null
        val needFetch = force || cached == null || !CachePolicy.isFresh(cached.fetchedAt, now, offset)
        if (needFetch && apiActive) {
            when (val r = fixtureProvider.fixtures(date)) {
                is ApiResult.Ok -> {
                    api = r.value
                    fetchedAt = now
                    fromCache = false
                    cache.write(date.toString(), now, r.value)
                }
                is ApiResult.Err -> {
                    notices.add(if (cached != null) "${r.message} Kayıtlı (eski) veri gösteriliyor." else r.message)
                }
            }
        }

        // Diğer aktif kaynaklar paralel çalışır; her biri kendi hatasını bildirir.
        val extras = fetchExtraSources(date, offset, force, now)
        for (e in extras) {
            val err = e.error
            if (err != null) notices.add(err)
        }
        if (fetchedAt == null && extras.any { it.fetched }) {
            fetchedAt = now
            fromCache = false
        }
        if (!apiActive && extras.isEmpty() && manual.isEmpty() && cached == null) {
            notices.add("Etkin veri kaynağı yok. Ayarlar > Veri kaynakları bölümünden bir kaynağı aktif et ve anahtarını gir, ya da maçı elle ekle.")
        }
        val merged = FixtureMerge.merge(api, extras.flatMap { it.matches })
        DayMatches(
            (merged + manual).sortedBy { it.kickoff },
            if (notices.isEmpty()) null else notices.joinToString("\n"),
            fetchedAt, fromCache
        )
    }

    private suspend fun fetchExtraSources(date: LocalDate, offset: Int, force: Boolean, now: Long): List<ExtraResult> = coroutineScope {
        val jobs = ArrayList<Deferred<ExtraResult>>()
        // Birleştirmede öncelik sırası: Football-Data > API Ninjas > OpenLigaDB > TheSportsDB
        settings.keyOf(SourceId.FOOTBALL_DATA)?.let { k ->
            jobs.add(async { cachedExtra(SourceId.FOOTBALL_DATA, date, offset, force, now) { footballData.fixtures(k, date, zone) } })
        }
        // API Ninjas ücretsiz kotası aylık: yalnızca bugün ve yarın için çağrılır.
        settings.keyOf(SourceId.API_NINJAS)?.let { k ->
            if (offset in 0..1) {
                jobs.add(async { cachedExtra(SourceId.API_NINJAS, date, offset, force, now) { apiNinjas.fixtures(k, date) } })
            }
        }
        if (settings.isActive(SourceId.OPENLIGADB)) {
            jobs.add(async { cachedExtra(SourceId.OPENLIGADB, date, offset, force, now) { openLiga.fixtures(date, zone, settings.season) } })
        }
        if (settings.isActive(SourceId.THESPORTSDB)) {
            val k = settings.keyOf(SourceId.THESPORTSDB) ?: "123"
            jobs.add(async { cachedExtra(SourceId.THESPORTSDB, date, offset, force, now) { theSportsDb.fixtures(k, date, zone, today()) } })
        }
        jobs.awaitAll()
    }

    private suspend fun cachedExtra(
        id: SourceId, date: LocalDate, offset: Int, force: Boolean, now: Long,
        fetch: suspend () -> ApiResult<List<Match>>
    ): ExtraResult {
        val c = extraCaches.getValue(id)
        val cached = c.read(date.toString())
        if (!force && cached != null && CachePolicy.isFresh(cached.fetchedAt, now, offset)) {
            return ExtraResult(id, cached.matches, null, false)
        }
        return when (val r = fetch()) {
            is ApiResult.Ok -> {
                c.write(date.toString(), now, r.value)
                ExtraResult(id, r.value, null, true)
            }
            is ApiResult.Err -> ExtraResult(
                id, cached?.matches ?: emptyList(),
                r.message + if (cached != null) " Kayıtlı (eski) veri kullanıldı." else "", false
            )
        }
    }

    // ---------------------------------------------------------------- Oranlar

    suspend fun oddsFor(matchId: String): List<OddsEntry> = withContext(Dispatchers.IO) {
        oddsProviders.flatMap { it.oddsFor(matchId) }
    }

    suspend fun oddsCounts(): Map<String, Int> = withContext(Dispatchers.IO) {
        store.allOdds().groupingBy { it.matchId }.eachCount()
    }

    suspend fun addManualMatch(m: Match) = withContext(Dispatchers.IO) { store.addMatch(m) }
    suspend fun deleteManualMatch(id: String) = withContext(Dispatchers.IO) { store.deleteMatch(id) }
    suspend fun saveOdds(entries: List<OddsEntry>) = withContext(Dispatchers.IO) { store.upsertOdds(entries) }
    suspend fun deleteOdds(id: String) = withContext(Dispatchers.IO) { store.deleteOdds(id) }

    fun externalOddsAvailable(leagueId: Int) = settings.oddsApiKey != null && oddsApi.supports(leagueId)

    /** İkinci kaynaktan (The Odds API) oranları çeker; kredi harcar. Kendi etiketiyle kaydedilir. */
    suspend fun importExternalOdds(match: Match): ApiResult<Int> = withContext(Dispatchers.IO) {
        when (val r = oddsApi.events(match.leagueId, force = false)) {
            is ApiResult.Err -> r
            is ApiResult.Ok -> {
                val ev = oddsApi.findEvent(r.value, match)
                    ?: return@withContext ApiResult.Err("Bu maç harici kaynakta bulunamadı (takım adı/saat eşleşmedi).")
                val entries = ev.prices.map {
                    OddsEntry(
                        id = "${match.id}|${it.marketKey}|${it.selectionKey}|${it.bookmaker.lowercase()}|ext",
                        matchId = match.id, marketKey = it.marketKey, selectionKey = it.selectionKey,
                        odds = it.odds, bookmaker = it.bookmaker, origin = "The Odds API", updatedAt = it.updatedAt
                    )
                }
                if (entries.isEmpty()) ApiResult.Err("Harici kaynakta bu maç için uygun pazar yok.")
                else { store.upsertOdds(entries); ApiResult.Ok(entries.size) }
            }
        }
    }

    // ---------------------------------------------------------------- Veri: puan durumu, model

    /**
     * Model için puan durumu (genel + iç saha + deplasman). Sırayla: API-Football, Football-Data.org.
     * Biri hata verirse diğeri denenir; ikisi de olmazsa kayıtlı (eski) tablo kullanılır.
     */
    suspend fun table(leagueId: Int, force: Boolean = false): ApiResult<LeagueTable> = withContext(Dispatchers.IO) {
        val season = settings.season
        val now = System.currentTimeMillis()
        val cached = tableCache.read(leagueId, season)
        if (cached != null && !force && now - cached.fetchedAt < 24L * 3600 * 1000) return@withContext ApiResult.Ok(cached)
        val errors = ArrayList<String>()

        if (settings.apiKey != null) {
            when (val r = fixtureProvider.call("/standings?league=$leagueId&season=$season")) {
                is ApiResult.Err -> errors.add(r.message)
                is ApiResult.Ok -> when (val p = parseStandings(r.value, leagueId, season, now)) {
                    is ApiResult.Ok -> { tableCache.write(p.value); return@withContext p }
                    is ApiResult.Err -> errors.add(p.message)
                }
            }
        }
        val fdKey = settings.keyOf(SourceId.FOOTBALL_DATA)
        if (fdKey != null && FootballDataClient.codes.containsKey(leagueId)) {
            when (val r = footballData.table(fdKey, leagueId, season, now)) {
                is ApiResult.Ok -> { tableCache.write(r.value); return@withContext r }
                is ApiResult.Err -> errors.add(r.message)
            }
        }
        if (cached != null) return@withContext ApiResult.Ok(cached)
        ApiResult.Err(
            if (errors.isEmpty()) "Puan durumu için etkin kaynak yok. API-Football veya Football-Data.org'u aktif edip anahtarını gir."
            else errors.joinToString(" | ")
        )
    }

    private fun resolveTeamId(rows: List<TeamRow>, id: Int, name: String): Int? {
        if (id > 0 && rows.any { it.teamId == id }) return id
        val best = TeamMatcher.bestMatch(name, rows.map { it.name }) ?: return null
        return rows.firstOrNull { it.name == best }?.teamId
    }

    private fun historyScore(): Double? = Metrics.historyScore(Metrics.report(predictions.all()))

    suspend fun analyze(match: Match): AnalysisResult = withContext(Dispatchers.IO) {
        val now = System.currentTimeMillis()
        var lh: Double? = null
        var la: Double? = null
        var dq = 0.0
        var note = ""

        val manual = settings.manualLambdas(match.id)
        if (manual != null) {
            lh = manual.first; la = manual.second; dq = 0.6
            note = "Elle girilen beklenen gol kullanıldı (veri kalitesi sınırlı sayıldı)."
        } else if (Leagues.byId(match.leagueId) == null) {
            note = "Bu lig desteklenen liglerde değil; model için beklenen golü elle gir."
        } else {
            when (val t = table(match.leagueId)) {
                is ApiResult.Err -> note = "Puan durumu alınamadı: ${t.message}"
                is ApiResult.Ok -> {
                    val hid = resolveTeamId(t.value.rows, match.homeId, match.home)
                    val aid = resolveTeamId(t.value.rows, match.awayId, match.away)
                    if (hid == null || aid == null) {
                        note = "Takımlar puan durumuyla eşleştirilemedi."
                    } else {
                        val l = Strength.lambdas(t.value.rows, hid, aid)
                        if (l == null) note = "Puan durumu verisi yetersiz."
                        else {
                            lh = l.home; la = l.away; dq = l.dataQuality
                            note = "Sezon ${t.value.season} iç saha/deplasman gol istatistikleri (puan durumu) ile hesaplandı."
                        }
                    }
                }
            }
        }

        val model = if (lh != null && la != null) ScoreModel(lh, la) else null
        val rotHigh = listOf(match.homeId, match.awayId).any { id ->
            id > 0 && cachedRotation(id, match.kickoff)?.risk == "Yüksek"
        }
        val ctx = AnalysisContext(model, dq, rotHigh, historyScore())
        val evals = OpportunityEngine.evaluate(store.oddsForMatch(match.id), ctx, now, match.kickoff)

        val core = ArrayList<CoreProb>()
        val tops = ArrayList<Triple<Int, Int, Double>>()
        if (model != null) {
            core.add(CoreProb("Ev sahibi kazanır", MarketProb.prob(model, "1x2", "1") ?: 0.0))
            core.add(CoreProb("Beraberlik", MarketProb.prob(model, "1x2", "X") ?: 0.0))
            core.add(CoreProb("Deplasman kazanır", MarketProb.prob(model, "1x2", "2") ?: 0.0))
            core.add(CoreProb("2.5 Üst", MarketProb.prob(model, "ou_2.5", "over") ?: 0.0))
            core.add(CoreProb("KG Var", MarketProb.prob(model, "btts", "yes") ?: 0.0))
            tops.addAll(model.topScores(3))
        }
        val recorded = if (model != null) record(match, model, dq, evals, now) else 0
        AnalysisResult(match, lh, la, dq, note, evals, core, tops, recorded)
    }

    private fun record(match: Match, model: ScoreModel, dq: Double, evals: List<Evaluation>, now: Long): Int {
        if (match.statusShort != "NS" || match.kickoff * 1000 <= now) return 0   // veri sızıntısını önle
        val label = "${match.home} - ${match.away}"
        val items = ArrayList<PredictionRecord>()
        val seen = HashSet<String>()
        for (e in evals) {
            val pm = e.modelProb ?: continue
            val id = predictions.idOf(match.id, e.marketKey, e.selectionKey, OpportunityEngine.MODEL_VERSION)
            if (!seen.add(id)) continue
            items.add(
                PredictionRecord(
                    id, match.id, label, match.leagueId, match.leagueName, match.kickoff,
                    e.marketKey, e.selectionKey, now, pm, e.adjProb ?: pm, e.odds, e.bookmaker, e.updatedAt,
                    "Model: puan durumu (${match.source}); oran: ${e.origin}/${e.bookmaker}",
                    OpportunityEngine.MODEL_VERSION, e.decision == Decision.RECOMMEND, null, null, null
                )
            )
        }
        for ((mk, sk) in OpportunityEngine.coreSelections) {
            val id = predictions.idOf(match.id, mk, sk, OpportunityEngine.MODEL_VERSION)
            if (!seen.add(id)) continue
            val p = MarketProb.prob(model, mk, sk) ?: continue
            items.add(
                PredictionRecord(
                    id, match.id, label, match.leagueId, match.leagueName, match.kickoff,
                    mk, sk, now, p, p, null, null, null,
                    "Model: puan durumu (${match.source}); oran yok",
                    OpportunityEngine.MODEL_VERSION, false, null, null, null
                )
            )
        }
        return predictions.addIfAbsent(items)
    }

    /** Önümüzdeki günlerde oranı girilmiş maçları tarar (yeni istek: yalnızca eski/eksik önbellek). */
    suspend fun scanUpcoming(days: Int): List<AnalysisResult> {
        val counts = oddsCounts()
        val now = System.currentTimeMillis()
        val out = ArrayList<AnalysisResult>()
        for (d in 0 until days) {
            val day = matchesForDate(today().plusDays(d.toLong()), false)
            for (m in day.matches) {
                if (m.statusShort != "NS" || m.kickoff * 1000 <= now) continue
                if ((counts[m.id] ?: 0) == 0) continue
                out.add(analyze(m))
            }
        }
        return out
    }

    fun buildCoupons(scan: List<AnalysisResult>): Map<CouponType, Coupon?> {
        val picks = scan.flatMap { r -> r.evaluations.map { CouponPick(r.match, it) } }
        return CouponType.values().associateWith { CouponLab.build(it, picks) }
    }

    // ---------------------------------------------------------------- Canlı, sakatlık, rotasyon

    private fun apiFixtureId(match: Match): Int? = if (match.id.startsWith("api-")) match.id.removePrefix("api-").toIntOrNull() else null

    suspend fun liveRefresh(match: Match): ApiResult<Match> {
        val id = apiFixtureId(match) ?: return ApiResult.Err("Canlı veri yalnızca API-Football maçları için.")
        return when (val r = fixtureProvider.call("/fixtures?id=$id&timezone=Europe/Istanbul")) {
            is ApiResult.Err -> r
            is ApiResult.Ok -> when (val p = fixtureProvider.parseFixtures(r.value)) {
                is ApiResult.Err -> p
                is ApiResult.Ok -> p.value.firstOrNull()?.let { ApiResult.Ok(it) } ?: ApiResult.Err("Maç verisi bulunamadı.")
            }
        }
    }

    suspend fun injuries(match: Match): ApiResult<List<String>> {
        val id = apiFixtureId(match) ?: return ApiResult.Err("Sakatlık verisi yalnızca API-Football maçları için.")
        return when (val r = fixtureProvider.call("/injuries?fixture=$id")) {
            is ApiResult.Err -> r
            is ApiResult.Ok -> try {
                val arr = JSONObject(r.value).optJSONArray("response") ?: JSONArray()
                ApiResult.Ok((0 until arr.length()).map {
                    val o = arr.getJSONObject(it)
                    val p = o.optJSONObject("player")
                    val team = o.optJSONObject("team")?.optString("name", "") ?: ""
                    "$team – ${p?.optString("name", "?") ?: "?"} (${p?.optString("reason", "") ?: ""})"
                })
            } catch (e: Exception) {
                ApiResult.Err("Sakatlık yanıtı okunamadı.")
            }
        }
    }

    private fun rotationFile(teamId: Int) = File(rotationDir, "rotation_$teamId.json")

    private fun readRotationRaw(teamId: Int): Pair<Long, List<Lineup>>? {
        val f = rotationFile(teamId)
        if (!f.exists()) return null
        return try {
            val o = JSONObject(f.readText())
            val a = o.getJSONArray("lineups")
            Pair(o.getLong("fetchedAt"), (0 until a.length()).map { Rotation.lineupFromJson(a.getJSONObject(it)) })
        } catch (e: Exception) { f.delete(); null }
    }

    fun cachedRotation(teamId: Int, kickoff: Long): RotationInfo? {
        val raw = readRotationRaw(teamId) ?: return null
        return Rotation.analyze(teamId, raw.second, kickoff)
    }

    /**
     * Teknik direktör rotasyon analizi. Takım başına ~5 istek harcar (dakikada 10 sınırı için
     * istekler arasında bekler). Sonuç 24 saat önbelleklenir.
     */
    suspend fun rotationFor(teamId: Int, kickoff: Long, onProgress: (String) -> Unit): ApiResult<RotationInfo> {
        val raw = readRotationRaw(teamId)
        val now = System.currentTimeMillis()
        if (raw != null && now - raw.first < 24L * 3600 * 1000) return ApiResult.Ok(Rotation.analyze(teamId, raw.second, kickoff))

        onProgress("Son maçlar alınıyor…")
        val list = when (val r = fixtureProvider.call("/fixtures?team=$teamId&last=4&timezone=Europe/Istanbul")) {
            is ApiResult.Err -> return r
            is ApiResult.Ok -> try {
                val arr = JSONObject(r.value).optJSONArray("response") ?: JSONArray()
                (0 until arr.length()).map {
                    val fx = arr.getJSONObject(it).getJSONObject("fixture")
                    Pair(fx.getInt("id"), fx.getLong("timestamp"))
                }
            } catch (e: Exception) { return ApiResult.Err("Son maç listesi okunamadı.") }
        }
        val lineups = ArrayList<Lineup>()
        for ((i, f) in list.withIndex()) {
            delay(6500)   // dakikada 10 istek sınırı
            onProgress("Kadro ${i + 1}/${list.size} alınıyor…")
            when (val r = fixtureProvider.call("/fixtures/lineups?fixture=${f.first}")) {
                is ApiResult.Err -> if (lineups.isEmpty() && i == list.lastIndex) return r
                is ApiResult.Ok -> Rotation.parseLineup(r.value, f.first, f.second, teamId)?.let { lineups.add(it) }
            }
        }
        if (lineups.isEmpty()) return ApiResult.Err("Kadro verisi alınamadı (bu lig veya plan için sunulmuyor olabilir).")
        val arr = JSONArray()
        lineups.forEach { arr.put(Rotation.lineupToJson(it)) }
        atomicWrite(rotationFile(teamId), JSONObject().put("fetchedAt", now).put("lineups", arr).toString())
        return ApiResult.Ok(Rotation.analyze(teamId, lineups, kickoff))
    }

    // ---------------------------------------------------------------- Geçmiş ve performans

    suspend fun predictionList(): List<PredictionRecord> = withContext(Dispatchers.IO) {
        predictions.all().sortedByDescending { it.kickoff }
    }

    suspend fun report(): Report = withContext(Dispatchers.IO) { Metrics.report(predictions.all()) }

    suspend fun saveManualResult(match: Match, fh: Int, fa: Int, hh: Int?, ha: Int?) = withContext(Dispatchers.IO) {
        store.addMatch(match.copy(statusShort = "FT", homeGoals = fh, awayGoals = fa, homeHt = hh, awayHt = ha))
    }

    /** Bitmiş maçların sonuçlarını alıp bekleyen tahminleri değerlendirir. Tarih başına 1 API isteği. */
    suspend fun settlePending(): String = withContext(Dispatchers.IO) {
        val now = System.currentTimeMillis()
        val all = predictions.all()
        val pending = all.filter { it.result == null && it.kickoff * 1000 + 3L * 3600 * 1000 < now }
        if (pending.isEmpty()) return@withContext "Değerlendirilecek bekleyen tahmin yok."

        val results = HashMap<String, Match>()
        store.matches().forEach { results[it.id] = it }
        val dates = pending.filter { it.matchId.startsWith("api-") }
            .map { Instant.ofEpochSecond(it.kickoff).atZone(zone).toLocalDate() }.distinct()
        var apiNote = ""
        for (d in dates) {
            when (val r = fixtureProvider.fixtures(d)) {
                is ApiResult.Ok -> { r.value.forEach { results[it.id] = it }; cache.write(d.toString(), now, r.value) }
                is ApiResult.Err -> apiNote = " (Bazı sonuçlar alınamadı: ${r.message})"
            }
        }
        var settled = 0
        val updated = all.map { rec ->
            if (rec.result != null || rec.kickoff * 1000 + 3L * 3600 * 1000 >= now) rec
            else {
                val m = results[rec.matchId]
                val fh = m?.homeGoals
                val fa = m?.awayGoals
                if (m != null && StatusText.isFinished(m.statusShort) && fh != null && fa != null) {
                    val s = Settler.settle(rec, fh, fa, m.homeHt, m.awayHt, now)
                    if (s != null) { settled++; s } else rec
                } else rec
            }
        }
        predictions.replaceAll(updated)
        "$settled tahmin değerlendirildi, ${pending.size - settled} beklemede.$apiNote"
    }

    // ---------------------------------------------------------------- Ayarlar

    suspend fun checkApiStatus(): String = when (val r = fixtureProvider.status()) {
        is ApiResult.Ok -> r.value
        is ApiResult.Err -> r.message
    }

    // ---------------------------------------------------------------- Kaynak testi ve doğrulama

    private fun noKey(id: SourceId) = ApiResult.Err("${id.title}: anahtar girilmedi.")

    /** Bağlantı testi kaynağa özeldir; sonuç yalnızca o kaynağın kartında görünür. */
    suspend fun testSource(id: SourceId): TestState {
        val now = System.currentTimeMillis()
        val raw = settings.rawKeyOf(id)
        val season = settings.season
        val r: ApiResult<String> = try {
            when (id) {
                SourceId.API_FOOTBALL ->
                    if (raw == null) noKey(id) else {
                        val was = settings.isEnabled(id)
                        if (!was) settings.setEnabled(id, true)
                        try { fixtureProvider.status() } finally { if (!was) settings.setEnabled(id, false) }
                    }
                SourceId.FOOTBALL_DATA -> if (raw == null) noKey(id) else footballData.test(raw)
                SourceId.API_NINJAS -> if (raw == null) noKey(id) else apiNinjas.test(raw)
                SourceId.ODDS_API -> if (raw == null) noKey(id) else oddsApi.testConnection(settings, raw)
                SourceId.THESPORTSDB -> theSportsDb.test(raw ?: "123")
                SourceId.OPENLIGADB -> openLiga.test(season)
                SourceId.STATSBOMB -> statsBomb.test()
            }
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            ApiResult.Err("${id.title}: Beklenmeyen hata (${e.javaClass.simpleName}).")
        }
        val state = when (r) {
            is ApiResult.Ok -> TestState(true, r.value, now)
            is ApiResult.Err -> TestState(false, r.message, now)
        }
        settings.setLastTest(id, state)
        return state
    }

    /**
     * Bir maçın ev/deplasman takımlarının toplam istatistiklerini kaynaklar arasında karşılaştırır.
     * Referans: model için kullanılan puan durumu. Karşılaştırma tahmini değiştirmez, yalnızca tutarlılığı gösterir.
     */
    suspend fun verifyMatch(match: Match): List<SourceCheck> = withContext(Dispatchers.IO) {
        val season = settings.season
        val out = ArrayList<SourceCheck>()
        var refSource: SourceId? = null
        var refRows: List<NamedTotals>? = null
        when (val t = table(match.leagueId)) {
            is ApiResult.Ok -> {
                val first = t.value.rows.firstOrNull()
                refSource = if (first != null && first.teamId < 0) SourceId.FOOTBALL_DATA else SourceId.API_FOOTBALL
                refRows = t.value.rows.map { NamedTotals(it.name, it.all.played, it.all.goalsFor, it.all.goalsAgainst, it.points) }
            }
            is ApiResult.Err -> {}
        }
        val rr = refRows
        val refHome = if (rr != null) Verifier.find(rr, match.home) else null
        val refAway = if (rr != null) Verifier.find(rr, match.away) else null
        val listed = FixtureMerge.sources(match)

        for (id in SourceId.values()) {
            val info = SourceCatalog.info(id)
            val listedNote = if (listed.contains(id.title)) " Bu maçı listeledi." else ""
            val check: SourceCheck = when {
                id == refSource ->
                    SourceCheck(id, CheckStatus.REFERENCE, "Karşılaştırmanın temeli: model puan durumu bu kaynaktan.$listedNote")
                id == SourceId.ODDS_API ->
                    SourceCheck(id, CheckStatus.UNSUPPORTED, "Oran kaynağı; puan durumu vermez.")
                id == SourceId.STATSBOMB ->
                    SourceCheck(id, CheckStatus.UNSUPPORTED, "Yalnızca seçili geçmiş sezonlar; güncel veri yok.")
                match.leagueId !in info.leagues ->
                    SourceCheck(id, CheckStatus.UNSUPPORTED, "Bu lig kaynağın kapsamında yok.")
                !settings.isActive(id) ->
                    SourceCheck(id, CheckStatus.DISABLED, "Kaynak pasif veya anahtarı yok.")
                else -> verifyWith(id, match, season, refHome, refAway, listedNote)
            }
            out.add(check)
        }
        out
    }

    private suspend fun verifyWith(
        id: SourceId, match: Match, season: Int, refHome: NamedTotals?, refAway: NamedTotals?, listedNote: String
    ): SourceCheck {
        val now = System.currentTimeMillis()
        val key = settings.keyOf(id) ?: ""
        val rows: ApiResult<List<NamedTotals>> = when (id) {
            SourceId.FOOTBALL_DATA -> when (val t = footballData.table(key, match.leagueId, season, now)) {
                is ApiResult.Ok -> ApiResult.Ok(t.value.rows.map { NamedTotals(it.name, it.all.played, it.all.goalsFor, it.all.goalsAgainst, it.points) })
                is ApiResult.Err -> t
            }
            SourceId.API_NINJAS -> apiNinjas.standings(key, match.leagueId, season)
            SourceId.THESPORTSDB -> theSportsDb.table(key.ifEmpty { "123" }, match.leagueId, season)
            SourceId.OPENLIGADB -> openLiga.table(season)
            else -> ApiResult.Err("${id.title}: puan durumu bu kaynaktan alınamadı.")
        }
        return when (rows) {
            is ApiResult.Err -> SourceCheck(id, CheckStatus.ERROR, rows.message)
            is ApiResult.Ok -> {
                val (st, note) = Verifier.compare(refHome, refAway, rows.value, match.home, match.away)
                SourceCheck(id, st, note + listedNote)
            }
        }
    }

    fun clearCache() {
        cache.clear(); tableCache.clear()
        extraCaches.values.forEach { it.clear() }
        extDir.listFiles()?.forEach { it.delete() }
        rotationDir.listFiles()?.forEach { it.delete() }
    }
}
