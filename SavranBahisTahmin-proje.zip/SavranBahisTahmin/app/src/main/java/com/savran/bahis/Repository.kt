package com.savran.bahis

import android.content.Context
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.time.Instant
import java.time.LocalDate
import java.time.ZoneId
import java.time.temporal.ChronoUnit

data class DayMatches(
    val matches: List<Match>,
    val notice: String?,
    val fetchedAt: Long?,
    val fromCache: Boolean
)

data class CoreProb(val label: String, val prob: Double)

data class AnalysisResult(
    val match: Match,
    val lambdaHome: Double?,
    val lambdaAway: Double?,
    val dataQuality: Double,
    val modelNote: String,
    val evaluations: List<Evaluation>,
    val core: List<CoreProb>,
    val topScores: List<Triple<Int, Int, Double>>,
    val recorded: Int
)

class Repository(context: Context) {
    val settings = AppSettings(context)
    val zone: ZoneId = ZoneId.of("Europe/Istanbul")

    private val root = context.filesDir
    private val store = LocalStore(root)
    private val cache = FixtureCache(File(root, "cache"))
    private val tableCache = TableCache(File(root, "tables"))
    private val extDir = File(root, "ext_odds").apply { mkdirs() }
    private val rotationDir = File(root, "rotation").apply { mkdirs() }
    private val predictions = PredictionStore(root)
    private val fixtureProvider = ApiFootballFixtureProvider(settings)
    private val oddsApi = OddsApiClient(settings, extDir)
    private val oddsProviders: List<OddsProvider> = listOf(ManualOddsProvider(store))

    fun today(): LocalDate = LocalDate.now(zone)

    // ---------------------------------------------------------------- Maç listesi

    suspend fun matchesForDate(date: LocalDate, force: Boolean): DayMatches = withContext(Dispatchers.IO) {
        val now = System.currentTimeMillis()
        val offset = ChronoUnit.DAYS.between(today(), date).toInt()

        val manual = store.matches().filter {
            Instant.ofEpochSecond(it.kickoff).atZone(zone).toLocalDate() == date
        }
        val cached = cache.read(date.toString())
        var api: List<Match> = cached?.matches ?: emptyList()
        var fetchedAt: Long? = cached?.fetchedAt
        var fromCache = cached != null
        var notice: String? = null

        val needFetch = force || cached == null || !CachePolicy.isFresh(cached.fetchedAt, now, offset)
        if (needFetch) {
            if (settings.apiKey == null) {
                if (cached == null && manual.isEmpty()) {
                    notice = "API anahtarı girilmedi. Ayarlar'dan ekle veya maçı elle ekle."
                }
            } else {
                when (val r = fixtureProvider.fixtures(date)) {
                    is ApiResult.Ok -> {
                        api = r.value
                        fetchedAt = now
                        fromCache = false
                        cache.write(date.toString(), now, r.value)
                    }
                    is ApiResult.Err -> {
                        notice = if (cached != null) "${r.message} Kayıtlı (eski) veri gösteriliyor." else r.message
                    }
                }
            }
        }
        DayMatches((api + manual).sortedBy { it.kickoff }, notice, fetchedAt, fromCache)
    }

    // ---------------------------------------------------------------- Oranlar

    suspend fun oddsFor(matchId: String): List<OddsEntry> = withContext(Dispatchers.IO) {
        oddsProviders.flatMap { it.oddsFor(matchId) }
    }

    suspend fun oddsCounts(): Map<String, Int> = withContext(Dispatchers.IO) {
        store.allOdds().groupingBy { it.matchId }.eachCount()
    }

    suspend fun addManualMatch(m: Match) = withContext(Dispatchers.IO) { store.addMatch(m) }
    suspend fun deleteManualMatch(id: String) = withContext(Dispatchers.IO) { store.deleteMatch(id) }
    suspend fun saveOdds(entries: List<OddsEntry>) = withContext(Dispatchers.IO) { store.upsertOdds(entries) }
    suspend fun deleteOdds(id: String) = withContext(Dispatchers.IO) { store.deleteOdds(id) }

    fun externalOddsAvailable(leagueId: Int) = settings.oddsApiKey != null && oddsApi.supports(leagueId)

    /** İkinci kaynaktan (The Odds API) oranları çeker; kredi harcar. Kendi etiketiyle kaydedilir. */
    suspend fun importExternalOdds(match: Match): ApiResult<Int> = withContext(Dispatchers.IO) {
        when (val r = oddsApi.events(match.leagueId, force = false)) {
            is ApiResult.Err -> r
            is ApiResult.Ok -> {
                val ev = oddsApi.findEvent(r.value, match)
                    ?: return@withContext ApiResult.Err("Bu maç harici kaynakta bulunamadı (takım adı/saat eşleşmedi).")
                val entries = ev.prices.map {
                    OddsEntry(
                        id = "${match.id}|${it.marketKey}|${it.selectionKey}|${it.bookmaker.lowercase()}|ext",
                        matchId = match.id, marketKey = it.marketKey, selectionKey = it.selectionKey,
                        odds = it.odds, bookmaker = it.bookmaker, origin = "The Odds API", updatedAt = it.updatedAt
                    )
                }
                if (entries.isEmpty()) ApiResult.Err("Harici kaynakta bu maç için uygun pazar yok.")
                else { store.upsertOdds(entries); ApiResult.Ok(entries.size) }
            }
        }
    }

    // ---------------------------------------------------------------- Veri: puan durumu, model

    suspend fun table(leagueId: Int, force: Boolean = false): ApiResult<LeagueTable> = withContext(Dispatchers.IO) {
        val season = settings.season
        val now = System.currentTimeMillis()
        val cached = tableCache.read(leagueId, season)
        if (cached != null && !force && now - cached.fetchedAt < 24L * 3600 * 1000) return@withContext ApiResult.Ok(cached)
        if (settings.apiKey == null) {
            return@withContext if (cached != null) ApiResult.Ok(cached) else ApiResult.Err("API anahtarı yok; puan durumu alınamadı.")
        }
        when (val r = fixtureProvider.call("/standings?league=$leagueId&season=$season")) {
            is ApiResult.Err -> if (cached != null) ApiResult.Ok(cached) else r
            is ApiResult.Ok -> {
                when (val p = parseStandings(r.value, leagueId, season, now)) {
                    is ApiResult.Ok -> { tableCache.write(p.value); p }
                    is ApiResult.Err -> if (cached != null) ApiResult.Ok(cached) else p
                }
            }
        }
    }

    private fun resolveTeamId(rows: List<TeamRow>, id: Int, name: String): Int? {
        if (id > 0 && rows.any { it.teamId == id }) return id
        val best = TeamMatcher.bestMatch(name, rows.map { it.name }) ?: return null
        return rows.firstOrNull { it.name == best }?.teamId
    }

    private fun historyScore(): Double? = Metrics.historyScore(Metrics.report(predictions.all()))

    suspend fun analyze(match: Match): AnalysisResult = withContext(Dispatchers.IO) {
        val now = System.currentTimeMillis()
        var lh: Double? = null
        var la: Double? = null
        var dq = 0.0
        var note = ""

        val manual = settings.manualLambdas(match.id)
        if (manual != null) {
            lh = manual.first; la = manual.second; dq = 0.6
            note = "Elle girilen beklenen gol kullanıldı (veri kalitesi sınırlı sayıldı)."
        } else if (Leagues.byId(match.leagueId) == null) {
            note = "Bu lig desteklenen liglerde değil; model için beklenen golü elle gir."
        } else {
            when (val t = table(match.leagueId)) {
                is ApiResult.Err -> note = "Puan durumu alınamadı: ${t.message}"
                is ApiResult.Ok -> {
                    val hid = resolveTeamId(t.value.rows, match.homeId, match.home)
                    val aid = resolveTeamId(t.value.rows, match.awayId, match.away)
                    if (hid == null || aid == null) {
                        note = "Takımlar puan durumuyla eşleştirilemedi."
                    } else {
                        val l = Strength.lambdas(t.value.rows, hid, aid)
                        if (l == null) note = "Puan durumu verisi yetersiz."
                        else {
                            lh = l.home; la = l.away; dq = l.dataQuality
                            note = "Sezon ${t.value.season} iç saha/deplasman gol istatistikleri (puan durumu) ile hesaplandı."
                        }
                    }
                }
            }
        }

        val model = if (lh != null && la != null) ScoreModel(lh, la) else null
        val rotHigh = listOf(match.homeId, match.awayId).any { id ->
            id > 0 && cachedRotation(id, match.kickoff)?.risk == "Yüksek"
        }
        val ctx = AnalysisContext(model, dq, rotHigh, historyScore())
        val evals = OpportunityEngine.evaluate(store.oddsForMatch(match.id), ctx, now, match.kickoff)

        val core = ArrayList<CoreProb>()
        val tops = ArrayList<Triple<Int, Int, Double>>()
        if (model != null) {
            core.add(CoreProb("Ev sahibi kazanır", MarketProb.prob(model, "1x2", "1") ?: 0.0))
            core.add(CoreProb("Beraberlik", MarketProb.prob(model, "1x2", "X") ?: 0.0))
            core.add(CoreProb("Deplasman kazanır", MarketProb.prob(model, "1x2", "2") ?: 0.0))
            core.add(CoreProb("2.5 Üst", MarketProb.prob(model, "ou_2.5", "over") ?: 0.0))
            core.add(CoreProb("KG Var", MarketProb.prob(model, "btts", "yes") ?: 0.0))
            tops.addAll(model.topScores(3))
        }
        val recorded = if (model != null) record(match, model, dq, evals, now) else 0
        AnalysisResult(match, lh, la, dq, note, evals, core, tops, recorded)
    }

    private fun record(match: Match, model: ScoreModel, dq: Double, evals: List<Evaluation>, now: Long): Int {
        if (match.statusShort != "NS" || match.kickoff * 1000 <= now) return 0   // veri sızıntısını önle
        val label = "${match.home} - ${match.away}"
        val items = ArrayList<PredictionRecord>()
        val seen = HashSet<String>()
        for (e in evals) {
            val pm = e.modelProb ?: continue
            val id = predictions.idOf(match.id, e.marketKey, e.selectionKey, OpportunityEngine.MODEL_VERSION)
            if (!seen.add(id)) continue
            items.add(
                PredictionRecord(
                    id, match.id, label, match.leagueId, match.leagueName, match.kickoff,
                    e.marketKey, e.selectionKey, now, pm, e.adjProb ?: pm, e.odds, e.bookmaker, e.updatedAt,
                    "Model: puan durumu (${match.source}); oran: ${e.origin}/${e.bookmaker}",
                    OpportunityEngine.MODEL_VERSION, e.decision == Decision.RECOMMEND, null, null, null
                )
            )
        }
        for ((mk, sk) in OpportunityEngine.coreSelections) {
            val id = predictions.idOf(match.id, mk, sk, OpportunityEngine.MODEL_VERSION)
            if (!seen.add(id)) continue
            val p = MarketProb.prob(model, mk, sk) ?: continue
            items.add(
                PredictionRecord(
                    id, match.id, label, match.leagueId, match.leagueName, match.kickoff,
                    mk, sk, now, p, p, null, null, null,
                    "Model: puan durumu (${match.source}); oran yok",
                    OpportunityEngine.MODEL_VERSION, false, null, null, null
                )
            )
        }
        return predictions.addIfAbsent(items)
    }

    /** Önümüzdeki günlerde oranı girilmiş maçları tarar (yeni istek: yalnızca eski/eksik önbellek). */
    suspend fun scanUpcoming(days: Int): List<AnalysisResult> {
        val counts = oddsCounts()
        val now = System.currentTimeMillis()
        val out = ArrayList<AnalysisResult>()
        for (d in 0 until days) {
            val day = matchesForDate(today().plusDays(d.toLong()), false)
            for (m in day.matches) {
                if (m.statusShort != "NS" || m.kickoff * 1000 <= now) continue
                if ((counts[m.id] ?: 0) == 0) continue
                out.add(analyze(m))
            }
        }
        return out
    }

    fun buildCoupons(scan: List<AnalysisResult>): Map<CouponType, Coupon?> {
        val picks = scan.flatMap { r -> r.evaluations.map { CouponPick(r.match, it) } }
        return CouponType.values().associateWith { CouponLab.build(it, picks) }
    }

    // ---------------------------------------------------------------- Canlı, sakatlık, rotasyon

    private fun apiFixtureId(match: Match): Int? = if (match.id.startsWith("api-")) match.id.removePrefix("api-").toIntOrNull() else null

    suspend fun liveRefresh(match: Match): ApiResult<Match> {
        val id = apiFixtureId(match) ?: return ApiResult.Err("Canlı veri yalnızca API-Football maçları için.")
        return when (val r = fixtureProvider.call("/fixtures?id=$id&timezone=Europe/Istanbul")) {
            is ApiResult.Err -> r
            is ApiResult.Ok -> when (val p = fixtureProvider.parseFixtures(r.value)) {
                is ApiResult.Err -> p
                is ApiResult.Ok -> p.value.firstOrNull()?.let { ApiResult.Ok(it) } ?: ApiResult.Err("Maç verisi bulunamadı.")
            }
        }
    }

    suspend fun injuries(match: Match): ApiResult<List<String>> {
        val id = apiFixtureId(match) ?: return ApiResult.Err("Sakatlık verisi yalnızca API-Football maçları için.")
        return when (val r = fixtureProvider.call("/injuries?fixture=$id")) {
            is ApiResult.Err -> r
            is ApiResult.Ok -> try {
                val arr = JSONObject(r.value).optJSONArray("response") ?: JSONArray()
                ApiResult.Ok((0 until arr.length()).map {
                    val o = arr.getJSONObject(it)
                    val p = o.optJSONObject("player")
                    val team = o.optJSONObject("team")?.optString("name", "") ?: ""
                    "$team – ${p?.optString("name", "?") ?: "?"} (${p?.optString("reason", "") ?: ""})"
                })
            } catch (e: Exception) {
                ApiResult.Err("Sakatlık yanıtı okunamadı.")
            }
        }
    }

    private fun rotationFile(teamId: Int) = File(rotationDir, "rotation_$teamId.json")

    private fun readRotationRaw(teamId: Int): Pair<Long, List<Lineup>>? {
        val f = rotationFile(teamId)
        if (!f.exists()) return null
        return try {
            val o = JSONObject(f.readText())
            val a = o.getJSONArray("lineups")
            Pair(o.getLong("fetchedAt"), (0 until a.length()).map { Rotation.lineupFromJson(a.getJSONObject(it)) })
        } catch (e: Exception) { f.delete(); null }
    }

    fun cachedRotation(teamId: Int, kickoff: Long): RotationInfo? {
        val raw = readRotationRaw(teamId) ?: return null
        return Rotation.analyze(teamId, raw.second, kickoff)
    }

    /**
     * Teknik direktör rotasyon analizi. Takım başına ~5 istek harcar (dakikada 10 sınırı için
     * istekler arasında bekler). Sonuç 24 saat önbelleklenir.
     */
    suspend fun rotationFor(teamId: Int, kickoff: Long, onProgress: (String) -> Unit): ApiResult<RotationInfo> {
        val raw = readRotationRaw(teamId)
        val now = System.currentTimeMillis()
        if (raw != null && now - raw.first < 24L * 3600 * 1000) return ApiResult.Ok(Rotation.analyze(teamId, raw.second, kickoff))

        onProgress("Son maçlar alınıyor…")
        val list = when (val r = fixtureProvider.call("/fixtures?team=$teamId&last=4&timezone=Europe/Istanbul")) {
            is ApiResult.Err -> return r
            is ApiResult.Ok -> try {
                val arr = JSONObject(r.value).optJSONArray("response") ?: JSONArray()
                (0 until arr.length()).map {
                    val fx = arr.getJSONObject(it).getJSONObject("fixture")
                    Pair(fx.getInt("id"), fx.getLong("timestamp"))
                }
            } catch (e: Exception) { return ApiResult.Err("Son maç listesi okunamadı.") }
        }
        val lineups = ArrayList<Lineup>()
        for ((i, f) in list.withIndex()) {
            delay(6500)   // dakikada 10 istek sınırı
            onProgress("Kadro ${i + 1}/${list.size} alınıyor…")
            when (val r = fixtureProvider.call("/fixtures/lineups?fixture=${f.first}")) {
                is ApiResult.Err -> if (lineups.isEmpty() && i == list.lastIndex) return r
                is ApiResult.Ok -> Rotation.parseLineup(r.value, f.first, f.second, teamId)?.let { lineups.add(it) }
            }
        }
        if (lineups.isEmpty()) return ApiResult.Err("Kadro verisi alınamadı (bu lig veya plan için sunulmuyor olabilir).")
        val arr = JSONArray()
        lineups.forEach { arr.put(Rotation.lineupToJson(it)) }
        atomicWrite(rotationFile(teamId), JSONObject().put("fetchedAt", now).put("lineups", arr).toString())
        return ApiResult.Ok(Rotation.analyze(teamId, lineups, kickoff))
    }

    // ---------------------------------------------------------------- Geçmiş ve performans

    suspend fun predictionList(): List<PredictionRecord> = withContext(Dispatchers.IO) {
        predictions.all().sortedByDescending { it.kickoff }
    }

    suspend fun report(): Report = withContext(Dispatchers.IO) { Metrics.report(predictions.all()) }

    suspend fun saveManualResult(match: Match, fh: Int, fa: Int, hh: Int?, ha: Int?) = withContext(Dispatchers.IO) {
        store.addMatch(match.copy(statusShort = "FT", homeGoals = fh, awayGoals = fa, homeHt = hh, awayHt = ha))
    }

    /** Bitmiş maçların sonuçlarını alıp bekleyen tahminleri değerlendirir. Tarih başına 1 API isteği. */
    suspend fun settlePending(): String = withContext(Dispatchers.IO) {
        val now = System.currentTimeMillis()
        val all = predictions.all()
        val pending = all.filter { it.result == null && it.kickoff * 1000 + 3L * 3600 * 1000 < now }
        if (pending.isEmpty()) return@withContext "Değerlendirilecek bekleyen tahmin yok."

        val results = HashMap<String, Match>()
        store.matches().forEach { results[it.id] = it }
        val dates = pending.filter { it.matchId.startsWith("api-") }
            .map { Instant.ofEpochSecond(it.kickoff).atZone(zone).toLocalDate() }.distinct()
        var apiNote = ""
        for (d in dates) {
            when (val r = fixtureProvider.fixtures(d)) {
                is ApiResult.Ok -> { r.value.forEach { results[it.id] = it }; cache.write(d.toString(), now, r.value) }
                is ApiResult.Err -> apiNote = " (Bazı sonuçlar alınamadı: ${r.message})"
            }
        }
        var settled = 0
        val updated = all.map { rec ->
            if (rec.result != null || rec.kickoff * 1000 + 3L * 3600 * 1000 >= now) rec
            else {
                val m = results[rec.matchId]
                val fh = m?.homeGoals
                val fa = m?.awayGoals
                if (m != null && StatusText.isFinished(m.statusShort) && fh != null && fa != null) {
                    val s = Settler.settle(rec, fh, fa, m.homeHt, m.awayHt, now)
                    if (s != null) { settled++; s } else rec
                } else rec
            }
        }
        predictions.replaceAll(updated)
        "$settled tahmin değerlendirildi, ${pending.size - settled} beklemede.$apiNote"
    }

    // ---------------------------------------------------------------- Ayarlar

    suspend fun checkApiStatus(): String = when (val r = fixtureProvider.status()) {
        is ApiResult.Ok -> r.value
        is ApiResult.Err -> r.message
    }

    fun clearCache() {
        cache.clear(); tableCache.clear()
        extDir.listFiles()?.forEach { it.delete() }
        rotationDir.listFiles()?.forEach { it.delete() }
    }
}
