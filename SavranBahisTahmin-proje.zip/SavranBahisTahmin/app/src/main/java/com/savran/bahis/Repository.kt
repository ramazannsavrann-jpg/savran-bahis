package com.savran.bahis

import android.content.Context
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Deferred
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import kotlin.math.abs
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.time.Instant
import java.time.LocalDate
import java.time.ZoneId
import java.time.temporal.ChronoUnit

data class DayMatches(
    val matches: List<Match>,
    val notice: String?,
    val fetchedAt: Long?,
    val fromCache: Boolean
)

data class CoreProb(val label: String, val prob: Double)

data class HealthItem(val title: String, val value: String, val ok: Boolean?)

data class AnalysisResult(
    val match: Match,
    val lambdaHome: Double?,
    val lambdaAway: Double?,
    val dataQuality: Double,
    val modelNote: String,
    val evaluations: List<Evaluation>,
    val core: List<CoreProb>,
    val topScores: List<Triple<Int, Int, Double>>,
    val recorded: Int,
    val forecasts: List<Forecast> = emptyList(),
    val forecastNote: String? = null,
    val criteria: List<Criterion> = emptyList(),
    val newsHome: List<NewsItem> = emptyList(),
    val newsAway: List<NewsItem> = emptyList(),
    val newsEffect: NewsEffect? = null
)

class Repository(context: Context) {
    companion object {
        /** Otomatik The Odds API isteği günlük sınırı (1 istek = 2 kredi; ücretsiz plan ~500/ay). */
        const val ODDS_AUTO_PER_DAY = 8
        const val ODDS_MIN_REMAINING = 60.0
        /** Tablo hiçbir kaynaktan alınamadıysa bu süre boyunca yeniden denenmez. */
        const val TABLE_FAIL_BACKOFF_MS = 10L * 60 * 1000
        /** Geçmiş günleri doldurmak için günlük API-Football isteği üst sınırı (ücretsiz plan 100/gün). */
        const val BACKFILL_PER_DAY = 12
    }
    private val tableFail = java.util.concurrent.ConcurrentHashMap<Int, Pair<Long, String>>()
    val settings = AppSettings(context)
    val zone: ZoneId = ZoneId.of("Europe/Istanbul")

    private val root = context.filesDir
    private val store = LocalStore(root)
    private val cache = FixtureCache(File(root, "cache"))
    private val tableCache = TableCache(File(root, "tables"))
    private val extDir = File(root, "ext_odds").apply { mkdirs() }
    private val rotationDir = File(root, "rotation").apply { mkdirs() }
    private val predictions = PredictionStore(root)
    private val fixtureProvider = ApiFootballFixtureProvider(settings)
    private val oddsApi = OddsApiClient(settings, extDir)
    private val oddsProviders: List<OddsProvider> = listOf(ManualOddsProvider(store))

    // Diğer veri kaynakları (her biri bağımsız; biri çökerse diğerleri etkilenmez)
    private val footballData = FootballDataClient(settings)
    private val apiNinjas = ApiNinjasClient(settings)
    private val theSportsDb = TheSportsDbClient(settings)
    private val openLiga = OpenLigaClient(settings)
    private val statsBomb = StatsBombClient(settings)
    private val newsStore = NewsStore(File(root, "news"))
    private val newsClient = GoogleNewsClient()
    private val learningStore = LearningStore(root)
    private val clubElo = ClubEloSource(File(root, "clubelo"))
    // football-data.co.uk Türkiye'de erişime kapalı olduğu için kullanılmıyor; yerine openfootball (GitHub).
    private val openFootball = OpenFootballSource(File(root, "openfootball"))
    private val resultsLog = ResultsLog(root)
    private val priorCache = java.util.concurrent.ConcurrentHashMap<Int, Pair<Long, Map<String, DoubleArray>>>()

    /** Geçen sezon sonu takım güçleri (openfootball). 12 saat bellekte; alınamazsa boş (önsel kullanılmaz). */
    private suspend fun lastSeasonRatings(leagueId: Int, season: Int): Map<String, DoubleArray> {
        if (Leagues.isCup(leagueId) || !OpenFootballSource.codes.containsKey(leagueId)) return emptyMap()
        val now = System.currentTimeMillis()
        priorCache[leagueId]?.let { if (now - it.first < 12L * 3600 * 1000) return it.second }
        val r = when (val x = openFootball.results(leagueId, season - 1)) {
            is ApiResult.Ok -> Strength.endRatings(x.value)
            is ApiResult.Err -> emptyMap()
        }
        priorCache[leagueId] = now to r
        return r
    }
    @Volatile private var backfillStatus = "Henüz başlamadı"

    /**
     * Güncel tablosu ücretsiz kaynaktan gelmeyen ligler (ör. Süper Lig) için: dünden geriye, sezon başına kadar günlük maç
     * listeleri çekilip bitmiş maç sonuçları biriktirilir. Günde en fazla [BACKFILL_PER_DAY] API-Football isteği harcanır.
     */
    private suspend fun backfillResults(season: Int, now: Long) {
        if (settings.apiKey == null) { backfillStatus = "API-Football anahtarı yok"; return }
        val start = LocalDate.of(season, 7, 15)
        val done = resultsLog.doneDays()
        var d = today().minusDays(1)
        while (!d.isBefore(start)) {
            if (d.toString() !in done) {
                if (settings.backfillCallsToday(now) >= BACKFILL_PER_DAY) { backfillStatus = "Bugünkü sınır doldu; yarın devam edecek"; return }
                settings.recordBackfillCall(now)
                when (val r = fixtureProvider.fixtures(d)) {
                    is ApiResult.Ok -> resultsLog.record(r.value, d.toString())
                    is ApiResult.Err -> { backfillStatus = "Durdu: ${r.message}"; return }
                }
            }
            d = d.minusDays(1)
        }
        backfillStatus = "Tamamlandı (sezon başına kadar)"
    }
    private val weatherSource = WeatherSource(File(root, "weather"))

    /**
     * Geri test: geçen sezonun gerçek sonuçları (openfootball) üzerinde modeli sınar. Ağ: lig başına 1 dosya (önbellekli).
     * Yalnızca yerli ligler (kupalar bu kaynakta yok).
     */
    suspend fun backtest(leagueId: Int): ApiResult<BacktestReport> {
        val season = settings.season - 1
        val name = Leagues.byId(leagueId)?.nameTr ?: "Lig"
        // Önsel: test edilen sezondan bir önceki sezonun sonu (uygulamadaki gibi).
        val priorRatings = when (val p = openFootball.results(leagueId, season - 1)) {
            is ApiResult.Ok -> Strength.endRatings(p.value)
            is ApiResult.Err -> emptyMap()
        }
        return when (val r = openFootball.results(leagueId, season)) {
            is ApiResult.Err -> r
            is ApiResult.Ok -> withContext(Dispatchers.Default) {
                if (r.value.size < 50) ApiResult.Err("Geri test için yeterli maç yok (${r.value.size}).")
                else ApiResult.Ok(Backtest.run(r.value, name, OpenFootballSource.seasonFolder(season), priorRatings))
            }
        }
    }

    /** Maç saatindeki hava (Open-Meteo). Bilgi amaçlı; modele katılmaz. Şehir bilinmiyorsa null. */
    suspend fun weather(match: Match): MatchWeather? = weatherSource.forMatch(match)
    fun clubEloStatus(): String = clubElo.status
    @Volatile private var learnCache: LearningState? = null
    private val extraCaches = mapOf(
        SourceId.FOOTBALL_DATA to FixtureCache(File(root, "cache_fd")),
        SourceId.API_NINJAS to FixtureCache(File(root, "cache_an")),
        SourceId.THESPORTSDB to FixtureCache(File(root, "cache_ts")),
        SourceId.OPENLIGADB to FixtureCache(File(root, "cache_ol"))
    )

    fun today(): LocalDate = LocalDate.now(zone)

    // ---------------------------------------------------------------- Maç listesi

    private data class ExtraResult(val id: SourceId, val matches: List<Match>, val error: String?, val fetched: Boolean)

    suspend fun matchesForDate(date: LocalDate, force: Boolean): DayMatches = withContext(Dispatchers.IO) {
        val now = System.currentTimeMillis()
        val offset = ChronoUnit.DAYS.between(today(), date).toInt()

        val manual = store.matches().filter {
            Instant.ofEpochSecond(it.kickoff).atZone(zone).toLocalDate() == date
        }
        val cached = cache.read(date.toString())
        var api: List<Match> = cached?.matches ?: emptyList()
        var fetchedAt: Long? = cached?.fetchedAt
        var fromCache = cached != null
        val notices = ArrayList<String>()

        val apiActive = settings.apiKey != null
        val needFetch = force || cached == null || !CachePolicy.isFresh(cached.fetchedAt, now, offset)
        if (needFetch && apiActive) {
            when (val r = fixtureProvider.fixtures(date)) {
                is ApiResult.Ok -> {
                    api = r.value
                    fetchedAt = now
                    fromCache = false
                    cache.write(date.toString(), now, r.value)
                }
                is ApiResult.Err -> {
                    notices.add(if (cached != null) "${r.message} Kayıtlı (eski) veri gösteriliyor." else r.message)
                }
            }
        }

        // Diğer aktif kaynaklar paralel çalışır; her biri kendi hatasını bildirir.
        val extras = fetchExtraSources(date, offset, force, now)
        for (e in extras) {
            val err = e.error
            if (err != null) notices.add(err)
        }
        if (fetchedAt == null && extras.any { it.fetched }) {
            fetchedAt = now
            fromCache = false
        }
        if (!apiActive && extras.isEmpty() && manual.isEmpty() && cached == null) {
            notices.add("Etkin veri kaynağı yok. Ayarlar > Veri kaynakları bölümünden bir kaynağı aktif et ve anahtarını gir, ya da maçı elle ekle.")
        }
        val merged = FixtureMerge.merge(api, extras.flatMap { it.matches })
        // Bitmiş yerli lig maçları sonuç kütüğüne eklenir (tablo veremeyen ligler için).
        try { resultsLog.record(merged) } catch (e: Exception) { }
        DayMatches(
            (merged + manual).sortedBy { it.kickoff },
            if (notices.isEmpty()) null else notices.joinToString("\n"),
            fetchedAt, fromCache
        )
    }

    private suspend fun fetchExtraSources(date: LocalDate, offset: Int, force: Boolean, now: Long): List<ExtraResult> = coroutineScope {
        val jobs = ArrayList<Deferred<ExtraResult>>()
        // Birleştirmede öncelik sırası: Football-Data > API Ninjas > OpenLigaDB > TheSportsDB
        settings.keyOf(SourceId.FOOTBALL_DATA)?.let { k ->
            jobs.add(async { cachedExtra(SourceId.FOOTBALL_DATA, date, offset, force, now) { footballData.fixtures(k, date, zone) } })
        }
        // API Ninjas ücretsiz kotası aylık: yalnızca bugün ve yarın için çağrılır.
        settings.keyOf(SourceId.API_NINJAS)?.let { k ->
            if (offset in 0..1) {
                jobs.add(async { cachedExtra(SourceId.API_NINJAS, date, offset, force, now) { apiNinjas.fixtures(k, date) } })
            }
        }
        if (settings.isActive(SourceId.OPENLIGADB)) {
            jobs.add(async { cachedExtra(SourceId.OPENLIGADB, date, offset, force, now) { openLiga.fixtures(date, zone, settings.season) } })
        }
        if (settings.isActive(SourceId.THESPORTSDB)) {
            val k = settings.keyOf(SourceId.THESPORTSDB) ?: "123"
            jobs.add(async { cachedExtra(SourceId.THESPORTSDB, date, offset, force, now) { theSportsDb.fixtures(k, date, zone, today()) } })
        }
        jobs.awaitAll()
    }

    private suspend fun cachedExtra(
        id: SourceId, date: LocalDate, offset: Int, force: Boolean, now: Long,
        fetch: suspend () -> ApiResult<List<Match>>
    ): ExtraResult {
        val c = extraCaches.getValue(id)
        val cached = c.read(date.toString())
        if (!force && cached != null && CachePolicy.isFresh(cached.fetchedAt, now, offset)) {
            return ExtraResult(id, cached.matches, null, false)
        }
        return when (val r = fetch()) {
            is ApiResult.Ok -> {
                c.write(date.toString(), now, r.value)
                ExtraResult(id, r.value, null, true)
            }
            is ApiResult.Err -> ExtraResult(
                id, cached?.matches ?: emptyList(),
                r.message + if (cached != null) " Kayıtlı (eski) veri kullanıldı." else "", false
            )
        }
    }

    // ---------------------------------------------------------------- Oranlar

    suspend fun oddsFor(matchId: String): List<OddsEntry> = withContext(Dispatchers.IO) {
        oddsProviders.flatMap { it.oddsFor(matchId) }
    }

    suspend fun oddsCounts(): Map<String, Int> = withContext(Dispatchers.IO) {
        store.allOdds().groupingBy { it.matchId }.eachCount()
    }

    suspend fun addManualMatch(m: Match) = withContext(Dispatchers.IO) { store.addMatch(m) }
    suspend fun deleteManualMatch(id: String) = withContext(Dispatchers.IO) { store.deleteMatch(id) }
    suspend fun saveOdds(entries: List<OddsEntry>) = withContext(Dispatchers.IO) { store.upsertOdds(entries) }
    suspend fun deleteOdds(id: String) = withContext(Dispatchers.IO) { store.deleteOdds(id) }

    fun externalOddsAvailable(leagueId: Int) = settings.oddsApiKey != null && oddsApi.supports(leagueId)

    /** İkinci kaynaktan (The Odds API) oranları çeker; kredi harcar. Kendi etiketiyle kaydedilir. */
    suspend fun importExternalOdds(match: Match): ApiResult<Int> = withContext(Dispatchers.IO) {
        try {
            importExternalOddsUnsafe(match)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            ApiResult.Err("Harici oran alınamadı: ${e.message ?: e.javaClass.simpleName}")
        }
    }

    private suspend fun importExternalOddsUnsafe(match: Match): ApiResult<Int> {
        return when (val r = oddsApi.events(match.leagueId, force = false)) {
            is ApiResult.Err -> r
            is ApiResult.Ok -> {
                val ev = oddsApi.findEvent(r.value, match)
                    ?: return ApiResult.Err("Bu maç harici kaynakta bulunamadı (takım adı/saat eşleşmedi).")
                val entries = ev.prices.map {
                    OddsEntry(
                        id = "${match.id}|${it.marketKey}|${it.selectionKey}|${it.bookmaker.lowercase()}|ext",
                        matchId = match.id, marketKey = it.marketKey, selectionKey = it.selectionKey,
                        odds = it.odds, bookmaker = it.bookmaker, origin = "The Odds API", updatedAt = it.updatedAt
                    )
                }
                if (entries.isEmpty()) ApiResult.Err("Harici kaynakta bu maç için uygun pazar yok.")
                else { store.upsertOdds(entries); ApiResult.Ok(entries.size) }
            }
        }
    }

    /**
     * The Odds API anahtarı varsa, başlamamış maçta taze harici oran yoksa oranları otomatik çeker.
     * Kredi koruması: lig başına önbellek (3 saat) ücretsizdir; yeni ağ isteği günde en fazla [ODDS_AUTO_PER_DAY]
     * ve kalan kredi [ODDS_MIN_REMAINING] altına düşünce otomatik çekim durur (elle "Oran çek" yine çalışır).
     * Oran yoksa/alınamazsa tahmin yine oransız üretilir.
     */
    private suspend fun autoExternalOdds(match: Match, now: Long): String? {
        if (settings.oddsApiKey == null || !oddsApi.supports(match.leagueId)) return null
        if (match.statusShort != "NS" || match.kickoff * 1000 <= now || match.kickoff * 1000 - now > 4L * 86_400_000L) return null
        val have = store.oddsForMatch(match.id).any { it.origin == "The Odds API" && !OddsFreshness.isStale(it.updatedAt, now, match.kickoff) }
        if (have) return null
        val cacheFree = oddsApi.cachedFresh(match.leagueId, 3L * 3600 * 1000)
        if (!cacheFree) {
            val rem = settings.oddsApiRemaining?.trim()?.toDoubleOrNull()
            if (rem != null && rem < ODDS_MIN_REMAINING) return "Otomatik oran durdu: The Odds API kredisi azaldı (${rem.toInt()})."
            if (settings.oddsAutoCallsToday(now) >= ODDS_AUTO_PER_DAY) return null
            settings.recordOddsAutoCall(now)
        }
        return try {
            when (val r = importExternalOddsUnsafe(match)) {
                is ApiResult.Ok -> "Piyasa oranları The Odds API'den otomatik alındı (${r.value} oran)."
                is ApiResult.Err -> null   // maç kaynakta yoksa sessizce oransız devam
            }
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) { null }
    }

    // ---------------------------------------------------------------- Veri: puan durumu, model

    /**
     * Model için puan durumu (genel + iç saha + deplasman). Sırayla: API-Football, Football-Data.org.
     * Biri hata verirse diğeri denenir; ikisi de olmazsa kayıtlı (eski) tablo kullanılır.
     */
    suspend fun table(leagueId: Int, force: Boolean = false): ApiResult<LeagueTable> = withContext(Dispatchers.IO) {
        val season = settings.season
        val now = System.currentTimeMillis()
        // 10'dan az takımlı (eksik) kayıtlı tablo kullanılmaz; yeniden çekilir.
        val cached = tableCache.read(leagueId, season)?.takeIf { it.rows.size >= 10 }
        if (cached != null && !force && now - cached.fetchedAt < 24L * 3600 * 1000) return@withContext ApiResult.Ok(cached)
        // Kısa süre önce tüm kaynaklar başarısız olduysa her maçta baştan denenmez (tarama uzamasın).
        if (!force) tableFail[leagueId]?.let { (t, msg) -> if (now - t < TABLE_FAIL_BACKOFF_MS) return@withContext ApiResult.Err(msg) }
        val errors = ArrayList<String>()

        if (settings.apiKey != null) {
            when (val r = fixtureProvider.call("/standings?league=$leagueId&season=$season")) {
                is ApiResult.Err -> errors.add(r.message)
                is ApiResult.Ok -> when (val p = parseStandings(r.value, leagueId, season, now)) {
                    is ApiResult.Ok -> { tableCache.write(p.value); return@withContext p }
                    is ApiResult.Err -> errors.add(p.message)
                }
            }
        }
        val fdKey = settings.keyOf(SourceId.FOOTBALL_DATA)
        if (fdKey != null && FootballDataClient.codes.containsKey(leagueId)) {
            when (val r = footballData.table(fdKey, leagueId, season, now)) {
                is ApiResult.Ok -> { tableCache.write(r.value); return@withContext r }
                is ApiResult.Err -> errors.add(r.message)
            }
        }
        // 3) Puan durumu alınamadıysa: bitmiş maç sonuçlarından iç saha/deplasman tablosu hesapla
        val derived = derivedTable(leagueId, season, now, errors)
        if (derived != null) {
            tableCache.write(derived)
            return@withContext ApiResult.Ok(derived)
        }
        // 4) Son yedek: yalnızca TOPLAM puan durumu veren kaynaklar (TheSportsDB, API Ninjas). Veri yoksa/ulaşılamazsa sessizce geçilir.
        val totals = totalsOnlyTable(leagueId, season, now, errors)
        if (totals != null) {
            tableCache.write(totals)
            return@withContext ApiResult.Ok(totals)
        }
        if (cached != null) return@withContext ApiResult.Ok(cached)
        val msg = if (errors.isEmpty()) "Puan durumu için etkin kaynak yok. API-Football veya Football-Data.org'u aktif edip anahtarını gir."
            else errors.joinToString(" | ")
        tableFail[leagueId] = now to msg
        ApiResult.Err(msg)
    }

    /**
     * Yalnızca toplam (iç saha/deplasman ayrımsız) puan durumu veren kaynaklardan tablo kurar. İç saha/deplasman 0 bırakılır;
     * model bu durumda toplam istatistiğe geçer (veri az, güven düşük). Hiçbir değer uydurulmaz.
     */
    private suspend fun totalsOnlyTable(leagueId: Int, season: Int, now: Long, errors: MutableList<String>): LeagueTable? {
        fun build(list: List<NamedTotals>, source: String): LeagueTable? {
            val ok = list.filter { it.played > 0 }
            // Ücretsiz anahtarla bazı kaynaklar tablonun yalnızca ilk 5 satırını verir; eksik tablo kullanılmaz.
            if (ok.size < 10) { errors.add("$source: tablo eksik (${ok.size} takım)"); return null }
            val rows = ok.sortedByDescending { it.points ?: 0 }.mapIndexed { i, t ->
                TeamRow(-(i + 1), t.name, i + 1, t.points ?: 0, SplitStats(t.played, t.gf, t.ga), SplitStats(0, 0, 0), SplitStats(0, 0, 0), "")
            }
            return LeagueTable(leagueId, season, now, rows, source)
        }
        if (settings.isActive(SourceId.THESPORTSDB)) {
            when (val r = theSportsDb.table(settings.keyOf(SourceId.THESPORTSDB) ?: "123", leagueId, season)) {
                is ApiResult.Ok -> build(r.value, SourceId.THESPORTSDB.title)?.let { return it }
                is ApiResult.Err -> errors.add(r.message)
            }
        }
        val nk = settings.keyOf(SourceId.API_NINJAS)
        if (nk != null) {
            when (val r = apiNinjas.standings(nk, leagueId, season)) {
                is ApiResult.Ok -> build(r.value, SourceId.API_NINJAS.title)?.let { return it }
                is ApiResult.Err -> errors.add(r.message)
            }
        }
        return null
    }

    /** Puan durumu yokken yalnızca gerçek bitmiş maç sonuçlarından tablo kurar; yeterli sonuç yoksa null. */
    private suspend fun derivedTable(leagueId: Int, season: Int, now: Long, errors: MutableList<String>): LeagueTable? {
        val fdKey = settings.keyOf(SourceId.FOOTBALL_DATA)
        if (fdKey != null && FootballDataClient.codes.containsKey(leagueId)) {
            when (val r = footballData.finishedResults(fdKey, leagueId, season)) {
                is ApiResult.Ok -> {
                    val t = ResultsTable.build(r.value, leagueId, season, now, SourceId.FOOTBALL_DATA.title)
                    if (t != null) return t
                    errors.add("Football-Data.org: tablo için yeterli bitmiş maç sonucu yok (${r.value.size}).")
                }
                is ApiResult.Err -> errors.add(r.message)
            }
        }
        if (leagueId == 78 && settings.isActive(SourceId.OPENLIGADB)) {
            when (val r = openLiga.finishedResults(season)) {
                is ApiResult.Ok -> {
                    val t = ResultsTable.build(r.value, leagueId, season, now, SourceId.OPENLIGADB.title)
                    if (t != null) return t
                    errors.add("OpenLigaDB: tablo için yeterli bitmiş maç sonucu yok (${r.value.size}).")
                }
                is ApiResult.Err -> errors.add(r.message)
            }
        }
        // Biriken gerçek maç sonuçları (günlük maç listelerinden + kotalı geriye doldurma). Yalnızca yerli ligler.
        if (!Leagues.isCup(leagueId)) {
            try { backfillResults(season, now) } catch (e: CancellationException) { throw e } catch (e: Exception) { }
            val since = LocalDate.of(season, 7, 1).atStartOfDay(zone).toEpochSecond()
            val res = resultsLog.results(leagueId, since)
            val t = ResultsTable.build(res, leagueId, season, now, "Biriken maç sonuçları (API-Football)")
            if (t != null && t.rows.size >= 10) return t
            errors.add("Biriken sonuçlar henüz yetersiz (${res.size} maç; geçmiş günler her gün biraz daha doldurulur).")
        }
        // Anahtarsız yedek: openfootball (yalnızca yerli ligler). Gönüllü güncellenir; son maç 21 günden eskiyse
        // tablo güncel sayılmaz ve kullanılmaz (eski tabloyla güncelmiş gibi tahmin yapılmaz).
        if (OpenFootballSource.codes.containsKey(leagueId)) {
            when (val r = openFootball.results(leagueId, season)) {
                is ApiResult.Ok -> {
                    val last = r.value.maxOfOrNull { it.kickoff } ?: 0L
                    if (now / 1000 - last > 21L * 86400) {
                        errors.add("openfootball: sezon verisi güncel değil (son maç 21 günden eski).")
                    } else {
                        val t = ResultsTable.build(r.value, leagueId, season, now, "openfootball")
                        if (t != null) return t
                        errors.add("openfootball: tablo için yeterli bitmiş maç sonucu yok (${r.value.size}).")
                    }
                }
                is ApiResult.Err -> errors.add(r.message)
            }
        }
        return null
    }

    private fun resolveTeamId(rows: List<TeamRow>, id: Int, name: String): Int? {
        if (id > 0 && rows.any { it.teamId == id }) return id
        val best = TeamMatcher.bestMatch(name, rows.map { it.name }) ?: return null
        return rows.firstOrNull { it.name == best }?.teamId
    }

    /** Veri sağlığı ekranı: kaynakların ve tabloların gerçek durumu. Hiçbir ağ isteği yapmaz. */
    fun dataHealth(): List<HealthItem> {
        val now = System.currentTimeMillis()
        val out = ArrayList<HealthItem>()
        for (id in SourceId.values()) {
            val active = settings.isActive(id)
            out.add(HealthItem(id.title, (if (active) "Aktif" else "Pasif/anahtar yok") + " · bugün ${settings.callsToday(id, now)} istek", active))
        }
        out.add(HealthItem("Biriken maç sonuçları (Süper Lig vb. için)", "${try { Leagues.supported.filter { !Leagues.isCup(it.id) }.joinToString(" · ") { "${it.nameTr} ${resultsLog.results(it.id, 0).size}" } } catch (e: Exception) { "-" }} · geriye doldurma: $backfillStatus (bugün ${settings.backfillCallsToday(now)}/$BACKFILL_PER_DAY)", null))
        out.add(HealthItem("openfootball (anahtarsız sonuç arşivi, Geri Test)", openFootball.status, if (openFootball.status.startsWith("Alındı") || openFootball.status.startsWith("Önbellekten")) true else null))
        out.add(HealthItem("The Odds API otomatik oran", "Bugün ${settings.oddsAutoCallsToday(now)}/$ODDS_AUTO_PER_DAY otomatik istek · kalan kredi ${settings.oddsApiRemaining ?: "bilinmiyor"}", if (settings.oddsApiKey != null) true else null))
        out.add(HealthItem("ClubElo (Avrupa kupası gücü)", clubElo.status, if (clubElo.status.startsWith("Alındı") || clubElo.status.startsWith("Önbellekten")) true else null))
        for (lg in Leagues.supported) {
            val t = try { tableCache.read(lg.id, settings.season) } catch (e: Exception) { null }
            if (t == null) out.add(HealthItem("Tablo: ${lg.nameTr}", "Önbellekte yok (ilgili maç analiz edilince çekilir)", null))
            else {
                val ageH = (now - t.fetchedAt) / 3_600_000L
                val minPlayed = t.rows.minOfOrNull { it.all.played } ?: 0
                out.add(HealthItem("Tablo: ${lg.nameTr}", "${t.rows.size} takım · en az $minPlayed maç · ${ageH} saat önce · ${t.source.ifEmpty { "API" }}", true))
            }
        }
        return out
    }

    private var histCache: Pair<Long, Double?>? = null

    /** Kayıt dosyasını her maçta baştan okumamak için 30 sn önbellek. */
    private fun historyScore(): Double? {
        val now = System.currentTimeMillis()
        histCache?.let { if (now - it.first < 30_000L) return it.second }
        val v = Metrics.historyScore(Metrics.report(predictions.all()))
        histCache = now to v
        return v
    }

    suspend fun analyze(match: Match): AnalysisResult = withContext(Dispatchers.IO) {
        val now = System.currentTimeMillis()
        var lh: Double? = null
        var la: Double? = null
        var dq = 0.0
        var note = ""
        var formUsed = false
        var homeGames: Int? = null
        var awayGames: Int? = null
        var tableSource: String? = null
        var seasonUsed: Int? = null
        var derivedUsed = false
        var thin = false
        var veryThin = false
        var cupGames = 0
        var goalTotal: Double? = null
        var eloPrior = false

        val manual: Pair<Double, Double>? = null   // elle beklenen gol girişi kaldırıldı; eski kayıtlar yok sayılır
        if (manual != null) {
            lh = manual.first; la = manual.second; dq = 0.6
            note = "Elle girilen beklenen gol kullanıldı (veri kalitesi sınırlı sayıldı)."
        } else if (Leagues.byId(match.leagueId) == null) {
            note = "Bu lig desteklenen liglerde değil; puan durumu kaynağı yok."
        } else {
            when (val t = table(match.leagueId)) {
                is ApiResult.Err -> note = "Puan durumu alınamadı: ${t.message}"
                is ApiResult.Ok -> {
                    val hid = resolveTeamId(t.value.rows, match.homeId, match.home)
                    val aid = resolveTeamId(t.value.rows, match.awayId, match.away)
                    val avg = Strength.leagueAverage(t.value.rows)
                    val ratings = try { lastSeasonRatings(match.leagueId, t.value.season) } catch (e: CancellationException) { throw e } catch (e: Exception) { emptyMap() }
                    val prior = if (ratings.isEmpty()) null else Strength.priorFor(t.value.rows, ratings)
                    val l = if (hid == null || aid == null) null
                        else Strength.lambdas(t.value.rows, hid, aid, if (Leagues.isCup(match.leagueId)) Strength.SHRINK_K_CUP else 5.0, prior)
                    if (l == null) {
                        // Takım eşleşmedi veya istatistik yetersiz: yine de tahmin için lig ortalaması (gerçek tablo verisi) kullanılır.
                        val why = if (hid == null || aid == null) "Takım${if (hid == null && aid == null) "lar" else ""} puan durumuyla eşleştirilemedi (${listOfNotNull(if (hid == null) match.home else null, if (aid == null) match.away else null).joinToString(", ")})"
                            else "Takım istatistiği yetersiz"
                        if (avg != null) {
                            lh = avg.first; la = avg.second; dq = 0.0; veryThin = true
                            goalTotal = avg.first + avg.second
                            seasonUsed = t.value.season
                            tableSource = t.value.source.ifEmpty { SourceId.API_FOOTBALL.title }
                            note = "$why. Çok az veri: lig ortalaması (${"%.2f".format(java.util.Locale.US, avg.first)}-${"%.2f".format(java.util.Locale.US, avg.second)} gol) ile tahmin yapıldı; güven Düşük, kupona girmez."
                        } else note = "$why; lig ortalaması da hesaplanamadı."
                    } else {
                        run {
                            lh = l.home; la = l.away; dq = l.dataQuality
                            formUsed = l.formUsed; homeGames = l.homeGames; awayGames = l.awayGames; thin = l.overallFallback
                            veryThin = dq < ForecastEngine.MIN_DATA_QUALITY
                            // Gol pazarları için temkinli toplam gol (GoalModel, geri testle ayarlandı).
                            if (avg != null) {
                                val cautious = Strength.lambdas(t.value.rows, hid!!, aid!!, maxOf(GoalModel.SHRINK_K, Strength.SHRINK_K_CUP))
                                goalTotal = GoalModel.total(cautious, avg.first + avg.second)
                            }
                            cupGames = minOf(
                                t.value.rows.firstOrNull { it.teamId == hid }?.all?.played ?: 0,
                                t.value.rows.firstOrNull { it.teamId == aid }?.all?.played ?: 0
                            )
                            seasonUsed = t.value.season
                            tableSource = if (t.value.source.isNotEmpty()) t.value.source
                                else if (t.value.rows.firstOrNull()?.let { it.teamId < 0 } == true) SourceId.FOOTBALL_DATA.title
                                else SourceId.API_FOOTBALL.title
                            derivedUsed = ResultsTable.isDerived(t.value)
                            note = (if (derivedUsed) "Puan durumu alınamadı; bitmiş maç sonuçlarından hesaplanan tablo kullanıldı ($tableSource). Sezon ${t.value.season}."
                                else if (Leagues.isCup(match.leagueId)) "Sezon ${t.value.season} turnuva tablosundaki gerçek maç istatistikleri ($tableSource) ile hesaplandı."
                                else "Sezon ${t.value.season} kendi liginin tablosundaki iç saha/deplasman gol istatistikleri ($tableSource) ile hesaplandı.") +
                                (if (l.totalsOnly) " Kaynak yalnızca toplam puan durumu verdi: iç saha avantajı hesaba katılmadı (veri az, güven düşük)." else if (l.overallFallback) " İç saha/deplasman maçı az olan takım için toplam maç istatistiği kullanıldı (veri az, güven düşük)." else "") +
                                (if (formUsed) " Son 5 maç formu hafif ağırlıkla eklendi." else " Form verisi alınamadı, kullanılmadı.") +
                                (if (prior != null) " Geçen sezon takım güçleri başlangıç bilgisi olarak birleştirildi (openfootball)." else "")
                        }
                    }
                }
            }
        }

        // Haber destekli düzeltme: yalnızca taze, söylenti olmayan, doğrulanmış (resmî veya ≥2 bağımsız haber) bilgiler; ±%6 sınırı.
        var newsEffect: NewsEffect? = null
        var newsHome: List<NewsItem> = emptyList()
        var newsAway: List<NewsItem> = emptyList()
        if (settings.newsEnabled) {
            newsHome = newsStore.read(match.home)?.second ?: emptyList()
            newsAway = newsStore.read(match.away)?.second ?: emptyList()
            val l0 = lh
            val l1 = la
            if (l0 != null && l1 != null && manual == null) {
                val eff = NewsImpact.compute(match.home, newsHome, match.away, newsAway, now / 1000)
                newsEffect = eff
                lh = (l0 * eff.homeFactor).coerceIn(0.2, 4.0)
                la = (l1 * eff.awayFactor).coerceIn(0.2, 4.0)
                if (eff.applied.isNotEmpty()) note += " Doğrulanmış haberler gol beklentisine yansıtıldı."
            }
        }
        val eff2 = newsEffect
        val newsState = when {
            !settings.newsEnabled -> 0
            eff2 != null && eff2.applied.isNotEmpty() -> 3
            newsHome.isNotEmpty() || newsAway.isNotEmpty() -> 2
            else -> 1
        }

        // ClubElo: yalnızca Avrupa kupası, elle λ yok; iki takım da güvenle eşleşirse küçük ve sınırlı güç düzeltmesi.
        var eloNote: String? = null
        var eloUsed = false
        val lh0 = lh
        val la0 = la
        if (lh0 != null && la0 != null && manual == null && (Leagues.isCup(match.leagueId) || veryThin)) {
            val tbl = clubElo.table(today())
            if (tbl == null) eloNote = "ClubElo alınamadı (${clubElo.status}); Elo düzeltmesi yapılmadı."
            else {
                val eh = EloAdjust.find(match.home, tbl)
                val ea = EloAdjust.find(match.away, tbl)
                if (eh == null || ea == null) eloNote = "ClubElo'da takım güvenle eşleşmedi (${if (eh == null) match.home else match.away}); Elo düzeltmesi yapılmadı."
                else if (Leagues.isCup(match.leagueId) && !veryThin) {
                    // Kupa maçı az: kupa tablosu λ'sı ile ClubElo uzun dönem gücü birleştirilir (maç arttıkça kupa payı büyür).
                    val elo = EloPrior.lambdas(eh.elo, ea.elo, lh0 + la0)
                    val (bh, ba) = EloPrior.blend(lh0 to la0, elo, cupGames)
                    lh = bh; la = ba
                    eloUsed = true; eloPrior = true
                    val w = Math.round(EloPrior.weight(cupGames) * 100)
                    eloNote = "ClubElo: ${eh.club} ${Math.round(eh.elo)} - ${ea.club} ${Math.round(ea.elo)}. Kupa verisi ($cupGames maç) %$w, ClubElo uzun dönem gücü %${100 - w} ağırlıkla birleştirildi."
                    note += " $eloNote"
                } else {
                    val (fh, fa) = EloAdjust.factors(eh.elo, ea.elo)
                    lh = (lh0 * fh).coerceIn(0.2, 4.0)
                    la = (la0 * fa).coerceIn(0.2, 4.0)
                    eloUsed = true
                    eloNote = "ClubElo: ${eh.club} ${Math.round(eh.elo)} - ${ea.club} ${Math.round(ea.elo)}; kulüp gücü farkı gol beklentisine en fazla ±%7.5 yansıtıldı."
                    note += " $eloNote"
                }
            }
        }
        if (lh != null && Leagues.isCup(match.leagueId)) note += (if (eloPrior) " Avrupa kupası maçı: kupa verisi az olduğu için ClubElo uzun dönem gücü ağırlıklı kullanıldı; güven en fazla Orta."
            else if (eloUsed) " Avrupa kupası maçı: ligler arası fark yalnızca ClubElo ile sınırlı eklendiği için güven en fazla Orta." else " Avrupa kupası maçı: ligler arası güç farkı modele girmediği için güven en fazla Orta.")
        // lh/la, run {} lambda içinde atandığı için doğrudan akıllı dönüşüm (smart cast) yapılamaz; yerel kopya kullanılır.
        val lhF = lh
        val laF = la
        val model = if (lhF != null && laF != null) ScoreModel(lhF, laF) else null
        val gT = goalTotal
        val goalModel = if (lhF != null && laF != null && gT != null) GoalModel.model(lhF, laF, gT) else null
        val rotHigh = listOf(match.homeId, match.awayId).any { id ->
            id > 0 && cachedRotation(id, match.kickoff)?.risk == "Yüksek"
        }
        val hist = historyScore()
        val rotationKnown = listOf(match.homeId, match.awayId).any { id -> id > 0 && cachedRotation(id, match.kickoff) != null }
        val criteriaInput = CriteriaInput(model != null, manual != null, formUsed, rotationKnown, hist != null, tableSource, seasonUsed, derivedUsed, newsState, Leagues.isCup(match.leagueId), eloUsed, eloNote)
        val learning = learningState()?.takeIf { it.modelVersion == OpportunityEngine.MODEL_VERSION }
        val ctx = AnalysisContext(model, dq, rotHigh, hist, Criteria.coverage(criteriaInput), homeGames, awayGames, learning, Leagues.isCup(match.leagueId), thin, veryThin, eloPrior, goalModel)
        val oddsNote = autoExternalOdds(match, now)
        if (oddsNote != null) note += " $oddsNote"
        val evals = OpportunityEngine.evaluate(store.oddsForMatch(match.id), ctx, now, match.kickoff)

        val forecasts = ForecastEngine.generate(match.id, ctx, evals)
        val core = ArrayList<CoreProb>()
        val tops = ArrayList<Triple<Int, Int, Double>>()
        if (model != null) {
            core.add(CoreProb("Ev sahibi kazanır", forecasts.firstOrNull { it.marketKey == "1x2" && it.selectionKey == "1" }?.prob ?: MarketProb.prob(model, "1x2", "1") ?: 0.0))
            core.add(CoreProb("Beraberlik", forecasts.firstOrNull { it.marketKey == "1x2" && it.selectionKey == "X" }?.prob ?: MarketProb.prob(model, "1x2", "X") ?: 0.0))
            core.add(CoreProb("Deplasman kazanır", forecasts.firstOrNull { it.marketKey == "1x2" && it.selectionKey == "2" }?.prob ?: MarketProb.prob(model, "1x2", "2") ?: 0.0))
            core.add(CoreProb("2.5 Üst", forecasts.firstOrNull { it.marketKey == "ou_2.5" && it.selectionKey == "over" }?.prob ?: MarketProb.prob(model, "ou_2.5", "over") ?: 0.0))
            core.add(CoreProb("KG Var", forecasts.firstOrNull { it.marketKey == "btts" && it.selectionKey == "yes" }?.prob ?: MarketProb.prob(model, "btts", "yes") ?: 0.0))
            tops.addAll(model.topScores(3))
        }
        val forecastNote = ForecastEngine.noForecastReason(ctx, note)
        val recorded = if (model != null) record(match, model, dq, evals, forecasts, now, manual != null) else 0
        // Maça 6 saatten az kala görülen taze piyasa olasılığı "kapanış" olarak kayda yazılır (model-piyasa kıyası).
        if (match.kickoff * 1000 - now in 1 until 6L * 3600 * 1000) {
            val fair = evals.filter { it.decision != Decision.STALE_ODDS && it.fairProb != null }
                .associate { (it.marketKey to it.selectionKey) to it.fairProb!! }
            try { predictions.updateClosing(match.id, fair, now) } catch (e: Exception) { }
        }
        // Oranlı seçeneklerde gösterilen model olasılığı, tahmin listesindekiyle aynı (kalibre) değer olsun.
        val evalsShown = evals.map { e ->
            forecasts.firstOrNull { it.marketKey == e.marketKey && it.selectionKey == e.selectionKey }?.let { f -> e.copy(modelProb = f.prob) } ?: e
        }
        AnalysisResult(
            match, lh, la, dq, note, evalsShown, core, tops, recorded, forecasts, forecastNote,
            Criteria.build(criteriaInput), newsHome, newsAway, newsEffect
        )
    }

    private fun record(
        match: Match, model: ScoreModel, dq: Double, evals: List<Evaluation>, forecasts: List<Forecast>, now: Long,
        manual: Boolean = false
    ): Int {
        val items = RecordBuilder.build(match, model, dq, evals, forecasts, now, manual)
        return if (items.isEmpty()) 0 else predictions.addIfAbsent(items)
    }

    /** Önümüzdeki günlerde başlamamış TÜM maçları analiz eder (oran girilmiş olması gerekmez) (yeni istek: yalnızca eski/eksik önbellek). */
    suspend fun scanUpcoming(days: Int, onlyWithOdds: Boolean = false, onProgress: (String) -> Unit = {}): List<AnalysisResult> {
        val counts = oddsCounts()
        val now = System.currentTimeMillis()
        val todo = ArrayList<Match>()
        for (d in 0 until days) {
            onProgress("Maç listesi alınıyor (${d + 1}/$days. gün)…")
            val day = try { matchesForDate(today().plusDays(d.toLong()), false) } catch (e: CancellationException) { throw e } catch (e: Exception) { null } ?: continue
            for (m in day.matches) {
                if (m.statusShort != "NS" || m.kickoff * 1000 <= now) continue
                if (onlyWithOdds && (counts[m.id] ?: 0) == 0) continue   // oran şartı yok: oransız maçlar da analiz edilir
                todo.add(m)
            }
        }
        // Her ligin tablosu bir kez hazırlanır; sonraki maçlar önbellekten (veya hata beklemesinden) hızlı geçer.
        val leagues = todo.map { it.leagueId }.distinct().filter { Leagues.byId(it) != null }
        leagues.forEachIndexed { i, id ->
            onProgress("Lig tabloları hazırlanıyor (${i + 1}/${leagues.size}): ${Leagues.byId(id)?.nameTr ?: ""}")
            try { table(id) } catch (e: CancellationException) { throw e } catch (e: Exception) { }
        }
        val out = ArrayList<AnalysisResult>()
        todo.forEachIndexed { i, m ->
            onProgress("Maçlar analiz ediliyor: ${i + 1}/${todo.size}")
            // Tek bir maçtaki beklenmeyen hata tüm taramayı/kupon üretimini durdurmaz; o maç atlanır.
            try {
                out.add(analyze(m))
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                // atla
            }
        }
        return out
    }

    /** Havuz: oranlı ve oransız tüm tahminler. Oran yalnızca taze ve gerçek oran varsa kullanılır. */
    fun buildCoupons(scan: List<AnalysisResult>, leagues: Set<Int> = emptySet()): Map<CouponType, CouponOutcome> =
        CouponType.values().associateWith { buildCoupon(scan, it, emptySet(), leagues) }

    /** Tek kupon türü; [exclude] içindeki maçlar kullanılmaz ("Başka kupon öner"). */
    fun buildCoupon(scan: List<AnalysisResult>, type: CouponType, exclude: Set<String>, leagues: Set<Int> = emptySet()): CouponOutcome {
        // "Çok az veri" (lig ortalaması) analizleri kupona girmez. [leagues] boş değilse yalnızca o liglerin maçları.
        val picks = scan.filter {
            it.dataQuality >= ForecastEngine.MIN_DATA_QUALITY && it.match.id !in exclude && (leagues.isEmpty() || it.match.leagueId in leagues)
        }.flatMap { r ->
            r.forecasts.map { f ->
                val e = r.evaluations.firstOrNull { it.marketKey == f.marketKey && it.selectionKey == f.selectionKey }
                    ?.takeIf { it.decision != Decision.STALE_ODDS && it.ev != null && it.adjProb != null }
                CouponPick(r.match, f, e)
            }
        }
        return CouponLab.build(type, picks)
    }

    // ---------------------------------------------------------------- Canlı, sakatlık, rotasyon

    private fun apiFixtureId(match: Match): Int? = if (match.id.startsWith("api-")) match.id.removePrefix("api-").toIntOrNull() else null

    suspend fun liveRefresh(match: Match): ApiResult<Match> {
        val id = apiFixtureId(match) ?: return ApiResult.Err("Canlı veri yalnızca API-Football maçları için.")
        return when (val r = fixtureProvider.call("/fixtures?id=$id&timezone=Europe/Istanbul")) {
            is ApiResult.Err -> r
            is ApiResult.Ok -> when (val p = fixtureProvider.parseFixtures(r.value)) {
                is ApiResult.Err -> p
                is ApiResult.Ok -> p.value.firstOrNull()?.let { ApiResult.Ok(it) } ?: ApiResult.Err("Maç verisi bulunamadı.")
            }
        }
    }

    suspend fun injuries(match: Match): ApiResult<List<String>> {
        val id = apiFixtureId(match) ?: return ApiResult.Err("Sakatlık verisi yalnızca API-Football maçları için.")
        return when (val r = fixtureProvider.call("/injuries?fixture=$id")) {
            is ApiResult.Err -> r
            is ApiResult.Ok -> try {
                val arr = JSONObject(r.value).optJSONArray("response") ?: JSONArray()
                ApiResult.Ok((0 until arr.length()).map {
                    val o = arr.getJSONObject(it)
                    val p = o.optJSONObject("player")
                    val team = o.optJSONObject("team")?.optString("name", "") ?: ""
                    "$team – ${p?.optString("name", "?") ?: "?"} (${p?.optString("reason", "") ?: ""})"
                })
            } catch (e: Exception) {
                ApiResult.Err("Sakatlık yanıtı okunamadı.")
            }
        }
    }

    private fun rotationFile(teamId: Int) = File(rotationDir, "rotation_$teamId.json")

    private fun readRotationRaw(teamId: Int): Pair<Long, List<Lineup>>? {
        val f = rotationFile(teamId)
        if (!f.exists()) return null
        return try {
            val o = JSONObject(f.readText())
            val a = o.getJSONArray("lineups")
            Pair(o.getLong("fetchedAt"), (0 until a.length()).map { Rotation.lineupFromJson(a.getJSONObject(it)) })
        } catch (e: Exception) { f.delete(); null }
    }

    fun cachedRotation(teamId: Int, kickoff: Long): RotationInfo? {
        val raw = readRotationRaw(teamId) ?: return null
        return Rotation.analyze(teamId, raw.second, kickoff)
    }

    /**
     * Teknik direktör rotasyon analizi. Takım başına ~5 istek harcar (dakikada 10 sınırı için
     * istekler arasında bekler). Sonuç 24 saat önbelleklenir.
     */
    suspend fun rotationFor(teamId: Int, kickoff: Long, onProgress: (String) -> Unit): ApiResult<RotationInfo> {
        val raw = readRotationRaw(teamId)
        val now = System.currentTimeMillis()
        if (raw != null && now - raw.first < 24L * 3600 * 1000) return ApiResult.Ok(Rotation.analyze(teamId, raw.second, kickoff))

        onProgress("Son maçlar alınıyor…")
        val list = when (val r = fixtureProvider.call("/fixtures?team=$teamId&last=4&timezone=Europe/Istanbul")) {
            is ApiResult.Err -> return r
            is ApiResult.Ok -> try {
                val arr = JSONObject(r.value).optJSONArray("response") ?: JSONArray()
                (0 until arr.length()).map {
                    val fx = arr.getJSONObject(it).getJSONObject("fixture")
                    Pair(fx.getInt("id"), fx.getLong("timestamp"))
                }
            } catch (e: Exception) { return ApiResult.Err("Son maç listesi okunamadı.") }
        }
        val lineups = ArrayList<Lineup>()
        for ((i, f) in list.withIndex()) {
            delay(6500)   // dakikada 10 istek sınırı
            onProgress("Kadro ${i + 1}/${list.size} alınıyor…")
            when (val r = fixtureProvider.call("/fixtures/lineups?fixture=${f.first}")) {
                is ApiResult.Err -> if (lineups.isEmpty() && i == list.lastIndex) return r
                is ApiResult.Ok -> Rotation.parseLineup(r.value, f.first, f.second, teamId)?.let { lineups.add(it) }
            }
        }
        if (lineups.isEmpty()) return ApiResult.Err("Kadro verisi alınamadı (bu lig veya plan için sunulmuyor olabilir).")
        val arr = JSONArray()
        lineups.forEach { arr.put(Rotation.lineupToJson(it)) }
        atomicWrite(rotationFile(teamId), JSONObject().put("fetchedAt", now).put("lineups", arr).toString())
        return ApiResult.Ok(Rotation.analyze(teamId, lineups, kickoff))
    }

    // ---------------------------------------------------------------- Geçmiş ve performans

    suspend fun predictionList(): List<PredictionRecord> = withContext(Dispatchers.IO) {
        predictions.all().sortedByDescending { it.kickoff }
    }

    suspend fun report(): Report = withContext(Dispatchers.IO) { Metrics.report(predictions.all()) }

    suspend fun saveManualResult(match: Match, fh: Int, fa: Int, hh: Int?, ha: Int?) = withContext(Dispatchers.IO) {
        store.addMatch(match.copy(statusShort = "FT", homeGoals = fh, awayGoals = fa, homeHt = hh, awayHt = ha))
    }

    /** Bitmiş maçların sonuçlarını alıp bekleyen tahminleri değerlendirir. Tarih başına 1 API isteği. */
    suspend fun settlePending(): String = withContext(Dispatchers.IO) {
        val now = System.currentTimeMillis()
        val all = predictions.all()
        val pending = all.filter { it.result == null && it.kickoff * 1000 + 3L * 3600 * 1000 < now }
        if (pending.isEmpty()) return@withContext "Değerlendirilecek bekleyen tahmin yok."

        val results = HashMap<String, Match>()
        store.matches().forEach { results[it.id] = it }
        val dates = pending.filter { !it.matchId.startsWith("man-") }
            .map { Instant.ofEpochSecond(it.kickoff).atZone(zone).toLocalDate() }.distinct()
        var apiNote = ""
        for (d in dates) {
            // Aktif tüm kaynaklardan güncel sonuçlar (önbellek atlanır); sonuç gelmezse tahmin beklemede kalır.
            val day = matchesForDate(d, true)
            day.matches.forEach { results[it.id] = it }
            if (day.notice != null) apiNote = " (Bazı sonuçlar alınamadı: ${day.notice})"
        }

        fun resultFor(rec: PredictionRecord): Match? {
            results[rec.matchId]?.let { return it }
            val parts = rec.matchLabel.split(" - ")
            if (parts.size != 2) return null
            return results.values.firstOrNull { m ->
                m.leagueId == rec.leagueId && abs(m.kickoff - rec.kickoff) <= 3 * 3600L &&
                    TeamMatcher.isSame(m.home, parts[0]) && TeamMatcher.isSame(m.away, parts[1])
            }
        }
        // Ertelenen/iptal edilen maçlar yanlış sayılmaz; beklemede kalır.
        val voided = pending.count { rec -> resultFor(rec)?.statusShort in setOf("PST", "CANC") }
        // Değerlendirmeler yalnızca bir "değişiklik" haritasına toplanır; yazma tek kilit altında,
        // GÜNCEL listeye uygulanır (ağ beklerken eklenen yeni kayıtlar kaybolmaz).
        val changes = HashMap<String, PredictionRecord>()
        for (rec in pending) {
            val m = resultFor(rec)
            val fh = m?.homeGoals
            val fa = m?.awayGoals
            if (m != null && StatusText.isFinished(m.statusShort) && fh != null && fa != null) {
                val s = Settler.settle(rec, fh, fa, m.homeHt, m.awayHt, now)
                if (s != null) changes[rec.id] = s
            }
        }
        val settled = predictions.updateById(changes)
        histCache = null
        val learned = if (settled > 0) learnNow() else null
        val learnNote = if (learned == null) "" else " Öğrenme: " +
            (if (learned.groups.isEmpty()) "kalibrasyon için yeterli veri yok, model değiştirilmedi." else "${learned.groups.size} pazar grubunda doğrulanmış kalibrasyon kullanılıyor.")
        "$settled tahmin değerlendirildi, ${pending.size - settled} beklemede." + learnNote +
            (if (voided > 0) " $voided tahmin ertelenen/iptal maçlara ait; yanlış sayılmadı." else "") + apiNote
    }

    // ---------------------------------------------------------------- Ayarlar

    suspend fun checkApiStatus(): String = when (val r = fixtureProvider.status()) {
        is ApiResult.Ok -> r.value
        is ApiResult.Err -> r.message
    }

    // ---------------------------------------------------------------- Kaynak testi ve doğrulama

    private fun noKey(id: SourceId) = ApiResult.Err("${id.title}: anahtar girilmedi.")

    /** Bağlantı testi kaynağa özeldir; sonuç yalnızca o kaynağın kartında görünür. */
    suspend fun testSource(id: SourceId): TestState {
        val now = System.currentTimeMillis()
        val raw = settings.rawKeyOf(id)
        val season = settings.season
        val r: ApiResult<String> = try {
            when (id) {
                SourceId.API_FOOTBALL ->
                    if (raw == null) noKey(id) else {
                        val was = settings.isEnabled(id)
                        if (!was) settings.setEnabled(id, true)
                        try { fixtureProvider.status() } finally { if (!was) settings.setEnabled(id, false) }
                    }
                SourceId.FOOTBALL_DATA -> if (raw == null) noKey(id) else footballData.test(raw)
                SourceId.API_NINJAS -> if (raw == null) noKey(id) else apiNinjas.test(raw)
                SourceId.ODDS_API -> if (raw == null) noKey(id) else oddsApi.testConnection(settings, raw)
                SourceId.THESPORTSDB -> theSportsDb.test(raw ?: "123")
                SourceId.OPENLIGADB -> openLiga.test(season)
                SourceId.STATSBOMB -> statsBomb.test()
            }
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            ApiResult.Err("${id.title}: Beklenmeyen hata (${e.javaClass.simpleName}).")
        }
        val state = when (r) {
            is ApiResult.Ok -> TestState(true, r.value, now)
            is ApiResult.Err -> TestState(false, r.message, now)
        }
        settings.setLastTest(id, state)
        return state
    }

    /**
     * Bir maçın ev/deplasman takımlarının toplam istatistiklerini kaynaklar arasında karşılaştırır.
     * Referans: model için kullanılan puan durumu. Karşılaştırma tahmini değiştirmez, yalnızca tutarlılığı gösterir.
     */
    suspend fun verifyMatch(match: Match): List<SourceCheck> = withContext(Dispatchers.IO) {
        val season = settings.season
        val out = ArrayList<SourceCheck>()
        var refSource: SourceId? = null
        var refRows: List<NamedTotals>? = null
        when (val t = table(match.leagueId)) {
            is ApiResult.Ok -> {
                val first = t.value.rows.firstOrNull()
                refSource = when {
                    t.value.source.contains(SourceId.FOOTBALL_DATA.title) -> SourceId.FOOTBALL_DATA
                    t.value.source.contains(SourceId.OPENLIGADB.title) -> SourceId.OPENLIGADB
                    first != null && first.teamId < 0 && t.value.source.isEmpty() -> SourceId.FOOTBALL_DATA
                    else -> SourceId.API_FOOTBALL
                }
                refRows = t.value.rows.map { NamedTotals(it.name, it.all.played, it.all.goalsFor, it.all.goalsAgainst, it.points) }
            }
            is ApiResult.Err -> {}
        }
        val rr = refRows
        val refHome = if (rr != null) Verifier.find(rr, match.home) else null
        val refAway = if (rr != null) Verifier.find(rr, match.away) else null
        val listed = FixtureMerge.sources(match)

        for (id in SourceId.values()) {
            val info = SourceCatalog.info(id)
            val listedNote = if (listed.contains(id.title)) " Bu maçı listeledi." else ""
            val check: SourceCheck = when {
                id == refSource ->
                    SourceCheck(id, CheckStatus.REFERENCE, "Karşılaştırmanın temeli: model puan durumu bu kaynaktan.$listedNote")
                id == SourceId.ODDS_API ->
                    SourceCheck(id, CheckStatus.UNSUPPORTED, "Oran kaynağı; puan durumu vermez.")
                id == SourceId.STATSBOMB ->
                    SourceCheck(id, CheckStatus.UNSUPPORTED, "Yalnızca seçili geçmiş sezonlar; güncel veri yok.")
                match.leagueId !in info.leagues ->
                    SourceCheck(id, CheckStatus.UNSUPPORTED, "Bu lig kaynağın kapsamında yok.")
                !settings.isActive(id) ->
                    SourceCheck(id, CheckStatus.DISABLED, "Kaynak pasif veya anahtarı yok.")
                else -> verifyWith(id, match, season, refHome, refAway, listedNote)
            }
            out.add(check)
        }
        out
    }

    private suspend fun verifyWith(
        id: SourceId, match: Match, season: Int, refHome: NamedTotals?, refAway: NamedTotals?, listedNote: String
    ): SourceCheck {
        val now = System.currentTimeMillis()
        val key = settings.keyOf(id) ?: ""
        val rows: ApiResult<List<NamedTotals>> = when (id) {
            SourceId.FOOTBALL_DATA -> when (val t = footballData.table(key, match.leagueId, season, now)) {
                is ApiResult.Ok -> ApiResult.Ok(t.value.rows.map { NamedTotals(it.name, it.all.played, it.all.goalsFor, it.all.goalsAgainst, it.points) })
                is ApiResult.Err -> t
            }
            SourceId.API_NINJAS -> apiNinjas.standings(key, match.leagueId, season)
            SourceId.THESPORTSDB -> theSportsDb.table(key.ifEmpty { "123" }, match.leagueId, season)
            SourceId.OPENLIGADB -> openLiga.table(season)
            else -> ApiResult.Err("${id.title}: puan durumu bu kaynaktan alınamadı.")
        }
        return when (rows) {
            is ApiResult.Err -> SourceCheck(id, CheckStatus.ERROR, rows.message)
            is ApiResult.Ok -> {
                val (st, note) = Verifier.compare(refHome, refAway, rows.value, match.home, match.away)
                SourceCheck(id, st, note + listedNote)
            }
        }
    }

    // ---------------------------------------------------------------- Öğrenme ve haber

    fun learningState(): LearningState? {
        learnCache?.let { return it }
        val s = learningStore.read()
        learnCache = s
        return s
    }

    /** Sonuçlanmış tahminlerden kontrollü kalibrasyon öğrenir ve kalıcı olarak saklar. */
    suspend fun learnNow(): LearningState = withContext(Dispatchers.IO) {
        val st = Learner.run(predictions.all(), learningState(), OpportunityEngine.MODEL_VERSION, System.currentTimeMillis())
        learningStore.write(st)
        learnCache = st
        st
    }

    /**
     * Maçın iki takımı için güncel haberleri (Google Haberler RSS) araştırır; 3 saat önbellek.
     * Döner: yeni haber verisi kaydedildiyse true. Hata olursa istatistiksel analiz etkilenmez.
     */
    suspend fun refreshNews(match: Match, force: Boolean = false): Boolean = withContext(Dispatchers.IO) {
        if (!settings.newsEnabled) return@withContext false
        val now = System.currentTimeMillis()
        val turkish = match.leagueId == 203 || match.leagueId == 204
        var changed = false
        for (team in listOf(match.home, match.away)) {
            val cached = newsStore.read(team)
            if (!force && cached != null && now / 1000 - cached.first < 3 * 3600) continue
            when (val r = newsClient.fetch(team, turkish, now / 1000)) {
                is ApiResult.Ok -> { newsStore.write(team, now / 1000, r.value); changed = true }
                is ApiResult.Err -> {}
            }
        }
        changed
    }

    fun clearCache() {
        newsStore.clear()
        cache.clear(); tableCache.clear()
        extraCaches.values.forEach { it.clear() }
        extDir.listFiles()?.forEach { it.delete() }
        rotationDir.listFiles()?.forEach { it.delete() }
    }
}
