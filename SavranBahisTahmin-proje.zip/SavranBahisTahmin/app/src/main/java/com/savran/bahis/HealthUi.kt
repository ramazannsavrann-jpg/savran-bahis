@file:OptIn(ExperimentalMaterial3Api::class)

package com.savran.bahis

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Card
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/** Veri sağlığı: hangi kaynak çalışıyor, hangi tablo ne kadar eski, hangi veriler HİÇ alınmıyor. Ağ isteği yapmaz. */
@Composable
fun DataHealthScreen(repo: Repository, pop: () -> Unit) {
    var tick by remember { mutableStateOf(0) }
    val items = remember(tick) { try { repo.dataHealth() } catch (e: Exception) { emptyList() } }
    Scaffold(topBar = { AppBar("Veri Sağlığı", pop) }) { pad ->
        Column(
            Modifier.padding(pad).fillMaxSize().verticalScroll(rememberScrollState()).padding(12.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Text(
                "Bu ekran yalnızca uygulamanın o an bildiği durumu gösterir; ağ isteği yapmaz. Yeşil: çalışıyor, sarı: henüz denenmedi/veri yok, kırmızı: kullanılamıyor.",
                fontSize = 11.sp, color = MutedText
            )
            SectionTitle("Kaynaklar ve tablolar")
            items.forEach { it0 ->
                val c = when (it0.ok) { true -> GreenOk; false -> RedBad; null -> AmberWarn }
                Card(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                        Text(it0.title, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                        Text(it0.value, fontSize = 12.sp, color = c)
                    }
                }
            }
            SectionTitle("Hiç alınmayan veriler (modele girmez)")
            listOf(
                "xG / xGA, şut, isabetli şut: bağlı kaynaklardan çekilmiyor",
                "Korner ve kart: veri yok, bu pazarlar için tahmin üretilmez",
                "Karşılıklı maç geçmişi: çekilmiyor",
                "Sakat/cezalı: yalnızca doğrulanmış haberlerle ve en fazla ±%6",
                "UEFA ülke katsayısı: eklenmedi (güvenilir, ülke adı belli kaynak yok); yerine kupa maçlarında ClubElo, alınamazsa kendi Savran Elo puanımız kullanılır"
            ).forEach { Text("• $it", fontSize = 12.sp) }
            Text(
                "Takım adları farklı yazılan kaynaklar birleştirilirken eşleşmezse aynı maç iki kez görünebilir; böyle bir şey görürsen haber ver.",
                fontSize = 11.sp, color = MutedText
            )
        }
    }
}

/** Bir analizin neye dayandığını ve neyi bilmediğini kriter listesinden özetler (yeni veri uydurmaz). */
object AnalysisBasis {
    fun lines(criteria: List<Criterion>): Pair<List<String>, List<String>> {
        val used = criteria.filter { it.status == CriterionStatus.USED || it.status == CriterionStatus.PARTIAL }.map { it.name }
        val missing = criteria.filter { it.status == CriterionStatus.NO_DATA || it.status == CriterionStatus.NOT_USED }.map { it.name }
        return used to missing
    }
}
