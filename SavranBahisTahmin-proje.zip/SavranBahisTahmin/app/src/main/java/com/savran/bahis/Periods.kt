package com.savran.bahis

import java.time.Instant
import java.time.ZoneId

enum class Period(val tr: String, val days: Int) {
    DAY("Günlük", 1), WEEK("Haftalık", 7), MONTH("Aylık", 30)
}

data class GroupStat(val label: String, val n: Int, val correct: Int) {
    val rate: Double get() = if (n == 0) 0.0 else correct.toDouble() / n
}

data class PeriodSummary(val settled: Int, val correct: Int) {
    val hitRate: Double? get() = if (settled == 0) null else correct.toDouble() / settled
}

data class PeriodReport(
    val period: Period,
    val fromMs: Long,
    val toMs: Long,
    val total: Int,                  // dönemdeki tüm kayıtlı tahminler
    val settled: Int,                // sonucu belli olanlar
    val correct: Int,
    val wrong: Int,
    val hitRate: Double?,            // yalnızca sonucu belli olanlardan
    val byMarket: List<GroupStat>,
    val byLeague: List<GroupStat>,
    val best: GroupStat?,
    val worst: GroupStat?,
    val previous: PeriodSummary,
    val meanProb: Double?            // sonuçlanan tahminlerin ortalama olasılığı
)

object PeriodReports {
    const val MIN_FOR_COMMENT = 5
    const val MIN_GROUP = 3

    fun marketLabel(mk: String): String = MarketFilters.groups.firstOrNull { it.test(mk) }?.label ?: "Diğer"

    /** Dönem penceresi maçın başlama zamanına göre (günlük = yerel bugün; haftalık = son 7 gün; aylık = son 30 gün). */
    fun window(period: Period, nowMs: Long, zone: ZoneId): Pair<Long, Long> {
        return if (period == Period.DAY) {
            val start = Instant.ofEpochMilli(nowMs).atZone(zone).toLocalDate().atStartOfDay(zone).toInstant().toEpochMilli()
            start to start + 24L * 3600_000
        } else {
            val len = period.days * 24L * 3600_000
            (nowMs - len) to nowMs
        }
    }

    private fun inWindow(r: PredictionRecord, from: Long, to: Long): Boolean {
        val t = r.kickoff * 1000
        return t >= from && t < to
    }

    fun build(records: List<PredictionRecord>, period: Period, nowMs: Long, zone: ZoneId): PeriodReport {
        val (from, to) = window(period, nowMs, zone)
        val len = to - from
        val picks = Metrics.modelPickIds(records)
        val cur = records.filter { it.id in picks && inWindow(it, from, to) }
        val prev = records.filter { it.id in picks && inWindow(it, from - len, from) && it.result != null }
        val settled = cur.filter { it.result != null }
        val correct = settled.count { it.result == true }
        fun stats(key: (PredictionRecord) -> String): List<GroupStat> =
            settled.groupBy(key).map { (k, l) -> GroupStat(k, l.size, l.count { it.result == true }) }
                .sortedByDescending { it.n }
        val byMarket = stats { marketLabel(it.marketKey) }
        val byLeague = stats { it.leagueName }
        val eligible = byMarket.filter { it.n >= MIN_GROUP }
        val best = eligible.maxByOrNull { it.rate }
        val worst = eligible.filter { it != best }.minByOrNull { it.rate }
        return PeriodReport(
            period, from, to, cur.size, settled.size, correct, settled.size - correct,
            if (settled.isEmpty()) null else correct.toDouble() / settled.size,
            byMarket, byLeague, best, worst,
            PeriodSummary(prev.size, prev.count { it.result == true }),
            if (settled.isEmpty()) null else settled.sumOf { it.prob } / settled.size
        )
    }

    private fun pc(x: Double) = "%" + Math.round(x * 100)

    /** Motorun kendi değerlendirmesi: yalnızca gerçek dönem verilerinden üretilir. */
    fun commentary(r: PeriodReport, learning: LearningState?): String {
        if (r.settled < MIN_FOR_COMMENT) {
            return "Bu dönemde sonucu belli olan ${r.settled} tahmin var; değerlendirme için en az $MIN_FOR_COMMENT gerekir. Yorum üretilmedi."
        }
        val sb = StringBuilder()
        sb.append("${r.period.tr} dönemde sonucu belli olan ${r.settled} tahminin ${r.correct}'i doğru (${pc(r.hitRate ?: 0.0)}). ")
        val pHit = r.previous.hitRate
        if (r.previous.settled >= MIN_FOR_COMMENT && pHit != null) {
            val diff = Math.round(((r.hitRate ?: 0.0) - pHit) * 100)
            sb.append(
                when {
                    diff > 0 -> "Önceki döneme göre başarı $diff puan arttı. "
                    diff < 0 -> "Önceki döneme göre başarı ${-diff} puan azaldı. "
                    else -> "Başarı önceki dönemle aynı seviyede. "
                }
            )
        } else {
            sb.append("Önceki dönemde karşılaştırma için yeterli sonuçlanmış tahmin yok. ")
        }
        r.best?.let { sb.append("En başarılı pazar: ${it.label} (${pc(it.rate)}, ${it.n} tahmin). ") }
        r.worst?.let { sb.append("En zayıf pazar: ${it.label} (${pc(it.rate)}, ${it.n} tahmin). ") }
        val mp = r.meanProb
        val hr = r.hitRate
        if (mp != null && hr != null && r.settled >= 20) {
            val gap = mp - hr
            if (gap >= 0.08) sb.append("Tahmin olasılıkları gerçekleşen orandan ortalama ${Math.round(gap * 100)} puan yüksek hesaplandı (fazla iddialı). ")
            else if (gap <= -0.08) sb.append("Tahmin olasılıkları gerçekleşen orandan ortalama ${Math.round(-gap * 100)} puan düşük kaldı (temkinli). ")
        }
        // Öğrenme durumu (kalıcı kayıtlardan)
        if (learning == null || (learning.groups.isEmpty() && learning.events.isEmpty())) {
            sb.append("Öğrenme: kalibrasyon için gereken veri (grup başına en az ${Calibration.MIN_N} sonuçlanmış tahmin) henüz birikmedi; model değiştirilmedi.")
        } else {
            val adopted = learning.groups.values.joinToString(", ") { Calibration.groupLabel(it.name) + " (n=" + it.n + ")" }
            if (adopted.isNotEmpty()) sb.append("Öğrenme: şu pazarlarda doğrulanmış kalibrasyon kullanılıyor: $adopted. ")
            else sb.append("Öğrenme: değerlendirme yapıldı ancak doğrulamada yeterli iyileşme bulunamadığı için model değiştirilmedi. ")
            if (learning.weak.isNotEmpty()) {
                sb.append("Zayıf bulunan pazarlarda güven seviyesi düşürülüyor: ${learning.weak.joinToString(", ") { Calibration.groupLabel(it) }}.")
            }
        }
        return sb.toString().trim()
    }
}
