package com.savran.bahis

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONException
import org.json.JSONObject
import java.io.File
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import java.time.Instant

data class ExtPrice(val marketKey: String, val selectionKey: String, val odds: Double, val bookmaker: String, val updatedAt: Long)
data class ExternalEvent(val home: String, val away: String, val commence: Long, val prices: List<ExtPrice>)

/**
 * İkinci veri kaynağı: The Odds API (ücretsiz anahtar, kredi sınırlı). Oranlar Avrupa/uluslararası
 * şirketlerindendir; her oran kendi şirket adıyla ve "The Odds API" kaynağıyla etiketlenir.
 * Hiçbir zaman Türkiye'deki bir şirketin oranıymış gibi gösterilmez. İsteğe bağlıdır.
 */
class OddsApiClient(private val settings: AppSettings, private val cacheDir: File) {
    private val base = "https://api.the-odds-api.com/v4"

    private val sportKeys = mapOf(
        203 to "soccer_turkey_super_league",
        39 to "soccer_epl",
        78 to "soccer_germany_bundesliga",
        140 to "soccer_spain_la_liga",
        61 to "soccer_france_ligue_one"
    )

    fun supports(leagueId: Int) = sportKeys.containsKey(leagueId)

    suspend fun events(leagueId: Int, force: Boolean): ApiResult<List<ExternalEvent>> = withContext(Dispatchers.IO) {
        val key = settings.oddsApiKey ?: return@withContext ApiResult.Err("İkinci API anahtarı (The Odds API) girilmedi.")
        val sport = sportKeys[leagueId] ?: return@withContext ApiResult.Err("Bu lig için harici oran kaynağı yok.")
        val cacheFile = File(cacheDir, "ext_odds_$leagueId.json")
        val now = System.currentTimeMillis()
        if (!force && cacheFile.exists()) {
            try {
                val root = JSONObject(cacheFile.readText())
                if (now - root.getLong("fetchedAt") < 3L * 3600 * 1000) {
                    return@withContext ApiResult.Ok(eventsFromCache(root.getJSONArray("events")))
                }
            } catch (e: Exception) { cacheFile.delete() }
        }
        val url = URL("$base/sports/$sport/odds/?apiKey=$key&regions=eu&markets=h2h,totals&oddsFormat=decimal&dateFormat=iso")
        val conn = url.openConnection() as HttpURLConnection
        try {
            conn.connectTimeout = 15000
            conn.readTimeout = 20000
            val code = conn.responseCode
            val remaining = conn.getHeaderField("x-requests-remaining")
            val body = (if (code in 200..299) conn.inputStream else conn.errorStream)?.bufferedReader()?.use { it.readText() } ?: ""
            if (code == 401) return@withContext ApiResult.Err("The Odds API anahtarı geçersiz (401).")
            if (code == 429) return@withContext ApiResult.Err("The Odds API limiti doldu (429).")
            if (code !in 200..299) return@withContext ApiResult.Err("The Odds API hatası ($code).")
            val parsed = parseEvents(body)
            if (parsed is ApiResult.Ok) {
                val arr = JSONArray()
                parsed.value.forEach { arr.put(eventToJson(it)) }
                atomicWrite(cacheFile, JSONObject().put("fetchedAt", now).put("events", arr).toString())
                if (remaining != null) settings.setOddsApiRemaining(remaining)
            }
            parsed
        } catch (e: IOException) {
            ApiResult.Err("İnternet bağlantısı yok veya The Odds API'ye ulaşılamadı.")
        } finally {
            conn.disconnect()
        }
    }

    internal fun parseEvents(body: String): ApiResult<List<ExternalEvent>> {
        return try {
            val arr = JSONArray(body)
            val out = ArrayList<ExternalEvent>()
            for (i in 0 until arr.length()) {
                val e = arr.getJSONObject(i)
                val home = e.getString("home_team")
                val away = e.getString("away_team")
                val commence = Instant.parse(e.getString("commence_time")).epochSecond
                val prices = ArrayList<ExtPrice>()
                val books = e.optJSONArray("bookmakers") ?: JSONArray()
                for (b in 0 until books.length()) {
                    val bk = books.getJSONObject(b)
                    val title = bk.getString("title")
                    val updated = try { Instant.parse(bk.getString("last_update")).toEpochMilli() } catch (ex: Exception) { System.currentTimeMillis() }
                    val markets = bk.optJSONArray("markets") ?: continue
                    for (m in 0 until markets.length()) {
                        val mo = markets.getJSONObject(m)
                        val outs = mo.optJSONArray("outcomes") ?: continue
                        for (k in 0 until outs.length()) {
                            val o = outs.getJSONObject(k)
                            val name = o.getString("name")
                            val price = o.getDouble("price")
                            if (!OddsMath.isValidOdds(price)) continue
                            when (mo.getString("key")) {
                                "h2h" -> {
                                    val sel = when (name) {
                                        home -> "1"
                                        away -> "2"
                                        "Draw" -> "X"
                                        else -> null
                                    }
                                    if (sel != null) prices.add(ExtPrice("1x2", sel, price, title, updated))
                                }
                                "totals" -> {
                                    val point = o.optDouble("point", Double.NaN)
                                    val mk = "ou_$point"
                                    val sel = when (name) { "Over" -> "over"; "Under" -> "under"; else -> null }
                                    if (!point.isNaN() && sel != null && MarketCatalog.find(mk) != null) {
                                        prices.add(ExtPrice(mk, sel, price, title, updated))
                                    }
                                }
                            }
                        }
                    }
                }
                out.add(ExternalEvent(home, away, commence, prices))
            }
            ApiResult.Ok(out)
        } catch (e: JSONException) {
            ApiResult.Err("The Odds API yanıtı okunamadı.")
        }
    }

    private fun eventToJson(e: ExternalEvent): JSONObject {
        val pa = JSONArray()
        e.prices.forEach { pa.put(JSONObject().put("m", it.marketKey).put("s", it.selectionKey).put("o", it.odds).put("b", it.bookmaker).put("u", it.updatedAt)) }
        return JSONObject().put("home", e.home).put("away", e.away).put("commence", e.commence).put("prices", pa)
    }

    private fun eventsFromCache(arr: JSONArray): List<ExternalEvent> = (0 until arr.length()).map {
        val o = arr.getJSONObject(it)
        val pa = o.getJSONArray("prices")
        ExternalEvent(
            o.getString("home"), o.getString("away"), o.getLong("commence"),
            (0 until pa.length()).map { j ->
                val p = pa.getJSONObject(j)
                ExtPrice(p.getString("m"), p.getString("s"), p.getDouble("o"), p.getString("b"), p.getLong("u"))
            }
        )
    }

    /** Takım adı + başlama saati ile bizim maçımızla eşleşen harici olayı bulur. */
    fun findEvent(events: List<ExternalEvent>, match: Match): ExternalEvent? =
        events.firstOrNull {
            TeamMatcher.isSame(it.home, match.home) && TeamMatcher.isSame(it.away, match.away) &&
                kotlin.math.abs(it.commence - match.kickoff) < 12 * 3600
        }
}
