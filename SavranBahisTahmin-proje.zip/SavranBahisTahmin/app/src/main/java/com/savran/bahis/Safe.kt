package com.savran.bahis

import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch

/**
 * Arayüzden başlatılan işlerde beklenmeyen bir istisna uygulamayı çökertmesin.
 * İptal (CancellationException) yeniden fırlatılır; diğer hatalar [onError] ile bildirilir, [onDone] her durumda çalışır.
 */
fun CoroutineScope.launchSafe(
    onError: (String) -> Unit = {},
    onDone: () -> Unit = {},
    block: suspend CoroutineScope.() -> Unit
): Job = launch {
    try {
        block()
    } catch (e: CancellationException) {
        throw e
    } catch (e: Exception) {
        onError(e.message ?: e.javaClass.simpleName)
    } finally {
        onDone()
    }
}
