package com.savran.bahis

import org.json.JSONArray
import org.json.JSONObject
import java.io.File

/**
 * Biriken maç sonuçları: uygulamanın çektiği günlük maç listelerindeki BİTMİŞ yerli lig maçları kaydedilir.
 * Süper Lig gibi güncel puan durumunu ücretsiz veren kaynak olmayan liglerde tablo bu gerçek sonuçlardan hesaplanır.
 * Geçmiş günler de (kota sınırlı) geriye doğru doldurulur. Kupa maçları da kaydedilir (yalnızca Savran Elo güncellemesi için).
 */
class ResultsLog(dir: File) {
    private val file = File(dir, "results_log.json")
    data class Entry(val id: String, val leagueId: Int, val r: FinishedResult)

    @Synchronized
    private fun read(): Pair<MutableMap<String, Entry>, MutableSet<String>> {
        val map = LinkedHashMap<String, Entry>()
        val days = HashSet<String>()
        if (!file.exists()) return map to days
        try {
            val o = JSONObject(file.readText())
            val a = o.optJSONArray("items") ?: JSONArray()
            for (i in 0 until a.length()) {
                val e = a.getJSONObject(i)
                val id = e.getString("id")
                map[id] = Entry(id, e.getInt("l"), FinishedResult(e.getString("h"), e.getString("a"), e.getInt("hg"), e.getInt("ag"), e.getLong("k")))
            }
            val d = o.optJSONArray("days") ?: JSONArray()
            for (i in 0 until d.length()) days.add(d.getString(i))
        } catch (e: Exception) {
            file.renameTo(File(file.parentFile, "results_log.corrupt.json"))
        }
        return map to days
    }

    @Synchronized
    private fun write(map: Map<String, Entry>, days: Set<String>) {
        val a = JSONArray()
        map.values.forEach {
            a.put(JSONObject().put("id", it.id).put("l", it.leagueId).put("h", it.r.home).put("a", it.r.away)
                .put("hg", it.r.homeGoals).put("ag", it.r.awayGoals).put("k", it.r.kickoff))
        }
        atomicWrite(file, JSONObject().put("items", a).put("days", JSONArray(days.toList())).toString())
    }

    /** Gerçek skorlu (FT/AET/PEN) yerli lig maçlarını ekler. [day] verilirse o gün "tamamlandı" işaretlenir. */
    @Synchronized
    fun record(matches: List<Match>, day: String? = null): Int {
        val (map, days) = read()
        var n = 0
        for (m in matches) {
            if (m.statusShort !in setOf("FT", "AET", "PEN")) continue
            if (Leagues.byId(m.leagueId) == null) continue   // kupa maçları da kaydedilir (Savran Elo güncellemesi için); tablolar yalnızca yerli ligleri okur
            val hg = m.homeGoals ?: continue
            val ag = m.awayGoals ?: continue
            if (!map.containsKey(m.id)) n++
            map[m.id] = Entry(m.id, m.leagueId, FinishedResult(m.home, m.away, hg, ag, m.kickoff))
        }
        val dayAdded = day != null && days.add(day)
        if (n > 0 || dayAdded) write(map, days)
        return n
    }

    @Synchronized
    fun results(leagueId: Int, sinceSec: Long): List<FinishedResult> =
        read().first.values.filter { it.leagueId == leagueId && it.r.kickoff >= sinceSec }.map { it.r }

    @Synchronized
    fun doneDays(): Set<String> = read().second

    /** [sinceSec] sonrası tüm kayıtlı sonuçlar (lig no ile), saat sırasıyla. */
    @Synchronized
    fun allSince(sinceSec: Long): List<Entry> = read().first.values.filter { it.r.kickoff >= sinceSec }.sortedBy { it.r.kickoff }

    @Synchronized
    fun size(): Int = read().first.size
}
