package com.savran.bahis

import java.time.Instant
import java.time.LocalTime
import java.time.ZoneOffset

/** Saf (Android'siz) hesap ve kural fonksiyonları. Birim testleri bunları doğrular. */
object OddsMath {
    fun isValidOdds(o: Double): Boolean = o.isFinite() && o >= 1.01 && o <= 1000.0

    /** "1,85" ve "1.85" kabul edilir. Geçersizse null. */
    fun parseOdds(text: String): Double? =
        text.trim().replace(',', '.').toDoubleOrNull()?.takeIf { isValidOdds(it) }

    /** Oran marjı dahil piyasa olasılığı (1/oran). Model olasılığı DEĞİLDİR. */
    fun impliedProbability(odds: Double): Double = 1.0 / odds

    /** EV = p*(oran-1) - (1-p) */
    fun expectedValue(probability: Double, odds: Double): Double =
        probability * (odds - 1.0) - (1.0 - probability)

    /** Tüm seçenekleri kapsayan bir pazarın marjı: sum(1/oran) - 1 */
    fun overround(odds: List<Double>): Double = odds.sumOf { 1.0 / it } - 1.0

    /** Marjı orantılı dağıtarak çıkarılmış olasılıklar (toplam 1). */
    fun fairProbabilities(odds: List<Double>): List<Double> {
        val total = odds.sumOf { 1.0 / it }
        return odds.map { (1.0 / it) / total }
    }
}

object OddsFreshness {
    const val STALE_AFTER_MS: Long = 6L * 60 * 60 * 1000

    /** Maç başladıysa veya oran 6 saatten eskiyse "eski" sayılır. */
    fun isStale(updatedAtMs: Long, nowMs: Long, kickoffSec: Long): Boolean =
        nowMs >= kickoffSec * 1000 || (nowMs - updatedAtMs) > STALE_AFTER_MS

    fun ageLabel(updatedAtMs: Long, nowMs: Long): String {
        val minutes = maxOf(0L, nowMs - updatedAtMs) / 60000
        return when {
            minutes < 1 -> "az önce"
            minutes < 60 -> "$minutes dk önce"
            minutes < 24 * 60 -> "${minutes / 60} sa önce"
            else -> "${minutes / (24 * 60)} gün önce"
        }
    }
}

object CachePolicy {
    private const val HOUR = 60L * 60 * 1000

    /** dayOffset: bugüne göre gün farkı (<0 geçmiş, 0 bugün, >0 gelecek). */
    fun isFresh(fetchedAtMs: Long, nowMs: Long, dayOffset: Int): Boolean {
        val age = maxOf(0L, nowMs - fetchedAtMs)
        val ttl = when {
            dayOffset < 0 -> 24 * HOUR
            dayOffset == 0 -> 3 * HOUR
            else -> 6 * HOUR
        }
        return age < ttl
    }
}

object Quota {
    const val DAILY_LIMIT = 100
    const val RESERVE = 5   // son 5 istek yedekte tutulur

    fun canSpend(usedToday: Int, remainingHeader: Int?): Boolean =
        if (remainingHeader != null) remainingHeader > RESERVE
        else usedToday < DAILY_LIMIT - RESERVE

    /** API-Football kotası 00:00 UTC'de sıfırlanır. */
    fun utcDay(nowMs: Long): String =
        Instant.ofEpochMilli(nowMs).atZone(ZoneOffset.UTC).toLocalDate().toString()
}

object TimeUtil {
    fun parseTime(s: String): LocalTime? {
        val p = s.trim().split(':', '.')
        if (p.size != 2) return null
        val h = p[0].toIntOrNull() ?: return null
        val m = p[1].toIntOrNull() ?: return null
        if (h !in 0..23 || m !in 0..59) return null
        return LocalTime.of(h, m)
    }
}
