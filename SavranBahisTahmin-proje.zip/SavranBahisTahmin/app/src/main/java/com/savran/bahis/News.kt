package com.savran.bahis

import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.net.URLEncoder
import java.time.ZonedDateTime
import java.time.format.DateTimeFormatter
import java.util.Locale

enum class NewsTopic(val tr: String) {
    GOALKEEPER("Kaleci"), STRIKER("Forvet/golcü"), DEFENDER("Savunma"), INJURY("Sakatlık"), SUSPENSION("Ceza"),
    LINEUP("İlk 11"), COACH("Teknik direktör"), LOAD("Yorgunluk/fikstür"), MOTIVATION("Motivasyon")
}

data class NewsItem(
    val team: String,
    val title: String,
    val source: String,
    val link: String,
    val publishedAt: Long,          // epoch saniye
    val fetchedAt: Long,            // epoch saniye
    val topics: Set<NewsTopic>,
    val out: Boolean,               // bir oyuncunun yokluğunu bildiriyor
    val rumor: Boolean,             // iddia/söylenti/tahmini dil
    val official: Boolean           // resmî açıklama veya resmî kaynak
)

data class RssItem(val title: String, val link: String, val published: Long?, val source: String?, val sourceUrl: String?)

object NewsText {
    /** Küçük harfe ve ASCII'ye yakın biçime çevirir: "İlk 11" ile "ilk 11" aynı eşleşir. */
    fun fold(s: String): String {
        val sb = StringBuilder()
        for (ch in s.lowercase(Locale.ROOT)) {
            when (ch) {
                '\u0307' -> {}
                'ı' -> sb.append('i')
                'ş' -> sb.append('s')
                'ğ' -> sb.append('g')
                'ü' -> sb.append('u')
                'ö' -> sb.append('o')
                'ç' -> sb.append('c')
                else -> sb.append(ch)
            }
        }
        return sb.toString()
    }

    private val outWords = listOf(
        "sakat", "sakatlik", "cezali", "kadro disi", " yok ", "forma giyemeyecek", "oynayamayacak", "oynamayacak",
        "eksik", "ameliyat", "sezonu kapatti", "injur", "ruled out", "out for", "suspended", "suspension", " miss ", " misses ", " out "
    )
    private val rumorWords = listOf(
        "iddia", "soylenti", "bekleniyor", "muhtemel", "olabilir", "belki", "tahmin", "rumour", "rumor", "reportedly",
        "could", "might", "doubt", "possible", "expected to", "set to"
    )
    private val officialWords = listOf("resmen", "resmi aciklama", "kulubumuz", "kap aciklama", "official", "confirmed by the club", "club statement")
    private val officialDomains = listOf(
        "tff.org", "galatasaray.org", "fenerbahce.org", "bjk.com.tr", "trabzonspor.org.tr", "premierleague.com",
        "bundesliga.com", "laliga.com", "ligue1.com", "uefa.com"
    )
    private val gk = listOf("kaleci", "goalkeeper", "keeper")
    private val striker = listOf("golcu", "forvet", "santrfor", "striker", "forward", "top scorer", "yildiz")
    private val defender = listOf("stoper", "defans", "savunma", " bek ", "defender", "centre-back", "center-back")
    private val lineup = listOf("ilk 11", "ilk on bir", "muhtemel 11", "lineup", "starting xi", "starting eleven")
    private val coachWord = listOf("teknik direktor", "hoca", "coach", "manager")
    private val coachChange = listOf("gorevden", "ayrildi", "istifa", "kovuldu", "sacked", "appointed", "yeni teknik direktor", "resign", "parted ways")
    private val load = listOf("yorgun", "yogun fikstur", "fixture congestion", "tired", "fatigue", "rotasyon")
    private val motivation = listOf("sampiyonluk", "kume dusme", "motivasyon", "relegation", "title race")

    private fun any(t: String, words: List<String>) = words.any { t.contains(it) }

    data class Classified(val topics: Set<NewsTopic>, val out: Boolean, val rumor: Boolean, val official: Boolean)

    fun classify(title: String, sourceUrl: String?): Classified {
        val t = " " + fold(title) + " "
        val out = any(t, outWords)
        val topics = HashSet<NewsTopic>()
        if (any(t, gk)) topics.add(NewsTopic.GOALKEEPER)
        if (any(t, striker)) topics.add(NewsTopic.STRIKER)
        if (any(t, defender)) topics.add(NewsTopic.DEFENDER)
        if (out && any(t, listOf("sakat", "injur", "ameliyat"))) topics.add(NewsTopic.INJURY)
        if (out && any(t, listOf("cezali", "suspend", "kart cezasi"))) topics.add(NewsTopic.SUSPENSION)
        if (any(t, lineup)) topics.add(NewsTopic.LINEUP)
        if (any(t, coachWord) && any(t, coachChange)) topics.add(NewsTopic.COACH)
        if (any(t, load)) topics.add(NewsTopic.LOAD)
        if (any(t, motivation)) topics.add(NewsTopic.MOTIVATION)
        val rumor = any(t, rumorWords) || topics.contains(NewsTopic.LINEUP)   // "muhtemel 11" tahmindir
        val host = sourceUrl?.let { fold(it) } ?: ""
        val official = any(t, officialWords) || officialDomains.any { host.contains(it) }
        return Classified(topics, out, rumor && !official, official)
    }

    /** Başlıkta takım adının tüm anlamlı parçaları geçiyor mu? ("Manchester City" için "Manchester United" haberi sayılmaz.) */
    fun mentions(title: String, team: String): Boolean {
        val t = fold(title)
        val tokens = fold(team).split(' ', '-', '.').filter { it.length >= 3 }
        return tokens.isNotEmpty() && tokens.all { t.contains(it) }
    }
}

object RssParser {
    private val itemRe = Regex("<item>(.*?)</item>", RegexOption.DOT_MATCHES_ALL)
    private fun unescape(s: String): String = s.replace("<![CDATA[", "").replace("]]>", "")
        .replace("&amp;", "&").replace("&lt;", "<").replace("&gt;", ">").replace("&quot;", "\"")
        .replace("&#39;", "'").replace("&apos;", "'").trim()

    private fun tag(block: String, name: String): String? =
        Regex("<$name[^>]*>(.*?)</$name>", RegexOption.DOT_MATCHES_ALL).find(block)?.groupValues?.get(1)?.let { unescape(it) }

    fun parse(body: String): List<RssItem> = itemRe.findAll(body).mapNotNull { m ->
        val block = m.groupValues[1]
        val title = tag(block, "title") ?: return@mapNotNull null
        val link = tag(block, "link") ?: ""
        val pub = tag(block, "pubDate")?.let {
            try { ZonedDateTime.parse(it, DateTimeFormatter.RFC_1123_DATE_TIME).toEpochSecond() } catch (e: Exception) { null }
        }
        val srcMatch = Regex("<source[^>]*url=\"([^\"]*)\"[^>]*>(.*?)</source>", RegexOption.DOT_MATCHES_ALL).find(block)
        val srcName = srcMatch?.groupValues?.get(2)?.let { unescape(it) }
        val srcUrl = srcMatch?.groupValues?.get(1)
        val clean = if (srcName != null && title.endsWith(" - $srcName")) title.removeSuffix(" - $srcName") else title
        RssItem(clean, link, pub, srcName, srcUrl)
    }.toList()

    fun toNewsItems(team: String, items: List<RssItem>, now: Long, maxAgeSec: Long = 7 * 24 * 3600L): List<NewsItem> =
        items.mapNotNull { r ->
            val pub = r.published ?: return@mapNotNull null          // tarihi bilinmeyen haber kullanılmaz
            if (now - pub > maxAgeSec || pub - now > 3600) return@mapNotNull null
            if (!NewsText.mentions(r.title, team)) return@mapNotNull null
            val c = NewsText.classify(r.title, r.sourceUrl)
            NewsItem(team, r.title, r.source ?: "Google Haberler", r.link, pub, now, c.topics, c.out, c.rumor, c.official)
        }.take(15)

    fun queryUrl(team: String, turkish: Boolean): String {
        val kw = if (turkish) "sakat OR cezalı OR kadro OR \"ilk 11\" OR \"teknik direktör\" OR kaleci"
        else "injury OR injured OR suspended OR lineup OR manager OR goalkeeper"
        val q = URLEncoder.encode("\"$team\" ($kw) when:7d", "UTF-8")
        return if (turkish) "https://news.google.com/rss/search?q=$q&hl=tr&gl=TR&ceid=TR:tr"
        else "https://news.google.com/rss/search?q=$q&hl=en-US&gl=US&ceid=US:en"
    }
}

data class NewsEffect(
    val homeFactor: Double,
    val awayFactor: Double,
    val applied: List<String>,      // hesaplamaya katılan doğrulanmış haberler
    val info: List<String>          // bilgi olarak gösterilen, hesaba katılmayanlar
)

/** Haberlerin tahmine etkisi: yalnızca taze, söylenti olmayan ve doğrulanmış haberler; en fazla ±%6. */
object NewsImpact {
    const val MAX_AGE_SEC = 72 * 3600L
    const val CAP = 0.06

    private fun tokens(title: String): Set<String> =
        NewsText.fold(title).split(Regex("[^a-z0-9]+")).filter { it.length >= 3 }.toSet()

    /** Aynı haberin farklı sitelerde tekrarı (başlık benzerliği) tek bilgi sayılır. */
    fun similar(a: String, b: String): Boolean {
        val ta = tokens(a)
        val tb = tokens(b)
        if (ta.isEmpty() || tb.isEmpty()) return false
        val inter = ta.intersect(tb).size.toDouble()
        return inter / (ta.union(tb).size.toDouble()) >= 0.6
    }

    fun distinctStories(items: List<NewsItem>): List<List<NewsItem>> {
        val groups = ArrayList<MutableList<NewsItem>>()
        for (it in items.sortedBy { n -> n.publishedAt }) {
            val g = groups.firstOrNull { grp -> similar(grp[0].title, it.title) }
            if (g != null) g.add(it) else groups.add(mutableListOf(it))
        }
        return groups
    }

    fun compute(homeTeam: String, home: List<NewsItem>, awayTeam: String, away: List<NewsItem>, now: Long): NewsEffect {
        var hf = 1.0
        var af = 1.0
        val applied = ArrayList<String>()
        val info = ArrayList<String>()

        fun side(team: String, items: List<NewsItem>, isHome: Boolean) {
            val fresh = items.filter { now - it.publishedAt <= MAX_AGE_SEC }
            val stale = items.size - fresh.size
            if (stale > 0) info.add("$team: $stale haber 72 saatten eski; hesaba katılmadı.")
            val rumors = fresh.count { it.rumor }
            if (rumors > 0) info.add("$team: $rumors haber söylenti/tahmini dilde (ör. muhtemel 11); kesin bilgi sayılmadı.")
            for (topic in listOf(NewsTopic.GOALKEEPER, NewsTopic.STRIKER, NewsTopic.DEFENDER)) {
                val rel = fresh.filter { !it.rumor && it.out && it.topics.contains(topic) }
                if (rel.isEmpty()) continue
                val stories = distinctStories(rel)
                val official = rel.any { it.official }
                if (official || stories.size >= 2) {
                    // Gol beklentisi etkisi: kaleci/savunma eksiği rakibin, forvet eksiği kendi golünü etkiler.
                    val basis = if (official) "resmî kaynak" else "${stories.size} bağımsız haber"
                    when (topic) {
                        NewsTopic.GOALKEEPER -> { if (isHome) af *= 1.03 else hf *= 1.03; applied.add("$team: kaleci eksikliği ($basis) → rakip gol beklentisi %3 arttı") }
                        NewsTopic.STRIKER -> { if (isHome) hf *= 0.97 else af *= 0.97; applied.add("$team: forvet/golcü eksikliği ($basis) → kendi gol beklentisi %3 azaldı") }
                        else -> { if (isHome) af *= 1.02 else hf *= 1.02; applied.add("$team: savunma oyuncusu eksikliği ($basis) → rakip gol beklentisi %2 arttı") }
                    }
                } else {
                    info.add("$team: ${topic.tr} ile ilgili tek bağımsız haber var ve resmî değil; doğrulanmadığı için hesaba katılmadı.")
                }
            }
            val coach = fresh.filter { it.topics.contains(NewsTopic.COACH) }
            if (coach.isNotEmpty()) info.add("$team: teknik direktör değişikliği haberi var (${coach[0].source}); modele katılmadı, belirsizlik olarak not edildi.")
            val ctx = fresh.filter { it.topics.contains(NewsTopic.LOAD) || it.topics.contains(NewsTopic.MOTIVATION) }
            if (ctx.isNotEmpty()) info.add("$team: yorgunluk/motivasyon ile ilgili ${ctx.size} haber var; yalnızca bilgi olarak gösterildi.")
        }
        side(homeTeam, home, true)
        side(awayTeam, away, false)
        return NewsEffect(hf.coerceIn(1 - CAP, 1 + CAP), af.coerceIn(1 - CAP, 1 + CAP), applied, info)
    }
}

class NewsStore(private val dir: File) {
    private val file = File(dir, "news.json")
    private val maxKeep = 14 * 24 * 3600L

    private fun key(team: String) = NewsText.fold(team).trim()

    @Synchronized
    private fun readAll(): JSONObject = try { if (file.exists()) JSONObject(file.readText()) else JSONObject() } catch (e: Exception) { JSONObject() }

    @Synchronized
    fun read(team: String): Pair<Long, List<NewsItem>>? {
        val o = readAll().optJSONObject(key(team)) ?: return null
        val arr = o.optJSONArray("items") ?: JSONArray()
        val items = (0 until arr.length()).map {
            val n = arr.getJSONObject(it)
            val topics = n.getJSONArray("topics").let { ta -> (0 until ta.length()).mapNotNull { i -> runCatching { NewsTopic.valueOf(ta.getString(i)) }.getOrNull() }.toSet() }
            NewsItem(
                team, n.getString("title"), n.getString("source"), n.getString("link"), n.getLong("pub"), n.getLong("fetched"),
                topics, n.getBoolean("out"), n.getBoolean("rumor"), n.getBoolean("official")
            )
        }
        return o.getLong("fetchedAt") to items
    }

    @Synchronized
    fun write(team: String, fetchedAt: Long, items: List<NewsItem>) {
        val root = readAll()
        val arr = JSONArray()
        for (n in items.filter { fetchedAt - it.publishedAt <= maxKeep }) {
            val ta = JSONArray()
            n.topics.forEach { ta.put(it.name) }
            arr.put(
                JSONObject().put("title", n.title).put("source", n.source).put("link", n.link).put("pub", n.publishedAt)
                    .put("fetched", n.fetchedAt).put("topics", ta).put("out", n.out).put("rumor", n.rumor).put("official", n.official)
            )
        }
        root.put(key(team), JSONObject().put("fetchedAt", fetchedAt).put("items", arr))
        atomicWrite(file, root.toString())
    }

    @Synchronized
    fun clear() { file.delete() }
}

/** Google Haberler RSS (anahtarsız). Yalnızca maç ekranı açılınca çağrılır; sonuç 3 saat önbelleklenir. */
class GoogleNewsClient {
    private val name = "Google Haberler"
    private val lock = Any()
    private var next = 0L

    suspend fun fetch(team: String, turkish: Boolean, now: Long): ApiResult<List<NewsItem>> = guardedNamed(name) {
        val waitMs = synchronized(lock) {
            val t = System.currentTimeMillis()
            val at = maxOf(t, next)
            next = at + 1500
            at - t
        }
        if (waitMs > 0) kotlinx.coroutines.delay(waitMs)
        val r = Http.get(RssParser.queryUrl(team, turkish))
        if (r.code !in 200..299) return@guardedNamed ApiResult.Err("$name: haber araması başarısız (${r.code}).")
        ApiResult.Ok(RssParser.toNewsItems(team, RssParser.parse(r.body), now))
    }
}
