@file:OptIn(ExperimentalMaterial3Api::class)

package com.savran.bahis

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Card
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.launch
import java.util.Locale

/** Geri test ekranı: geçen sezon gerçek sonuçlarla modelin her pazarda basit tabandan iyi olup olmadığı. */
@Composable
fun BacktestScreen(repo: Repository, pop: () -> Unit) {
    val scope = rememberCoroutineScope()
    var busy by remember { mutableStateOf<Int?>(null) }
    var results by remember { mutableStateOf<Map<Int, String>>(emptyMap()) }
    var reports by remember { mutableStateOf<Map<Int, BacktestReport>>(emptyMap()) }
    val leagues = Leagues.supported.filter { OpenFootballSource.codes.containsKey(it.id) }
    Scaffold(topBar = { AppBar("Geri Test", pop) }) { pad ->
        Column(
            Modifier.padding(pad).fillMaxSize().verticalScroll(rememberScrollState()).padding(12.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Text(
                "Model, geçen sezonun gerçek sonuçlarıyla sınanır: her maç yalnızca ondan ÖNCEKİ maçlarla tahmin edilir. " +
                    "\"Taban\" = ligin o ana kadarki gerçek sıklığı. Brier düşükse daha iyi. Model tabanı yenemiyorsa o pazara fazla güvenme. " +
                    "Kaynak: openfootball (GitHub, ücretsiz). Avrupa kupaları bu kaynakta yok; Süper Lig geçen sezon verisi eksik olabilir.",
                fontSize = 11.sp, color = MutedText
            )
            leagues.forEach { lg ->
                Card(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Row {
                            Text(lg.nameTr, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                            if (busy == lg.id) CircularProgressIndicator(Modifier.padding(2.dp))
                            else OutlinedButton(enabled = busy == null, onClick = {
                                busy = lg.id
                                scope.launch {
                                    try {
                                        when (val r = repo.backtest(lg.id)) {
                                            is ApiResult.Ok -> { reports = reports + (lg.id to r.value); results = results - lg.id }
                                            is ApiResult.Err -> results = results + (lg.id to r.message)
                                        }
                                    } catch (e: CancellationException) {
                                        throw e
                                    } catch (e: Exception) {
                                        results = results + (lg.id to "Hata: ${e.message ?: e.javaClass.simpleName}")
                                    }
                                    busy = null
                                }
                            }) { Text("Test et") }
                        }
                        results[lg.id]?.let { Text(it, fontSize = 12.sp, color = RedBad) }
                        reports[lg.id]?.let { rep ->
                            Text("Sezon ${rep.seasonCode}: ${rep.matches} maç, ${rep.tested} maç test edildi", fontSize = 12.sp, color = MutedText)
                            rep.lines.forEach { l ->
                                val v = Backtest.verdict(l)
                                val c = when (v) { "model tabandan iyi" -> GreenOk; "model tabandan KÖTÜ" -> RedBad; else -> AmberWarn }
                                Text(
                                    "${l.label}: Brier ${"%.3f".format(Locale.US, l.brierModel)} (taban ${"%.3f".format(Locale.US, l.brierBase)}) · isabet ${pct(l.hitRate)} · n=${l.n} · $v",
                                    fontSize = 12.sp, color = c
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}
