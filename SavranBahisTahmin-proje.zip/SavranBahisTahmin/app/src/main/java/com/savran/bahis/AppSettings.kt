package com.savran.bahis

import android.content.Context
import android.content.SharedPreferences
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey
import org.json.JSONArray
import org.json.JSONObject

/** Kullanıcının eklediği özel API kaynağı (şimdilik bağlantı testi + yedek; analize veri vermesi için o servise özel okuyucu gerekir). */
data class CustomSource(val name: String, val url: String, val key: String, val header: String)

/**
 * API anahtarı ve kota sayacı. Anahtar yalnızca bu telefonda, şifreli saklanır;
 * kaynak koduna veya GitHub'a hiçbir zaman yazılmaz.
 */
class AppSettings(context: Context) {

    private val prefs: SharedPreferences = try {
        val masterKey = MasterKey.Builder(context)
            .setKeyScheme(MasterKey.KeyScheme.AES256_GCM)
            .build()
        EncryptedSharedPreferences.create(
            context,
            "savran_secure_prefs",
            masterKey,
            EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
            EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
        )
    } catch (e: Exception) {
        // Keystore sorunu olan cihazlar için uygulama-özel (yine de başkası okuyamaz) yedek
        context.getSharedPreferences("savran_prefs_fallback", Context.MODE_PRIVATE)
    }

    var apiKey: String?
        get() = if (isEnabled(SourceId.API_FOOTBALL)) prefs.getString("api_key", null)?.takeIf { it.isNotBlank() } else null
        set(value) {
            val e = prefs.edit()
            if (value.isNullOrBlank()) e.remove("api_key") else e.putString("api_key", value.trim())
            e.apply()
        }

    /** Gelecekte başka oran/veri sağlayıcıları için ikinci anahtar (The Odds API). */
    var oddsApiKey: String?
        get() = if (isEnabled(SourceId.ODDS_API)) prefs.getString("odds_api_key", null)?.takeIf { it.isNotBlank() } else null
        set(value) {
            val e = prefs.edit()
            if (value.isNullOrBlank()) e.remove("odds_api_key") else e.putString("odds_api_key", value.trim())
            e.apply()
        }

    val oddsApiRemaining: String?
        get() = prefs.getString("odds_api_remaining", null)

    fun setOddsApiRemaining(v: String) { prefs.edit().putString("odds_api_remaining", v).apply() }

    /** Otomatik (analiz sırasında) The Odds API çağrısı sayacı: ücretsiz kredi (ayda ~500) hızlı bitmesin diye günlük sınır. */
    fun oddsAutoCallsToday(nowMs: Long): Int {
        val d = Quota.utcDay(nowMs)
        return if (prefs.getString("odds_auto_day", null) == d) prefs.getInt("odds_auto_n", 0) else 0
    }

    fun recordOddsAutoCall(nowMs: Long) {
        val d = Quota.utcDay(nowMs)
        val n = if (prefs.getString("odds_auto_day", null) == d) prefs.getInt("odds_auto_n", 0) else 0
        prefs.edit().putString("odds_auto_day", d).putInt("odds_auto_n", n + 1).apply()
    }

    /** Basit görünüm: maç ekranında yalnızca özet + tahminler (detaylar "Uzman" görünümde). */
    var simpleMode: Boolean
        get() = prefs.getBoolean("simple_mode", true)
        set(v) { prefs.edit().putBoolean("simple_mode", v).apply() }

    /** Kupon Laboratuvarı'nda seçili ligler (boş = tüm ligler). */
    fun couponLeagues(): Set<Int> = prefs.getString("coupon_leagues", null)?.split(',')?.mapNotNull { it.trim().toIntOrNull() }?.toSet() ?: emptySet()

    fun setCouponLeagues(ids: Set<Int>) { prefs.edit().putString("coupon_leagues", ids.joinToString(",")).apply() }

    /** Başlangıç rehberi gizlendi mi? */
    var guideHidden: Boolean
        get() = prefs.getBoolean("guide_hidden", false)
        set(v) { prefs.edit().putBoolean("guide_hidden", v).apply() }

    /** Favori takımlar (küçük harf ad). Maç listesinde üstte ve ★ ile gösterilir. */
    fun favoriteTeams(): Set<String> = prefs.getString("fav_teams", null)?.split("\n")?.filter { it.isNotBlank() }?.toSet() ?: emptySet()

    fun isFavorite(team: String): Boolean = team.trim().lowercase() in favoriteTeams()

    fun toggleFavorite(team: String) {
        val k = team.trim().lowercase()
        val s = favoriteTeams().toMutableSet()
        if (!s.add(k)) s.remove(k)
        prefs.edit().putString("fav_teams", s.joinToString("\n")).apply()
    }

    /** Takip edilen (hatırlatma kurulmuş) maçlar: "matchId|kickoffSec|ev - dep" satırları. */
    fun reminders(): List<String> = prefs.getString("reminders", null)?.split("\n")?.filter { it.isNotBlank() } ?: emptyList()

    fun setReminders(list: List<String>) { prefs.edit().putString("reminders", list.joinToString("\n")).apply() }

    var season: Int
        get() = prefs.getInt("season", defaultSeason())
        set(value) { prefs.edit().putInt("season", value).apply() }

    private fun defaultSeason(): Int {
        val d = java.time.LocalDate.now(java.time.ZoneId.of("Europe/Istanbul"))
        return if (d.monthValue >= 7) d.year else d.year - 1
    }

    /** Elle girilen beklenen gol (λ). Veri yoksa modeli yine çalıştırmak için. */
    fun manualLambdas(matchId: String): Pair<Double, Double>? {
        val s = prefs.getString("lambda_$matchId", null) ?: return null
        val p = s.split(",")
        if (p.size != 2) return null
        val h = p[0].toDoubleOrNull() ?: return null
        val a = p[1].toDoubleOrNull() ?: return null
        return Pair(h, a)
    }

    fun setManualLambdas(matchId: String, h: Double?, a: Double?) {
        val e = prefs.edit()
        if (h == null || a == null) e.remove("lambda_$matchId") else e.putString("lambda_$matchId", "$h,$a")
        e.apply()
    }

    var lastBookmaker: String?
        get() = prefs.getString("last_bookmaker", null)
        set(value) { prefs.edit().putString("last_bookmaker", value).apply() }

    private fun rollDay(nowMs: Long) {
        val today = Quota.utcDay(nowMs)
        if (prefs.getString("quota_day", null) != today) {
            prefs.edit().putString("quota_day", today).putInt("used", 0).remove("remaining").apply()
        }
    }

    fun usedToday(nowMs: Long): Int {
        rollDay(nowMs)
        return prefs.getInt("used", 0)
    }

    fun remainingKnown(nowMs: Long): Int? {
        rollDay(nowMs)
        val r = prefs.getInt("remaining", -1)
        return if (r < 0) null else r
    }

    fun recordRequest(nowMs: Long, remainingFromHeader: Int?) {
        rollDay(nowMs)
        val e = prefs.edit().putInt("used", prefs.getInt("used", 0) + 1)
        if (remainingFromHeader != null) e.putInt("remaining", remainingFromHeader)
        e.apply()
    }

    fun setRemaining(nowMs: Long, remaining: Int) {
        rollDay(nowMs)
        prefs.edit().putInt("remaining", maxOf(0, remaining)).apply()
    }

    /** Google Haberler RSS ile takım haberi araştırması (anahtarsız). Maç ekranı açılınca çalışır. */
    var newsEnabled: Boolean
        get() = prefs.getBoolean("news_enabled", true)
        set(value) { prefs.edit().putBoolean("news_enabled", value).apply() }

    // ------------------------------------------------------------ Kaynak yönetimi (7 kaynak)

    /** Kaynağın aktif/pasif anahtarı. Pasif kaynak hiçbir istek yapmaz. */
    fun isEnabled(id: SourceId): Boolean = prefs.getBoolean("enabled_" + id.name, id.enabledByDefault)

    fun setEnabled(id: SourceId, value: Boolean) {
        prefs.edit().putBoolean("enabled_" + id.name, value).apply()
    }

    /** Kaydedilmiş anahtar (yoksa varsayılan, örn. TheSportsDB için 123). Aktif/pasife bakmaz. */
    fun rawKeyOf(id: SourceId): String? =
        prefs.getString(id.prefKey, null)?.takeIf { it.isNotBlank() } ?: id.keyDefault

    fun hasCustomKey(id: SourceId): Boolean = prefs.getString(id.prefKey, null)?.isNotBlank() == true

    fun setRawKey(id: SourceId, value: String?) {
        val e = prefs.edit()
        if (value.isNullOrBlank()) e.remove(id.prefKey) else e.putString(id.prefKey, value.trim())
        e.apply()
    }

    /** İstemcilerin kullandığı anahtar: kaynak pasifse null döner. */
    fun keyOf(id: SourceId): String? = if (isEnabled(id)) rawKeyOf(id) else null

    /** Aktif ve (gerekiyorsa) anahtarı olan kaynak. */
    fun isActive(id: SourceId): Boolean = isEnabled(id) && (!id.needsKey || rawKeyOf(id) != null)

    fun lastTest(id: SourceId): TestState? {
        val at = prefs.getLong("test_at_" + id.name, 0L)
        if (at == 0L) return null
        return TestState(prefs.getBoolean("test_ok_" + id.name, false), prefs.getString("test_msg_" + id.name, "") ?: "", at)
    }

    fun setLastTest(id: SourceId, state: TestState) {
        prefs.edit()
            .putBoolean("test_ok_" + id.name, state.ok)
            .putString("test_msg_" + id.name, state.message.take(600))
            .putLong("test_at_" + id.name, state.at)
            .apply()
    }

    /** API-Football'un kendi sayacı dışındaki kaynaklar için günlük çağrı sayacı. */
    fun recordSourceCall(id: SourceId, nowMs: Long) {
        val day = Quota.utcDay(nowMs)
        val k = "calls_" + id.name
        val dk = "calls_day_" + id.name
        val used = if (prefs.getString(dk, null) == day) prefs.getInt(k, 0) else 0
        prefs.edit().putString(dk, day).putInt(k, used + 1).apply()
    }

    fun callsToday(id: SourceId, nowMs: Long): Int {
        val day = Quota.utcDay(nowMs)
        return if (prefs.getString("calls_day_" + id.name, null) == day) prefs.getInt("calls_" + id.name, 0) else 0
    }

    // ------------------------------------------------------------ Özel kaynaklar ve anahtar yedeği

    fun customSources(): List<CustomSource> {
        val raw = prefs.getString("custom_sources", null) ?: return emptyList()
        return try {
            val a = JSONArray(raw)
            (0 until a.length()).mapNotNull {
                val o = a.optJSONObject(it) ?: return@mapNotNull null
                val name = o.optString("name").trim()
                val url = o.optString("url").trim()
                if (name.isEmpty() || !url.startsWith("https://")) null
                else CustomSource(name, url, o.optString("key"), o.optString("header").ifBlank { "X-Api-Key" })
            }
        } catch (e: Exception) {
            emptyList()
        }
    }

    fun setCustomSources(list: List<CustomSource>) {
        val a = JSONArray()
        list.forEach { a.put(JSONObject().put("name", it.name).put("url", it.url).put("key", it.key).put("header", it.header)) }
        prefs.edit().putString("custom_sources", a.toString()).apply()
    }

    /** Tüm anahtarlar + özel kaynaklar tek metin (JSON). Kullanıcı bunu kendi notlarına kaydeder; uygulama silinirse geri yükler. */
    fun exportBackup(): String {
        val keys = JSONObject()
        for (id in SourceId.values()) {
            if (hasCustomKey(id)) keys.put(id.name, prefs.getString(id.prefKey, "") ?: "")
        }
        val custom = JSONArray()
        customSources().forEach { custom.put(JSONObject().put("name", it.name).put("url", it.url).put("key", it.key).put("header", it.header)) }
        return JSONObject().put("savran", 1).put("keys", keys).put("custom", custom).toString()
    }

    /** Yedek metnini geri yükler. Tanınmayan/bozuk kısımlar atlanır; yüklenen kalem sayısını döndürür, hiçbir şey yüklenemezse 0. */
    fun importBackup(text: String): Int {
        val a = text.indexOf('{')
        val b = text.lastIndexOf('}')
        if (a < 0 || b <= a) return 0
        return try {
            val o = JSONObject(text.substring(a, b + 1))
            if (!o.has("savran")) return 0
            var n = 0
            o.optJSONObject("keys")?.let { k ->
                for (id in SourceId.values()) {
                    val v = k.optString(id.name).trim()
                    if (v.isNotEmpty()) { setRawKey(id, v); n++ }
                }
            }
            o.optJSONArray("custom")?.let { arr ->
                val list = (0 until arr.length()).mapNotNull {
                    val c = arr.optJSONObject(it) ?: return@mapNotNull null
                    val name = c.optString("name").trim()
                    val url = c.optString("url").trim()
                    if (name.isEmpty() || !url.startsWith("https://")) null
                    else CustomSource(name, url, c.optString("key"), c.optString("header").ifBlank { "X-Api-Key" })
                }
                if (list.isNotEmpty()) { setCustomSources(list); n += list.size }
            }
            n
        } catch (e: Exception) {
            0
        }
    }
}
