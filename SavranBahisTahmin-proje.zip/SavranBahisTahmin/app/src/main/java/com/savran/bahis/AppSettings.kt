package com.savran.bahis

import android.content.Context
import android.content.SharedPreferences
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey

/**
 * API anahtarı ve kota sayacı. Anahtar yalnızca bu telefonda, şifreli saklanır;
 * kaynak koduna veya GitHub'a hiçbir zaman yazılmaz.
 */
class AppSettings(context: Context) {

    private val prefs: SharedPreferences = try {
        val masterKey = MasterKey.Builder(context)
            .setKeyScheme(MasterKey.KeyScheme.AES256_GCM)
            .build()
        EncryptedSharedPreferences.create(
            context,
            "savran_secure_prefs",
            masterKey,
            EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
            EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
        )
    } catch (e: Exception) {
        // Keystore sorunu olan cihazlar için uygulama-özel (yine de başkası okuyamaz) yedek
        context.getSharedPreferences("savran_prefs_fallback", Context.MODE_PRIVATE)
    }

    var apiKey: String?
        get() = prefs.getString("api_key", null)?.takeIf { it.isNotBlank() }
        set(value) {
            val e = prefs.edit()
            if (value.isNullOrBlank()) e.remove("api_key") else e.putString("api_key", value.trim())
            e.apply()
        }

    /** Gelecekte başka oran/veri sağlayıcıları için ikinci anahtar (The Odds API). */
    var oddsApiKey: String?
        get() = prefs.getString("odds_api_key", null)?.takeIf { it.isNotBlank() }
        set(value) {
            val e = prefs.edit()
            if (value.isNullOrBlank()) e.remove("odds_api_key") else e.putString("odds_api_key", value.trim())
            e.apply()
        }

    val oddsApiRemaining: String?
        get() = prefs.getString("odds_api_remaining", null)

    fun setOddsApiRemaining(v: String) { prefs.edit().putString("odds_api_remaining", v).apply() }

    var season: Int
        get() = prefs.getInt("season", defaultSeason())
        set(value) { prefs.edit().putInt("season", value).apply() }

    private fun defaultSeason(): Int {
        val d = java.time.LocalDate.now(java.time.ZoneId.of("Europe/Istanbul"))
        return if (d.monthValue >= 7) d.year else d.year - 1
    }

    /** Elle girilen beklenen gol (λ). Veri yoksa modeli yine çalıştırmak için. */
    fun manualLambdas(matchId: String): Pair<Double, Double>? {
        val s = prefs.getString("lambda_$matchId", null) ?: return null
        val p = s.split(",")
        if (p.size != 2) return null
        val h = p[0].toDoubleOrNull() ?: return null
        val a = p[1].toDoubleOrNull() ?: return null
        return Pair(h, a)
    }

    fun setManualLambdas(matchId: String, h: Double?, a: Double?) {
        val e = prefs.edit()
        if (h == null || a == null) e.remove("lambda_$matchId") else e.putString("lambda_$matchId", "$h,$a")
        e.apply()
    }

    var lastBookmaker: String?
        get() = prefs.getString("last_bookmaker", null)
        set(value) { prefs.edit().putString("last_bookmaker", value).apply() }

    private fun rollDay(nowMs: Long) {
        val today = Quota.utcDay(nowMs)
        if (prefs.getString("quota_day", null) != today) {
            prefs.edit().putString("quota_day", today).putInt("used", 0).remove("remaining").apply()
        }
    }

    fun usedToday(nowMs: Long): Int {
        rollDay(nowMs)
        return prefs.getInt("used", 0)
    }

    fun remainingKnown(nowMs: Long): Int? {
        rollDay(nowMs)
        val r = prefs.getInt("remaining", -1)
        return if (r < 0) null else r
    }

    fun recordRequest(nowMs: Long, remainingFromHeader: Int?) {
        rollDay(nowMs)
        val e = prefs.edit().putInt("used", prefs.getInt("used", 0) + 1)
        if (remainingFromHeader != null) e.putInt("remaining", remainingFromHeader)
        e.apply()
    }

    fun setRemaining(nowMs: Long, remaining: Int) {
        rollDay(nowMs)
        prefs.edit().putInt("remaining", maxOf(0, remaining)).apply()
    }
}
