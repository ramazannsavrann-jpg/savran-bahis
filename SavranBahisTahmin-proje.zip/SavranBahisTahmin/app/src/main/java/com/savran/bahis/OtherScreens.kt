@file:OptIn(ExperimentalMaterial3Api::class)

package com.savran.bahis

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.launch
import java.time.Instant
import java.time.ZonedDateTime
import java.util.Locale
import java.util.UUID

private fun one(x: Double): String = "%.1f".format(Locale.US, x)

// ------------------------------------------------------------------ Oran ekle

@Composable
fun AddOddsScreen(repo: Repository, match: Match, pop: () -> Unit) {
    val scope = rememberCoroutineScope()
    var group by remember { mutableStateOf(MarketCatalog.groups.first()) }
    var marketKey by remember { mutableStateOf(MarketCatalog.all.first().key) }
    var bookmaker by remember { mutableStateOf(repo.settings.lastBookmaker ?: "") }
    var error by remember { mutableStateOf<String?>(null) }

    val markets = MarketCatalog.all.filter { it.group == group }
    val market = markets.firstOrNull { it.key == marketKey } ?: markets.first()
    val fields = remember(market.key) { mutableStateMapOf<String, String>() }

    fun save() {
        val book = bookmaker.trim()
        if (book.isEmpty()) { error = "Oranın kaynağını (şirket adı) yaz."; return }
        val now = System.currentTimeMillis()
        val entries = ArrayList<OddsEntry>()
        val bad = ArrayList<String>()
        for (s in market.selections) {
            val txt = fields[s.key]?.trim().orEmpty()
            if (txt.isEmpty()) continue
            val o = OddsMath.parseOdds(txt)
            if (o == null) bad.add(s.label)
            else entries.add(
                OddsEntry(
                    id = "${match.id}|${market.key}|${s.key}|${book.lowercase()}|manual",
                    matchId = match.id, marketKey = market.key, selectionKey = s.key,
                    odds = o, bookmaker = book, origin = "Manuel", updatedAt = now
                )
            )
        }
        if (bad.isNotEmpty()) { error = "Geçersiz oran (1.01 ile 1000 arası olmalı): " + bad.joinToString(", "); return }
        if (entries.isEmpty()) { error = "En az bir oran gir."; return }
        repo.settings.lastBookmaker = book
        scope.launch { repo.saveOdds(entries); pop() }
    }

    Scaffold(topBar = { AppBar("Oran Ekle", pop) }) { pad ->
        Column(
            Modifier.padding(pad).fillMaxSize().verticalScroll(rememberScrollState()).padding(12.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Text("${match.home} - ${match.away}", fontWeight = FontWeight.Bold)
            Text("Yalnızca bahis şirketinde gerçekten gördüğün oranı gir. Oran, girdiğin zamanla kaydedilir; eskidikçe uyarı verilir.", fontSize = 12.sp, color = MutedText)
            OutlinedTextField(
                bookmaker, { bookmaker = it }, label = { Text("Oranın kaynağı (şirket adı)") },
                singleLine = true, modifier = Modifier.fillMaxWidth()
            )
            ChipRow(MarketCatalog.groups, group, { it }) { g ->
                group = g
                marketKey = MarketCatalog.all.first { it.group == g }.key
                error = null
            }
            ChipRow(markets, market, { it.title }) { mk -> marketKey = mk.key; error = null }
            Text(market.title, fontWeight = FontWeight.Bold, color = GreenOk)
            market.selections.forEach { s ->
                OutlinedTextField(
                    value = fields[s.key] ?: "",
                    onValueChange = { fields[s.key] = it },
                    label = { Text(s.label) },
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                    modifier = Modifier.fillMaxWidth()
                )
            }
            val err = error
            if (err != null) Text(err, color = RedBad, fontSize = 13.sp)
            Button(onClick = { save() }, modifier = Modifier.fillMaxWidth()) { Text("Kaydet") }
            Text("Boş bıraktığın seçenekler kaydedilmez. Farklı pazar için tekrar \"Oran ekle\" kullan.", fontSize = 11.sp, color = MutedText)
        }
    }
}

// ------------------------------------------------------------------ Maç ekle

@Composable
fun AddMatchScreen(repo: Repository, pop: () -> Unit) {
    val scope = rememberCoroutineScope()
    var leagueIdx by remember { mutableStateOf(0) }
    var otherLeague by remember { mutableStateOf("") }
    var home by remember { mutableStateOf("") }
    var away by remember { mutableStateOf("") }
    var dayOffset by remember { mutableStateOf(0) }
    var time by remember { mutableStateOf("20:00") }
    var error by remember { mutableStateOf<String?>(null) }

    fun save() {
        val h = home.trim()
        val a = away.trim()
        if (h.isEmpty() || a.isEmpty()) { error = "İki takım adını da yaz."; return }
        val t = TimeUtil.parseTime(time)
        if (t == null) { error = "Saati SS:DD biçiminde yaz (örn. 20:45)."; return }
        val known = if (leagueIdx < Leagues.supported.size) Leagues.supported[leagueIdx] else null
        val date = repo.today().plusDays(dayOffset.toLong())
        val kickoff = ZonedDateTime.of(date, t, repo.zone).toEpochSecond()
        val m = Match(
            id = "man-" + UUID.randomUUID().toString(),
            leagueId = known?.id ?: 0,
            leagueName = known?.nameTr ?: otherLeague.trim().ifEmpty { "Diğer" },
            home = h, away = a, kickoff = kickoff, statusShort = "NS",
            homeGoals = null, awayGoals = null, homeLogo = null, awayLogo = null, source = "Manuel"
        )
        scope.launch { repo.addManualMatch(m); pop() }
    }

    Scaffold(topBar = { AppBar("Maç Ekle", pop) }) { pad ->
        Column(
            Modifier.padding(pad).fillMaxSize().verticalScroll(rememberScrollState()).padding(12.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Text("Lig", fontWeight = FontWeight.Bold)
            ChipRow((0..Leagues.supported.size).toList(), leagueIdx, { i ->
                if (i < Leagues.supported.size) Leagues.supported[i].nameTr else "Diğer"
            }) { leagueIdx = it }
            if (leagueIdx >= Leagues.supported.size) {
                OutlinedTextField(otherLeague, { otherLeague = it }, label = { Text("Lig adı") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                Text("Desteklenen liglerin dışındaki maçlarda model için beklenen golü elle girmen gerekir.", fontSize = 11.sp, color = MutedText)
            }
            OutlinedTextField(home, { home = it }, label = { Text("Ev sahibi") }, singleLine = true, modifier = Modifier.fillMaxWidth())
            OutlinedTextField(away, { away = it }, label = { Text("Deplasman") }, singleLine = true, modifier = Modifier.fillMaxWidth())
            Text("Gün", fontWeight = FontWeight.Bold)
            ChipRow((0..6).toList(), dayOffset, { o ->
                when (o) {
                    0 -> "Bugün"
                    1 -> "Yarın"
                    else -> repo.today().plusDays(o.toLong()).format(dayFmt)
                }
            }) { dayOffset = it }
            OutlinedTextField(
                time, { time = it }, label = { Text("Saat (SS:DD)") }, singleLine = true,
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), modifier = Modifier.fillMaxWidth()
            )
            val err = error
            if (err != null) Text(err, color = RedBad, fontSize = 13.sp)
            Button(onClick = { save() }, modifier = Modifier.fillMaxWidth()) { Text("Kaydet") }
        }
    }
}

// ------------------------------------------------------------------ Fırsatlar

@Composable
fun OpportunitiesScreen(repo: Repository, pop: () -> Unit) {
    var days by remember { mutableStateOf(1) }
    var tick by remember { mutableStateOf(0) }
    var loading by remember { mutableStateOf(true) }
    var scan by remember { mutableStateOf<List<AnalysisResult>>(emptyList()) }
    var error by remember { mutableStateOf<String?>(null) }

    LaunchedEffect(days, tick) {
        loading = true
        error = null
        try {
            scan = repo.scanUpcoming(days)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            error = "Tarama hatası: ${e.message ?: e.javaClass.simpleName}"
        }
        loading = false
    }

    Scaffold(topBar = { AppBar("Bahis Fırsatları", pop) { TextButton(onClick = { tick++ }) { Text("Yenile") } } }) { pad ->
        Column(Modifier.padding(pad).fillMaxSize().padding(horizontal = 12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            ChipRow(listOf(1, 2, 3), days, { if (it == 1) "Bugün" else "$it gün" }) { days = it }
            Text("Yalnızca oranı girilmiş, henüz başlamamış maçlar taranır. Eksik puan durumu için API isteği harcanabilir (24 saat önbellek).", fontSize = 11.sp, color = MutedText)
            if (loading) Box(Modifier.fillMaxWidth().padding(16.dp), contentAlignment = Alignment.Center) { CircularProgressIndicator() }
            val err = error
            if (err != null) InfoCard("Hata", err, warn = true)
            val all = scan.flatMap { r -> r.evaluations.map { r to it } }
            val recs = all.filter { it.second.decision == Decision.RECOMMEND }.sortedByDescending { it.second.quality ?: 0 }
            if (!loading && err == null) {
                if (scan.isEmpty()) {
                    InfoCard("Taranacak maç yok", "Önce bir maça gerçek oran gir (Maç → Oran ekle). Oranı olmayan maçlar değerlendirilmez.")
                } else if (recs.isEmpty()) {
                    InfoCard(
                        "Bugün öneri yok",
                        "${scan.size} maç ve ${all.size} seçenek tarandı; hiçbiri yeterli avantaj, kalite ve veri güvenilirliğini birlikte sağlamadı. Mutlaka bahis çıkarmak zorunda değiliz."
                    )
                } else {
                    Text("${scan.size} maç, ${all.size} seçenek tarandı · ${recs.size} öneri", fontSize = 12.sp, color = MutedText)
                }
            }
            LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp), contentPadding = PaddingValues(bottom = 16.dp)) {
                items(recs.size) { i ->
                    val (r, e) = recs[i]
                    EvalCard(e, repo, r.match.kickoff, title = "${r.match.home} - ${r.match.away} · ${r.match.leagueName}")
                }
            }
        }
    }
}

// ------------------------------------------------------------------ Kupon laboratuvarı

@Composable
fun CouponsScreen(repo: Repository, pop: () -> Unit) {
    var tick by remember { mutableStateOf(0) }
    var loading by remember { mutableStateOf(true) }
    var coupons by remember { mutableStateOf<Map<CouponType, Coupon?>>(emptyMap()) }
    var error by remember { mutableStateOf<String?>(null) }

    LaunchedEffect(tick) {
        loading = true
        error = null
        try {
            coupons = repo.buildCoupons(repo.scanUpcoming(3))
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            error = "Kupon hatası: ${e.message ?: e.javaClass.simpleName}"
        }
        loading = false
    }

    Scaffold(topBar = { AppBar("Kupon Laboratuvarı", pop) { TextButton(onClick = { tick++ }) { Text("Yenile") } } }) { pad ->
        Column(
            Modifier.padding(pad).fillMaxSize().verticalScroll(rememberScrollState()).padding(12.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Text(
                "Önümüzdeki 3 günün, oranı girilmiş maçlarından kurulur. Her maçtan en fazla bir seçim alınır; ${CouponLab.MIN_PICKS}-${CouponLab.MAX_PICKS} maç. Yeterli kaliteli seçim yoksa kupon oluşturulmaz.",
                fontSize = 12.sp, color = MutedText
            )
            if (loading) Box(Modifier.fillMaxWidth().padding(16.dp), contentAlignment = Alignment.Center) { CircularProgressIndicator() }
            val err = error
            if (err != null) InfoCard("Hata", err, warn = true)
            if (!loading) {
                CouponType.values().forEach { type ->
                    val c = coupons[type]
                    SectionTitle(type.tr)
                    Text(type.desc, fontSize = 12.sp, color = MutedText)
                    if (c == null) {
                        InfoCard("Kupon oluşturulmadı", "Bu tür için yeterli kaliteli seçim yok. Kupon doldurmak için kötü seçim eklenmez.")
                    } else {
                        Card(Modifier.fillMaxWidth()) {
                            Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                c.picks.forEach { p ->
                                    Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                                        Text("${p.match.home} - ${p.match.away}", fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                        Text("${p.match.leagueName} · ${kickoffText(p.match, repo)}", fontSize = 11.sp, color = MutedText)
                                        Row {
                                            Text(
                                                MarketCatalog.marketTitle(p.eval.marketKey) + " · " + MarketCatalog.selectionLabel(p.eval.marketKey, p.eval.selectionKey),
                                                modifier = Modifier.weight(1f), fontSize = 13.sp
                                            )
                                            Text(odd2(p.eval.odds), fontWeight = FontWeight.Bold)
                                        }
                                        Text(
                                            "Tahmin ${p.eval.adjProb?.let { pct(it) } ?: "-"} · Kalite ${p.eval.quality ?: "-"}/100 · ${p.eval.origin}/${p.eval.bookmaker}",
                                            fontSize = 11.sp, color = MutedText
                                        )
                                        Text(p.eval.reason, fontSize = 11.sp, color = MutedText)
                                    }
                                }
                                Text("Toplam oran: ${odd2(c.totalOdds)} · Tahmini gerçekleşme: ${pct(c.probability)} · Risk: ${c.risk}", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                                Text("Farklı maçlar yaklaşık bağımsız kabul edilir. Yüksek toplam oran kalite anlamına gelmez; garanti yoktur.", fontSize = 11.sp, color = MutedText)
                            }
                        }
                    }
                }
            }
        }
    }
}

// ------------------------------------------------------------------ Tahmin geçmişi

@Composable
fun HistoryScreen(repo: Repository, pop: () -> Unit) {
    val scope = rememberCoroutineScope()
    var tick by remember { mutableStateOf(0) }
    var filter by remember { mutableStateOf(0) }   // 0 hepsi, 1 bekleyen, 2 sonuçlanan
    var list by remember { mutableStateOf<List<PredictionRecord>>(emptyList()) }
    var info by remember { mutableStateOf<String?>(null) }
    var busy by remember { mutableStateOf(false) }

    LaunchedEffect(tick) { list = repo.predictionList() }

    val shown = when (filter) {
        1 -> list.filter { it.result == null }
        2 -> list.filter { it.result != null }
        else -> list
    }

    Scaffold(topBar = {
        AppBar("Tahmin Geçmişi", pop) {
            TextButton(enabled = !busy, onClick = {
                scope.launch {
                    busy = true
                    info = try { repo.settlePending() } catch (e: CancellationException) { throw e } catch (e: Exception) { "Hata: ${e.message}" }
                    busy = false
                    tick++
                }
            }) { Text("Sonuçları güncelle") }
        }
    }) { pad ->
        Column(Modifier.padding(pad).fillMaxSize().padding(horizontal = 12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            ChipRow(listOf(0, 1, 2), filter, { when (it) { 0 -> "Hepsi (${list.size})"; 1 -> "Bekleyen"; else -> "Sonuçlanan" } }) { filter = it }
            if (busy) Box(Modifier.fillMaxWidth().padding(8.dp), contentAlignment = Alignment.Center) { CircularProgressIndicator() }
            val i = info
            if (i != null) InfoCard("Bilgi", i)
            if (list.isEmpty()) {
                InfoCard("Henüz kayıt yok", "Bir maçın detayını açtığında model, başlamamış maçlar için tahminleri otomatik kaydeder. Gelecekteki maç bilgisi geçmiş tahminlerde kullanılmaz.")
            }
            LazyColumn(verticalArrangement = Arrangement.spacedBy(6.dp), contentPadding = PaddingValues(bottom = 16.dp)) {
                items(shown.take(300), key = { it.id }) { r ->
                    Card(Modifier.fillMaxWidth()) {
                        Column(Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                            Text(r.matchLabel, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            Text(
                                MarketCatalog.marketTitle(r.marketKey) + " · " + MarketCatalog.selectionLabel(r.marketKey, r.selectionKey),
                                fontSize = 13.sp
                            )
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                                Text("Tahmin ${pct(r.prob)}" + (r.odds?.let { " · Oran ${odd2(it)}" } ?: ""), fontSize = 12.sp, modifier = Modifier.weight(1f))
                                when (r.result) {
                                    true -> Tag("Doğru", GreenOk)
                                    false -> Tag("Yanlış", RedBad)
                                    null -> Tag("Bekliyor", MutedText)
                                }
                                if (r.recommended) Tag("Önerilmişti", AmberWarn)
                            }
                            Text(
                                clockText(r.kickoff * 1000, repo).let { Instant.ofEpochSecond(r.kickoff).atZone(repo.zone).format(dayFmt) + " " + it } +
                                    (r.finalScore?.let { " · Skor $it" } ?: ""),
                                fontSize = 11.sp, color = MutedText
                            )
                        }
                    }
                }
            }
        }
    }
}

// ------------------------------------------------------------------ Model performansı

@Composable
private fun StatLine(label: String, value: String) {
    Row(Modifier.fillMaxWidth()) {
        Text(label, modifier = Modifier.weight(1f), fontSize = 13.sp)
        Text(value, fontWeight = FontWeight.Bold, fontSize = 13.sp)
    }
}

@Composable
fun PerformanceScreen(repo: Repository, pop: () -> Unit) {
    var report by remember { mutableStateOf<Report?>(null) }
    LaunchedEffect(Unit) { report = repo.report() }

    Scaffold(topBar = { AppBar("Model Performansı", pop) }) { pad ->
        Column(
            Modifier.padding(pad).fillMaxSize().verticalScroll(rememberScrollState()).padding(12.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            val r = report
            if (r == null) {
                Box(Modifier.fillMaxWidth().padding(16.dp), contentAlignment = Alignment.Center) { CircularProgressIndicator() }
            } else {
                Card(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        StatLine("Toplam tahmin", "${r.total}")
                        StatLine("Sonuçlanan", "${r.settled}")
                        StatLine("Doğru / Yanlış", "${r.correct} / ${r.wrong}")
                        StatLine("Başarı oranı", r.hitRate?.let { pct(it) } ?: "-")
                        StatLine("Brier skoru (düşük iyi)", r.brier?.let { "%.3f".format(Locale.US, it) } ?: "-")
                        StatLine("Log loss (düşük iyi)", r.logLoss?.let { "%.3f".format(Locale.US, it) } ?: "-")
                        Text("Referans: hep %50 diyen modelin Brier skoru 0.250'dir.", fontSize = 11.sp, color = MutedText)
                    }
                }
                if (r.settled < Metrics.MIN_FOR_HISTORY_SCORE) {
                    InfoCard(
                        "Örnek sayısı az",
                        "${r.settled} sonuçlanmış tahminle model başarısı hakkında sağlam bir şey söylenemez. Anlamlı değerlendirme için en az ${Metrics.MIN_FOR_HISTORY_SCORE} sonuçlanmış tahmin gerekir.",
                        warn = true
                    )
                }

                SectionTitle("Kalibrasyon (olasılık grupları)")
                if (r.bins.isEmpty()) Text("Henüz sonuçlanmış tahmin yok.", fontSize = 12.sp, color = MutedText)
                r.bins.forEach { b ->
                    StatLine("${b.label} · n=${b.count}", "tahmin ${pct(b.meanPredicted)} → gerçek ${pct(b.hitRate)}")
                }
                Text("İyi kalibre model %70 dediği tahminlerin yaklaşık %70'inde haklı çıkar.", fontSize = 11.sp, color = MutedText)

                SectionTitle("Pazar grubuna göre")
                if (r.byMarketGroup.isEmpty()) Text("-", color = MutedText)
                r.byMarketGroup.entries.sortedByDescending { it.value.first }.forEach { (k, v) ->
                    StatLine("$k · n=${v.first}", "${v.second} doğru · ${pct(v.third)}")
                }
                SectionTitle("Lige göre")
                if (r.byLeague.isEmpty()) Text("-", color = MutedText)
                r.byLeague.entries.sortedByDescending { it.value.first }.forEach { (k, v) ->
                    StatLine("$k · n=${v.first}", "${v.second} doğru · ${pct(v.third)}")
                }

                SectionTitle("Gerçek oranlarla geçmiş getiri")
                Card(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        StatLine("Oranı olan sonuçlanmış tahmin", "${r.roiN}")
                        StatLine("Birim getiri (1 birim/bahis)", r.unitReturn?.let { (if (it >= 0) "+" else "") + "%.2f".format(Locale.US, it) } ?: "-")
                        StatLine("ROI", r.roi?.let { (if (it >= 0) "+" else "") + one(it * 100) + "%" } ?: "-")
                        Text("Bu bir geçmiş ölçümdür; para, bakiye veya sanal kupon takibi değildir ve gelecekteki kazancı garanti etmez.", fontSize = 11.sp, color = MutedText)
                    }
                }
            }
        }
    }
}
