@file:OptIn(ExperimentalMaterial3Api::class)

package com.savran.bahis

import androidx.compose.foundation.background
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.height
import androidx.compose.material3.ButtonDefaults
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.launch
import java.time.Instant
import java.time.ZonedDateTime
import java.util.Locale
import java.util.UUID

private fun one(x: Double): String = "%.1f".format(Locale.US, x)

// ------------------------------------------------------------------ Oran ekle

@Composable
fun AddOddsScreen(repo: Repository, match: Match, pop: () -> Unit) {
    val scope = rememberCoroutineScope()
    var group by remember { mutableStateOf(MarketCatalog.groups.first()) }
    var marketKey by remember { mutableStateOf(MarketCatalog.all.first().key) }
    var bookmaker by remember { mutableStateOf(repo.settings.lastBookmaker ?: "") }
    var error by remember { mutableStateOf<String?>(null) }

    val markets = MarketCatalog.all.filter { it.group == group }
    val market = markets.firstOrNull { it.key == marketKey } ?: markets.first()
    val fields = remember(market.key) { mutableStateMapOf<String, String>() }

    fun save() {
        val book = bookmaker.trim()
        if (book.isEmpty()) { error = "Oranın kaynağını (şirket adı) yaz."; return }
        val now = System.currentTimeMillis()
        val entries = ArrayList<OddsEntry>()
        val bad = ArrayList<String>()
        for (s in market.selections) {
            val txt = fields[s.key]?.trim().orEmpty()
            if (txt.isEmpty()) continue
            val o = OddsMath.parseOdds(txt)
            if (o == null) bad.add(s.label)
            else entries.add(
                OddsEntry(
                    id = "${match.id}|${market.key}|${s.key}|${book.lowercase()}|manual",
                    matchId = match.id, marketKey = market.key, selectionKey = s.key,
                    odds = o, bookmaker = book, origin = "Manuel", updatedAt = now
                )
            )
        }
        if (bad.isNotEmpty()) { error = "Geçersiz oran (1.01 ile 1000 arası olmalı): " + bad.joinToString(", "); return }
        if (entries.isEmpty()) { error = "En az bir oran gir."; return }
        repo.settings.lastBookmaker = book
        scope.launchSafe(onError = { error = "Kaydedilemedi: $it" }) { repo.saveOdds(entries); pop() }
    }

    Scaffold(topBar = { AppBar("Oran Ekle", pop) }) { pad ->
        Column(
            Modifier.padding(pad).fillMaxSize().verticalScroll(rememberScrollState()).padding(12.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Text("${match.home} - ${match.away}", fontWeight = FontWeight.Bold)
            Text("Yalnızca bahis şirketinde gerçekten gördüğün oranı gir. Oran, girdiğin zamanla kaydedilir; eskidikçe uyarı verilir.", fontSize = 12.sp, color = MutedText)
            OutlinedTextField(
                bookmaker, { bookmaker = it }, label = { Text("Oranın kaynağı (şirket adı)") },
                singleLine = true, modifier = Modifier.fillMaxWidth()
            )
            ChipRow(MarketCatalog.groups, group, { it }) { g ->
                group = g
                marketKey = MarketCatalog.all.first { it.group == g }.key
                error = null
            }
            ChipRow(markets, market, { it.title }) { mk -> marketKey = mk.key; error = null }
            Text(market.title, fontWeight = FontWeight.Bold, color = GreenOk)
            market.selections.forEach { s ->
                OutlinedTextField(
                    value = fields[s.key] ?: "",
                    onValueChange = { fields[s.key] = it },
                    label = { Text(s.label) },
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                    modifier = Modifier.fillMaxWidth()
                )
            }
            val err = error
            if (err != null) Text(err, color = RedBad, fontSize = 13.sp)
            Button(onClick = { save() }, modifier = Modifier.fillMaxWidth()) { Text("Kaydet") }
            Text("Boş bıraktığın seçenekler kaydedilmez. Farklı pazar için tekrar \"Oran ekle\" kullan.", fontSize = 11.sp, color = MutedText)
        }
    }
}

// ------------------------------------------------------------------ Maç ekle

@Composable
fun AddMatchScreen(repo: Repository, pop: () -> Unit) {
    val scope = rememberCoroutineScope()
    var leagueIdx by remember { mutableStateOf(0) }
    var otherLeague by remember { mutableStateOf("") }
    var home by remember { mutableStateOf("") }
    var away by remember { mutableStateOf("") }
    var dayOffset by remember { mutableStateOf(0) }
    var time by remember { mutableStateOf("20:00") }
    var error by remember { mutableStateOf<String?>(null) }

    fun save() {
        val h = home.trim()
        val a = away.trim()
        if (h.isEmpty() || a.isEmpty()) { error = "İki takım adını da yaz."; return }
        val t = TimeUtil.parseTime(time)
        if (t == null) { error = "Saati SS:DD biçiminde yaz (örn. 20:45)."; return }
        val known = if (leagueIdx < Leagues.supported.size) Leagues.supported[leagueIdx] else null
        val date = repo.today().plusDays(dayOffset.toLong())
        val kickoff = ZonedDateTime.of(date, t, repo.zone).toEpochSecond()
        val m = Match(
            id = "man-" + UUID.randomUUID().toString(),
            leagueId = known?.id ?: 0,
            leagueName = known?.nameTr ?: otherLeague.trim().ifEmpty { "Diğer" },
            home = h, away = a, kickoff = kickoff, statusShort = "NS",
            homeGoals = null, awayGoals = null, homeLogo = null, awayLogo = null, source = "Manuel"
        )
        scope.launchSafe(onError = { error = "Kaydedilemedi: $it" }) { repo.addManualMatch(m); pop() }
    }

    Scaffold(topBar = { AppBar("Maç Ekle", pop) }) { pad ->
        Column(
            Modifier.padding(pad).fillMaxSize().verticalScroll(rememberScrollState()).padding(12.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Text("Lig", fontWeight = FontWeight.Bold)
            ChipRow((0..Leagues.supported.size).toList(), leagueIdx, { i ->
                if (i < Leagues.supported.size) Leagues.supported[i].nameTr else "Diğer"
            }) { leagueIdx = it }
            if (leagueIdx >= Leagues.supported.size) {
                OutlinedTextField(otherLeague, { otherLeague = it }, label = { Text("Lig adı") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                Text("Desteklenen liglerin dışındaki maçlarda model için beklenen golü elle girmen gerekir.", fontSize = 11.sp, color = MutedText)
            }
            OutlinedTextField(home, { home = it }, label = { Text("Ev sahibi") }, singleLine = true, modifier = Modifier.fillMaxWidth())
            OutlinedTextField(away, { away = it }, label = { Text("Deplasman") }, singleLine = true, modifier = Modifier.fillMaxWidth())
            Text("Gün", fontWeight = FontWeight.Bold)
            ChipRow((0..6).toList(), dayOffset, { o ->
                when (o) {
                    0 -> "Bugün"
                    1 -> "Yarın"
                    else -> repo.today().plusDays(o.toLong()).format(dayFmt)
                }
            }) { dayOffset = it }
            OutlinedTextField(
                time, { time = it }, label = { Text("Saat (SS:DD)") }, singleLine = true,
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), modifier = Modifier.fillMaxWidth()
            )
            val err = error
            if (err != null) Text(err, color = RedBad, fontSize = 13.sp)
            Button(onClick = { save() }, modifier = Modifier.fillMaxWidth()) { Text("Kaydet") }
        }
    }
}

// ------------------------------------------------------------------ Bahis fırsatları: güçlü tahminler + pazar filtresi

@Composable
fun OpportunitiesScreen(repo: Repository, push: (Screen) -> Unit, pop: () -> Unit) {
    var days by remember { mutableStateOf(1) }
    var groupId by remember { mutableStateOf<String?>(null) }
    var optionKey by remember { mutableStateOf<String?>(null) }
    var tick by remember { mutableStateOf(0) }
    var loading by remember { mutableStateOf(true) }
    var scan by remember { mutableStateOf<List<AnalysisResult>>(emptyList()) }
    var error by remember { mutableStateOf<String?>(null) }

    LaunchedEffect(days, tick) {
        loading = true
        error = null
        try {
            scan = repo.scanUpcoming(days)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            error = "Tarama hatası: ${e.message ?: e.javaClass.simpleName}"
        }
        loading = false
    }

    val all = scan.flatMap { it.forecasts }
    val groups = MarketFilters.availableGroups(all)
    val group = groups.firstOrNull { it.id == groupId }
    val options = if (group != null) MarketFilters.options(group, all) else emptyList()
    val option = options.firstOrNull { it.first + "|" + it.second == optionKey }

    val rows: List<Pair<AnalysisResult, Forecast>> =
        if (group == null) {
            scan.flatMap { r -> MarketFilters.shown(r.forecasts).sortedByDescending { ForecastEngine.weighted(it) }.take(3).map { r to it } }
                .sortedByDescending { ForecastEngine.weighted(it.second) }.take(60)
        } else {
            scan.flatMap { r -> MarketFilters.apply(r.forecasts, group, option).map { r to it } }
                .sortedByDescending { ForecastEngine.weighted(it.second) }.take(80)
        }

    Scaffold(topBar = { AppBar("Bahis Fırsatları", pop) { TextButton(onClick = { tick++ }) { Text("Yenile") } } }) { pad ->
        Column(Modifier.padding(pad).fillMaxSize().padding(horizontal = 12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Spacer(Modifier.height(4.dp))
            ChipRow(listOf(1, 2, 3), days, { if (it == 1) "Bugün" else "$it gün" }) { days = it }
            ChipRow(listOf<String?>(null) + groups.map { it.id }, groupId, { id -> if (id == null) "Tümü" else MarketFilters.group(id)?.label ?: id }) {
                groupId = it
                optionKey = null
            }
            if (group != null && options.size > 1) {
                ChipRow(
                    listOf<String?>(null) + options.map { it.first + "|" + it.second }, optionKey,
                    { k -> if (k == null) "Hepsi" else MarketFilters.shortLabel(k.substringBefore("|"), k.substringAfter("|")) }
                ) { optionKey = it }
            }
            var showInfo by remember { mutableStateOf(false) }
            TextButton(onClick = { showInfo = !showInfo }, contentPadding = PaddingValues(0.dp)) {
                Text(if (showInfo) "Açıklamayı gizle" else "ⓘ Açıklama", fontSize = 11.sp, color = MutedText)
            }
            if (showInfo) {
                Text(
                    "Başlamamış tüm maçlar taranır; oran gerekmez. Her pazarda yalnızca modelin hesapladığı EN YÜKSEK olasılıklı seçenek gösterilir, düşük olasılıklı alternatifler listelenmez. Yeterli güveni olmayan tahminler gösterilmez (hiç güvenli seçim yoksa, düşük güven etiketiyle gösterilir). %90 ve üzeri bariz seçimler listelenmez. Bir tahmine dokunarak maçı kendin değerlendirebilirsin.",
                    fontSize = 11.sp, color = MutedText
                )
            }
            if (loading) Box(Modifier.fillMaxWidth().padding(16.dp), contentAlignment = Alignment.Center) { CircularProgressIndicator() }
            val err = error
            if (err != null) InfoCard("Hata", err, warn = true)

            if (!loading && err == null) {
                val withForecast = scan.count { it.forecasts.isNotEmpty() }
                if (scan.isEmpty()) {
                    InfoCard("Taranacak maç yok", "Başlamamış maç bulunamadı. Ayarlar'dan veri kaynağını kontrol et veya maçı elle ekle.")
                } else if (withForecast == 0) {
                    InfoCard(
                        "Tahmin üretilemedi",
                        "${scan.size} maç tarandı ama hiçbirinde yeterli takım verisi yok. Örnek neden: ${scan.firstOrNull()?.forecastNote ?: "-"}",
                        warn = true
                    )
                } else {
                    val label = when {
                        group == null -> "Pazar başına en iyi seçenekler (her maçtan en güçlü 3)"
                        option != null -> group.label + " · " + MarketFilters.shortLabel(option.first, option.second)
                        else -> group.label
                    }
                    Text(
                        "$label: ${rows.size} tahmin · $withForecast/${scan.size} maçta tahmin" +
                            (if (scan.size > withForecast) " (${scan.size - withForecast} maçta veri yetersiz)" else ""),
                        fontSize = 11.sp, color = MutedText
                    )
                    if (rows.isEmpty()) {
                        InfoCard("Bu seçim için tahmin yok", "Taranan maçlarda bu pazar için tahmin üretilmedi.")
                    }
                    LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp), contentPadding = PaddingValues(bottom = 16.dp)) {
                        items(rows.size) { i ->
                            val (r, f) = rows[i]
                            ForecastRow(
                                f,
                                title = "${r.match.home} - ${r.match.away} · ${r.match.leagueName} · ${kickoffText(r.match, repo)}",
                                onClick = { push(Screen.Detail(r.match)) },
                                market = r.marketProb(f)
                            )
                        }
                    }
                }
            }
        }
    }
}

// ------------------------------------------------------------------ Kupon laboratuvarı

private fun couponColor(t: CouponType): Color = when (t) {
    CouponType.BALANCED -> GreenOk
    CouponType.SURPRISE -> AccentBlue
    CouponType.HIGH_RISK -> Color(0xFFFB923C)
}

@Composable
fun CouponsScreen(repo: Repository, pop: () -> Unit) {
    var tab by remember { mutableStateOf(CouponType.BALANCED) }
    var tick by remember { mutableStateOf(0) }
    var loading by remember { mutableStateOf(true) }
    var coupons by remember { mutableStateOf<Map<CouponType, CouponOutcome>>(emptyMap()) }
    var strongList by remember { mutableStateOf<List<Pair<AnalysisResult, Forecast>>>(emptyList()) }
    var error by remember { mutableStateOf<String?>(null) }

    LaunchedEffect(tick) {
        loading = true
        error = null
        try {
            val scan = repo.scanUpcoming(3)
            coupons = repo.buildCoupons(scan)
            strongList = scan.flatMap { r -> MarketFilters.shown(r.forecasts).sortedByDescending { ForecastEngine.weighted(it) }.take(2).map { r to it } }
                .sortedByDescending { ForecastEngine.weighted(it.second) }
                .take(12)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            error = "Kupon hatası: ${e.message ?: e.javaClass.simpleName}"
        }
        loading = false
    }

    Scaffold(topBar = { AppBar("Kupon Laboratuvarı", pop) { TextButton(onClick = { tick++ }) { Text("Yenile") } } }) { pad ->
        Column(Modifier.padding(pad).fillMaxSize()) {
            // Üç kupon türü ekranın üstünde; seçilen türün içeriği açılır
            Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 10.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                CouponType.values().forEach { t ->
                    if (t == tab) {
                        Button(
                            onClick = { tab = t }, modifier = Modifier.weight(1f), contentPadding = PaddingValues(horizontal = 4.dp, vertical = 10.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = couponColor(t), contentColor = Color(0xFF04210F))
                        ) { Text(t.short, maxLines = 1, fontWeight = FontWeight.Bold, fontSize = 13.sp) }
                    } else {
                        OutlinedButton(
                            onClick = { tab = t }, modifier = Modifier.weight(1f), contentPadding = PaddingValues(horizontal = 4.dp, vertical = 10.dp)
                        ) { Text(t.short, maxLines = 1, fontSize = 13.sp) }
                    }
                }
            }
            Column(
                Modifier.weight(1f).fillMaxWidth().verticalScroll(rememberScrollState()).padding(horizontal = 12.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Text(
                    "Önümüzdeki 3 günün başlamamış maçlarından kurulur; oran girilmesi gerekmez. Her maçtan en fazla bir seçim alınır. " +
                        "Önce yüksek güvenli seçimler kullanılır; yeterli seçim yoksa kriterler kademeli ve işaretlenerek esnetilir.",
                    fontSize = 11.sp, color = MutedText
                )
                if (loading) Box(Modifier.fillMaxWidth().padding(16.dp), contentAlignment = Alignment.Center) { CircularProgressIndicator() }
                val err = error
                if (err != null) InfoCard("Hata", err, warn = true)
                if (!loading) {
                    val color = couponColor(tab)
                    val out = coupons[tab]
                    Box(Modifier.fillMaxWidth().background(Brush.horizontalGradient(listOf(color.copy(alpha = 0.35f), Color.Transparent)), RoundedCornerShape(16.dp)).padding(12.dp)) {
                        Column {
                            Text(tab.tr, fontWeight = FontWeight.Bold, fontSize = 17.sp)
                            Text(tab.desc, fontSize = 12.sp, color = MutedText)
                        }
                    }
                    val c = out?.coupon
                    if (c == null) {
                        InfoCard("Kupon oluşturulamadı", (out?.notes ?: listOf("Henüz hesaplanmadı.")).joinToString("\n"), warn = true)
                    } else {
                        Card(Modifier.fillMaxWidth()) {
                            Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                    ConfidenceTag(c.level)
                                    Tag("Risk: " + c.risk, color)
                                    if (c.unpricedCount > 0) Tag("Oransız", MutedText)
                                }
                                c.picks.forEach { p ->
                                    Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                                        Text("${p.match.home} - ${p.match.away}", fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                        Text("${p.match.leagueName} · ${kickoffText(p.match, repo)}", fontSize = 11.sp, color = MutedText)
                                        Row {
                                            Text(
                                                MarketCatalog.marketTitle(p.f.marketKey) + " · " + MarketCatalog.selectionLabel(p.f.marketKey, p.f.selectionKey),
                                                modifier = Modifier.weight(1f), fontSize = 13.sp
                                            )
                                            val e = p.eval
                                            if (e != null) Text(odd2(e.odds), fontWeight = FontWeight.Bold)
                                            else Text("oran yok", fontSize = 12.sp, color = MutedText)
                                        }
                                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
                                            Text("Tahmin " + pct(p.prob), fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                            ConfidenceTag(p.f.confidence)
                                            if (p.f.dataQuality > 0.0) Tag("Veri " + pct(p.f.dataQuality), MutedText)
                                            if (p.f.confidence == Confidence.LOW) Tag("Düşük güvenli", confidenceColor(Confidence.LOW))
                                        }
                                    }
                                }
                                val total = c.totalOdds
                                Text(
                                    (if (total != null) "Toplam oran: ${odd2(total)}" else "Toplam oran: hesaplanmadı (oransız seçim var)") +
                                        " · Tahmini gerçekleşme: ${pct(c.probability)}",
                                    fontWeight = FontWeight.Bold, fontSize = 13.sp
                                )
                                if (c.unpricedCount > 0) {
                                    Text(
                                        "Bu kuponda ${c.unpricedCount} oransız seçim var: gerçek oran girilmeden toplam oran ve potansiyel kazanç gösterilmez.",
                                        fontSize = 11.sp, color = AmberWarn
                                    )
                                }
                                if (c.relaxedTier > 0) {
                                    Text("Kriterler kontrollü esnetildi (kademe ${c.relaxedTier + 1}); düşük güvenli seçimler işaretlidir.", fontSize = 11.sp, color = AmberWarn)
                                }
                                Text("Farklı maçlar yaklaşık bağımsız kabul edilir. Yüksek toplam oran kalite anlamına gelmez; garanti yoktur.", fontSize = 11.sp, color = MutedText)
                                Text((out?.notes ?: emptyList()).joinToString("\n"), fontSize = 11.sp, color = MutedText)
                            }
                        }
                    }
                    SectionTitle("Mevcut güçlü tahminler")
                    Text(
                        "Kupon kurulsa da kurulmasa da, taranan maçlardaki en güçlü tahminler.",
                        fontSize = 11.sp, color = MutedText
                    )
                    if (strongList.isEmpty()) {
                        InfoCard("Güçlü tahmin yok", "Taranan maçlarda yeterli veriyle üretilmiş tahmin bulunamadı (veri yetersiz olabilir).")
                    }
                    strongList.forEach { (r, f) ->
                        ForecastRow(f, title = "${r.match.home} - ${r.match.away} · ${r.match.leagueName}", market = r.marketProb(f))
                    }
                    Spacer(Modifier.height(16.dp))
                }
            }
        }
    }
}

// ------------------------------------------------------------------ Tahmin geçmişi

@Composable
fun HistoryScreen(repo: Repository, pop: () -> Unit) {
    val scope = rememberCoroutineScope()
    var tick by remember { mutableStateOf(0) }
    var filter by remember { mutableStateOf(0) }   // 0 hepsi, 1 bekleyen, 2 sonuçlanan
    var list by remember { mutableStateOf<List<PredictionRecord>>(emptyList()) }
    var info by remember { mutableStateOf<String?>(null) }
    var busy by remember { mutableStateOf(false) }

    LaunchedEffect(tick) { list = repo.predictionList() }

    val shown = when (filter) {
        1 -> list.filter { it.result == null }
        2 -> list.filter { it.result != null }
        else -> list
    }

    Scaffold(topBar = {
        AppBar("Tahmin Geçmişi", pop) {
            TextButton(enabled = !busy, onClick = {
                scope.launch {
                    busy = true
                    info = try { repo.settlePending() } catch (e: CancellationException) { throw e } catch (e: Exception) { "Hata: ${e.message}" }
                    busy = false
                    tick++
                }
            }) { Text("Sonuçları güncelle") }
        }
    }) { pad ->
        Column(Modifier.padding(pad).fillMaxSize().padding(horizontal = 12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            ChipRow(listOf(0, 1, 2), filter, { when (it) { 0 -> "Hepsi (${list.size})"; 1 -> "Bekleyen"; else -> "Sonuçlanan" } }) { filter = it }
            if (busy) Box(Modifier.fillMaxWidth().padding(8.dp), contentAlignment = Alignment.Center) { CircularProgressIndicator() }
            val i = info
            if (i != null) InfoCard("Bilgi", i)
            if (list.isEmpty()) {
                InfoCard("Henüz kayıt yok", "Bir maçın detayını açtığında model, başlamamış maçlar için tahminleri otomatik kaydeder. Gelecekteki maç bilgisi geçmiş tahminlerde kullanılmaz.")
            }
            LazyColumn(verticalArrangement = Arrangement.spacedBy(6.dp), contentPadding = PaddingValues(bottom = 16.dp)) {
                items(shown.take(300), key = { it.id }) { r ->
                    Card(Modifier.fillMaxWidth()) {
                        Column(Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                            Text(r.matchLabel, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            Text(
                                MarketCatalog.marketTitle(r.marketKey) + " · " + MarketCatalog.selectionLabel(r.marketKey, r.selectionKey),
                                fontSize = 13.sp
                            )
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                                Text("Tahmin ${pct(r.prob)}" + (r.odds?.let { " · Oran ${odd2(it)}" } ?: ""), fontSize = 12.sp, modifier = Modifier.weight(1f))
                                when (r.result) {
                                    true -> Tag("Doğru", GreenOk)
                                    false -> Tag("Yanlış", RedBad)
                                    null -> Tag("Bekliyor", MutedText)
                                }
                                if (r.recommended) Tag("Önerilmişti", AmberWarn)
                            }
                            Text(
                                clockText(r.kickoff * 1000, repo).let { Instant.ofEpochSecond(r.kickoff).atZone(repo.zone).format(dayFmt) + " " + it } +
                                    (r.finalScore?.let { " · Skor $it" } ?: ""),
                                fontSize = 11.sp, color = MutedText
                            )
                        }
                    }
                }
            }
        }
    }
}
