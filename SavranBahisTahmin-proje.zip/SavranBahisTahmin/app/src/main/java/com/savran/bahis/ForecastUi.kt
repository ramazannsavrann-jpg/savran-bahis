@file:OptIn(ExperimentalMaterial3Api::class)

package com.savran.bahis

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.ui.graphics.compositeOver
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.util.Locale

/** Güven seviyeleri renkle ayrılır: Yüksek yeşil, Orta sarı, Düşük turuncu. */
fun confidenceColor(c: Confidence): Color = when (c) {
    Confidence.HIGH -> GreenOk
    Confidence.MEDIUM -> AmberWarn
    Confidence.LOW -> Color(0xFFFF8A65)
}

@Composable
fun ConfidenceTag(c: Confidence) {
    Tag("Güven: " + c.tr, confidenceColor(c))
}

@Composable
fun ProbBar(p: Double, color: Color) {
    val target = p.toFloat().coerceIn(0f, 1f)
    val frac by animateFloatAsState(targetValue = target, animationSpec = tween(500), label = "prob")
    Box(Modifier.fillMaxWidth().height(6.dp).background(Color(0x33FFFFFF), RoundedCornerShape(3.dp))) {
        Box(Modifier.fillMaxWidth(frac).height(6.dp).background(androidx.compose.ui.graphics.Brush.horizontalGradient(listOf(color.copy(alpha = 0.6f), color)), RoundedCornerShape(3.dp)))
    }
}

/** Tek bir tahmin: seçenek, olasılık çubuğu, güven seviyesi, oranlı/oransız etiketi. */
@Composable
fun ForecastRow(f: Forecast, title: String? = null, onClick: (() -> Unit)? = null, market: Double? = null) {
    val color = confidenceColor(f.confidence)
    val base = Modifier.fillMaxWidth()
    Card(
        if (onClick != null) base.clickable { onClick() } else base,
        colors = CardDefaults.cardColors(containerColor = color.copy(alpha = 0.08f).compositeOver(Color(0xFF121C2E)))
    ) {
        Column(Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            if (title != null) {
                Text(title, fontSize = 12.sp, color = MutedText, maxLines = 1, overflow = TextOverflow.Ellipsis)
            }
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text(MarketCatalog.marketTitle(f.marketKey), fontSize = 12.sp, color = MutedText, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    Text(MarketCatalog.selectionLabel(f.marketKey, f.selectionKey), fontWeight = FontWeight.Bold)
                }
                ProbRing(f.prob, color, 50.dp)
            }
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                ConfidenceTag(f.confidence)
                if (f.dataQuality < ForecastEngine.MIN_DATA_QUALITY) Tag("Çok az veri", RedBad)
                else Tag("Veri " + pct(f.dataQuality), if (f.dataQuality >= 0.75) GreenOk else if (f.dataQuality >= 0.5) AmberWarn else confidenceColor(Confidence.LOW))
                val o = f.odds
                if (o != null) Tag("Oran " + odd2(o), GreenOk) else Tag("Oransız", MutedText)
                // Piyasa: oranın marjı ayıklanmış olasılığı. Model piyasadan belirgin yüksekse yeşil, düşükse kırmızı.
                if (market != null) {
                    val d = f.prob - market
                    Tag("Piyasa " + pct(market), if (d >= 0.05) GreenOk else if (d <= -0.05) RedBad else MutedText)
                }
                val ev = f.ev
                if (ev != null) {
                    Tag("EV %" + "%.1f".format(Locale.US, ev * 100), if (ev >= 0) GreenOk else RedBad)
                }
            }
        }
    }
}

/** Maç detayında: oran girilmese de çalışan tahmin bölümü. */
@Composable
fun ForecastSection(a: AnalysisResult, hasOdds: Boolean) {
    var showAll by remember { mutableStateOf(false) }
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text(
            if (hasOdds) "Oranlı analiz: tahminler istatistikten gelir; girilen oranlar için EV ve değer analizi aşağıdaki bölümdedir."
            else "Oransız analiz: tahminler yalnızca istatistikten gelir. Oran girilmediği için EV ve değer hesaplanmaz.",
            fontSize = 12.sp, color = MutedText
        )
        if (a.forecasts.isEmpty()) {
            InfoCard("Tahmin üretilemedi", a.forecastNote ?: "Veri yetersiz.", warn = true)
        } else {
            val basis = AnalysisBasis.lines(a.criteria)
            if (a.criteria.isNotEmpty()) {
                Card(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                        Text("Bu analiz neye dayanıyor?", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                        Text("Kullanılan: " + (basis.first.joinToString(", ").ifEmpty { "-" }), fontSize = 11.sp, color = GreenOk)
                        Text("Bilinmeyen / kullanılmayan: " + (basis.second.joinToString(", ").ifEmpty { "-" }), fontSize = 11.sp, color = MutedText)
                        Text("Veri kalitesi " + pct(a.dataQuality) + " — olasılık ile güven aynı şey değildir.", fontSize = 11.sp, color = MutedText)
                    }
                }
            }
            Text(
                "Olasılık, güven ve veri kalitesi ayrı kavramlardır: yüksek olasılık kesinlik değildir; güven seviyesi verinin ne kadar sağlam olduğunu gösterir.",
                fontSize = 11.sp, color = MutedText
            )
            Text("Bahis Fırsatları: her pazarın en yüksek olasılıklı seçeneği", fontWeight = FontWeight.Bold)
            val best = ForecastEngine.shownWithFallback(a.forecasts).sortedByDescending { ForecastEngine.weighted(it) }
            if (best.isEmpty()) {
                InfoCard("Gösterilecek tahmin yok", "Tüm seçenekler yazı-turaya çok yakın; anlamlı bir öneri çıkmadı. Aşağıdan tüm pazarlara bakabilirsin.")
            } else if (best.none { it.confidence.rank >= ForecastEngine.MIN_SHOWN_CONFIDENCE.rank }) {
                InfoCard(
                    "Veri az: düşük güvenli tahmin",
                    "Bu maç için takımların az maçı var (veri ${pct(a.dataQuality)}). Aşağıdaki seçimler yine gerçek istatistikten hesaplandı ama güven DÜŞÜK; kesin sonuç gibi okuma.",
                    warn = true
                )
            }
            best.take(12).forEach { ForecastRow(it, market = a.marketProb(it)) }
            Text(
                "Her pazarda yalnızca en yüksek olasılıklı seçenek listelenir. Yeterli güvenli seçenek varsa düşük güvenliler gizlenir; hiç yoksa düşük güvenliler etiketle gösterilir. İlk Yarı 2.5 Alt gibi oynanamaz seçenekler ile %85 ve üzeri bariz seçimler (bahis şirketleri çoğu zaman oran vermez) listelenmez; \"Tüm pazarlar\"da görünür.",
                fontSize = 11.sp, color = MutedText
            )
            val ladders = ForecastEngine.ladders(a.forecasts)
            if (ladders.isNotEmpty()) {
                Text("Çizgi karşılaştırması", fontWeight = FontWeight.Bold)
                ladders.forEach { l ->
                    Card(Modifier.fillMaxWidth()) {
                        Column(Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                            Text(l.title, fontSize = 12.sp, color = MutedText)
                            Text(l.items.joinToString("  ·  ") { it.first + " " + pct(it.second) }, fontSize = 13.sp)
                        }
                    }
                }
            }
            TextButton(onClick = { showAll = !showAll }) {
                Text(if (showAll) "Tüm pazarları gizle" else "Tüm pazarları göster (${a.forecasts.size})")
            }
            if (showAll) {
                a.forecasts.sortedByDescending { it.prob }.take(150).forEach { ForecastRow(it, market = a.marketProb(it)) }
            }
        }
    }
}


/** "Bu analizde kullanılan kriterler": yalnızca gerçekten kullanılanlar "Kullanıldı" görünür. */
@Composable
fun CriteriaCard(criteria: List<Criterion>) {
    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            criteria.forEach { c ->
                val color = when (c.status) {
                    CriterionStatus.USED -> GreenOk
                    CriterionStatus.PARTIAL -> AmberWarn
                    CriterionStatus.NO_DATA -> RedBad
                    CriterionStatus.NOT_USED -> MutedText
                }
                Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(c.name, fontWeight = FontWeight.Bold, fontSize = 13.sp, modifier = Modifier.weight(1f))
                        Tag(c.status.tr, color)
                    }
                    Text(c.note, fontSize = 11.sp, color = MutedText)
                }
            }
            Text(
                "Kullanılmayan veya veri alınamayan kriterler hesaba katılmaz; eksik veri tahmin edilerek doldurulmaz.",
                fontSize = 11.sp, color = MutedText
            )
        }
    }
}


/** Güncel takım haberleri: tarih ve kaynakla; yalnızca doğrulanmış etkiler hesaba katılır. */
@Composable
fun NewsSection(a: AnalysisResult, searching: Boolean, nowSec: Long) {
    val zone = java.time.ZoneId.of("Europe/Istanbul")
    val fmt = java.time.format.DateTimeFormatter.ofPattern("d MMM HH:mm")
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        if (searching) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                androidx.compose.material3.CircularProgressIndicator(Modifier.size(18.dp), strokeWidth = 2.dp)
                Text("Haberler araştırılıyor…", fontSize = 12.sp, color = MutedText)
            }
        }
        val eff = a.newsEffect
        if (eff != null && eff.applied.isNotEmpty()) {
            InfoCard("Hesaba katılan haberler", eff.applied.joinToString("\n"))
        }
        if (eff != null && eff.info.isNotEmpty()) {
            InfoCard("Bilgi (hesaba katılmadı)", eff.info.joinToString("\n"))
        }
        val items = (a.newsHome + a.newsAway).sortedByDescending { it.publishedAt }.take(12)
        if (items.isEmpty() && !searching) {
            InfoCard("Haber bulunamadı", "Güncel haber bulunamadı veya araştırılamadı; analiz yalnızca istatistiğe dayanıyor.")
        }
        items.forEach { n ->
            val stale = nowSec - n.publishedAt > NewsImpact.MAX_AGE_SEC
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text(n.title, fontSize = 13.sp, maxLines = 3, overflow = TextOverflow.Ellipsis)
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        Tag(n.source, MutedText)
                        Tag(java.time.Instant.ofEpochSecond(n.publishedAt).atZone(zone).format(fmt), if (stale) AmberWarn else MutedText)
                        if (n.official) Tag("Resmî", GreenOk)
                        if (n.rumor) Tag("Söylenti/tahmini", AmberWarn)
                        if (stale) Tag("Eski", AmberWarn)
                    }
                }
            }
        }
        Text(
            "Kaynak: Google Haberler başlıkları. Aynı haberin farklı sitelerdeki tekrarı tek bilgi sayılır. Oyuncunun önemi bilinmediği için etki küçük ve sınırlıdır (en fazla ±%6); haber yoksa istatistik analizi aynen sürer.",
            fontSize = 11.sp, color = MutedText
        )
    }
}

/** Bu tahminin seçeneği için piyasanın (marjı ayıklanmış) olasılığı; taze oran yoksa null. */
fun AnalysisResult.marketProb(f: Forecast): Double? =
    evaluations.firstOrNull { it.marketKey == f.marketKey && it.selectionKey == f.selectionKey && it.decision != Decision.STALE_ODDS }?.fairProb
