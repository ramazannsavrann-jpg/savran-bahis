@file:OptIn(ExperimentalMaterial3Api::class)

package com.savran.bahis

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Card
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.util.Locale

/** Güven seviyeleri renkle ayrılır: Yüksek yeşil, Orta sarı, Düşük turuncu. */
fun confidenceColor(c: Confidence): Color = when (c) {
    Confidence.HIGH -> GreenOk
    Confidence.MEDIUM -> AmberWarn
    Confidence.LOW -> Color(0xFFFF8A65)
}

@Composable
fun ConfidenceTag(c: Confidence) {
    Tag("Güven: " + c.tr, confidenceColor(c))
}

@Composable
fun ProbBar(p: Double, color: Color) {
    val target = p.toFloat().coerceIn(0f, 1f)
    val frac by animateFloatAsState(targetValue = target, animationSpec = tween(500), label = "prob")
    Box(Modifier.fillMaxWidth().height(6.dp).background(Color(0x33FFFFFF), RoundedCornerShape(3.dp))) {
        Box(Modifier.fillMaxWidth(frac).height(6.dp).background(color, RoundedCornerShape(3.dp)))
    }
}

/** Tek bir tahmin: seçenek, olasılık çubuğu, güven seviyesi, oranlı/oransız etiketi. */
@Composable
fun ForecastRow(f: Forecast, title: String? = null, onClick: (() -> Unit)? = null) {
    val color = confidenceColor(f.confidence)
    val base = Modifier.fillMaxWidth()
    Card(if (onClick != null) base.clickable { onClick() } else base) {
        Column(Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            if (title != null) {
                Text(title, fontSize = 12.sp, color = MutedText, maxLines = 1, overflow = TextOverflow.Ellipsis)
            }
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text(MarketCatalog.marketTitle(f.marketKey), fontSize = 12.sp, color = MutedText, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    Text(MarketCatalog.selectionLabel(f.marketKey, f.selectionKey), fontWeight = FontWeight.Bold)
                }
                Text(pct(f.prob), fontWeight = FontWeight.Bold, fontSize = 20.sp, color = color)
            }
            ProbBar(f.prob, color)
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                ConfidenceTag(f.confidence)
                if (f.dataQuality > 0.0) Tag("Veri " + pct(f.dataQuality), if (f.dataQuality >= 0.75) GreenOk else if (f.dataQuality >= 0.5) AmberWarn else confidenceColor(Confidence.LOW))
                val o = f.odds
                if (o != null) Tag("Oran " + odd2(o), GreenOk) else Tag("Oransız", MutedText)
                val ev = f.ev
                if (ev != null) {
                    Tag("EV %" + "%.1f".format(Locale.US, ev * 100), if (ev >= 0) GreenOk else RedBad)
                }
            }
        }
    }
}

/** Maç detayında: oran girilmese de çalışan tahmin bölümü. */
@Composable
fun ForecastSection(a: AnalysisResult, hasOdds: Boolean) {
    var showAll by remember { mutableStateOf(false) }
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text(
            if (hasOdds) "Oranlı analiz: tahminler istatistikten gelir; girilen oranlar için EV ve değer analizi aşağıdaki bölümdedir."
            else "Oransız analiz: tahminler yalnızca istatistikten gelir. Oran girilmediği için EV ve değer hesaplanmaz.",
            fontSize = 12.sp, color = MutedText
        )
        if (a.forecasts.isEmpty()) {
            InfoCard("Tahmin üretilemedi", a.forecastNote ?: "Veri yetersiz.", warn = true)
        } else {
            Text(
                "Olasılık, güven ve veri kalitesi ayrı kavramlardır: yüksek olasılık kesinlik değildir; güven seviyesi verinin ne kadar sağlam olduğunu gösterir.",
                fontSize = 11.sp, color = MutedText
            )
            Text("En güçlü seçenekler", fontWeight = FontWeight.Bold)
            ForecastEngine.strongest(a.forecasts, 8).forEach { ForecastRow(it) }
            Text(
                "%95 üstü olasılıklar genellikle çok düşük oran demektir; bu listede gösterilmez.",
                fontSize = 11.sp, color = MutedText
            )
            val ladders = ForecastEngine.ladders(a.forecasts)
            if (ladders.isNotEmpty()) {
                Text("Çizgi karşılaştırması", fontWeight = FontWeight.Bold)
                ladders.forEach { l ->
                    Card(Modifier.fillMaxWidth()) {
                        Column(Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                            Text(l.title, fontSize = 12.sp, color = MutedText)
                            Text(l.items.joinToString("  ·  ") { it.first + " " + pct(it.second) }, fontSize = 13.sp)
                        }
                    }
                }
            }
            TextButton(onClick = { showAll = !showAll }) {
                Text(if (showAll) "Tüm pazarları gizle" else "Tüm pazarları göster (${a.forecasts.size})")
            }
            if (showAll) {
                a.forecasts.sortedByDescending { it.prob }.take(150).forEach { ForecastRow(it) }
            }
        }
    }
}


/** "Bu analizde kullanılan kriterler": yalnızca gerçekten kullanılanlar "Kullanıldı" görünür. */
@Composable
fun CriteriaCard(criteria: List<Criterion>) {
    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            criteria.forEach { c ->
                val color = when (c.status) {
                    CriterionStatus.USED -> GreenOk
                    CriterionStatus.PARTIAL -> AmberWarn
                    CriterionStatus.NO_DATA -> RedBad
                    CriterionStatus.NOT_USED -> MutedText
                }
                Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(c.name, fontWeight = FontWeight.Bold, fontSize = 13.sp, modifier = Modifier.weight(1f))
                        Tag(c.status.tr, color)
                    }
                    Text(c.note, fontSize = 11.sp, color = MutedText)
                }
            }
            Text(
                "Kullanılmayan veya veri alınamayan kriterler hesaba katılmaz; eksik veri tahmin edilerek doldurulmaz.",
                fontSize = 11.sp, color = MutedText
            )
        }
    }
}
