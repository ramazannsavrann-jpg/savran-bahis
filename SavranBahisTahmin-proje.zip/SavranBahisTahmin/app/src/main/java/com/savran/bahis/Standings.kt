package com.savran.bahis

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONException
import org.json.JSONObject
import java.io.File
import java.net.URL

data class SplitStats(val played: Int, val goalsFor: Int, val goalsAgainst: Int)

data class TeamRow(
    val teamId: Int,
    val name: String,
    val rank: Int,
    val points: Int,
    val all: SplitStats,
    val home: SplitStats,
    val away: SplitStats,
    val form: String
)

data class LeagueTable(val leagueId: Int, val season: Int, val fetchedAt: Long, val rows: List<TeamRow>)

private fun splitToJson(s: SplitStats) = JSONObject().put("p", s.played).put("f", s.goalsFor).put("a", s.goalsAgainst)
private fun splitFromJson(o: JSONObject) = SplitStats(o.getInt("p"), o.getInt("f"), o.getInt("a"))

class TableCache(private val dir: File) {
    private fun f(league: Int, season: Int) = File(dir, "table_${league}_$season.json")

    fun read(league: Int, season: Int): LeagueTable? {
        val file = f(league, season)
        if (!file.exists()) return null
        return try {
            val root = JSONObject(file.readText())
            val arr = root.getJSONArray("rows")
            val rows = (0 until arr.length()).map {
                val o = arr.getJSONObject(it)
                TeamRow(
                    o.getInt("id"), o.getString("name"), o.getInt("rank"), o.getInt("pts"),
                    splitFromJson(o.getJSONObject("all")), splitFromJson(o.getJSONObject("home")),
                    splitFromJson(o.getJSONObject("away")), o.optString("form", "")
                )
            }
            LeagueTable(league, season, root.getLong("fetchedAt"), rows)
        } catch (e: Exception) {
            file.delete()
            null
        }
    }

    fun write(t: LeagueTable) {
        val arr = JSONArray()
        t.rows.forEach {
            arr.put(
                JSONObject().put("id", it.teamId).put("name", it.name).put("rank", it.rank).put("pts", it.points)
                    .put("all", splitToJson(it.all)).put("home", splitToJson(it.home))
                    .put("away", splitToJson(it.away)).put("form", it.form)
            )
        }
        atomicWrite(f(t.leagueId, t.season), JSONObject().put("fetchedAt", t.fetchedAt).put("rows", arr).toString())
    }

    fun clear() { dir.listFiles()?.forEach { it.delete() } }
}

/** API-Football'a genel istek (kota ve hata denetimiyle). */
suspend fun ApiFootballFixtureProvider.call(pathAndQuery: String): ApiResult<String> = withContext(Dispatchers.IO) {
    val key = settings.apiKey ?: return@withContext ApiResult.Err("API anahtarı girilmedi.")
    val now = System.currentTimeMillis()
    if (!Quota.canSpend(settings.usedToday(now), settings.remainingKnown(now))) {
        return@withContext ApiResult.Err("Günlük istek sınırına yaklaşıldı (son ${Quota.RESERVE} istek yedekte).")
    }
    val r = request(URL(base + pathAndQuery), key, true)
    if (r is ApiResult.Ok) {
        val e = apiErrorOf(r.value)
        if (e != null) return@withContext ApiResult.Err("API mesajı: $e")
    }
    r
}

fun apiErrorOf(body: String): String? {
    return try {
        val errors = JSONObject(body).opt("errors")
        when (errors) {
            is JSONObject -> if (errors.length() > 0) errors.keys().asSequence().map { errors.optString(it) }.joinToString("; ") else null
            is JSONArray -> if (errors.length() > 0) (0 until errors.length()).joinToString("; ") { errors.optString(it) } else null
            else -> null
        }
    } catch (e: JSONException) {
        "Yanıt okunamadı"
    }
}

fun parseStandings(body: String, leagueId: Int, season: Int, now: Long): ApiResult<LeagueTable> {
    return try {
        val resp = JSONObject(body).optJSONArray("response")
        if (resp == null || resp.length() == 0) return ApiResult.Err("Bu lig/sezon için puan durumu verisi yok.")
        val groups = resp.getJSONObject(0).getJSONObject("league").getJSONArray("standings")
        val rows = ArrayList<TeamRow>()
        for (g in 0 until groups.length()) {
            val grp = groups.getJSONArray(g)
            for (i in 0 until grp.length()) {
                val o = grp.getJSONObject(i)
                fun split(k: String): SplitStats {
                    val s = o.getJSONObject(k)
                    val goals = s.getJSONObject("goals")
                    return SplitStats(s.getInt("played"), goals.getInt("for"), goals.getInt("against"))
                }
                rows.add(
                    TeamRow(
                        o.getJSONObject("team").getInt("id"), o.getJSONObject("team").getString("name"),
                        o.getInt("rank"), o.getInt("points"), split("all"), split("home"), split("away"),
                        o.optString("form", "")
                    )
                )
            }
        }
        if (rows.isEmpty()) ApiResult.Err("Puan durumu boş döndü.") else ApiResult.Ok(LeagueTable(leagueId, season, now, rows))
    } catch (e: JSONException) {
        ApiResult.Err("Puan durumu yanıtı okunamadı.")
    }
}
