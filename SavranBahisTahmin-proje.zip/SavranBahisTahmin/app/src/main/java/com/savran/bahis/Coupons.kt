package com.savran.bahis

enum class CouponType(val tr: String, val desc: String) {
    BALANCED("Dengeli Kupon", "Yüksek tahmini olasılık, yüksek güven, düşük risk"),
    SURPRISE("Sürpriz Potansiyelli Kupon", "Olasılığı daha düşük ama modelce desteklenen seçimler"),
    VALUE("Değer Kuponu", "Gerçek oranı girilmiş, piyasa oranı ile model olasılığı arasında fark olan seçimler")
}

/** eval: yalnızca o seçenek için taze ve gerçek oran varsa dolu. Oransız seçim de kupona girebilir. */
data class CouponPick(val match: Match, val f: Forecast, val eval: Evaluation?) {
    val prob: Double get() = eval?.adjProb ?: f.prob
}

data class Coupon(
    val type: CouponType,
    val picks: List<CouponPick>,
    val totalOdds: Double?,          // yalnızca TÜM seçimlerde gerçek oran varsa; aksi halde null
    val probability: Double,
    val risk: String,
    val level: Confidence,           // seçimlerin en düşük güven seviyesi
    val lowConfidenceCount: Int,
    val unpricedCount: Int,
    val relaxedTier: Int             // 0 = en katı kademe; yükseldikçe kriter esnetildi
)

data class CouponOutcome(val coupon: Coupon?, val notes: List<String>)

object CouponLab {
    const val MIN_PICKS = 2
    const val MAX_PICKS = 6
    /** Bu sayıya ulaşılınca daha düşük kademeye inilmez (kupon kötü seçimle doldurulmaz). */
    const val TARGET_PICKS = 3

    private class Tier(val label: String, val test: (CouponPick) -> Boolean)
    private class Plan(val tiers: List<Tier>, val order: (CouponPick) -> Double, val limit: Int)

    private fun highRisk(p: CouponPick) = p.f.marketKey == "cs" || p.eval?.highRisk == true
    private fun safeMarket(mk: String) = OpportunityEngine.marketReliability(mk) >= 0.8

    /** Oran girilmişse alt sınırlar uygulanır; oransız seçimde oran koşulu yoktur. */
    private fun priceOk(p: CouponPick, minOdds: Double, minEv: Double): Boolean {
        val e = p.eval ?: return true
        return e.odds >= minOdds && (e.ev ?: -1.0) >= minEv
    }

    private fun balancedTier(label: String, minConf: Confidence, minProb: Double) = Tier(label) { p ->
        p.f.confidence.rank >= minConf.rank && p.prob >= minProb && p.prob <= 0.95 &&
            !highRisk(p) && safeMarket(p.f.marketKey) && priceOk(p, 1.30, 0.0)
    }

    private fun surpriseTier(label: String, minConf: Confidence) = Tier(label) { p ->
        val e = p.eval
        val inBand = if (e == null) p.prob in 0.28..0.50 else (e.odds >= 2.2 && p.prob in 0.22..0.50 && (e.ev ?: -1.0) >= 0.0)
        p.f.confidence.rank >= minConf.rank && inBand && !highRisk(p)
    }

    private fun valueTier(label: String, minEv: Double, minQuality: Int, minConf: Confidence?, recommendOnly: Boolean) = Tier(label) { p ->
        val e = p.eval
        e != null && !highRisk(p) &&
            (e.ev ?: -1.0) >= minEv && (e.quality ?: 0) >= minQuality &&
            (if (recommendOnly) e.decision == Decision.RECOMMEND else (e.decision == Decision.RECOMMEND || e.decision == Decision.LOW_EDGE)) &&
            (minConf == null || p.f.confidence.rank >= minConf.rank)
    }

    fun build(type: CouponType, candidates: List<CouponPick>): CouponOutcome {
        val plan: Plan = when (type) {
            CouponType.BALANCED -> Plan(
                listOf(
                    balancedTier("Yüksek güven", Confidence.HIGH, 0.60),
                    balancedTier("Orta güven", Confidence.MEDIUM, 0.57),
                    balancedTier("Düşük güven", Confidence.LOW, 0.55)
                ),
                { p -> ForecastEngine.weighted(p.f) }, 5
            )
            CouponType.SURPRISE -> Plan(
                listOf(
                    surpriseTier("Yüksek güven", Confidence.HIGH),
                    surpriseTier("Orta güven", Confidence.MEDIUM),
                    surpriseTier("Düşük güven", Confidence.LOW)
                ),
                { p -> ForecastEngine.weighted(p.f) }, 4
            )
            CouponType.VALUE -> Plan(
                listOf(
                    valueTier("Katı (öneri, EV %6+)", 0.06, 55, null, true),
                    valueTier("Esnetilmiş (EV %4+, orta güven)", 0.04, 50, Confidence.MEDIUM, false),
                    valueTier("Esnetilmiş (EV %2+, düşük güven)", 0.02, 45, Confidence.LOW, false)
                ),
                { p -> p.eval?.ev ?: -1.0 }, MAX_PICKS
            )
        }
        val tiers = plan.tiers
        val order = plan.order
        val limit = plan.limit

        val notes = ArrayList<String>()
        val matchCount = candidates.map { it.match.id }.distinct().size
        val priced = candidates.count { it.eval != null }
        notes.add("Havuz: $matchCount maç, ${candidates.size} seçim; ${priced} seçimde gerçek oran var.")
        if (candidates.isEmpty()) {
            notes.add("Analiz edilebilen maç yok (veri yetersiz, maçlar başlamış veya veri kaynağı yok).")
            return CouponOutcome(null, notes)
        }
        if (type == CouponType.VALUE && priced < MIN_PICKS) {
            notes.add("Değer kuponu yalnızca oranı girilmiş seçimlerle kurulur (EV oran gerektirir); oranlı seçim yeterli değil.")
            return CouponOutcome(null, notes)
        }

        val chosen = LinkedHashMap<String, CouponPick>()   // maç başına en fazla bir seçim
        var usedTier = 0
        for ((i, t) in tiers.withIndex()) {
            val eligible = candidates.filter(t.test).sortedByDescending(order)
            val eligibleMatches = eligible.map { it.match.id }.distinct().size
            val cap = if (i == 0) limit else minOf(limit, TARGET_PICKS)
            var added = 0
            for (c in eligible) {
                if (chosen.size >= cap) break
                if (!chosen.containsKey(c.match.id)) {
                    chosen[c.match.id] = c
                    added++
                    usedTier = i
                }
            }
            notes.add("${t.label}: $eligibleMatches maç uygun, $added seçim eklendi.")
            if (chosen.size >= TARGET_PICKS) break
        }

        if (chosen.size < MIN_PICKS) {
            notes.add("Kupon için en az $MIN_PICKS farklı maçta uygun seçim gerekir; ${chosen.size} bulundu. Kalite kriterleri bundan daha fazla düşürülmedi.")
            return CouponOutcome(null, notes)
        }
        if (usedTier > 0) notes.add("Yeterli seçim olmadığı için kriterler kontrollü şekilde esnetildi (kademe ${usedTier + 1}).")

        val picks = chosen.values.toList()
        val unpriced = picks.count { it.eval == null }
        val totalOdds = if (unpriced == 0) picks.fold(1.0) { acc, p -> acc * (p.eval?.odds ?: 1.0) } else null
        // Farklı maçlar yaklaşık bağımsız kabul edilir; aynı maçtan seçim yoktur.
        val prob = picks.fold(1.0) { acc, p -> acc * p.prob }
        val level = picks.minByOrNull { it.f.confidence.rank }?.f?.confidence ?: Confidence.LOW
        if (unpriced > 0) notes.add("$unpriced seçimde gerçek oran yok: toplam oran, potansiyel kazanç ve beklenen kazanç hesaplanmadı.")
        return CouponOutcome(
            Coupon(type, picks, totalOdds, prob, riskLevel(prob), level, picks.count { it.f.confidence == Confidence.LOW }, unpriced, usedTier),
            notes
        )
    }

    fun riskLevel(p: Double): String = when {
        p >= 0.40 -> "Düşük"
        p >= 0.15 -> "Orta"
        else -> "Yüksek"
    }
}
