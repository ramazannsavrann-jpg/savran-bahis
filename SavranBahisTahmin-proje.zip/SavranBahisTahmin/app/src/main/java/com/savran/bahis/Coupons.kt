package com.savran.bahis

enum class CouponType(val tr: String, val desc: String) {
    BALANCED("Dengeli Kupon", "Yüksek tahmini olasılık + oran avantajı + düşük risk"),
    SURPRISE("Sürpriz Potansiyelli Kupon", "Daha yüksek oranlı ama istatistikle desteklenen seçimler"),
    VALUE("Değer Kuponu", "Piyasa oranı ile model olasılığı arasında anlamlı fark")
}

data class CouponPick(val match: Match, val eval: Evaluation)

data class Coupon(
    val type: CouponType,
    val picks: List<CouponPick>,
    val totalOdds: Double,
    val probability: Double,
    val risk: String
)

object CouponLab {
    const val MIN_PICKS = 2
    const val MAX_PICKS = 6

    private fun usable(e: Evaluation) =
        e.ev != null && e.adjProb != null && e.quality != null &&
            (e.decision == Decision.RECOMMEND || e.decision == Decision.LOW_EDGE) && !e.highRisk

    /**
     * Her maçtan en fazla BİR seçim alınır (aynı maçtaki bağımlı bahisler birleştirilmez).
     * Yeterli iyi seçim yoksa null döner; kupon doldurmak için kötü seçim eklenmez.
     */
    fun build(type: CouponType, candidates: List<CouponPick>): Coupon? {
        var filtered: List<CouponPick> = emptyList()
        var sorted: List<CouponPick> = emptyList()
        var limit = 0
        when (type) {
            CouponType.BALANCED -> {
                filtered = candidates.filter {
                    val e = it.eval
                    e.decision == Decision.RECOMMEND && !e.highRisk &&
                        (e.adjProb ?: 0.0) >= 0.55 && e.odds >= 1.30 && (e.quality ?: 0) >= 60
                }
                sorted = filtered.sortedByDescending { it.eval.quality ?: 0 }
                limit = 5
            }
            CouponType.SURPRISE -> {
                filtered = candidates.filter {
                    val e = it.eval
                    usable(e) && (e.ev ?: -1.0) >= 0.02 && (e.adjProb ?: 0.0) in 0.22..0.50 &&
                        e.odds >= 2.2 && (e.quality ?: 0) >= 45
                }
                sorted = filtered.sortedByDescending { it.eval.ev ?: -1.0 }
                limit = 4
            }
            CouponType.VALUE -> {
                filtered = candidates.filter {
                    val e = it.eval
                    e.decision == Decision.RECOMMEND && !e.highRisk &&
                        (e.ev ?: -1.0) >= 0.06 && (e.quality ?: 0) >= 55
                }
                sorted = filtered.sortedByDescending { it.eval.ev ?: -1.0 }
                limit = MAX_PICKS
            }
        }
        val onePerMatch = LinkedHashMap<String, CouponPick>()
        for (c in sorted) if (!onePerMatch.containsKey(c.match.id)) onePerMatch[c.match.id] = c
        val picks = onePerMatch.values.take(minOf(limit, MAX_PICKS))
        if (picks.size < MIN_PICKS) return null
        val totalOdds = picks.fold(1.0) { acc, p -> acc * p.eval.odds }
        // Farklı maçlar: seçimler bağımsız kabul edilir (yaklaşım). Aynı maçtan seçim yok.
        val prob = picks.fold(1.0) { acc, p -> acc * (p.eval.adjProb ?: 0.0) }
        return Coupon(type, picks, totalOdds, prob, riskLevel(prob))
    }

    fun riskLevel(p: Double): String = when {
        p >= 0.40 -> "Düşük"
        p >= 0.15 -> "Orta"
        else -> "Yüksek"
    }
}
