package com.savran.bahis

import kotlin.math.abs
import kotlin.math.ln

enum class CouponType(val tr: String, val short: String, val desc: String) {
    BALANCED("Dengeli Kupon", "Dengeli", "Makul risk, makul kazanma potansiyeli; çok düşük oranlı favorilerden kaçınır"),
    SURPRISE("Sürpriz Kupon", "Sürpriz", "Modelce desteklenen, mantıklı sürpriz sonuçlar (hedef ≈5.25 adil oran)"),
    HIGH_RISK("Yüksek Riskli Kupon", "Yüksek Risk", "Daha cesur ve sürprize açık; yine de istatistiksel desteği olan seçimler")
}

/** eval: yalnızca o seçenek için taze ve gerçek oran girilmişse dolu. Kupon oran gerektirmez. */
data class CouponPick(val match: Match, val f: Forecast, val eval: Evaluation?) {
    val prob: Double get() = eval?.adjProb ?: f.prob
}

data class Coupon(
    val type: CouponType,
    val picks: List<CouponPick>,
    val totalOdds: Double?,          // yalnızca TÜM seçimlerde gerçek oran girilmişse; aksi halde null
    val probability: Double,
    val risk: String,
    val level: Confidence,           // seçimlerin en düşük güven seviyesi
    val lowConfidenceCount: Int,
    val unpricedCount: Int,
    val relaxedTier: Int             // 0 = en katı kademe
)

data class CouponOutcome(val coupon: Coupon?, val notes: List<String>)

object CouponLab {
    const val MIN_PICKS = 2
    const val TARGET_PICKS = 3

    /** Sürpriz kupon: tahmini gerçekleşme ≈ %19 (model adil oranı ≈ 5.25). Oran gösterilmez, yalnızca hedeftir. */
    const val SURPRISE_TARGET_PROB = 1.0 / 5.25
    /** Yüksek riskli kupon: tahmini gerçekleşme ≈ %6 (model adil oranı ≈ 16-17). */
    const val HIGH_RISK_TARGET_PROB = 0.06
    const val BALANCED_SWEET_SPOT = 0.64

    private class Tier(val label: String, val test: (CouponPick) -> Boolean)
    private class Plan(
        val tiers: List<Tier>,
        val order: (CouponPick) -> Double,
        val limit: Int,
        val targetProb: Double?          // verilirse seçimler bu olasılığa en yakın olacak şekilde kırpılır
    )

    private fun highRisk(p: CouponPick) = p.f.marketKey == "cs" || p.eval?.highRisk == true
    private fun reliability(p: CouponPick) = OpportunityEngine.marketReliability(p.f.marketKey)

    /** Kupon havuzuna girebilir mi? Oynanamayan pazarlar (0.5 Üst, 4.5 Alt) ve tahmini olmayanlar hariç. */
    fun eligible(p: CouponPick): Boolean =
        ForecastEngine.isPlayable(p.f.marketKey, p.f.selectionKey) && p.f.prob < ForecastEngine.OBVIOUS_PROB

    private fun balancedTier(label: String, minConf: Confidence) = Tier(label) { p ->
        val e = p.eval
        p.f.confidence.rank >= minConf.rank && p.prob in 0.50..0.75 && !highRisk(p) && reliability(p) >= 0.8 &&
            (e == null || e.odds >= 1.30)
    }

    private fun surpriseTier(label: String, minConf: Confidence) = Tier(label) { p ->
        p.f.confidence.rank >= minConf.rank && p.prob in 0.35..0.55 && !highRisk(p) && reliability(p) >= 0.7
    }

    private fun highRiskTier(label: String, minConf: Confidence) = Tier(label) { p ->
        p.f.confidence.rank >= minConf.rank && p.prob in 0.22..0.45 && !highRisk(p) && reliability(p) >= 0.6
    }

    /** Dengeli: ağırlıklı olasılık, ama çok yüksek (düşük oranlı) favoriler yerine "tatlı nokta"ya yakın seçimler öne çıkar. */
    private fun balancedOrder(p: CouponPick): Double =
        ForecastEngine.weighted(p.f) * (1.0 - 2.0 * abs(p.prob - BALANCED_SWEET_SPOT))

    /** Seçimleri hedef olasılığa en yakın olacak şekilde kırpar (sıralı önek; en güvenilirler korunur). */
    fun trimToTarget(picks: List<CouponPick>, target: Double): List<CouponPick> {
        if (picks.size <= MIN_PICKS) return picks
        var best = picks.size
        var bestDist = Double.MAX_VALUE
        var prod = 1.0
        for ((i, p) in picks.withIndex()) {
            prod *= p.prob
            val k = i + 1
            if (k < MIN_PICKS) continue
            val d = abs(ln(prod / target))
            if (d < bestDist) { bestDist = d; best = k }
        }
        return picks.take(best)
    }

    fun build(type: CouponType, candidates: List<CouponPick>): CouponOutcome {
        val plan: Plan = when (type) {
            CouponType.BALANCED -> Plan(
                listOf(
                    balancedTier("Yüksek güven", Confidence.HIGH),
                    balancedTier("Orta güven", Confidence.MEDIUM),
                    balancedTier("Düşük güven", Confidence.LOW)
                ),
                { p -> balancedOrder(p) }, 4, null
            )
            CouponType.SURPRISE -> Plan(
                listOf(
                    surpriseTier("Yüksek güven", Confidence.HIGH),
                    surpriseTier("Orta güven", Confidence.MEDIUM),
                    surpriseTier("Düşük güven", Confidence.LOW)
                ),
                { p -> ForecastEngine.weighted(p.f) }, 4, SURPRISE_TARGET_PROB
            )
            CouponType.HIGH_RISK -> Plan(
                listOf(
                    highRiskTier("Orta güven ve üstü", Confidence.MEDIUM),
                    highRiskTier("Düşük güven", Confidence.LOW)
                ),
                { p -> ForecastEngine.weighted(p.f) }, 6, HIGH_RISK_TARGET_PROB
            )
        }
        val tiers = plan.tiers
        val order = plan.order
        val limit = plan.limit

        val pool = candidates.filter { eligible(it) }
        val notes = ArrayList<String>()
        val matchCount = pool.map { it.match.id }.distinct().size
        notes.add("Havuz: $matchCount maç, ${pool.size} oynanabilir seçim (0.5 Üst ve 4.5 Alt havuz dışı).")
        if (pool.isEmpty()) {
            notes.add("Analiz edilebilen maç yok (veri yetersiz, maçlar başlamış veya veri kaynağı yok).")
            return CouponOutcome(null, notes)
        }

        val chosen = LinkedHashMap<String, CouponPick>()   // maç başına en fazla bir seçim
        var usedTier = 0
        for ((i, t) in tiers.withIndex()) {
            val elig = pool.filter(t.test).sortedByDescending(order)
            val eligibleMatches = elig.map { it.match.id }.distinct().size
            val cap = if (i == 0) limit else minOf(limit, TARGET_PICKS + 1)
            var added = 0
            for (c in elig) {
                if (chosen.size >= cap) break
                if (!chosen.containsKey(c.match.id)) {
                    chosen[c.match.id] = c
                    added++
                    usedTier = i
                }
            }
            notes.add("${t.label}: $eligibleMatches maç uygun, $added seçim eklendi.")
            if (chosen.size >= TARGET_PICKS) break
        }

        if (chosen.size < MIN_PICKS) {
            notes.add("Kupon için en az $MIN_PICKS farklı maçta uygun seçim gerekir; ${chosen.size} bulundu. Kalite kriterleri bundan daha fazla düşürülmedi.")
            return CouponOutcome(null, notes)
        }
        if (usedTier > 0) notes.add("Yeterli seçim olmadığı için kriterler kontrollü şekilde esnetildi (kademe ${usedTier + 1}); düşük güvenli seçimler işaretli.")

        var picks = chosen.values.toList()
        val target = plan.targetProb
        if (target != null) {
            val trimmed = trimToTarget(picks, target)
            if (trimmed.size < picks.size) notes.add("Seçim sayısı, hedef tahmini gerçekleşmeye (≈${pctOf(target)}) yaklaşmak için ${picks.size}'den ${trimmed.size}'e indirildi.")
            picks = trimmed
        }
        val unpriced = picks.count { it.eval == null }
        val totalOdds = if (unpriced == 0) picks.fold(1.0) { acc, p -> acc * (p.eval?.odds ?: 1.0) } else null
        // Farklı maçlar yaklaşık bağımsız kabul edilir; aynı maçtan seçim yoktur.
        val prob = picks.fold(1.0) { acc, p -> acc * p.prob }
        val level = picks.minByOrNull { it.f.confidence.rank }?.f?.confidence ?: Confidence.LOW
        if (unpriced > 0) notes.add("$unpriced seçimde gerçek oran yok: toplam oran ve potansiyel kazanç hesaplanmadı.")
        if (target != null) notes.add("Hedef: tahmini gerçekleşme ≈ ${pctOf(target)} (model adil oranı ≈ ${"%.2f".format(java.util.Locale.US, 1.0 / target)}); gerçek oran girilmediği için oran gösterilmez.")
        return CouponOutcome(
            Coupon(type, picks, totalOdds, prob, riskLevel(prob), level, picks.count { it.f.confidence == Confidence.LOW }, unpriced, usedTier),
            notes
        )
    }

    private fun pctOf(p: Double): String = "%" + Math.round(p * 100)

    fun riskLevel(p: Double): String = when {
        p >= 0.40 -> "Düşük"
        p >= 0.15 -> "Orta"
        p >= 0.08 -> "Yüksek"
        else -> "Çok yüksek"
    }
}
