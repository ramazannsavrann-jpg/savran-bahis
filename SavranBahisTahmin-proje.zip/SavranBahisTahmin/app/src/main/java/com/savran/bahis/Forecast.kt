package com.savran.bahis

import kotlin.math.roundToInt

/** Güven seviyesi, tahmin olasılığından AYRIDIR: veri kalitesi ve pazar güvenilirliğinden gelir. */
enum class Confidence(val tr: String, val rank: Int) {
    HIGH("Yüksek", 3),
    MEDIUM("Orta", 2),
    LOW("Düşük", 1)
}

/**
 * Oran gerekmeden, yalnızca istatistik modelinden gelen tahmin.
 * odds/bookmaker/ev/decision yalnızca o seçenek için GERÇEK oran girilmişse doludur.
 */
data class Forecast(
    val matchId: String,
    val marketKey: String,
    val selectionKey: String,
    val prob: Double,
    val confidence: Confidence,
    val confidenceScore: Int,          // 0..100 (olasılık DEĞİL)
    val odds: Double?,
    val bookmaker: String?,
    val ev: Double?,
    val decision: Decision?,
    val reason: String,
    val dataQuality: Double = 0.0,     // tahminin dayandığı veri kalitesi (0..1)
    val rawProb: Double = prob         // kalibrasyon öncesi ham model olasılığı
)

data class Ladder(val title: String, val items: List<Pair<String, Double>>)

private fun pctText(p: Double): String = "%" + (p * 100).roundToInt()

object ForecastEngine {
    /** Veri kalitesi bunun altındaysa tahmin üretilmez (uydurmamak için). 0.25 ≈ en az 2 maç. */
    const val MIN_DATA_QUALITY = 0.25
    const val HIGH_AT = 80
    const val MEDIUM_AT = 55
    const val LOW_AT = 35

    /** Bundan yüksek olasılıklar çoğunlukla çok düşük orandır; "en güçlü" listesinde gösterilmez. */
    const val TRIVIAL_PROB = 0.95

    /**
     * Güven puanı: veri kalitesi (en ağır), veri kapsamı (kullanılan kriter oranı), model geçmişi, rotasyon riski;
     * pazar güvenilirliği çarpan. Tahmin olasılığı bu hesaba girmez.
     * dq=1, geçmiş yok, rotasyon yok, güvenilir pazar -> 93 (Yüksek).
     */
    fun confidenceScore(dq: Double, reliability: Double, history: Double?, rotationHigh: Boolean, coverage: Double = 1.0): Int {
        val raw = (45.0 * dq.coerceIn(0.0, 1.0) +
            10.0 * coverage.coerceIn(0.0, 1.0) +
            10.0 * (history ?: 0.5).coerceIn(0.0, 1.0) +
            (if (rotationHigh) 0.0 else 10.0)) / 75.0 * 100.0
        return (raw * (0.5 + 0.5 * reliability.coerceIn(0.0, 1.0))).toInt().coerceIn(0, 100)
    }

    fun level(score: Int): Confidence? = when {
        score >= HIGH_AT -> Confidence.HIGH
        score >= MEDIUM_AT -> Confidence.MEDIUM
        score >= LOW_AT -> Confidence.LOW
        else -> null
    }

    /** Sıralama için: olasılık, güvenle hafifçe ağırlıklandırılır. */
    fun weighted(f: Forecast): Double = f.prob * (0.6 + 0.4 * f.confidenceScore / 100.0)

    /** Tahmin neden yok? Nedeni açıkça söyler; veri çok azsa tahmin uydurmaz. */
    fun noForecastReason(ctx: AnalysisContext, modelNote: String): String? {
        if (ctx.model == null) return "Model çalışmadı: $modelNote"
        if (ctx.veryThin) return null
        if (ctx.dataQuality < MIN_DATA_QUALITY) {
            val h = ctx.homeGames
            val a = ctx.awayGames
            val detail = if (h != null && a != null) {
                " Analize giren maç sayısı: ev sahibi $h, deplasman takımı $a (her biri için en az 2 gerekir; toplam maç sayısı da yetmiyor)."
            } else ""
            return "Takım verisi çok az (veri kalitesi ${pctText(ctx.dataQuality)}); tahmin uydurmamak için üretilmedi.$detail"
        }
        return null
    }

    /** Modelin desteklediği tüm pazarlar için tahmin üretir. Korner/kart gibi modelsiz pazarlar atlanır. */
    fun generate(matchId: String, ctx: AnalysisContext, evals: List<Evaluation>): List<Forecast> {
        val model = ctx.model ?: return emptyList()
        if (ctx.dataQuality < MIN_DATA_QUALITY && !ctx.veryThin) return emptyList()
        val byKey = evals.associateBy { it.marketKey to it.selectionKey }
        // Kupada ClubElo uzun dönem verisi kullanıldıysa güven hesabı en az ELO_PRIOR_DQ veriyle yapılır (gösterilen "Veri %" değişmez).
        val confDq = if (ctx.eloPrior) maxOf(ctx.dataQuality, ELO_PRIOR_DQ) else ctx.dataQuality
        val out = ArrayList<Forecast>()
        for (market in MarketCatalog.all) {
            val reliability = OpportunityEngine.marketReliability(market.key)
            val weak = ctx.learning?.let { Calibration.group(market.key)?.let { g -> g in it.weak } } == true
            val goal = GoalModel.isGoalMarket(market.key)
            val m = ctx.modelFor(market.key) ?: model
            val score = (confidenceScore(confDq, reliability, ctx.historyScore, ctx.rotationHigh, ctx.coverage) -
                (if (weak) WEAK_MARKET_PENALTY else 0) - (if (ctx.thinData) THIN_DATA_PENALTY else 0) - (if (goal) GOAL_MARKET_PENALTY else 0))
                .coerceIn(0, 100)
                .let { if (ctx.cup) minOf(it, CUP_MAX_SCORE) else it }
                // 4 maçtan az veriyle (dq<0.5) güven en fazla Düşük: 2-3 maçlık örnek "Orta" sayılmaz.
                .let { if (confDq < ORTA_MIN_DQ) minOf(it, MEDIUM_AT - 1) else it }
                // Takım verisi neredeyse yok (lig ortalaması/Elo): güven en fazla "Düşük" alt sınırı.
                .let { if (ctx.veryThin) minOf(it, VERY_THIN_MAX_SCORE) else it }
            // Veri kapısı (MIN_DATA_QUALITY) geçildiyse tahmin üretilir; puan çok düşükse "Düşük" güvenle ve işaretli gösterilir.
            val level = level(score) ?: Confidence.LOW
            for (s in market.selections) {
                val p = MarketProb.prob(m, market.key, s.key) ?: continue
                val e = byKey[market.key to s.key]
                out.add(
                    Forecast(
                        matchId, market.key, s.key, p, level, score,
                        e?.odds, e?.bookmaker, e?.ev, e?.decision,
                        (if (ctx.veryThin) "Çok az veri: takım istatistiği çok az (gerekirse lig ortalaması/kulüp gücü kullanıldı); güven Düşük. " else "") +
                        "Poisson modeli: beklenen gol ${"%.2f".format(java.util.Locale.US, m.lambdaHome)}-${"%.2f".format(java.util.Locale.US, m.lambdaAway)}" +
                            (if (goal && m !== model) " (gol pazarı: temkinli gol modeli)" else "") + "; veri kalitesi ${pctText(ctx.dataQuality)}.",
                        ctx.dataQuality
                    )
                )
            }
        }
        return Calibrator.apply(out, ctx.learning)
    }

    /** Öğrenme sistemi bir pazar grubunu zayıf bulduysa (yeterli veriyle) güven puanı bu kadar düşer. */
    const val WEAK_MARKET_PENALTY = 20

    /** Toplam maç istatistiğine geçilen (iç saha/deplasman ayrımsız) analizlerde güven puanından düşülür. */
    const val THIN_DATA_PENALTY = 8

    /** Gol pazarlarında geri testte modelin basit lig ortalamasına üstünlüğü görülmedi: güven puanından düşülür. */
    const val GOAL_MARKET_PENALTY = 8

    /** Kupa + ClubElo birleşiminde güven hesabında kullanılan en az veri değeri (≈5 maç eşdeğeri; doğrulanmadı). */
    const val ELO_PRIOR_DQ = 0.6

    /** "Çok az veri" tahminlerinde güven puanı üst sınırı (Düşük). */
    const val VERY_THIN_MAX_SCORE = 35

    /** Bu veri kalitesinin (4 maç) altında güven "Orta"ya çıkamaz. */
    const val ORTA_MIN_DQ = 0.5

    /** Avrupa kupalarında güven en fazla Orta olur (74 < 80): takımların lig gücü farkı modelde yok. */
    const val CUP_MAX_SCORE = 74

    /**
     * Oynanabilir pazar mı? Toplam Gol 0.5 Üst ve 4.5 Alt için genellikle kullanılabilir oran yoktur;
     * kupon havuzundan ve filtreli tahmin listesinden çıkarılır (maç analizinde "tüm pazarlar"da görünür).
     */
    fun isPlayable(mk: String, sk: String): Boolean =
        !(mk == "ou_0.5" && sk == "over") && !(mk == "ou_4.5" && sk == "under") &&
            !(mk == "ht_ou_2.5" && sk == "under")      // İlk Yarı 2.5 Alt hiçbir koşulda önerilmez

    /** Bahis Fırsatları'nda gösterilecek en düşük güven seviyesi: yetersiz güvenli tahmin gösterilmez. */
    val MIN_SHOWN_CONFIDENCE: Confidence = Confidence.MEDIUM

    /** İki seçenekli pazarlarda en iyi seçenek yazı-turaya çok yakınsa (%55 altı) anlamlı tahmin sayılmaz. */
    const val BINARY_MIN_TOP_PROB = 0.55

    /**
     * %90 ve üzeri olasılıklar "bariz" sayılır: bahis şirketleri bunlara çoğu zaman oran bile vermez (veya ~1.10 altı verir),
     * yani bilgi vermez ve listenin başını doldurur. Bahis Fırsatları ve kupon havuzunda yer almaz; maç ekranındaki "Tüm pazarlar"da görünür.
     */
    const val OBVIOUS_PROB = 0.90

    fun isBinary(mk: String): Boolean = MarketCatalog.find(mk)?.selections?.size == 2

    /**
     * Her maçın her pazarında yalnızca en yüksek olasılıklı seçenek. Birbirine alternatif seçenekler
     * (ör. KG Var/Yok, 2.5 Üst/Alt, 1/X/2) karşılaştırılır; düşük olasılıklı alternatif gösterilmez.
     */
    fun bestPerMarket(list: List<Forecast>): List<Forecast> =
        list.groupBy { it.matchId + "|" + it.marketKey }
            .mapNotNull { (_, l) -> l.maxByOrNull { it.prob } }

    /**
     * Bahis Fırsatları: pazar başına en iyi seçenek; SONRA yasaklı seçenekler elenir (yasaklı seçenek
     * en iyiyse pazar tamamen düşer, düşük olasılıklı alternatif gösterilmez), yetersiz güven elenir.
     */
    fun bahisFirsatlari(list: List<Forecast>): List<Forecast> =
        bestPerMarket(list).filter {
            isPlayable(it.marketKey, it.selectionKey) &&
                it.prob < OBVIOUS_PROB &&
                it.confidence.rank >= MIN_SHOWN_CONFIDENCE.rank &&
                (!isBinary(it.marketKey) || it.prob >= BINARY_MIN_TOP_PROB)
        }

    /**
     * Kullanıcıya gösterilen liste: önce katı kural (en az Orta güven). Hiçbir seçenek bu kuralı geçmiyorsa
     * (veri az: kupa başı, sezon başı) boş bırakmak yerine, yine pazar başına en yüksek olasılıklı ve oynanabilir
     * seçenekler "Düşük güven" etiketiyle gösterilir. Geçmiş/öğrenme kaydı bu listeyi KULLANMAZ (bahisFirsatlari kullanılır).
     */
    fun shownWithFallback(list: List<Forecast>): List<Forecast> {
        val strict = bahisFirsatlari(list)
        if (strict.isNotEmpty()) return strict
        return bestPerMarket(list).filter {
            isPlayable(it.marketKey, it.selectionKey) && it.prob < OBVIOUS_PROB &&
                (!isBinary(it.marketKey) || it.prob >= BINARY_MIN_TOP_PROB)
        }
    }

    /** Aynı yöndeki seçenekler aynı aileye girer (ör. tüm "toplam gol Üst" çizgileri). */
    fun family(mk: String, sk: String): String = when {
        mk == "1x2" || mk == "dc" -> "result"
        mk.startsWith("ou_") -> "goals-$sk"
        mk.startsWith("home_ou_") -> "home-goals-$sk"
        mk.startsWith("away_ou_") -> "away-goals-$sk"
        mk == "btts" -> "btts-$sk"
        mk.startsWith("ht_ou_") -> "ht-goals-$sk"
        mk.startsWith("ht_") -> "ht-other"
        else -> "$mk-$sk"
    }

    /** Her aileden en güçlü seçenek; sonra ağırlıklı olasılığa göre ilk n. */
    fun strongest(list: List<Forecast>, n: Int): List<Forecast> =
        list.filter { it.prob < TRIVIAL_PROB }
            .groupBy { family(it.marketKey, it.selectionKey) }
            .mapNotNull { (_, l) -> l.maxByOrNull { weighted(it) } }
            .sortedByDescending { weighted(it) }
            .take(n)

    /** Çizgi merdivenleri: 2.5 Üst zayıfsa 1.5 Üst daha güçlü olabilir; kullanıcı yan yana görür. */
    fun ladders(list: List<Forecast>): List<Ladder> {
        fun ladder(title: String, prefix: String, sk: String, word: String): Ladder {
            val items = list.filter { it.marketKey.startsWith(prefix) && it.selectionKey == sk }
                .mapNotNull { f -> f.marketKey.substringAfterLast('_').toDoubleOrNull()?.let { it to f.prob } }
                .sortedBy { it.first }
                .map { (line, p) -> "$line $word" to p }
            return Ladder(title, items)
        }
        return listOf(
            ladder("Toplam gol Üst", "ou_", "over", "Üst"),
            ladder("Toplam gol Alt", "ou_", "under", "Alt"),
            ladder("Ev sahibi gol Üst", "home_ou_", "over", "Üst"),
            ladder("Deplasman gol Üst", "away_ou_", "over", "Üst"),
            ladder("İlk yarı gol Üst", "ht_ou_", "over", "Üst")
        ).filter { it.items.size >= 2 }
    }
}
