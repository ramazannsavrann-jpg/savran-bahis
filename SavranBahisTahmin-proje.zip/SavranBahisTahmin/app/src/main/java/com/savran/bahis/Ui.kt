@file:OptIn(ExperimentalMaterial3Api::class)

package com.savran.bahis

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import java.time.Instant
import java.time.format.DateTimeFormatter
import java.util.Locale
import kotlin.math.roundToInt

val GreenOk = Color(0xFF3DDC84)
val AmberWarn = Color(0xFFFFB74D)
val RedBad = Color(0xFFEF5350)
val MutedText = Color(0xFF9AA7B5)

@Composable
fun SavranTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = GreenOk,
            onPrimary = Color(0xFF062012),
            background = Color(0xFF0E1621),
            onBackground = Color(0xFFE8EEF4),
            surface = Color(0xFF16222F),
            onSurface = Color(0xFFE8EEF4),
            surfaceVariant = Color(0xFF1E2D3D),
            onSurfaceVariant = Color(0xFFB8C4D0),
            secondary = AmberWarn,
            error = RedBad
        )
    ) {
        Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) { content() }
    }
}

fun pct(p: Double): String = "%" + (p * 100).roundToInt()
fun odd2(o: Double): String = "%.2f".format(Locale.US, o)

private val timeFmt: DateTimeFormatter = DateTimeFormatter.ofPattern("d MMM HH:mm", Locale.forLanguageTag("tr"))
val dayFmt: DateTimeFormatter = DateTimeFormatter.ofPattern("d MMM", Locale.forLanguageTag("tr"))
val hourFmt: DateTimeFormatter = DateTimeFormatter.ofPattern("HH:mm")

fun kickoffText(m: Match, repo: Repository): String =
    Instant.ofEpochSecond(m.kickoff).atZone(repo.zone).format(timeFmt)

fun clockText(epochMs: Long, repo: Repository): String =
    Instant.ofEpochMilli(epochMs).atZone(repo.zone).format(hourFmt)

@Composable
fun AppBar(title: String, onBack: (() -> Unit)?, actions: @Composable RowScope.() -> Unit = {}) {
    TopAppBar(
        title = { Text(title, maxLines = 1, overflow = TextOverflow.Ellipsis, fontSize = 18.sp) },
        navigationIcon = {
            if (onBack != null) IconButton(onClick = onBack) { Text("←", fontSize = 22.sp) }
        },
        actions = actions
    )
}

@Composable
fun InfoCard(title: String, text: String, warn: Boolean = false) {
    Card(
        Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = if (warn) Color(0xFF3A2E14) else MaterialTheme.colorScheme.surfaceVariant)
    ) {
        Column(Modifier.padding(12.dp)) {
            Text(title, fontWeight = FontWeight.Bold, color = if (warn) AmberWarn else MaterialTheme.colorScheme.onSurface)
            Spacer(Modifier.height(4.dp))
            Text(text, fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

@Composable
fun SectionTitle(text: String) {
    Text(text, fontWeight = FontWeight.Bold, fontSize = 16.sp, color = GreenOk, modifier = Modifier.padding(top = 8.dp))
}

@Composable
fun <T> ChipRow(items: List<T>, selected: T?, label: (T) -> String, onSelect: (T) -> Unit) {
    Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        items.forEach { item ->
            FilterChip(selected = item == selected, onClick = { onSelect(item) }, label = { Text(label(item), maxLines = 1) })
        }
    }
}

@Composable
fun TeamLogo(url: String?) {
    if (url != null) {
        AsyncImage(model = url, contentDescription = null, modifier = Modifier.size(24.dp))
    } else {
        Box(Modifier.size(24.dp).background(Color(0xFF2B3E52), CircleShape))
    }
}

@Composable
fun Tag(text: String, color: Color) {
    Text(
        text, color = color, fontSize = 12.sp, fontWeight = FontWeight.Bold, maxLines = 1,
        modifier = Modifier.background(color.copy(alpha = 0.15f), CircleShape).padding(horizontal = 10.dp, vertical = 3.dp)
    )
}

fun decisionColor(d: Decision): Color = when (d) {
    Decision.RECOMMEND -> GreenOk
    Decision.LOW_EDGE, Decision.STALE_ODDS -> AmberWarn
    Decision.LOW_ODDS, Decision.NO_DATA -> MutedText
}

@Composable
fun EvalCard(e: Evaluation, repo: Repository, kickoff: Long, title: String? = null) {
    var open by remember { mutableStateOf(false) }
    val now = System.currentTimeMillis()
    Card(Modifier.fillMaxWidth().clickable { open = !open }) {
        Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            if (title != null) Text(title, fontSize = 12.sp, color = MutedText, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    MarketCatalog.marketTitle(e.marketKey) + " · " + MarketCatalog.selectionLabel(e.marketKey, e.selectionKey),
                    fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f), maxLines = 2, overflow = TextOverflow.Ellipsis
                )
                Spacer(Modifier.width(8.dp))
                Text(odd2(e.odds), fontWeight = FontWeight.Bold, fontSize = 18.sp)
            }
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Tag(e.decision.tr, decisionColor(e.decision))
                if (e.highRisk) Tag("Yüksek risk", RedBad)
                Spacer(Modifier.weight(1f))
                if (e.quality != null) Text("Kalite ${e.quality}/100", fontSize = 13.sp, fontWeight = FontWeight.Bold)
            }
            if (e.adjProb != null) {
                val ev = e.ev?.let { " · EV " + (if (it >= 0) "+" else "") + "%.1f".format(Locale.US, it * 100) + "%" } ?: ""
                Text("Tahmin ${pct(e.adjProb)} · Oran zımni ${pct(e.impliedProb)}$ev", fontSize = 13.sp)
            }
            Text(e.reason, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            if (open) {
                val stale = OddsFreshness.isStale(e.updatedAt, now, kickoff)
                Text(
                    "Kaynak: ${e.origin} · ${e.bookmaker} · ${OddsFreshness.ageLabel(e.updatedAt, now)} (${clockText(e.updatedAt, repo)})" +
                        if (stale) " · ESKİ" else "",
                    fontSize = 12.sp, color = if (stale) AmberWarn else MutedText
                )
                if (e.modelProb != null) Text("Ham model olasılığı ${pct(e.modelProb)}" + (e.fairProb?.let { " · Marjsız piyasa ${pct(it)}" } ?: " · Piyasa doğrulaması yok"), fontSize = 12.sp, color = MutedText)
                e.breakdown?.let { b ->
                    Text(
                        "Kalite dağılımı: EV ${b.ev.roundToInt()}/30 · Avantaj ${b.edge.roundToInt()}/15 · Olasılık ${b.prob.roundToInt()}/10 · " +
                            "Veri ${b.data.roundToInt()}/15 · Güncellik ${b.fresh.roundToInt()}/10 · Pazar ${b.market.roundToInt()}/10 · " +
                            "Model geçmişi ${b.history.roundToInt()}/10 · Ceza -${b.penalty.roundToInt()}",
                        fontSize = 12.sp, color = MutedText
                    )
                }
                Text("Kalite puanı kazanma olasılığı değildir; yüksek puan kazanç garantisi vermez.", fontSize = 11.sp, color = MutedText)
            }
        }
    }
}

// ------------------------------------------------------------------------- Ana ekran

private data class Tile(val title: String, val sub: String, val target: Screen)

@Composable
fun HomeScreen(repo: Repository, push: (Screen) -> Unit) {
    val tiles = listOf(
        Tile("1. Bugünün Maçları", "6 lig · oran gir · analiz et", Screen.Matches(0, "Bugünün Maçları")),
        Tile("2. Yarınki Maçlar", "Yarının fikstürü", Screen.Matches(1, "Yarınki Maçlar")),
        Tile("3. Maç Analizi", "Maç seç: model, olasılık, rotasyon, canlı", Screen.Matches(0, "Analiz için maç seç")),
        Tile("4. Bahis Fırsatları", "Oranı girilmiş tüm maçları tara", Screen.Opportunities),
        Tile("5. Kupon Laboratuvarı", "Dengeli · Sürpriz · Değer", Screen.Coupons),
        Tile("6. Tahmin Geçmişi", "Kayıtlı tahminler ve sonuçları", Screen.History),
        Tile("7. Model Performansı", "Brier, log loss, kalibrasyon, birim getiri", Screen.Performance),
        Tile("8. Ayarlar", "API anahtarları, kota, önbellek", Screen.Settings)
    )
    Scaffold(topBar = { AppBar("Savran Bahis Tahmin", null) }) { pad ->
        LazyColumn(
            Modifier.padding(pad).fillMaxSize(),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            item {
                if (repo.settings.apiKey == null) {
                    InfoCard("API anahtarı girilmedi", "Ayarlar'dan API-Football anahtarını ekle veya maçları elle ekle.", warn = true)
                }
            }
            items(tiles) { t ->
                Card(Modifier.fillMaxWidth().clickable { push(t.target) }) {
                    Column(Modifier.padding(14.dp)) {
                        Text(t.title, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                        Text(t.sub, fontSize = 13.sp, color = MutedText)
                    }
                }
            }
            item {
                Text(
                    "Bu uygulama analiz ve karar desteğidir. Kesin kazanç, garanti kupon veya kayıpsız bahis iddiası taşımaz. Bahis kararı ve riski sana aittir.",
                    fontSize = 11.sp, color = MutedText
                )
            }
        }
    }
}

// ------------------------------------------------------------------------- Maç listesi

@Composable
fun MatchesScreen(repo: Repository, initialOffset: Int, title: String, push: (Screen) -> Unit, pop: () -> Unit) {
    var offset by remember { mutableStateOf(initialOffset) }
    var leagueFilter by remember { mutableStateOf<Int?>(null) }
    var data by remember { mutableStateOf<DayMatches?>(null) }
    var counts by remember { mutableStateOf<Map<String, Int>>(emptyMap()) }
    var loading by remember { mutableStateOf(false) }
    var tick by remember { mutableStateOf(0) }
    var force by remember { mutableStateOf(false) }

    LaunchedEffect(offset, tick) {
        loading = true
        val f = force
        force = false
        data = repo.matchesForDate(repo.today().plusDays(offset.toLong()), f)
        counts = repo.oddsCounts()
        loading = false
    }

    Scaffold(topBar = {
        AppBar(title, pop) {
            TextButton(onClick = { force = true; tick++ }) { Text("Yenile") }
            TextButton(onClick = { push(Screen.AddMatch) }) { Text("+ Maç") }
        }
    }) { pad ->
        Column(Modifier.padding(pad).fillMaxSize().padding(horizontal = 12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            ChipRow(listOf(-1, 0, 1, 2, 3), offset, { o ->
                when (o) {
                    -1 -> "Dün"
                    0 -> "Bugün"
                    1 -> "Yarın"
                    else -> repo.today().plusDays(o.toLong()).format(dayFmt)
                }
            }) { offset = it }
            ChipRow(listOf<Int?>(null) + Leagues.supported.map { it.id }, leagueFilter, { id ->
                if (id == null) "Tümü" else Leagues.byId(id)?.nameTr ?: "Lig"
            }) { leagueFilter = it }

            val d = data
            if (loading) Box(Modifier.fillMaxWidth().padding(16.dp), contentAlignment = Alignment.Center) { CircularProgressIndicator() }
            if (d?.notice != null) InfoCard("Bilgi", d.notice, warn = true)
            if (d?.fetchedAt != null) {
                Text(
                    "Maç listesi: ${clockText(d.fetchedAt, repo)}" + if (d.fromCache) " (önbellek)" else "",
                    fontSize = 11.sp, color = MutedText
                )
            }
            val list = d?.matches.orEmpty().filter { leagueFilter == null || it.leagueId == leagueFilter }
            if (!loading && d != null && list.isEmpty() && d.notice == null) {
                Text("Bu gün için maç bulunamadı (6 lig). İstersen \"+ Maç\" ile elle ekleyebilirsin.", color = MutedText)
            }
            LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp), contentPadding = PaddingValues(bottom = 16.dp)) {
                items(list, key = { it.id }) { m -> MatchRow(m, repo, counts[m.id] ?: 0) { push(Screen.Detail(m)) } }
            }
        }
    }
}

@Composable
fun MatchRow(m: Match, repo: Repository, oddsCount: Int, onClick: () -> Unit) {
    Card(Modifier.fillMaxWidth().clickable(onClick = onClick)) {
        Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(m.leagueName, fontSize = 12.sp, color = MutedText, modifier = Modifier.weight(1f), maxLines = 1, overflow = TextOverflow.Ellipsis)
                val status = when {
                    StatusText.isLive(m.statusShort) -> "${StatusText.tr(m.statusShort)}${m.elapsed?.let { " $it'" } ?: ""}"
                    StatusText.isFinished(m.statusShort) -> "Bitti"
                    m.statusShort == "NS" -> kickoffText(m, repo)
                    else -> StatusText.tr(m.statusShort)
                }
                Text(status, fontSize = 12.sp, color = if (StatusText.isLive(m.statusShort)) GreenOk else MutedText, maxLines = 1)
            }
            Row(verticalAlignment = Alignment.CenterVertically) {
                TeamLogo(m.homeLogo); Spacer(Modifier.width(8.dp))
                Text(m.home, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f), maxLines = 1, overflow = TextOverflow.Ellipsis)
                Text(m.homeGoals?.toString() ?: "", fontWeight = FontWeight.Bold)
            }
            Row(verticalAlignment = Alignment.CenterVertically) {
                TeamLogo(m.awayLogo); Spacer(Modifier.width(8.dp))
                Text(m.away, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f), maxLines = 1, overflow = TextOverflow.Ellipsis)
                Text(m.awayGoals?.toString() ?: "", fontWeight = FontWeight.Bold)
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                if (oddsCount > 0) Tag("$oddsCount oran", GreenOk) else Tag("oran yok", MutedText)
                if (m.source == "Manuel") Tag("Manuel", AmberWarn)
            }
        }
    }
}
