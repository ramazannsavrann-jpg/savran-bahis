package com.savran.bahis

data class Match(
    val id: String,            // "api-123" veya "man-<uuid>"
    val leagueId: Int,         // API-Football lig no; elle eklenen "diğer" ligler için 0
    val leagueName: String,
    val home: String,
    val away: String,
    val kickoff: Long,         // epoch saniye
    val statusShort: String,   // NS, 1H, HT, 2H, FT ...
    val homeGoals: Int?,
    val awayGoals: Int?,
    val homeLogo: String?,
    val awayLogo: String?,
    val source: String,        // "API-Football" veya "Manuel"
    val homeId: Int = 0,       // API-Football takım no (yoksa 0)
    val awayId: Int = 0,
    val homeHt: Int? = null,   // devre skoru
    val awayHt: Int? = null,
    val elapsed: Int? = null,  // canlı maçta dakika
    val venueCity: String? = null  // stadın şehri (API-Football); hava durumu notu için
)

/** Bir bahis oranı kaydı. Oran her zaman bir kaynağa ve bir güncellenme zamanına bağlıdır. */
data class OddsEntry(
    val id: String,
    val matchId: String,
    val marketKey: String,
    val selectionKey: String,
    val odds: Double,
    val bookmaker: String,     // oranın alındığı şirket/kaynak adı (kullanıcının yazdığı)
    val origin: String,        // "Manuel" (ileride başka sağlayıcılar)
    val updatedAt: Long        // epoch milisaniye
)

object Leagues {
    data class League(val id: Int, val nameTr: String)

    val supported = listOf(
        League(203, "Süper Lig"),
        League(204, "1. Lig"),
        League(39, "Premier League"),
        League(78, "Bundesliga"),
        League(140, "La Liga"),
        League(61, "Ligue 1"),
        League(135, "Serie A"),
        League(2, "Şampiyonlar Ligi"),
        League(3, "Avrupa Ligi"),
        League(848, "Konferans Ligi")
    )

    fun byId(id: Int): League? = supported.firstOrNull { it.id == id }

    /** UEFA kupaları: puan durumu yerine turnuva tablosu; ligler arası güç farkı modele girmez. */
    fun isCup(id: Int): Boolean = id == 2 || id == 3 || id == 848
}

object StatusText {
    fun tr(short: String): String = when (short) {
        "NS", "TBD" -> "Başlamadı"
        "1H" -> "1. Yarı"
        "HT" -> "Devre Arası"
        "2H" -> "2. Yarı"
        "ET", "BT", "P" -> "Uzatma"
        "FT", "AET", "PEN" -> "Bitti"
        "PST" -> "Ertelendi"
        "CANC" -> "İptal"
        "SUSP", "INT" -> "Durduruldu"
        "ABD" -> "Yarıda Kaldı"
        "AWD", "WO" -> "Hükmen"
        "LIVE" -> "Canlı"
        else -> short
    }

    fun isLive(short: String) = short in setOf("1H", "HT", "2H", "ET", "BT", "P", "LIVE")
    fun isFinished(short: String) = short in setOf("FT", "AET", "PEN", "AWD", "WO")
}
