package com.savran.bahis

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.compositeOver
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.util.Locale

object Summary {
    /** Geri testte üstünlüğü kanıtlanan pazarlar (maç sonucu, çifte şans) özet sıralamasında öne alınır. */
    private fun proven(mk: String) = mk == "1x2"

    /** Farklı pazarlardan en güçlü 3 tahmin (oynanabilir, bariz olmayan). */
    fun top(forecasts: List<Forecast>, n: Int = 3): List<Forecast> =
        MarketFilters.shown(forecasts)
            .sortedByDescending { ForecastEngine.weighted(it) + if (proven(it.marketKey)) 0.05 else 0.0 }
            .distinctBy { Calibration.group(it.marketKey) ?: it.marketKey }
            .take(n)
}

/** Maç ekranının en üstünde: beklenen/en olası skor, 1-X-2 şeridi, öne çıkan 3 tahmin, veri ve piyasa özeti. */
@Composable
fun SummaryCard(a: AnalysisResult) {
    val lh = a.lambdaHome
    val la = a.lambdaAway
    Card(
        Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = AccentBlue.copy(alpha = 0.10f).compositeOver(Color(0xFF121C2E)))
    ) {
        Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Text("Maç özeti", fontWeight = FontWeight.Bold, fontSize = 16.sp)
            if (lh == null || la == null) {
                Text(a.forecastNote ?: "Bu maç için model çalışmadı.", fontSize = 12.sp, color = MutedText)
                return@Column
            }
            Row {
                Text("Beklenen skor", fontSize = 12.sp, color = MutedText, modifier = Modifier.weight(1f))
                Text("${"%.1f".format(Locale.US, lh)} – ${"%.1f".format(Locale.US, la)}", fontWeight = FontWeight.Bold)
            }
            a.topScores.firstOrNull()?.let { (h, aw, p) ->
                Row {
                    Text("En olası skor", fontSize = 12.sp, color = MutedText, modifier = Modifier.weight(1f))
                    Text("$h-$aw (${pct(p)})", fontWeight = FontWeight.Bold)
                }
            }
            if (a.core.size >= 3) OneXTwoStrip(a.core[0].prob, a.core[1].prob, a.core[2].prob)
            val top = Summary.top(a.forecasts)
            if (top.isNotEmpty()) {
                Text("Öne çıkan tahminler", fontSize = 12.sp, color = MutedText)
                top.forEach { f ->
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        ProbRing(f.prob, confidenceColor(f.confidence), 40.dp)
                        Column(Modifier.weight(1f)) {
                            Text(MarketFilters.shortLabel(f.marketKey, f.selectionKey), fontWeight = FontWeight.Bold, fontSize = 14.sp)
                            Text(MarketCatalog.marketTitle(f.marketKey), fontSize = 11.sp, color = MutedText)
                        }
                        Tag(f.confidence.tr, confidenceColor(f.confidence))
                    }
                    val m = a.marketProb(f)
                    if (m != null) {
                        val d = f.prob - m
                        Text(
                            "Piyasa ${pct(m)} · " + when {
                                d >= 0.05 -> "model piyasadan belirgin yüksek"
                                d <= -0.05 -> "model piyasadan belirgin düşük"
                                else -> "piyasayla uyumlu"
                            },
                            fontSize = 11.sp, color = if (d >= 0.05) GreenOk else if (d <= -0.05) RedBad else MutedText
                        )
                    }
                }
            } else {
                Text(a.forecastNote ?: "Gösterilecek güçlü tahmin yok.", fontSize = 12.sp, color = MutedText)
            }
            Text(
                "Veri: ${if (a.dataQuality < ForecastEngine.MIN_DATA_QUALITY) "çok az" else pct(a.dataQuality)}" +
                    " · Olasılık, güven ve veri kalitesi ayrı ölçülerdir; garanti yoktur.",
                fontSize = 11.sp, color = MutedText
            )
        }
    }
}
