package com.savran.bahis

import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.time.LocalDate
import java.time.LocalTime
import java.time.ZoneId

/**
 * openfootball/football.json (GitHub, ücretsiz, anahtarsız, kamu malı veri): sezon maç sonuçları.
 * Geri test (geçen sezon) ve diğer kaynaklar tablo veremezse yedek tablo için kullanılır.
 * Not: gönüllü projedir, güncel sezon geriden gelebilir; bu yüzden güncel sezonda yalnızca son maçı yakın tarihli ise kullanılır.
 */
class OpenFootballSource(private val dir: File) {
    @Volatile var status: String = "Henüz denenmedi"
        private set

    suspend fun results(leagueId: Int, season: Int): ApiResult<List<FinishedResult>> = withContext(Dispatchers.IO) {
        val code = codes[leagueId] ?: return@withContext ApiResult.Err("openfootball bu ligi kapsamıyor.")
        val folder = seasonFolder(season)
        dir.mkdirs()
        val f = File(dir, "${code}_$folder.json")
        val now = System.currentTimeMillis()
        if (f.exists() && now - f.lastModified() < 12L * 3600 * 1000) {
            val r = try { parse(f.readText()) } catch (e: Exception) { emptyList() }
            if (r.isNotEmpty()) {
                status = "Önbellekten: $code $folder (${r.size} maç)"
                return@withContext ApiResult.Ok(r)
            }
        }
        try {
            val resp = Http.get("https://raw.githubusercontent.com/openfootball/football.json/master/$folder/$code.json")
            if (resp.code == 404) {
                status = "Bu sezon dosyası yok ($code $folder)"
                return@withContext staleOr(f, "openfootball'da $folder sezonu için ${code} dosyası yok.")
            }
            if (resp.code !in 200..299) {
                status = "HTTP ${resp.code}"
                return@withContext staleOr(f, "openfootball hatası (${resp.code}).")
            }
            val r = parse(resp.body)
            if (r.isNotEmpty()) atomicWrite(f, resp.body)
            status = "Alındı: $code $folder (${r.size} maç)"
            ApiResult.Ok(r)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            status = "Ulaşılamadı (${e.javaClass.simpleName})"
            staleOr(f, "openfootball'a ulaşılamadı.")
        }
    }

    private fun staleOr(f: File, msg: String): ApiResult<List<FinishedResult>> {
        if (f.exists()) {
            val r = try { parse(f.readText()) } catch (e: Exception) { emptyList() }
            if (r.isNotEmpty()) return ApiResult.Ok(r)
        }
        return ApiResult.Err(msg)
    }

    companion object {
        /** API-Football lig no -> openfootball lig kodu. */
        val codes = mapOf(203 to "tr.1", 39 to "en.1", 78 to "de.1", 140 to "es.1", 61 to "fr.1", 135 to "it.1", 2 to "uefa.cl")
        // Not: Avrupa Ligi ve Konferans Ligi openfootball'da yok; ŞL için de her sezon dosyası bulunmayabilir.

        /** 2025 -> "2025-26". */
        fun seasonFolder(season: Int): String = "$season-%02d".format((season + 1) % 100)

        private val zone: ZoneId = ZoneId.of("Europe/London")
        private val COUNTRY_SUFFIX = Regex("""\s*\([A-Z]{2,3}\)$""")

        private fun ft(m: JSONObject): Pair<Int, Int>? {
            val s = m.opt("score") ?: return null
            val arr: JSONArray? = when (s) {
                is JSONObject -> s.optJSONArray("ft")
                is JSONArray -> s
                else -> null
            }
            if (arr == null || arr.length() < 2 || arr.isNull(0) || arr.isNull(1)) return null
            return try { arr.getInt(0) to arr.getInt(1) } catch (e: Exception) { null }
        }

        /** Yalnızca skoru olan maçlar; bozuk kayıt atlanır. "matches" veya "rounds[].matches" biçimi. */
        fun parse(json: String): List<FinishedResult> {
            val root = JSONObject(json)
            val all = ArrayList<JSONObject>()
            root.optJSONArray("matches")?.let { a -> for (i in 0 until a.length()) a.optJSONObject(i)?.let { all.add(it) } }
            root.optJSONArray("rounds")?.let { rs ->
                for (i in 0 until rs.length()) rs.optJSONObject(i)?.optJSONArray("matches")?.let { a ->
                    for (j in 0 until a.length()) a.optJSONObject(j)?.let { all.add(it) }
                }
            }
            val out = ArrayList<FinishedResult>()
            for (m in all) {
                val sc = ft(m) ?: continue
                // Kupa dosyalarında takım adının sonunda ülke kodu olur: "Arsenal FC (ENG)" -> "Arsenal FC".
                val home = m.optString("team1").trim().replace(COUNTRY_SUFFIX, "")
                val away = m.optString("team2").trim().replace(COUNTRY_SUFFIX, "")
                if (home.isEmpty() || away.isEmpty()) continue
                val date = try { LocalDate.parse(m.optString("date")) } catch (e: Exception) { continue }
                val time = try { LocalTime.parse(m.optString("time")) } catch (e: Exception) { LocalTime.NOON }
                out.add(FinishedResult(home, away, sc.first, sc.second, date.atTime(time).atZone(zone).toEpochSecond()))
            }
            return out
        }
    }
}
