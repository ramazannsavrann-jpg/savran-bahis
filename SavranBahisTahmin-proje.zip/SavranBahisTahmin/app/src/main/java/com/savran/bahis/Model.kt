package com.savran.bahis

import kotlin.math.exp
import kotlin.math.max
import kotlin.math.min

object Poisson {
    fun pmf(lambda: Double, maxK: Int): DoubleArray {
        val r = DoubleArray(maxK + 1)
        r[0] = exp(-lambda)
        for (k in 1..maxK) r[k] = r[k - 1] * lambda / k
        return r
    }
}

/**
 * Bağımsız Poisson skor modeli. Tam maç ve ilk yarı skor matrisleri ile
 * devre/maç ortak dağılımı aynı λ'lardan türetilir (tutarlıdır).
 */
class ScoreModel(val lambdaHome: Double, val lambdaAway: Double, val htShare: Double = 0.45) {
    companion object { const val N = 10 }

    val ft: Array<DoubleArray> = matrix(lambdaHome, lambdaAway)
    val ht: Array<DoubleArray> by lazy { matrix(lambdaHome * htShare, lambdaAway * htShare) }

    /** "1/1", "1/X" ... ilk yarı sonucu / maç sonucu ortak olasılıkları. */
    val htft: Map<String, Double> by lazy {
        val h2 = matrix(lambdaHome * (1 - htShare), lambdaAway * (1 - htShare))
        val out = HashMap<String, Double>()
        for (a in 0..N) for (b in 0..N) {
            val p1 = ht[a][b]
            if (p1 < 1e-9) continue
            for (c in 0..N) for (d in 0..N) {
                val key = Outcomes.res(a - b) + "/" + Outcomes.res(a + c - (b + d))
                out[key] = (out[key] ?: 0.0) + p1 * h2[c][d]
            }
        }
        val total = out.values.sum()
        out.mapValues { it.value / total }
    }

    private fun matrix(lh: Double, la: Double): Array<DoubleArray> {
        val ph = Poisson.pmf(lh, N)
        val pa = Poisson.pmf(la, N)
        val m = Array(N + 1) { h -> DoubleArray(N + 1) { a -> ph[h] * pa[a] } }
        var total = 0.0
        for (row in m) for (v in row) total += v
        for (row in m) for (i in row.indices) row[i] = row[i] / total
        return m
    }

    fun sum(m: Array<DoubleArray>, pred: (Int, Int) -> Boolean): Double {
        var s = 0.0
        for (h in 0..N) for (a in 0..N) if (pred(h, a)) s += m[h][a]
        return s
    }

    /** En olası skorlar (tam maç). */
    fun topScores(n: Int): List<Triple<Int, Int, Double>> {
        val all = ArrayList<Triple<Int, Int, Double>>()
        for (h in 0..N) for (a in 0..N) all.add(Triple(h, a, ft[h][a]))
        return all.sortedByDescending { it.third }.take(n)
    }
}

/** Bir bahis seçeneğinin gerçek skora göre kazanıp kazanmadığı. Desteklenmeyen pazar: null. */
object Outcomes {
    fun res(d: Int): String = if (d > 0) "1" else if (d == 0) "X" else "2"

    private fun dcSet(sk: String): Set<String>? = when (sk) {
        "1X" -> setOf("1", "X")
        "12" -> setOf("1", "2")
        "X2" -> setOf("X", "2")
        else -> null
    }

    private fun overUnder(total: Int, line: Double, sk: String): Boolean? = when (sk) {
        "over" -> total > line
        "under" -> total < line
        else -> null
    }

    fun eval(mk: String, sk: String, fh: Int, fa: Int, hh: Int?, ha: Int?): Boolean? {
        val line = mk.substringAfterLast('_').toDoubleOrNull()
        return when {
            mk == "1x2" -> res(fh - fa) == sk
            mk == "dc" -> dcSet(sk)?.contains(res(fh - fa))
            mk.startsWith("ou_") && line != null -> overUnder(fh + fa, line, sk)
            mk.startsWith("home_ou_") && line != null -> overUnder(fh, line, sk)
            mk.startsWith("away_ou_") && line != null -> overUnder(fa, line, sk)
            mk == "btts" -> (fh > 0 && fa > 0) == (sk == "yes")
            mk == "ht_1x2" -> if (hh == null || ha == null) null else res(hh - ha) == sk
            mk == "ht_dc" -> if (hh == null || ha == null) null else dcSet(sk)?.contains(res(hh - ha))
            mk.startsWith("ht_ou_") && line != null -> if (hh == null || ha == null) null else overUnder(hh + ha, line, sk)
            mk == "ht_btts" -> if (hh == null || ha == null) null else (hh > 0 && ha > 0) == (sk == "yes")
            mk == "htft" -> if (hh == null || ha == null) null else sk == res(hh - ha) + "/" + res(fh - fa)
            mk == "cs" -> if (sk == "other") (fh > 3 || fa > 3) else sk == "$fh-$fa"
            mk == "combo_1x2_ou25" -> {
                val p = sk.split("_")
                if (p.size != 2) null else res(fh - fa) == p[0] && ((fh + fa) > 2.5) == (p[1] == "over")
            }
            mk == "combo_1x2_btts" -> {
                val p = sk.split("_")
                if (p.size != 2) null else res(fh - fa) == p[0] && (fh > 0 && fa > 0) == (p[1] == "yes")
            }
            mk == "hcp_home_minus1" -> res(fh - 1 - fa) == sk
            mk == "hcp_home_plus1" -> res(fh + 1 - fa) == sk
            else -> null   // korner, kart vb.: istatistik/model yok
        }
    }
}

object MarketProb {
    /** null = bu pazar için modelimiz yok (veri yetersiz). Sahte olasılık üretilmez. */
    fun prob(m: ScoreModel, mk: String, sk: String): Double? {
        if (Outcomes.eval(mk, sk, 0, 0, 0, 0) == null) return null
        return when {
            mk == "htft" -> m.htft[sk] ?: 0.0
            mk.startsWith("ht_") -> m.sum(m.ht) { h, a -> Outcomes.eval(mk, sk, 0, 0, h, a) == true }
            else -> m.sum(m.ft) { h, a -> Outcomes.eval(mk, sk, h, a, null, null) == true }
        }
    }
}

/** Puan tablosundan (iç saha/deplasman gol istatistikleri) takım güçleri ve beklenen goller. */
object FormUtil {
    /** "WWDLW" veya "W,D,L,W,W" biçimindeki form dizisinden (puan/maç, maç sayısı). En az 3 sonuç yoksa null. */
    fun ppg(form: String): Pair<Double, Int>? {
        val r = form.filter { it == 'W' || it == 'D' || it == 'L' }.takeLast(5)
        if (r.length < 3) return null
        var pts = 0
        for (c in r) pts += if (c == 'W') 3 else if (c == 'D') 1 else 0
        return pts.toDouble() / r.length to r.length
    }
}

object Strength {
    data class Lambdas(
        val home: Double, val away: Double, val dataQuality: Double,
        val formUsed: Boolean = false, val homeGames: Int = 0, val awayGames: Int = 0,
        val overallFallback: Boolean = false,
        val totalsOnly: Boolean = false      // kaynak yalnızca toplam tablo verdi: iç saha avantajı hesaba katılmadı
    )

    /** İç saha/deplasman ayrımı için gereken en az maç; altında toplam maç istatistiğine geçilir. */
    const val MIN_SPLIT_GAMES = 2

    /**
     * Tablodaki gerçek maçlardan lig ortalaması (ev golü, deplasman golü). İç saha/deplasman verisi yoksa
     * toplam ortalama iki tarafa da verilir (iç saha avantajı eklenmez). Yeterli maç yoksa null.
     */
    fun leagueAverage(rows: List<TeamRow>): Pair<Double, Double>? {
        val hp = rows.sumOf { it.home.played }
        val ap = rows.sumOf { it.away.played }
        if (hp >= 6 && ap >= 6) {
            val h = rows.sumOf { it.home.goalsFor }.toDouble() / hp
            val a = rows.sumOf { it.away.goalsFor }.toDouble() / ap
            if (h > 0 && a > 0) return h.coerceIn(0.2, 4.0) to a.coerceIn(0.2, 4.0)
        }
        val p = rows.sumOf { it.all.played }
        if (p < 6) return null
        val g = rows.sumOf { it.all.goalsFor }.toDouble() / p
        if (g <= 0) return null
        return g.coerceIn(0.2, 4.0) to g.coerceIn(0.2, 4.0)
    }

    /** Form ayarı en fazla ±%6 etkiler (kalibrasyon yeterli veriyle doğrulanana kadar düşük tutulur). */
    const val FORM_WEIGHT = 0.06

    /** Takımın son maç formu ile sezon ortalaması arasındaki fark, -1..1 aralığında. Veri yetersizse null. */
    fun formAdjust(h: TeamRow, a: TeamRow): Pair<Double, Double>? {
        val fh = FormUtil.ppg(h.form) ?: return null
        val fa = FormUtil.ppg(a.form) ?: return null
        if (h.all.played <= 0 || a.all.played <= 0) return null
        val sh = h.points.toDouble() / h.all.played
        val sa = a.points.toDouble() / a.all.played
        return ((fh.first - sh) / 3.0).coerceIn(-1.0, 1.0) to ((fa.first - sa) / 3.0).coerceIn(-1.0, 1.0)
    }

    private const val SHRINK_K = 5.0

    /** Kupada takımlar farklı rakiplerle az maç oynadığı için gözlem daha temkinli (lig ortalamasına daha çok) küçültülür. */
    const val SHRINK_K_CUP = 8.0

    private fun shrink(x: Double, n: Int, k: Double = SHRINK_K, target: Double = 1.0): Double = if (n <= 0) target else (n * x + k * target) / (n + k)

    /**
     * Geçen sezon önsel bilgisi (geri testle seçildi: 2024-25'te ayarlandı, 2025-26'da doğrulandı; maç sonucu Brier'i
     * belirgin iyileşti). Takımın geçen sezon sonu güç oranları (ev hücum, ev savunma, dep hücum, dep savunma), lig
     * ortalamasına [PRIOR_REGRESS] oranında yaklaştırılır; bu sezonki maçlar K=[PRIOR_K] ile bu önsele doğru birleştirilir.
     * Geçen sezon ligde olmayan (yükselen) takımlar için [NEW_TEAM_ATT]/[NEW_TEAM_DEF].
     */
    const val PRIOR_K = 10.0
    const val PRIOR_REGRESS = 0.75
    const val NEW_TEAM_ATT = 0.85
    const val NEW_TEAM_DEF = 1.15

    /** Bitmiş sezon sonuçlarından takım adı -> [evHücum, evSavunma, depHücum, depSavunma] (lig ortalamasına oran). */
    fun endRatings(results: List<FinishedResult>): Map<String, DoubleArray> {
        if (results.size < 50) return emptyMap()
        val acc = HashMap<String, IntArray>()   // hp, hf, ha, ap, af, aa
        for (r in results) {
            val h = acc.getOrPut(r.home) { IntArray(6) }
            val a = acc.getOrPut(r.away) { IntArray(6) }
            h[0]++; h[1] += r.homeGoals; h[2] += r.awayGoals
            a[3]++; a[4] += r.awayGoals; a[5] += r.homeGoals
        }
        val n = results.size.toDouble()
        val avgH = results.sumOf { it.homeGoals } / n
        val avgA = results.sumOf { it.awayGoals } / n
        if (avgH <= 0 || avgA <= 0) return emptyMap()
        fun reg(x: Double) = 1.0 + PRIOR_REGRESS * (x - 1.0)
        return acc.mapValues { (_, v) ->
            doubleArrayOf(
                if (v[0] > 0) reg((v[1].toDouble() / v[0]) / avgH) else NEW_TEAM_ATT,
                if (v[0] > 0) reg((v[2].toDouble() / v[0]) / avgA) else NEW_TEAM_DEF,
                if (v[3] > 0) reg((v[4].toDouble() / v[3]) / avgA) else NEW_TEAM_ATT,
                if (v[3] > 0) reg((v[5].toDouble() / v[3]) / avgH) else NEW_TEAM_DEF
            )
        }
    }

    /** Tablo satırlarını (teamId) geçen sezon adlarıyla eşleştirir; eşleşmeyen = yükselen takım. */
    fun priorFor(rows: List<TeamRow>, ratings: Map<String, DoubleArray>): Map<Int, DoubleArray> {
        if (ratings.isEmpty()) return emptyMap()
        val names = ratings.keys.toList()
        return rows.associate { r ->
            val best = TeamMatcher.bestMatch(r.name, names)
            r.teamId to (best?.let { ratings[it] } ?: doubleArrayOf(NEW_TEAM_ATT, NEW_TEAM_DEF, NEW_TEAM_ATT, NEW_TEAM_DEF))
        }
    }

    /**
     * Kaynak yalnızca TOPLAM puan durumu verdiyse (iç saha/deplasman ayrımı yok): toplam gol oranlarıyla hesap.
     * İç saha avantajı bilinmediği için eklenmez (Poisson'un iki tarafı aynı lig ortalamasından başlar); bu, notta belirtilir.
     */
    private fun totalsOnly(rows: List<TeamRow>, h: TeamRow, a: TeamRow, k: Double): Lambdas? {
        val played = rows.sumOf { it.all.played }
        if (played <= 0 || h.all.played < MIN_SPLIT_GAMES || a.all.played < MIN_SPLIT_GAMES) return null
        val avg = rows.sumOf { it.all.goalsFor }.toDouble() / played
        if (avg <= 0.0) return null
        fun rate(goals: Int, p: Int) = (goals.toDouble() / p) / avg
        val attH = shrink(rate(h.all.goalsFor, h.all.played), h.all.played, k)
        val defH = shrink(rate(h.all.goalsAgainst, h.all.played), h.all.played, k)
        val attA = shrink(rate(a.all.goalsFor, a.all.played), a.all.played, k)
        val defA = shrink(rate(a.all.goalsAgainst, a.all.played), a.all.played, k)
        val lh = (avg * attH * defA).coerceIn(0.2, 4.0)
        val la = (avg * attA * defH).coerceIn(0.2, 4.0)
        val dq = min(1.0, min(h.all.played, a.all.played) / 8.0)
        return Lambdas(lh, la, dq, formUsed = false, homeGames = h.all.played, awayGames = a.all.played, overallFallback = true, totalsOnly = true)
    }

    /**
     * Geri testle seçildi (2024-25'te ayarlandı, 2025-26'da 6 ligin hepsinde doğrulandı; maç sonucu Brier 0.6097 -> 0.6027):
     * takım gücü %25 iç saha/deplasman, %75 tüm maçlardan; ev sahibi avantajı oranı lig maçı azken geçmiş sezonların
     * ortalamasına ([HOME_RATIO_PRIOR], [HOME_RATIO_K] maç ağırlığında) çekilir. Gol modeli bunları kullanmaz (ayrı doğrulandı).
     */
    const val ALL_BLEND = 0.75
    const val HOME_RATIO_PRIOR = 1.20
    const val HOME_RATIO_K = 200.0

    fun lambdas(
        rows: List<TeamRow>, homeId: Int, awayId: Int, shrinkK: Double = SHRINK_K, prior: Map<Int, DoubleArray>? = null,
        allBlend: Double = ALL_BLEND, poolHome: Boolean = true
    ): Lambdas? {
        val h = rows.firstOrNull { it.teamId == homeId } ?: return null
        val a = rows.firstOrNull { it.teamId == awayId } ?: return null
        val homeGames = rows.sumOf { it.home.played }
        val awayGames = rows.sumOf { it.away.played }
        if (homeGames <= 0 && awayGames <= 0) return totalsOnly(rows, h, a, shrinkK)
        if (homeGames <= 0 || awayGames <= 0) return null
        val avgHome = rows.sumOf { it.home.goalsFor }.toDouble() / homeGames
        val avgAway = rows.sumOf { it.away.goalsFor }.toDouble() / awayGames
        if (avgHome <= 0.0 || avgAway <= 0.0) return null
        val allGames = rows.sumOf { it.all.played }
        val avgAll = if (allGames > 0) rows.sumOf { it.all.goalsFor }.toDouble() / allGames else 0.0

        fun rate(goals: Int, played: Int, avg: Double) = if (played <= 0) 1.0 else (goals.toDouble() / played) / avg

        // İç saha/deplasman ayrımı yeterliyse (≥2 maç) o kullanılır. Kupa başlangıcı gibi ayrım ince ise,
        // gerçek TOPLAM maç istatistiğine (≥2 maç) geçilir; veri uydurulmaz, ancak ev/deplasman farkı o takım için ayrılamaz.
        val hSplit = h.home.played >= MIN_SPLIT_GAMES
        val aSplit = a.away.played >= MIN_SPLIT_GAMES
        val hOverall = !hSplit && h.all.played >= MIN_SPLIT_GAMES && avgAll > 0.0
        val aOverall = !aSplit && a.all.played >= MIN_SPLIT_GAMES && avgAll > 0.0
        val hs = if (hOverall) h.all else h.home
        val aws = if (aOverall) a.all else a.away
        val hAvgFor = if (hOverall) avgAll else avgHome
        val hAvgAgainst = if (hOverall) avgAll else avgAway
        val aAvgFor = if (aOverall) avgAll else avgAway
        val aAvgAgainst = if (aOverall) avgAll else avgHome
        // Önsel (geçen sezon) varsa küçültme 1.0 yerine takımın geçen sezon gücüne doğru yapılır.
        val ph = prior?.get(h.teamId)
        val pa = prior?.get(a.teamId)
        val kH = if (ph != null) PRIOR_K else shrinkK
        val kA = if (pa != null) PRIOR_K else shrinkK
        val tAttH = ph?.let { if (hOverall) (it[0] + it[2]) / 2 else it[0] } ?: 1.0
        val tDefH = ph?.let { if (hOverall) (it[1] + it[3]) / 2 else it[1] } ?: 1.0
        val tAttA = pa?.let { if (aOverall) (it[0] + it[2]) / 2 else it[2] } ?: 1.0
        val tDefA = pa?.let { if (aOverall) (it[1] + it[3]) / 2 else it[3] } ?: 1.0
        val attH = shrink(rate(hs.goalsFor, hs.played, hAvgFor), hs.played, kH, tAttH)
        val defH = shrink(rate(hs.goalsAgainst, hs.played, hAvgAgainst), hs.played, kH, tDefH)
        val attA = shrink(rate(aws.goalsFor, aws.played, aAvgFor), aws.played, kA, tAttA)
        val defA = shrink(rate(aws.goalsAgainst, aws.played, aAvgAgainst), aws.played, kA, tDefA)

        // Tüm maçlardan güç (ev+deplasman birlikte; beklenen gol, maçların oynandığı yere göre lig ortalamasından).
        fun allRates(t: TeamRow, p: DoubleArray?, k: Double): Pair<Double, Double>? {
            val denomF = t.home.played * avgHome + t.away.played * avgAway
            val denomA = t.home.played * avgAway + t.away.played * avgHome
            if (t.all.played <= 0 || denomF <= 0 || denomA <= 0) return null
            val tA = p?.let { (it[0] + it[2]) / 2 } ?: 1.0
            val tD = p?.let { (it[1] + it[3]) / 2 } ?: 1.0
            return shrink(t.all.goalsFor / denomF, t.all.played, k, tA) to shrink(t.all.goalsAgainst / denomA, t.all.played, k, tD)
        }
        var attHf = attH; var defHf = defH; var attAf = attA; var defAf = defA
        if (allBlend > 0.0) {
            if (!hOverall) allRates(h, ph, kH)?.let { (aa, dd) -> attHf = (1 - allBlend) * attH + allBlend * aa; defHf = (1 - allBlend) * defH + allBlend * dd }
            if (!aOverall) allRates(a, pa, kA)?.let { (aa, dd) -> attAf = (1 - allBlend) * attA + allBlend * aa; defAf = (1 - allBlend) * defA + allBlend * dd }
        }
        // Ev sahibi avantajı oranının küçültülmesi (az maçta lig oranı gürültülü).
        var baseH = avgHome
        var baseA = avgAway
        if (poolHome) {
            val r = avgHome / avgAway
            val r2 = (homeGames * r + HOME_RATIO_K * HOME_RATIO_PRIOR) / (homeGames + HOME_RATIO_K)
            val tot = avgHome + avgAway
            baseH = tot * r2 / (1 + r2)
            baseA = tot / (1 + r2)
        }
        var lhRaw = baseH * attHf * defAf
        var laRaw = baseA * attAf * defHf
        val adj = formAdjust(h, a)
        if (adj != null) {
            lhRaw *= (1 + 0.5 * FORM_WEIGHT * adj.first) * (1 - 0.5 * FORM_WEIGHT * adj.second)
            laRaw *= (1 + 0.5 * FORM_WEIGHT * adj.second) * (1 - 0.5 * FORM_WEIGHT * adj.first)
        }
        val lh = lhRaw.coerceIn(0.2, 4.0)
        val la = laRaw.coerceIn(0.2, 4.0)
        val effH = hs.played
        val effA = aws.played
        val dq = min(1.0, min(effH, effA) / 8.0)
        return Lambdas(
            lh, la, dq, formUsed = adj != null, homeGames = effH, awayGames = effA,
            overallFallback = hOverall || aOverall
        )
    }
}

/**
 * Gol pazarları (Alt/Üst, KG, takım golleri, İY golleri) için ayrı, daha temkinli gol modeli.
 * Geri test (openfootball 2024-25'te ayarlandı, 2025-26'da doğrulandı; 6 lig, ~1600 maç): takım bazlı gol farkları
 * abartılıyordu. Takım güçleri K=20 ile küçültülüp toplam gol lig ortalamasına %50 çekilince gol pazarları basit
 * lig ortalaması tahminiyle aynı seviyeye geldi (önceden daha kötüydü). Maç sonucu pazarları değişmez (K=5 en iyisi).
 */
object GoalModel {
    /**
     * Gol pazarı kalibrasyonu (openfootball 2024-25, 6 lig, ~1800 maçtan kutu eşlemesi; 2025-26'da doğrulandı:
     * KG Var Brier 0.2505 -> 0.2475, 1.5 Üst 0.1769 -> 0.1760). Kutu = olasılık onda biri; (tutan, toplam).
     * Az örnekli kutuda model olasılığına yakın kalır (m = 20).
     */
    private val CAL: Map<String, List<Pair<Int, Int>>> = mapOf(
        "ou_1.5" to listOf(0 to 0, 0 to 0, 0 to 0, 0 to 0, 0 to 0, 0 to 0, 48 to 70, 932 to 1230, 441 to 536, 0 to 0),
        "ou_2.5" to listOf(0 to 0, 0 to 0, 0 to 0, 0 to 0, 201 to 431, 589 to 1081, 196 to 321, 2 to 3, 0 to 0, 0 to 0),
        "btts" to listOf(0 to 0, 0 to 0, 1 to 2, 27 to 44, 199 to 386, 655 to 1149, 142 to 255, 0 to 0, 0 to 0, 0 to 0)
    )

    /** "Üst"/"Var" olasılığını kalibre eder; diğer seçenek 1 - p. Kalibrasyonu olmayan pazar aynen döner. */
    fun calibrate(mk: String, sk: String, p: Double): Double {
        val bins = CAL[mk] ?: return p
        val positive = sk == "over" || sk == "yes"
        val q = if (positive) p else 1 - p
        val (hit, n) = bins[(q * 10).toInt().coerceIn(0, 9)]
        val c = (hit + 20 * q) / (n + 20)
        return if (positive) c else 1 - c
    }

    const val SHRINK_K = 20.0
    const val PULL = 0.5

    fun isGoalMarket(mk: String): Boolean =
        mk.startsWith("ou_") || mk == "btts" || mk.startsWith("home_ou_") || mk.startsWith("away_ou_") ||
            mk.startsWith("ht_ou_") || mk == "ht_btts"

    /** Gol modeli için toplam beklenen gol: temkinli takım tahmini, lig ortalamasına PULL oranında çekilir. */
    fun total(cautious: Strength.Lambdas?, leagueTotal: Double): Double {
        val t = cautious?.let { it.home + it.away } ?: leagueTotal
        return (leagueTotal + (1 - PULL) * (t - leagueTotal)).coerceIn(0.6, 6.0)
    }

    /** Ana modelin ev/deplasman oranını koruyarak toplamı [total] yapar. */
    fun model(lh: Double, la: Double, total: Double): ScoreModel {
        val s = total / (lh + la)
        return ScoreModel((lh * s).coerceIn(0.2, 4.0), (la * s).coerceIn(0.2, 4.0))
    }
}

/** Canlı maç: kalan süreye göre kalan beklenen goller + mevcut skor. (Zaman düzgün dağılımı varsayımı.) */
object LiveModel {
    data class View(val win: Double, val draw: Double, val lose: Double, val over25: Double, val btts: Double, val remainingFraction: Double)

    fun view(lh: Double, la: Double, elapsed: Int, gh: Int, ga: Int): View {
        val frac = max(0, 90 - elapsed) / 90.0
        val rem = ScoreModel(lh * frac, la * frac)
        fun p(pred: (Int, Int) -> Boolean) = rem.sum(rem.ft) { r1, r2 -> pred(gh + r1, ga + r2) }
        return View(
            win = p { h, a -> h > a },
            draw = p { h, a -> h == a },
            lose = p { h, a -> h < a },
            over25 = p { h, a -> h + a > 2.5 },
            btts = p { h, a -> h > 0 && a > 0 },
            remainingFraction = frac
        )
    }
}
