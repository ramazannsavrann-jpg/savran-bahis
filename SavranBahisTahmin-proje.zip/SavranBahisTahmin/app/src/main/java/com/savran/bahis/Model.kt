package com.savran.bahis

import kotlin.math.exp
import kotlin.math.max
import kotlin.math.min

object Poisson {
    fun pmf(lambda: Double, maxK: Int): DoubleArray {
        val r = DoubleArray(maxK + 1)
        r[0] = exp(-lambda)
        for (k in 1..maxK) r[k] = r[k - 1] * lambda / k
        return r
    }
}

/**
 * Bağımsız Poisson skor modeli. Tam maç ve ilk yarı skor matrisleri ile
 * devre/maç ortak dağılımı aynı λ'lardan türetilir (tutarlıdır).
 */
class ScoreModel(val lambdaHome: Double, val lambdaAway: Double, val htShare: Double = 0.45) {
    companion object { const val N = 10 }

    val ft: Array<DoubleArray> = matrix(lambdaHome, lambdaAway)
    val ht: Array<DoubleArray> by lazy { matrix(lambdaHome * htShare, lambdaAway * htShare) }

    /** "1/1", "1/X" ... ilk yarı sonucu / maç sonucu ortak olasılıkları. */
    val htft: Map<String, Double> by lazy {
        val h2 = matrix(lambdaHome * (1 - htShare), lambdaAway * (1 - htShare))
        val out = HashMap<String, Double>()
        for (a in 0..N) for (b in 0..N) {
            val p1 = ht[a][b]
            if (p1 < 1e-9) continue
            for (c in 0..N) for (d in 0..N) {
                val key = Outcomes.res(a - b) + "/" + Outcomes.res(a + c - (b + d))
                out[key] = (out[key] ?: 0.0) + p1 * h2[c][d]
            }
        }
        val total = out.values.sum()
        out.mapValues { it.value / total }
    }

    private fun matrix(lh: Double, la: Double): Array<DoubleArray> {
        val ph = Poisson.pmf(lh, N)
        val pa = Poisson.pmf(la, N)
        val m = Array(N + 1) { h -> DoubleArray(N + 1) { a -> ph[h] * pa[a] } }
        var total = 0.0
        for (row in m) for (v in row) total += v
        for (row in m) for (i in row.indices) row[i] = row[i] / total
        return m
    }

    fun sum(m: Array<DoubleArray>, pred: (Int, Int) -> Boolean): Double {
        var s = 0.0
        for (h in 0..N) for (a in 0..N) if (pred(h, a)) s += m[h][a]
        return s
    }

    /** En olası skorlar (tam maç). */
    fun topScores(n: Int): List<Triple<Int, Int, Double>> {
        val all = ArrayList<Triple<Int, Int, Double>>()
        for (h in 0..N) for (a in 0..N) all.add(Triple(h, a, ft[h][a]))
        return all.sortedByDescending { it.third }.take(n)
    }
}

/** Bir bahis seçeneğinin gerçek skora göre kazanıp kazanmadığı. Desteklenmeyen pazar: null. */
object Outcomes {
    fun res(d: Int): String = if (d > 0) "1" else if (d == 0) "X" else "2"

    private fun dcSet(sk: String): Set<String>? = when (sk) {
        "1X" -> setOf("1", "X")
        "12" -> setOf("1", "2")
        "X2" -> setOf("X", "2")
        else -> null
    }

    private fun overUnder(total: Int, line: Double, sk: String): Boolean? = when (sk) {
        "over" -> total > line
        "under" -> total < line
        else -> null
    }

    fun eval(mk: String, sk: String, fh: Int, fa: Int, hh: Int?, ha: Int?): Boolean? {
        val line = mk.substringAfterLast('_').toDoubleOrNull()
        return when {
            mk == "1x2" -> res(fh - fa) == sk
            mk == "dc" -> dcSet(sk)?.contains(res(fh - fa))
            mk.startsWith("ou_") && line != null -> overUnder(fh + fa, line, sk)
            mk.startsWith("home_ou_") && line != null -> overUnder(fh, line, sk)
            mk.startsWith("away_ou_") && line != null -> overUnder(fa, line, sk)
            mk == "btts" -> (fh > 0 && fa > 0) == (sk == "yes")
            mk == "ht_1x2" -> if (hh == null || ha == null) null else res(hh - ha) == sk
            mk == "ht_dc" -> if (hh == null || ha == null) null else dcSet(sk)?.contains(res(hh - ha))
            mk.startsWith("ht_ou_") && line != null -> if (hh == null || ha == null) null else overUnder(hh + ha, line, sk)
            mk == "ht_btts" -> if (hh == null || ha == null) null else (hh > 0 && ha > 0) == (sk == "yes")
            mk == "htft" -> if (hh == null || ha == null) null else sk == res(hh - ha) + "/" + res(fh - fa)
            mk == "cs" -> if (sk == "other") (fh > 3 || fa > 3) else sk == "$fh-$fa"
            mk == "combo_1x2_ou25" -> {
                val p = sk.split("_")
                if (p.size != 2) null else res(fh - fa) == p[0] && ((fh + fa) > 2.5) == (p[1] == "over")
            }
            mk == "combo_1x2_btts" -> {
                val p = sk.split("_")
                if (p.size != 2) null else res(fh - fa) == p[0] && (fh > 0 && fa > 0) == (p[1] == "yes")
            }
            mk == "hcp_home_minus1" -> res(fh - 1 - fa) == sk
            mk == "hcp_home_plus1" -> res(fh + 1 - fa) == sk
            else -> null   // korner, kart vb.: istatistik/model yok
        }
    }
}

object MarketProb {
    /** null = bu pazar için modelimiz yok (veri yetersiz). Sahte olasılık üretilmez. */
    fun prob(m: ScoreModel, mk: String, sk: String): Double? {
        if (Outcomes.eval(mk, sk, 0, 0, 0, 0) == null) return null
        return when {
            mk == "htft" -> m.htft[sk] ?: 0.0
            mk.startsWith("ht_") -> m.sum(m.ht) { h, a -> Outcomes.eval(mk, sk, 0, 0, h, a) == true }
            else -> m.sum(m.ft) { h, a -> Outcomes.eval(mk, sk, h, a, null, null) == true }
        }
    }
}

/** Puan tablosundan (iç saha/deplasman gol istatistikleri) takım güçleri ve beklenen goller. */
object FormUtil {
    /** "WWDLW" veya "W,D,L,W,W" biçimindeki form dizisinden (puan/maç, maç sayısı). En az 3 sonuç yoksa null. */
    fun ppg(form: String): Pair<Double, Int>? {
        val r = form.filter { it == 'W' || it == 'D' || it == 'L' }.takeLast(5)
        if (r.length < 3) return null
        var pts = 0
        for (c in r) pts += if (c == 'W') 3 else if (c == 'D') 1 else 0
        return pts.toDouble() / r.length to r.length
    }
}

object Strength {
    data class Lambdas(
        val home: Double, val away: Double, val dataQuality: Double,
        val formUsed: Boolean = false, val homeGames: Int = 0, val awayGames: Int = 0,
        val overallFallback: Boolean = false,
        val totalsOnly: Boolean = false      // kaynak yalnızca toplam tablo verdi: iç saha avantajı hesaba katılmadı
    )

    /** İç saha/deplasman ayrımı için gereken en az maç; altında toplam maç istatistiğine geçilir. */
    const val MIN_SPLIT_GAMES = 2

    /**
     * Tablodaki gerçek maçlardan lig ortalaması (ev golü, deplasman golü). İç saha/deplasman verisi yoksa
     * toplam ortalama iki tarafa da verilir (iç saha avantajı eklenmez). Yeterli maç yoksa null.
     */
    fun leagueAverage(rows: List<TeamRow>): Pair<Double, Double>? {
        val hp = rows.sumOf { it.home.played }
        val ap = rows.sumOf { it.away.played }
        if (hp >= 6 && ap >= 6) {
            val h = rows.sumOf { it.home.goalsFor }.toDouble() / hp
            val a = rows.sumOf { it.away.goalsFor }.toDouble() / ap
            if (h > 0 && a > 0) return h.coerceIn(0.2, 4.0) to a.coerceIn(0.2, 4.0)
        }
        val p = rows.sumOf { it.all.played }
        if (p < 6) return null
        val g = rows.sumOf { it.all.goalsFor }.toDouble() / p
        if (g <= 0) return null
        return g.coerceIn(0.2, 4.0) to g.coerceIn(0.2, 4.0)
    }

    /** Form ayarı en fazla ±%6 etkiler (kalibrasyon yeterli veriyle doğrulanana kadar düşük tutulur). */
    const val FORM_WEIGHT = 0.06

    /** Takımın son maç formu ile sezon ortalaması arasındaki fark, -1..1 aralığında. Veri yetersizse null. */
    fun formAdjust(h: TeamRow, a: TeamRow): Pair<Double, Double>? {
        val fh = FormUtil.ppg(h.form) ?: return null
        val fa = FormUtil.ppg(a.form) ?: return null
        if (h.all.played <= 0 || a.all.played <= 0) return null
        val sh = h.points.toDouble() / h.all.played
        val sa = a.points.toDouble() / a.all.played
        return ((fh.first - sh) / 3.0).coerceIn(-1.0, 1.0) to ((fa.first - sa) / 3.0).coerceIn(-1.0, 1.0)
    }

    private const val SHRINK_K = 5.0

    /** Kupada takımlar farklı rakiplerle az maç oynadığı için gözlem daha temkinli (lig ortalamasına daha çok) küçültülür. */
    const val SHRINK_K_CUP = 8.0

    private fun shrink(x: Double, n: Int, k: Double = SHRINK_K): Double = if (n <= 0) 1.0 else (n * x + k) / (n + k)

    /**
     * Kaynak yalnızca TOPLAM puan durumu verdiyse (iç saha/deplasman ayrımı yok): toplam gol oranlarıyla hesap.
     * İç saha avantajı bilinmediği için eklenmez (Poisson'un iki tarafı aynı lig ortalamasından başlar); bu, notta belirtilir.
     */
    private fun totalsOnly(rows: List<TeamRow>, h: TeamRow, a: TeamRow, k: Double): Lambdas? {
        val played = rows.sumOf { it.all.played }
        if (played <= 0 || h.all.played < MIN_SPLIT_GAMES || a.all.played < MIN_SPLIT_GAMES) return null
        val avg = rows.sumOf { it.all.goalsFor }.toDouble() / played
        if (avg <= 0.0) return null
        fun rate(goals: Int, p: Int) = (goals.toDouble() / p) / avg
        val attH = shrink(rate(h.all.goalsFor, h.all.played), h.all.played, k)
        val defH = shrink(rate(h.all.goalsAgainst, h.all.played), h.all.played, k)
        val attA = shrink(rate(a.all.goalsFor, a.all.played), a.all.played, k)
        val defA = shrink(rate(a.all.goalsAgainst, a.all.played), a.all.played, k)
        val lh = (avg * attH * defA).coerceIn(0.2, 4.0)
        val la = (avg * attA * defH).coerceIn(0.2, 4.0)
        val dq = min(1.0, min(h.all.played, a.all.played) / 8.0)
        return Lambdas(lh, la, dq, formUsed = false, homeGames = h.all.played, awayGames = a.all.played, overallFallback = true, totalsOnly = true)
    }

    fun lambdas(rows: List<TeamRow>, homeId: Int, awayId: Int, shrinkK: Double = SHRINK_K): Lambdas? {
        val h = rows.firstOrNull { it.teamId == homeId } ?: return null
        val a = rows.firstOrNull { it.teamId == awayId } ?: return null
        val homeGames = rows.sumOf { it.home.played }
        val awayGames = rows.sumOf { it.away.played }
        if (homeGames <= 0 && awayGames <= 0) return totalsOnly(rows, h, a, shrinkK)
        if (homeGames <= 0 || awayGames <= 0) return null
        val avgHome = rows.sumOf { it.home.goalsFor }.toDouble() / homeGames
        val avgAway = rows.sumOf { it.away.goalsFor }.toDouble() / awayGames
        if (avgHome <= 0.0 || avgAway <= 0.0) return null
        val allGames = rows.sumOf { it.all.played }
        val avgAll = if (allGames > 0) rows.sumOf { it.all.goalsFor }.toDouble() / allGames else 0.0

        fun rate(goals: Int, played: Int, avg: Double) = if (played <= 0) 1.0 else (goals.toDouble() / played) / avg

        // İç saha/deplasman ayrımı yeterliyse (≥2 maç) o kullanılır. Kupa başlangıcı gibi ayrım ince ise,
        // gerçek TOPLAM maç istatistiğine (≥2 maç) geçilir; veri uydurulmaz, ancak ev/deplasman farkı o takım için ayrılamaz.
        val hSplit = h.home.played >= MIN_SPLIT_GAMES
        val aSplit = a.away.played >= MIN_SPLIT_GAMES
        val hOverall = !hSplit && h.all.played >= MIN_SPLIT_GAMES && avgAll > 0.0
        val aOverall = !aSplit && a.all.played >= MIN_SPLIT_GAMES && avgAll > 0.0
        val hs = if (hOverall) h.all else h.home
        val aws = if (aOverall) a.all else a.away
        val hAvgFor = if (hOverall) avgAll else avgHome
        val hAvgAgainst = if (hOverall) avgAll else avgAway
        val aAvgFor = if (aOverall) avgAll else avgAway
        val aAvgAgainst = if (aOverall) avgAll else avgHome
        val attH = shrink(rate(hs.goalsFor, hs.played, hAvgFor), hs.played, shrinkK)
        val defH = shrink(rate(hs.goalsAgainst, hs.played, hAvgAgainst), hs.played, shrinkK)
        val attA = shrink(rate(aws.goalsFor, aws.played, aAvgFor), aws.played, shrinkK)
        val defA = shrink(rate(aws.goalsAgainst, aws.played, aAvgAgainst), aws.played, shrinkK)

        var lhRaw = avgHome * attH * defA
        var laRaw = avgAway * attA * defH
        val adj = formAdjust(h, a)
        if (adj != null) {
            lhRaw *= (1 + 0.5 * FORM_WEIGHT * adj.first) * (1 - 0.5 * FORM_WEIGHT * adj.second)
            laRaw *= (1 + 0.5 * FORM_WEIGHT * adj.second) * (1 - 0.5 * FORM_WEIGHT * adj.first)
        }
        val lh = lhRaw.coerceIn(0.2, 4.0)
        val la = laRaw.coerceIn(0.2, 4.0)
        val effH = hs.played
        val effA = aws.played
        val dq = min(1.0, min(effH, effA) / 8.0)
        return Lambdas(
            lh, la, dq, formUsed = adj != null, homeGames = effH, awayGames = effA,
            overallFallback = hOverall || aOverall
        )
    }
}

/** Canlı maç: kalan süreye göre kalan beklenen goller + mevcut skor. (Zaman düzgün dağılımı varsayımı.) */
object LiveModel {
    data class View(val win: Double, val draw: Double, val lose: Double, val over25: Double, val btts: Double, val remainingFraction: Double)

    fun view(lh: Double, la: Double, elapsed: Int, gh: Int, ga: Int): View {
        val frac = max(0, 90 - elapsed) / 90.0
        val rem = ScoreModel(lh * frac, la * frac)
        fun p(pred: (Int, Int) -> Boolean) = rem.sum(rem.ft) { r1, r2 -> pred(gh + r1, ga + r2) }
        return View(
            win = p { h, a -> h > a },
            draw = p { h, a -> h == a },
            lose = p { h, a -> h < a },
            over25 = p { h, a -> h + a > 2.5 },
            btts = p { h, a -> h > 0 && a > 0 },
            remainingFraction = frac
        )
    }
}
