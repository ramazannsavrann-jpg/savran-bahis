package com.savran.bahis

import java.text.Normalizer

/** Farklı veri kaynaklarındaki takım adlarını eşleştirir (ör. "Man City" = "Manchester City"). */
object TeamMatcher {
    private val stopTokens = setOf(
        "fc", "sk", "as", "cf", "afc", "fk", "ac", "sc", "spor", "kulubu", "club", "jk", "ssc", "rc",
        "1899", "1907", "1905", "1910", "1903", "1913", "1900", "1904", "1909"
    )

    private val aliases = mapOf(
        "man city" to "manchester city",
        "man utd" to "manchester united",
        "man united" to "manchester united",
        "spurs" to "tottenham",
        "tottenham hotspur" to "tottenham",
        "wolves" to "wolverhampton",
        "wolverhampton wanderers" to "wolverhampton",
        "newcastle united" to "newcastle",
        "west ham united" to "west ham",
        "brighton and hove albion" to "brighton",
        "nottingham forest" to "nottingham",
        "psg" to "paris saint germain",
        "paris sg" to "paris saint germain",
        "bayern munich" to "bayern munchen",
        "borussia monchengladbach" to "monchengladbach",
        "gladbach" to "monchengladbach",
        "koln" to "cologne",
        "1 koln" to "cologne",
        "atletico madrid" to "atletico madrid",
        "ath madrid" to "atletico madrid",
        "athletic bilbao" to "athletic club",
        "real betis" to "betis",
        "rayo vallecano" to "rayo",
        "istanbul basaksehir" to "basaksehir",
        "medipol basaksehir" to "basaksehir",
        "buyuksehir belediye erzurumspor" to "erzurumspor",
        "eyupspor" to "eyupspor",
        "sporting cp" to "sporting",
        "sporting clube de portugal" to "sporting",
        "sporting lisbon" to "sporting",
        "shakhtar donetsk" to "shakhtar",
        "shakhtar" to "shakhtar",
        "inter milan" to "inter",
        "internazionale" to "inter",
        "fc internazionale milano" to "inter",
        "bayer leverkusen" to "leverkusen",
        "bayer 04 leverkusen" to "leverkusen",
        "eintracht frankfurt" to "frankfurt",
        "red star belgrade" to "crvena zvezda",
        "red bull salzburg" to "salzburg",
        "rb salzburg" to "salzburg",
        "psv eindhoven" to "psv",
        "club brugge kv" to "club brugge",
        "olympiakos piraeus" to "olympiacos",
        "olympiakos" to "olympiacos",
        "slavia praha" to "slavia prague",
        "sk slavia praha" to "slavia prague"
    )

    fun normalize(name: String): String {
        var s = name.lowercase().replace('ı', 'i').replace("ß", "ss")
        s = Normalizer.normalize(s, Normalizer.Form.NFD).replace(Regex("\\p{M}+"), "")
        s = s.replace(Regex("[^a-z0-9]+"), " ").trim()
        val tokens = s.split(" ").filter { it.isNotEmpty() && it !in stopTokens }
        val joined = tokens.joinToString(" ")
        return aliases[joined] ?: joined
    }

    fun similarity(a: String, b: String): Double {
        val na = normalize(a)
        val nb = normalize(b)
        if (na.isEmpty() || nb.isEmpty()) return 0.0
        if (na == nb) return 1.0
        val ta = na.split(" ").toSet()
        val tb = nb.split(" ").toSet()
        val inter = ta.intersect(tb).size.toDouble()
        val jaccard = inter / ta.union(tb).size
        val lev = 1.0 - levenshtein(na, nb).toDouble() / maxOf(na.length, nb.length)
        var contain = 0.0
        val small = if (ta.size <= tb.size) ta else tb
        val big = if (ta.size <= tb.size) tb else ta
        if (small.isNotEmpty() && big.containsAll(small) && small.any { it.length >= 4 }) contain = 0.9
        return maxOf(jaccard, lev, contain)
    }

    fun isSame(a: String, b: String, threshold: Double = 0.8): Boolean = similarity(a, b) >= threshold

    /** En iyi eşleşmeyi döndürür; belirsizse (iki aday aynı skorda) null. */
    fun bestMatch(name: String, candidates: List<String>, threshold: Double = 0.8): String? {
        val scored = candidates.map { it to similarity(name, it) }.filter { it.second >= threshold }
            .sortedByDescending { it.second }
        if (scored.isEmpty()) return null
        if (scored.size > 1 && scored[0].second - scored[1].second < 0.02) return null
        return scored[0].first
    }

    private fun levenshtein(a: String, b: String): Int {
        val dp = IntArray(b.length + 1) { it }
        for (i in 1..a.length) {
            var prev = dp[0]
            dp[0] = i
            for (j in 1..b.length) {
                val tmp = dp[j]
                dp[j] = minOf(dp[j] + 1, dp[j - 1] + 1, prev + if (a[i - 1] == b[j - 1]) 0 else 1)
                prev = tmp
            }
        }
        return dp[b.length]
    }
}
