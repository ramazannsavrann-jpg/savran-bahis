package com.savran.bahis

import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import org.json.JSONException
import org.json.JSONObject
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import java.time.Instant
import java.time.LocalDateTime
import java.time.ZoneOffset

/** Uygulamadaki 7 veri kaynağı. Her biri ayrı yönetilir; biri çökerse diğerleri etkilenmez. */
enum class SourceId(val title: String, val needsKey: Boolean, val keyDefault: String?) {
    API_FOOTBALL("API-Football", true, null),
    FOOTBALL_DATA("Football-Data.org", true, null),
    API_NINJAS("API Ninjas Football", true, null),
    ODDS_API("The Odds API", true, null),
    THESPORTSDB("TheSportsDB", false, "123"),
    OPENLIGADB("OpenLigaDB", false, null),
    STATSBOMB("StatsBomb Open Data", false, null);

    /** Ayarlarda anahtarın saklandığı ad (ilk ikisi eski sürümle uyumlu). */
    val prefKey: String
        get() = when (this) {
            API_FOOTBALL -> "api_key"
            ODDS_API -> "odds_api_key"
            else -> "key_" + name.lowercase()
        }

    /** Önceki sürümle aynı davranış: yalnızca bu ikisi varsayılan açık (anahtar girilirse çalışır). */
    val enabledByDefault: Boolean get() = this == API_FOOTBALL || this == ODDS_API

    val keyEditable: Boolean get() = needsKey || keyDefault != null
}

/**
 * Her kaynağın GERÇEKTE sunduğu kapsam (resmî belgelere göre). Burada olmayan bir veri
 * uygulamada "var" gibi gösterilmez.
 */
data class SourceInfo(
    val id: SourceId,
    val signup: String,
    val leagues: Set<Int>,          // bu uygulamadaki 6 ligden hangileri
    val provides: List<String>,
    val notProvided: List<String>,
    val seasons: String,
    val limits: String,
    val usedFor: String
)

object SourceCatalog {
    private val allSix = Leagues.supported.map { it.id }.toSet()

    val all: List<SourceInfo> = listOf(
        SourceInfo(
            SourceId.API_FOOTBALL, "api-football.com / dashboard.api-football.com",
            leagues = allSix,
            provides = listOf("Maç listesi ve skorlar", "Puan durumu (iç saha/deplasman dahil)", "Sakat/cezalı listesi", "Son maç kadroları (rotasyon)", "Canlı skor"),
            notProvided = listOf("xG ve gelişmiş istatistik bu uygulamada kullanılmıyor", "Oranlar bu uygulamada API-Football'dan alınmaz"),
            seasons = "Plana bağlıdır. Ücretsiz planda güncel sezon/tarih kısıtı olabilir; kısıt olursa API'nin mesajı aynen gösterilir.",
            limits = "Ücretsiz planda günde 100 istek (uygulama son 5 isteği yedekte tutar).",
            usedFor = "Ana maç listesi, model için puan durumu, canlı skor, sakatlık, rotasyon."
        ),
        SourceInfo(
            SourceId.FOOTBALL_DATA, "football-data.org/client/register",
            leagues = setOf(39, 78, 140, 61),
            provides = listOf("Fikstür ve sonuçlar (skorlar gecikmeli)", "Puan durumu: genel, iç saha ve deplasman tabloları"),
            notProvided = listOf("Süper Lig ve 1. Lig yok", "Kadro, sakatlık, kart, korner ve maç istatistikleri ücretsiz planda yok", "Oran verisi yok"),
            seasons = "Ücretsiz planda 12 yarışmanın güncel sezonu.",
            limits = "Dakikada 10 istek.",
            usedFor = "Maç listesi (birleştirme), model için yedek puan durumu, veri doğrulama."
        ),
        SourceInfo(
            SourceId.API_NINJAS, "api-ninjas.com/register",
            leagues = setOf(39, 78, 140, 61),
            provides = listOf("Fikstür ve sonuçlar (biten maçlarda devre skoru)", "Puan durumu (yalnızca toplam)", "Kulüp ve kadro listeleri"),
            notProvided = listOf("Süper Lig ve 1. Lig yok", "Canlı skor/dakika ücretli planda", "İç saha/deplasman ayrımı yok", "Sakatlık ve oran verisi yok"),
            seasons = "Ücretsiz planda yalnızca güncel sezon.",
            limits = "Aylık plan kotası. Ücretsiz planda ticari kullanım yasak (kişisel kullanım serbest).",
            usedFor = "Maç listesi (yalnızca bugün/yarın), puan durumu ile veri doğrulama."
        ),
        SourceInfo(
            SourceId.ODDS_API, "the-odds-api.com",
            leagues = setOf(203, 39, 78, 140, 61),
            provides = listOf("1X2 (h2h) oranları", "Toplam gol (totals) oranları", "Avrupa/uluslararası bahis şirketlerinden oranlar"),
            notProvided = listOf("1. Lig yok", "KG, ilk yarı, korner, kart, doğru skor pazarları bu uygulamada çekilmiyor", "Maç, puan durumu veya sakatlık verisi yok"),
            seasons = "Yalnızca yaklaşan maçların güncel oranları (geçmiş oran ücretli).",
            limits = "Ayda 500 kredi. Her çağrı = pazar × bölge; bu uygulamada 2 pazar × 1 bölge = 2 kredi. Lig anahtarları bağlantı testiyle doğrulanır.",
            usedFor = "Oran analizi: maç detayında \"Harici oran çek\". Oranlar şirket adıyla ve The Odds API etiketiyle kaydedilir."
        ),
        SourceInfo(
            SourceId.THESPORTSDB, "thesportsdb.com",
            leagues = setOf(203, 39, 78, 140, 61),
            provides = listOf("Fikstür/sonuçlar (lig başına sınırlı sayıda)", "Puan durumu (yalnızca toplam, öne çıkan futbol ligleri)", "Takım rozetleri"),
            notProvided = listOf("1. Lig için kimlik doğrulanamadı, kapsam dışı sayılır", "Canlı skor ücretli anahtarda", "İç saha/deplasman ayrımı, sakatlık ve oran yok"),
            seasons = "Güncel sezon; ücretsiz anahtar az sayıda sonuç döndürür. Lig kimlikleri bağlantı testiyle doğrulanır.",
            limits = "Dakikada 30 istek. Ortak ücretsiz anahtar 123.",
            usedFor = "Maç listesi (birleştirme), puan durumu ile veri doğrulama."
        ),
        SourceInfo(
            SourceId.OPENLIGADB, "openligadb.de (anahtar gerekmez)",
            leagues = setOf(78),
            provides = listOf("Bundesliga fikstürü ve sonuçları (devre skoru dahil)", "Bundesliga puan durumu (yalnızca toplam)"),
            notProvided = listOf("Süper Lig, 1. Lig, Premier League, La Liga, Ligue 1 yok", "Canlı skor, sakatlık ve oran yok"),
            seasons = "Sezon başlangıç yılıyla (ör. 2026) sorgulanır; geçmiş sezonlar da vardır.",
            limits = "Resmî kota sayfası yok; makul sıklıkta kullanılır. Veri ODbL lisanslıdır.",
            usedFor = "Yalnızca Bundesliga: maç listesi (birleştirme) ve veri doğrulama."
        ),
        SourceInfo(
            SourceId.STATSBOMB, "github.com/statsbomb/open-data (anahtar gerekmez)",
            leagues = emptySet(),
            provides = listOf("Seçili GEÇMİŞ yarışma/sezonlarda olay bazlı maç verisi (şut, xG vb.)"),
            notProvided = listOf("Güncel sezon yok", "Fikstür, puan durumu ve oran yok", "6 ligimizin güncel verisi yok"),
            seasons = "Yalnızca StatsBomb'un açtığı seçili geçmiş sezonlar (bağlantı testi listeler).",
            limits = "GitHub'daki statik dosyalar. Yayınlanan analizde StatsBomb kaynak olarak belirtilmelidir.",
            usedFor = "Şu an tahmin modeline girmiyor; yalnızca erişim ve kapsam testi yapılır."
        )
    )

    fun info(id: SourceId): SourceInfo = all.first { it.id == id }

    fun leagueNames(ids: Collection<Int>): String =
        if (ids.isEmpty()) "yok" else ids.mapNotNull { Leagues.byId(it)?.nameTr }.joinToString(", ")
}

data class TestState(val ok: Boolean, val message: String, val at: Long)

// ------------------------------------------------------------------ HTTP ve hata altyapısı

data class HttpResp(val code: Int, val body: String, val headers: Map<String, String>)

object Http {
    fun get(url: String, headers: Map<String, String> = emptyMap(), readTimeoutMs: Int = 20000): HttpResp {
        val conn = URL(url).openConnection() as HttpURLConnection
        try {
            conn.requestMethod = "GET"
            conn.connectTimeout = 15000
            conn.readTimeout = readTimeoutMs
            conn.setRequestProperty("User-Agent", "SavranAnaliz/0.2")
            headers.forEach { (k, v) -> conn.setRequestProperty(k, v) }
            val code = conn.responseCode
            val stream = if (code in 200..299) conn.inputStream else conn.errorStream
            val body = stream?.bufferedReader()?.use { it.readText() } ?: ""
            val hs = HashMap<String, String>()
            conn.headerFields.forEach { (k, v) -> if (k != null && v != null && v.isNotEmpty()) hs[k.lowercase()] = v[0] }
            return HttpResp(code, body, hs)
        } finally {
            conn.disconnect()
        }
    }
}

/** Kaynak başına istek sınırı: iki çağrı arasında en az gapMs bekler. */
object Throttle {
    private val next = HashMap<SourceId, Long>()
    suspend fun wait(id: SourceId, gapMs: Long) {
        val now = System.currentTimeMillis()
        val waitMs = synchronized(next) {
            val at = maxOf(now, next[id] ?: 0L)
            next[id] = at + gapMs
            at - now
        }
        if (waitMs > 0) delay(waitMs)
    }
}

/** Her kaynak çağrısı bu sarmalayıcıdan geçer: hata kaynağa özel mesaja çevrilir, diğer kaynaklar etkilenmez. */
suspend fun <T> guarded(src: SourceId, block: suspend () -> ApiResult<T>): ApiResult<T> =
    withContext(Dispatchers.IO) {
        try {
            block()
        } catch (e: CancellationException) {
            throw e
        } catch (e: IOException) {
            ApiResult.Err("${src.title}: İnternet bağlantısı yok veya sunucuya ulaşılamadı.")
        } catch (e: JSONException) {
            ApiResult.Err("${src.title}: Yanıt okunamadı (beklenmeyen biçim).")
        } catch (e: Exception) {
            ApiResult.Err("${src.title}: Beklenmeyen hata (${e.javaClass.simpleName}).")
        }
    }

fun httpErr(src: SourceId, code: Int, body: String): ApiResult.Err {
    val detail = try {
        val o = JSONObject(body)
        o.optString("message", o.optString("error", ""))
    } catch (e: Exception) {
        ""
    }
    val base = when (code) {
        400 -> "istek reddedildi (400)"
        401, 403 -> "anahtar geçersiz veya bu plan/kaynak için yetki yok ($code)"
        404 -> "kaynak bulunamadı (404)"
        429 -> "istek sınırı doldu (429)"
        else -> "sunucu hatası ($code)"
    }
    return ApiResult.Err("${src.title}: $base" + if (detail.isNotBlank()) " — ${detail.take(160)}" else "")
}

/** Kaynak çağrısını sayar (ayarlarda "bugün yapılan istek" olarak gösterilir) ve isteği yapar. */
fun httpGet(settings: AppSettings, src: SourceId, url: String, headers: Map<String, String> = emptyMap()): HttpResp {
    settings.recordSourceCall(src, System.currentTimeMillis())
    return Http.get(url, headers)
}

// ------------------------------------------------------------------ Küçük JSON/zaman yardımcıları

internal fun JSONObject.looseInt(k: String): Int? {
    if (!has(k) || isNull(k)) return null
    val v = opt(k)
    return when (v) {
        is Number -> v.toInt()
        is String -> v.trim().toIntOrNull()
        else -> null
    }
}

internal fun JSONObject.looseStr(k: String): String? = if (!has(k) || isNull(k)) null else getString(k)

/** "2026-10-31T17:00:00Z" veya Z'siz "2026-10-31T17:00:00" (UTC kabul edilir) -> epoch saniye. */
fun parseUtc(s: String?): Long? {
    if (s.isNullOrBlank()) return null
    return try {
        Instant.parse(s).epochSecond
    } catch (e: Exception) {
        try {
            LocalDateTime.parse(s).toEpochSecond(ZoneOffset.UTC)
        } catch (e2: Exception) {
            null
        }
    }
}
