package com.savran.bahis

import java.io.File
import java.time.LocalDate

/** ClubElo'dan bir kulübün Elo puanı. */
data class EloEntry(val club: String, val country: String, val elo: Double)

/** ClubElo CSV ayrıştırıcı. Başlık sırasına bağlı değildir; bozuk satırlar atlanır, hiçbir zaman istisna fırlatmaz. */
object ClubEloParser {
    fun parse(csv: String): List<EloEntry> {
        val lines = csv.lineSequence().map { it.trim() }.filter { it.isNotEmpty() }.toList()
        if (lines.size < 2) return emptyList()
        val header = lines[0].split(",").map { it.trim().lowercase() }
        val ci = header.indexOf("club")
        val ei = header.indexOf("elo")
        val ni = header.indexOf("country")
        if (ci < 0 || ei < 0) return emptyList()
        val out = ArrayList<EloEntry>()
        for (l in lines.drop(1)) {
            val p = l.split(",")
            if (p.size <= maxOf(ci, ei)) continue
            val elo = p[ei].trim().toDoubleOrNull() ?: continue
            val club = p[ci].trim()
            if (club.isEmpty() || elo < 500.0 || elo > 3000.0) continue
            out.add(EloEntry(club, if (ni in p.indices) p[ni].trim() else "", elo))
        }
        return out
    }
}

/**
 * Elo farkından küçük ve SINIRLI bir güç düzeltmesi (yalnızca Avrupa kupası maçlarında; takımların lig gücü farkını
 * tahminen yansıtır). Kalibrasyonla doğrulanmadığı için etkisi en fazla ±%7.5 (ev/deplasman λ'sı ters yönde).
 */
object EloAdjust {
    const val MAX_LOG = 0.15

    /** (ev çarpanı, deplasman çarpanı). */
    fun factors(homeElo: Double, awayElo: Double): Pair<Double, Double> {
        val d = homeElo - awayElo
        val f = (d / 400.0 * 0.25).coerceIn(-MAX_LOG, MAX_LOG)
        return Math.exp(f / 2.0) to Math.exp(-f / 2.0)
    }

    /** Takım adına en uygun Elo kaydı; belirsiz veya bulunamazsa null (uydurma eşleştirme yok). */
    fun find(name: String, table: List<EloEntry>): EloEntry? {
        val best = TeamMatcher.bestMatch(name, table.map { it.club }) ?: return null
        return table.firstOrNull { it.club == best }
    }
}

/**
 * Avrupa kupaları (ŞL, Avrupa Ligi, Konferans Ligi) için: az sayıdaki kupa maçı, ClubElo'nun uzun dönem kulüp gücüyle
 * birleştirilir. Elo farkından beklenen sonuç (We) hesaplanır; aynı Poisson modeliyle bu sonucu veren gol farkı bulunur
 * (toplam gol kupa tablosundan). Sonra kupa λ'sı ile Elo λ'sı log ölçekte, kupa maç sayısına göre ağırlıklı birleştirilir.
 */
object EloPrior {
    /** Kupa verisinin ağırlığı = n / (n + K). n = iki takımın en az kupa maçı. 3 maçta ≈ %33, 12 maçta ≈ %67. */
    const val K = 6.0
    /** Ev sahibi avantajı (Elo puanı). ClubElo'nun yaklaşık değeri; geri testle doğrulanmadı. */
    const val HOME_ADV = 60.0

    fun expected(homeElo: Double, awayElo: Double, homeAdv: Double = HOME_ADV): Double =
        1.0 / (1.0 + Math.pow(10.0, -(homeElo - awayElo + homeAdv) / 400.0))

    /** Toplam gol [total] sabitken, P(ev)+P(X)/2 = We olacak (λh, λa). */
    fun lambdas(homeElo: Double, awayElo: Double, total: Double): Pair<Double, Double> {
        val t = total.coerceIn(1.0, 6.0)
        val we = expected(homeElo, awayElo)
        fun score(s: Double): Double {
            val m = ScoreModel((t + s) / 2, (t - s) / 2)
            val h = MarketProb.prob(m, "1x2", "1") ?: 0.0
            val d = MarketProb.prob(m, "1x2", "X") ?: 0.0
            return h + d / 2
        }
        var lo = -(t - 0.4)
        var hi = t - 0.4
        repeat(40) {
            val mid = (lo + hi) / 2
            if (score(mid) < we) lo = mid else hi = mid
        }
        val s = (lo + hi) / 2
        return ((t + s) / 2).coerceIn(0.2, 4.0) to ((t - s) / 2).coerceIn(0.2, 4.0)
    }

    fun weight(cupGames: Int): Double = cupGames / (cupGames + K)

    /** Kupa λ'sı ile Elo λ'sını log ölçekte birleştirir. */
    fun blend(cup: Pair<Double, Double>, elo: Pair<Double, Double>, cupGames: Int): Pair<Double, Double> {
        val w = weight(cupGames)
        fun mix(a: Double, b: Double) = Math.exp(w * Math.log(a) + (1 - w) * Math.log(b)).coerceIn(0.2, 4.0)
        return mix(cup.first, elo.first) to mix(cup.second, elo.second)
    }
}

/**
 * Savran Elo: ClubElo'ya ulaşılamadığında kullanılan kendi kulüp güç puanımız. openfootball arşivindeki ~54.000 maçtan
 * (2015-16'dan Eylül 2026'ya; 5 büyük lig + 2. ligleri, Süper Lig, PT, NL, AT, SCO, GR, BE, CH, CZ, HU, RU ve ŞL) ClubElo
 * yöntemiyle (K=20, ŞL maçlarında K=40, ev avantajı 60, gol farkı çarpanı) hesaplandı; uygulamaya sabit dosya olarak girer.
 * Doğrulama: ŞL 2024-25'te (116 maç) 1-X-2 toplam Brier: kupa tablosu 0.547, Savran Elo 0.530, birleşim 0.529, taban 0.600.
 * Sınırlar: küçük liglerin üst takımları biraz yüksek çıkabilir (2020-24 ŞL verisi yok); arşivde olmayan ülkelerin
 * takımları (ör. Ukrayna, Slovenya) bulunmaz, o zaman Elo kullanılmaz.
 */
object SavranElo {
    const val DATA_DATE = "Eylül 2026"
    /** Dosyadaki puanların son maç tarihi (2026-09-21 00:00 UTC); bundan sonraki sonuçlar uygulamada işlenir. */
    const val DATA_CUTOFF_SEC = 1789948800L
    const val K = 20.0
    const val K_CUP = 40.0
    const val HOME_ADV = 60.0

    @Volatile private var base: List<EloEntry>? = null
    @Volatile private var updated: Pair<Int, List<EloEntry>>? = null

    fun baseTable(context: android.content.Context): List<EloEntry> {
        base?.let { return it }
        val t = try {
            context.assets.open("savran_elo.csv").bufferedReader(Charsets.UTF_8).use { ClubEloParser.parse(it.readText()) }
        } catch (e: Exception) { emptyList() }
        base = t
        return t
    }

    /** Dosyadaki puanlar + uygulamanın biriktirdiği (dosya tarihinden sonraki) bitmiş maçlarla güncellenmiş tablo. */
    fun table(context: android.content.Context, log: ResultsLog? = null): List<EloEntry> {
        val b = baseTable(context)
        if (log == null || b.isEmpty()) return b
        val n = try { log.size() } catch (e: Exception) { return b }
        updated?.let { if (it.first == n) return it.second }
        val res = try { log.allSince(DATA_CUTOFF_SEC) } catch (e: Exception) { emptyList() }
        val t = update(b, res.map { Leagues.isCup(it.leagueId) to it.r })
        updated = n to t
        return t
    }

    /** Güncellenen maç sayısı (Veri Sağlığı için). */
    @Volatile var lastApplied = 0
        private set

    /**
     * ClubElo yöntemiyle güncelleme. Aynı kulübün farklı yazılışları dosyada aynı puanla durur (ülke+puan aynı = aynı kulüp).
     * Takımı eşleşmeyen maç atlanır (uydurma yok).
     */
    fun update(base: List<EloEntry>, results: List<Pair<Boolean, FinishedResult>>): List<EloEntry> {
        if (results.isEmpty()) { lastApplied = 0; return base }
        val groupOf = HashMap<String, String>()
        val rating = HashMap<String, Double>()
        for (e in base) {
            val g = e.country + "|" + e.elo
            groupOf[e.club] = g
            rating[g] = e.elo
        }
        val names = base.map { it.club }
        val match = HashMap<String, String?>()
        fun group(team: String): String? = match.getOrPut(team) { TeamMatcher.bestMatch(team, names)?.let { groupOf[it] } }
        var applied = 0
        for ((cup, r) in results) {
            val gh = group(r.home) ?: continue
            val ga = group(r.away) ?: continue
            if (gh == ga) continue
            val eh = rating[gh] ?: continue
            val ea = rating[ga] ?: continue
            val exp = 1.0 / (1.0 + Math.pow(10.0, -(eh - ea + HOME_ADV) / 400.0))
            val res = if (r.homeGoals > r.awayGoals) 1.0 else if (r.homeGoals == r.awayGoals) 0.5 else 0.0
            val g = kotlin.math.abs(r.homeGoals - r.awayGoals)
            val mult = if (g <= 1) 1.0 else if (g == 2) 1.5 else (11.0 + g) / 8.0
            val d = (if (cup) K_CUP else K) * mult * (res - exp)
            rating[gh] = eh + d
            rating[ga] = ea - d
            applied++
        }
        lastApplied = applied
        return base.map { e -> e.copy(elo = rating[groupOf[e.club]] ?: e.elo) }
    }
}

/** Günlük önbellekli ClubElo istemcisi. Anahtar gerekmez. Hata durumunda null döner ve durum metni saklanır. */
class ClubEloSource(private val dir: File) {
    @Volatile var status: String = "Henüz denenmedi"
        private set
    @Volatile private var mem: Pair<String, List<EloEntry>>? = null
    @Volatile private var failedAt = 0L

    private fun file(date: String) = File(dir, "clubelo_$date.csv")

    fun table(today: LocalDate): List<EloEntry>? {
        val key = today.toString()
        mem?.let { if (it.first == key) return it.second }
        // Başarısız denemeden sonra 10 dk tekrar denenmez (her maçta ağ zaman aşımı beklenmesin).
        if (failedAt != 0L && System.currentTimeMillis() - failedAt < 10 * 60_000L) return staleOrNull(today)
        try {
            dir.mkdirs()
            val f = file(key)
            if (f.exists()) {
                val cached = ClubEloParser.parse(f.readText())
                if (cached.isNotEmpty()) {
                    mem = key to cached
                    status = "Önbellekten okundu (${cached.size} kulüp)"
                    return cached
                }
            }
            // Sırayla: bugün, dün, önceki gün; her biri için önce HTTPS, sonra http. (Sunucu bazen 502 veriyor.)
            var lastErr = ""
            for (back in 0L..2L) {
                val d = today.minusDays(back).toString()
                for (scheme in listOf("https", "http")) {
                    val r = try {
                        Http.get("$scheme://api.clubelo.com/$d", mapOf("User-Agent" to "Mozilla/5.0 (Android) SavranAnaliz"))
                    } catch (e: kotlinx.coroutines.CancellationException) {
                        throw e
                    } catch (e: Exception) {
                        lastErr = e.javaClass.simpleName; null
                    } ?: continue
                    if (r.code !in 200..299) { lastErr = "HTTP ${r.code}"; continue }
                    val parsed = ClubEloParser.parse(r.body)
                    if (parsed.isEmpty()) { lastErr = "boş yanıt"; continue }
                    f.writeText(r.body)
                    mem = key to parsed
                    status = "Alındı (${parsed.size} kulüp${if (back > 0) ", $d tarihli" else ""})"
                    return parsed
                }
            }
            failedAt = System.currentTimeMillis()
            status = "İstek başarısız ($lastErr)"
            return staleOrNull(today)
        } catch (e: kotlinx.coroutines.CancellationException) {
            throw e
        } catch (e: Exception) {
            status = "Ulaşılamadı (${e.javaClass.simpleName})"
            failedAt = System.currentTimeMillis()
            return staleOrNull(today)
        }
    }

    /** Sunucuya ulaşılamazsa son 7 gün içindeki kayıtlı Elo tablosu kullanılır (Elo yavaş değişir). */
    private fun staleOrNull(today: LocalDate): List<EloEntry>? {
        for (back in 1L..7L) {
            val f = file(today.minusDays(back).toString())
            if (!f.exists()) continue
            val t = try { ClubEloParser.parse(f.readText()) } catch (e: Exception) { emptyList() }
            if (t.isNotEmpty()) {
                status += " · ${back} gün önceki kayıt kullanılıyor"
                return t
            }
        }
        return null
    }
}
