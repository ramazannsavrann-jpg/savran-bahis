package com.savran.bahis

import java.io.File
import java.time.LocalDate

/** ClubElo'dan bir kulübün Elo puanı. */
data class EloEntry(val club: String, val country: String, val elo: Double)

/** ClubElo CSV ayrıştırıcı. Başlık sırasına bağlı değildir; bozuk satırlar atlanır, hiçbir zaman istisna fırlatmaz. */
object ClubEloParser {
    fun parse(csv: String): List<EloEntry> {
        val lines = csv.lineSequence().map { it.trim() }.filter { it.isNotEmpty() }.toList()
        if (lines.size < 2) return emptyList()
        val header = lines[0].split(",").map { it.trim().lowercase() }
        val ci = header.indexOf("club")
        val ei = header.indexOf("elo")
        val ni = header.indexOf("country")
        if (ci < 0 || ei < 0) return emptyList()
        val out = ArrayList<EloEntry>()
        for (l in lines.drop(1)) {
            val p = l.split(",")
            if (p.size <= maxOf(ci, ei)) continue
            val elo = p[ei].trim().toDoubleOrNull() ?: continue
            val club = p[ci].trim()
            if (club.isEmpty() || elo < 500.0 || elo > 3000.0) continue
            out.add(EloEntry(club, if (ni in p.indices) p[ni].trim() else "", elo))
        }
        return out
    }
}

/**
 * Elo farkından küçük ve SINIRLI bir güç düzeltmesi (yalnızca Avrupa kupası maçlarında; takımların lig gücü farkını
 * tahminen yansıtır). Kalibrasyonla doğrulanmadığı için etkisi en fazla ±%7.5 (ev/deplasman λ'sı ters yönde).
 */
object EloAdjust {
    const val MAX_LOG = 0.15

    /** (ev çarpanı, deplasman çarpanı). */
    fun factors(homeElo: Double, awayElo: Double): Pair<Double, Double> {
        val d = homeElo - awayElo
        val f = (d / 400.0 * 0.25).coerceIn(-MAX_LOG, MAX_LOG)
        return Math.exp(f / 2.0) to Math.exp(-f / 2.0)
    }

    /** Takım adına en uygun Elo kaydı; belirsiz veya bulunamazsa null (uydurma eşleştirme yok). */
    fun find(name: String, table: List<EloEntry>): EloEntry? {
        val best = TeamMatcher.bestMatch(name, table.map { it.club }) ?: return null
        return table.firstOrNull { it.club == best }
    }
}

/**
 * Avrupa kupaları (ŞL, Avrupa Ligi, Konferans Ligi) için: az sayıdaki kupa maçı, ClubElo'nun uzun dönem kulüp gücüyle
 * birleştirilir. Elo farkından beklenen sonuç (We) hesaplanır; aynı Poisson modeliyle bu sonucu veren gol farkı bulunur
 * (toplam gol kupa tablosundan). Sonra kupa λ'sı ile Elo λ'sı log ölçekte, kupa maç sayısına göre ağırlıklı birleştirilir.
 */
object EloPrior {
    /** Kupa verisinin ağırlığı = n / (n + K). n = iki takımın en az kupa maçı. 3 maçta ≈ %33, 12 maçta ≈ %67. */
    const val K = 6.0
    /** Ev sahibi avantajı (Elo puanı). ClubElo'nun yaklaşık değeri; geri testle doğrulanmadı. */
    const val HOME_ADV = 60.0

    fun expected(homeElo: Double, awayElo: Double, homeAdv: Double = HOME_ADV): Double =
        1.0 / (1.0 + Math.pow(10.0, -(homeElo - awayElo + homeAdv) / 400.0))

    /** Toplam gol [total] sabitken, P(ev)+P(X)/2 = We olacak (λh, λa). */
    fun lambdas(homeElo: Double, awayElo: Double, total: Double): Pair<Double, Double> {
        val t = total.coerceIn(1.0, 6.0)
        val we = expected(homeElo, awayElo)
        fun score(s: Double): Double {
            val m = ScoreModel((t + s) / 2, (t - s) / 2)
            val h = MarketProb.prob(m, "1x2", "1") ?: 0.0
            val d = MarketProb.prob(m, "1x2", "X") ?: 0.0
            return h + d / 2
        }
        var lo = -(t - 0.4)
        var hi = t - 0.4
        repeat(40) {
            val mid = (lo + hi) / 2
            if (score(mid) < we) lo = mid else hi = mid
        }
        val s = (lo + hi) / 2
        return ((t + s) / 2).coerceIn(0.2, 4.0) to ((t - s) / 2).coerceIn(0.2, 4.0)
    }

    fun weight(cupGames: Int): Double = cupGames / (cupGames + K)

    /** Kupa λ'sı ile Elo λ'sını log ölçekte birleştirir. */
    fun blend(cup: Pair<Double, Double>, elo: Pair<Double, Double>, cupGames: Int): Pair<Double, Double> {
        val w = weight(cupGames)
        fun mix(a: Double, b: Double) = Math.exp(w * Math.log(a) + (1 - w) * Math.log(b)).coerceIn(0.2, 4.0)
        return mix(cup.first, elo.first) to mix(cup.second, elo.second)
    }
}

/** Günlük önbellekli ClubElo istemcisi. Anahtar gerekmez. Hata durumunda null döner ve durum metni saklanır. */
class ClubEloSource(private val dir: File) {
    @Volatile var status: String = "Henüz denenmedi"
        private set
    @Volatile private var mem: Pair<String, List<EloEntry>>? = null
    @Volatile private var failedAt = 0L

    private fun file(date: String) = File(dir, "clubelo_$date.csv")

    fun table(today: LocalDate): List<EloEntry>? {
        val key = today.toString()
        mem?.let { if (it.first == key) return it.second }
        // Başarısız denemeden sonra 10 dk tekrar denenmez (her maçta ağ zaman aşımı beklenmesin).
        if (failedAt != 0L && System.currentTimeMillis() - failedAt < 10 * 60_000L) return null
        try {
            dir.mkdirs()
            val f = file(key)
            if (f.exists()) {
                val cached = ClubEloParser.parse(f.readText())
                if (cached.isNotEmpty()) {
                    mem = key to cached
                    status = "Önbellekten okundu (${cached.size} kulüp)"
                    return cached
                }
            }
            // Önce HTTPS; olmazsa (sunucu yalnızca http veriyorsa) http. Cleartext yalnızca bu alan adı için açıktır.
            val r = try {
                Http.get("https://api.clubelo.com/$key")
            } catch (e: kotlinx.coroutines.CancellationException) {
                throw e
            } catch (e: Exception) {
                Http.get("http://api.clubelo.com/$key")
            }
            if (r.code !in 200..299) {
                status = "İstek başarısız (HTTP ${r.code})"
                failedAt = System.currentTimeMillis()
                return null
            }
            val parsed = ClubEloParser.parse(r.body)
            if (parsed.isEmpty()) {
                status = "Yanıt okunamadı veya boş"
                failedAt = System.currentTimeMillis()
                return null
            }
            f.writeText(r.body)
            mem = key to parsed
            status = "Alındı (${parsed.size} kulüp)"
            return parsed
        } catch (e: kotlinx.coroutines.CancellationException) {
            throw e
        } catch (e: Exception) {
            status = "Ulaşılamadı (${e.javaClass.simpleName})"
            failedAt = System.currentTimeMillis()
            return null
        }
    }
}
