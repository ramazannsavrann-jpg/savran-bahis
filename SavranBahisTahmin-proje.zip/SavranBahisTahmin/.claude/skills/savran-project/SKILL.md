---
name: savran-project
description: Savran Analiz projesinin haritası, değiştirilemez kuralları ve ajan çıktı sözleşmesi. Her Savran uzman ajanı bunu bilmelidir.
---

# Savran Analiz – proje bilgisi

Kişisel, reklamsız, platformdan bağımsız (Nesine DEĞİL) Android futbol analiz uygulaması. Kotlin + Jetpack Compose, paket `com.savran.bahis`, kaynak: `app/src/main/java/com/savran/bahis`.

## Kod haritası
- Model/olasılık: Model.kt (Poisson/Dixon tarzı skor modeli, Strength.lambdas), Markets.kt, Analysis.kt, Forecast.kt (güven puanı), Criteria.kt (kullanılan/kullanılamayan kriterler)
- Pazar seçimi: Filters.kt (pazar başına en yüksek olasılık), Rules.kt
- Kupon: Coupons.kt (Dengeli / Sürpriz / Yüksek Riskli)
- Öğrenme: Learning.kt (kalibrasyon), History.kt, Periods.kt (günlük/haftalık/aylık rapor)
- Haber: News.kt, Rotation.kt; tablo yedeği: ResultsTable.kt, Standings.kt
- Veri: Sources.kt, SourceClients.kt, ApiFootball.kt, OddsApi.kt, Repository.kt, FixtureMerge.kt, Verification.kt, TeamMatcher.kt
- Ayar/anahtar: AppSettings.kt (EncryptedSharedPreferences)
- Arayüz: Ui.kt, DetailScreen.kt, OtherScreens.kt, ForecastUi.kt, SourcesUi.kt, PerformanceUi.kt, MainActivity.kt
- Testler: app/src/test/java/com/savran/bahis (RulesTest, SourcesTest, ForecastTest, NewFeaturesTest) – henüz hiç çalıştırılmadı.

## Değiştirilemez kurallar
1. Yalnızca gerçek, çekilmiş veri. Veri uydurma, eksik veriyi tahminle doldurma yok. Eksik veri açıkça yazılır.
2. Olasılık ≠ güven ≠ veri kalitesi. Üçü ayrı gösterilir.
3. Tahmin oransız çalışır. Oran yoksa toplam oran / kazanç / EV gösterilmez.
4. Her pazarda yalnızca en yüksek olasılıklı seçenek. Yasaklılar: İlk Yarı 2.5 Alt, 0.5 Üst, 4.5 Alt.
5. Kupon türleri yalnızca Dengeli, Sürpriz, Yüksek Riskli. Değer kuponu ve sanal kupon takibi YOK. Nesine entegrasyonu YOK.
6. Öğrenme kontrollü: küçük örneklemden sonuç çıkarılmaz, veri sızıntısı olmaz, geçmiş kayıt silinmez.
7. UEFA kupalarında güven sınırlı (en fazla Orta).
8. API anahtarları koda/repoya yazılmaz; yalnızca uygulama Ayarlar'ında şifreli saklanır.
9. Ücretli servis kullanmadan önce kullanıcıdan onay alınır.
10. "Derlendi / test edildi" yalnızca gerçekten derlenip çalıştırıldıysa söylenir. Sandbox'ta Gradle/Android SDK yoktur; derleme GitHub Actions'ta olur.

## Ortak çıktı sözleşmesi (her ajan bu başlıklarla yanıt verir, Türkçe)
## Sonuç
## Kullanılan veriler   (kaynak + tarih; doğrulanmış mı?)
## Eksik veriler
## Güven   (Yüksek/Orta/Düşük + gerekçe)
## Başka ajanın kontrol etmesi gerekenler

Kesin tahmin dili yasak ("kesin", "garanti" kullanma). Doğrulanmamış bilgi "doğrulanmadı" diye işaretlenir.
