---
name: machina-football-data
description: Machina Sports "sports-skills" football-data aracını (Python CLI) kullanma rehberi, kapsam sınırları ve kullanım şartları. Güncel takım/oyuncu/xG/sakatlık verisi araştırırken kullan.
---

# Machina Sports – Football Data (kullanım rehberi)

Bu, resmi SKILL.md DEĞİL; Savran Analiz için yazılmış kullanım rehberidir. Resmi paket: github.com/machina-sports/sports-skills (MIT).

## Ne olduğu
Python 3.10+ paketi/CLI. API anahtarı gerektirmez. Kaynaklar: ESPN, FPL, Understat, Transfermarkt, football-data.co.uk, ClubElo.

## Kurulum (yalnızca ağ erişimi olan bir ortamda)
```
pip install sports-skills
npx skills add machina-sports/sports-skills@football-data
```
Ağ yoksa kurulamaz; kurulmadan "çalıştı" denmez.

## Doğrulanmış komut örnekleri
```
sports-skills football get_daily_schedule
sports-skills football get_season_standings --season_id=premier-league-2025
sports-skills football scores --date=YYYY-MM-DD
sports-skills football get_event_summary --event_id=<id>
sports-skills football get_event_xg --event_id=<id>
sports-skills football get_season_leaders --season_id=<id>
sports-skills football get_missing_players --season_id=<id>
```
Sezon kimliği için önce `get_current_season(competition_id=...)`. Komut adları sürümle değişebilir: önce `--help` ile doğrula.

## Kapsam sınırları (dürüstlük)
- xG yalnızca ilk 5 lig (Understat). Süper Lig / 1. Lig / UEFA kupaları için xG YOK → "veri alınamadı" yaz.
- FPL verisi yalnızca Premier League.
- ESPN uç noktaları belgesiz; bozulabilir. Hata alırsan veri uydurma.
- Kişisel / ticari olmayan kullanım; kaynak sitelerin şartları geçerlidir.
- Android uygulamasının içine gömülemez (Python). Yalnızca araştırma/doğrulama aracıdır; uygulamaya veri aktarımı ayrı bir geliştirme kararıdır.

## Kanıt kuralı
Her sayının yanına kaynak (ESPN/Understat/…) ve çekim tarihi yaz. Çekilmemiş veriyi "Machina'dan" diye sunma. Araç çalıştırılamadıysa bunu "Eksik veriler" altında belirt.
