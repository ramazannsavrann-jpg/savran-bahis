package com.savran.bahis

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test

class ThinDataFallbackTest {
    private fun row(id: Int, allP: Int, homeP: Int, awayP: Int) =
        TeamRow(id, "T$id", id, allP, SplitStats(allP, allP * 2, allP), SplitStats(homeP, homeP * 2, homeP), SplitStats(awayP, awayP, awayP), "")

    @Test
    fun thinSplitFallsBackToOverallWhenTwoGamesExist() {
        val rows = listOf(row(1, 2, 1, 1), row(2, 2, 1, 1), row(3, 2, 1, 1), row(4, 2, 1, 1))
        val l = Strength.lambdas(rows, 1, 2)
        assertNotNull(l)
        assertTrue(l!!.overallFallback)
        assertEquals(0.25, l.dataQuality, 1e-9)
        assertTrue(l.dataQuality >= ForecastEngine.MIN_DATA_QUALITY)
    }

    @Test
    fun enoughSplitDoesNotUseFallback() {
        val rows = listOf(row(1, 8, 4, 4), row(2, 8, 4, 4))
        val l = Strength.lambdas(rows, 1, 2)!!
        assertTrue(!l.overallFallback)
        assertEquals(0.5, l.dataQuality, 1e-9)
    }

    @Test
    fun oneTotalGameStillProducesNoForecast() {
        val rows = listOf(row(1, 1, 1, 0), row(2, 1, 0, 1))
        val l = Strength.lambdas(rows, 1, 2)
        assertTrue(l == null || l.dataQuality < ForecastEngine.MIN_DATA_QUALITY)
    }

    @Test
    fun lowConfidenceShownOnlyWhenNothingStrongerExists() {
        val low = Forecast("m", "1x2", "1", 0.6, Confidence.LOW, 40, null, null, null, null, "")
        assertTrue(ForecastEngine.bahisFirsatlari(listOf(low)).isEmpty())
        assertEquals(1, ForecastEngine.shownWithFallback(listOf(low)).size)
        val mid = low.copy(marketKey = "dc", selectionKey = "1X", confidence = Confidence.MEDIUM)
        assertEquals(listOf(mid), ForecastEngine.shownWithFallback(listOf(low, mid)))
    }
}
