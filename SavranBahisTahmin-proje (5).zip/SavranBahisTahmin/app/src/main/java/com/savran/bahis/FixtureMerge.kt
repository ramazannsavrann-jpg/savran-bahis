package com.savran.bahis

import kotlin.math.abs

/**
 * Birden fazla kaynaktan gelen maç listelerini tek listede birleştirir.
 * Aynı maç = aynı lig + kickoff farkı ≤ 3 saat + iki takım adı benzer.
 * Ana listedeki (öncelikli) maç korunur; yalnızca eksik logo ve "kaynak" listesi tamamlanır.
 * Canlı/skor verisi iki kaynaktan karıştırılmaz.
 */
object FixtureMerge {
    private const val MAX_DIFF_SEC = 3 * 3600L
    private const val LOOSE_SIDE = 0.4
    const val SEP = " + "

    fun sameMatch(a: Match, b: Match): Boolean {
        if (a.leagueId != b.leagueId) return false
        if (abs(a.kickoff - b.kickoff) > MAX_DIFF_SEC) return false
        val homeSame = TeamMatcher.isSame(a.home, b.home)
        val awaySame = TeamMatcher.isSame(a.away, b.away)
        if (homeSame && awaySame) return true
        // Aynı ligde, birkaç saat içinde aynı takım iki farklı maç oynayamaz: bir taraf kesin eşleşiyorsa ve
        // diğer taraf da en azından benzerse (farklı yazım: "Sporting CP" / "Sporting Clube de Portugal") aynı maçtır.
        if (homeSame && TeamMatcher.similarity(a.away, b.away) >= LOOSE_SIDE) return true
        if (awaySame && TeamMatcher.similarity(a.home, b.home) >= LOOSE_SIDE) return true
        return false
    }

    fun sources(m: Match): List<String> = m.source.split(SEP).map { it.trim() }.filter { it.isNotEmpty() }

    fun merge(base: List<Match>, extras: List<Match>): List<Match> {
        val out = base.toMutableList()
        for (e in extras) {
            val i = out.indexOfFirst { sameMatch(it, e) }
            if (i < 0) out.add(e) else out[i] = enrich(out[i], e)
        }
        return out.sortedBy { it.kickoff }
    }

    private fun enrich(a: Match, b: Match): Match {
        val names = (sources(a) + sources(b)).distinct().joinToString(SEP)
        var r = a.copy(source = names, homeLogo = a.homeLogo ?: b.homeLogo, awayLogo = a.awayLogo ?: b.awayLogo)
        // Ana kaynakta maç hâlâ "başlamadı" görünüyor ama diğer kaynakta bitmişse, bitmiş veriyi bir bütün olarak al.
        if (!StatusText.isFinished(a.statusShort) && StatusText.isFinished(b.statusShort)) {
            r = r.copy(
                statusShort = b.statusShort, homeGoals = b.homeGoals, awayGoals = b.awayGoals,
                homeHt = b.homeHt ?: r.homeHt, awayHt = b.awayHt ?: r.awayHt
            )
        }
        return r
    }
}
