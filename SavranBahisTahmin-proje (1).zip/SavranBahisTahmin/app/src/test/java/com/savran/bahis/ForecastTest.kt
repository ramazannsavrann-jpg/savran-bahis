package com.savran.bahis

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

private fun ctx(dq: Double, model: ScoreModel? = ScoreModel(1.6, 1.1), rot: Boolean = false, hist: Double? = null) =
    AnalysisContext(model, dq, rot, hist)

class ForecastEngineTest {
    @Test fun oddlessMatchGetsForecastsForManyMarkets() {
        val f = ForecastEngine.generate("m1", ctx(0.9), emptyList())
        assertTrue(f.isNotEmpty())
        assertTrue(f.all { it.odds == null && it.ev == null && it.decision == null })
        assertTrue(f.all { it.prob in 0.0..1.0 })
        assertTrue(f.all { it.dataQuality == 0.9 })
        listOf("1x2", "dc", "ou_1.5", "ou_2.5", "ou_3.5", "btts", "home_ou_0.5", "away_ou_1.5", "ht_1x2", "htft", "cs")
            .forEach { mk -> assertTrue(mk, f.any { it.marketKey == mk }) }
    }

    @Test fun noInventedForecastsForMarketsWithoutModel() {
        val f = ForecastEngine.generate("m1", ctx(0.9), emptyList())
        assertFalse(f.any { it.marketKey.contains("corners") || it.marketKey.startsWith("cards") || it.marketKey.startsWith("yellow") })
    }

    @Test fun overAndUnderAreComplementary() {
        val f = ForecastEngine.generate("m1", ctx(0.9), emptyList())
        val over = f.first { it.marketKey == "ou_2.5" && it.selectionKey == "over" }.prob
        val under = f.first { it.marketKey == "ou_2.5" && it.selectionKey == "under" }.prob
        assertEquals(1.0, over + under, 1e-3)
    }

    @Test fun tooLittleDataOrNoModelMeansNoForecastAndAReason() {
        assertTrue(ForecastEngine.generate("m1", ctx(0.2), emptyList()).isEmpty())
        assertTrue(ForecastEngine.generate("m1", ctx(0.9, model = null), emptyList()).isEmpty())
        assertNotNull(ForecastEngine.noForecastReason(ctx(0.2), "not"))
        assertNotNull(ForecastEngine.noForecastReason(ctx(0.9, model = null), "puan durumu alınamadı"))
        assertNull(ForecastEngine.noForecastReason(ctx(0.9), ""))
    }

    @Test fun thresholdMeansFewerThanTwoHomeOrAwayGames() {
        // dq = min(ev sahibinin iç saha maçı, deplasman takımının deplasman maçı) / 8; 0.25 = tam 2 maç
        assertEquals(0.25, minOf(2, 9) / 8.0, 1e-12)
        val one = AnalysisContext(ScoreModel(1.6, 1.1), 1 / 8.0, false, null, 1.0, 1, 5)
        assertTrue(ForecastEngine.generate("m", one, emptyList()).isEmpty())
        val reason = ForecastEngine.noForecastReason(one, "")!!
        assertTrue(reason.contains("iç saha maçı: 1"))
        assertTrue(reason.contains("en az 2"))
        val two = AnalysisContext(ScoreModel(1.6, 1.1), 2 / 8.0, false, null, 1.0, 2, 5)
        assertTrue(ForecastEngine.generate("m", two, emptyList()).isNotEmpty())
    }

    @Test fun confidenceDropsWithPartialData() {
        fun lvl(dq: Double, rel: Double = 1.0, rot: Boolean = false, cov: Double = 1.0) =
            ForecastEngine.level(ForecastEngine.confidenceScore(dq, rel, null, rot, cov))
        assertEquals(Confidence.HIGH, lvl(1.0))
        assertEquals(Confidence.MEDIUM, lvl(0.5))
        assertEquals(Confidence.LOW, lvl(0.25))
        assertEquals(Confidence.MEDIUM, lvl(1.0, rel = 0.4))      // doğru skor gibi riskli pazar
        assertTrue(ForecastEngine.confidenceScore(1.0, 1.0, null, true) < ForecastEngine.confidenceScore(1.0, 1.0, null, false))
        assertTrue(ForecastEngine.confidenceScore(1.0, 1.0, null, false, 0.0) < ForecastEngine.confidenceScore(1.0, 1.0, null, false, 1.0))
        assertNull(ForecastEngine.level(34))
    }

    @Test fun lowCoverageLowersConfidenceOfTheSameMatch() {
        val full = AnalysisContext(ScoreModel(1.6, 1.1), 0.9, false, null, 1.0)
        val partial = AnalysisContext(ScoreModel(1.6, 1.1), 0.9, false, null, 0.0)
        val a = ForecastEngine.generate("m", full, emptyList()).first { it.marketKey == "1x2" }
        val b = ForecastEngine.generate("m", partial, emptyList()).first { it.marketKey == "1x2" }
        assertTrue(b.confidenceScore < a.confidenceScore)
        assertEquals(a.prob, b.prob, 1e-12)   // olasılık aynı, yalnızca güven düşer
    }

    @Test fun confidenceIsIndependentOfProbability() {
        val f = ForecastEngine.generate("m1", ctx(0.9), emptyList())
        val a = f.first { it.marketKey == "ou_2.5" && it.selectionKey == "over" }
        val b = f.first { it.marketKey == "ou_0.5" && it.selectionKey == "over" }
        assertTrue(a.prob < b.prob)
        assertEquals(a.confidenceScore, b.confidenceScore)
    }

    @Test fun realOddsAreAttachedOnlyWhenEntered() {
        val e = Evaluation(
            "m1", "ou_2.5", "over", 1.90, "Kaynak", "Manuel", 0L, 0.6, 0.6, 1 / 1.9, null, 0.14, 70, null,
            Decision.RECOMMEND, "r", false
        )
        val f = ForecastEngine.generate("m1", ctx(0.9), listOf(e))
        val withOdds = f.first { it.marketKey == "ou_2.5" && it.selectionKey == "over" }
        assertEquals(1.90, withOdds.odds!!, 1e-9)
        assertEquals(0.14, withOdds.ev!!, 1e-9)
        assertNull(f.first { it.marketKey == "ou_1.5" && it.selectionKey == "over" }.odds)
    }

    @Test fun strongestPicksOnePerFamilyAndSkipsTrivialProbabilities() {
        val f = ForecastEngine.generate("m1", ctx(0.9), emptyList())
        val s = ForecastEngine.strongest(f, 8)
        assertTrue(s.size <= 8)
        assertTrue(s.all { it.prob < ForecastEngine.TRIVIAL_PROB })
        val fams = s.map { ForecastEngine.family(it.marketKey, it.selectionKey) }
        assertEquals(fams.size, fams.distinct().size)
        assertEquals(s, s.sortedByDescending { ForecastEngine.weighted(it) })
    }

    @Test fun laddersShowLinesSideBySide() {
        val f = ForecastEngine.generate("m1", ctx(0.9), emptyList())
        val l = ForecastEngine.ladders(f).first { it.title == "Toplam gol Üst" }
        assertEquals(5, l.items.size)
        assertEquals(l.items.map { it.second }, l.items.map { it.second }.sortedDescending())
    }

    @Test fun unplayableLinesAreMarked() {
        assertFalse(ForecastEngine.isPlayable("ou_0.5", "over"))
        assertFalse(ForecastEngine.isPlayable("ou_4.5", "under"))
        assertTrue(ForecastEngine.isPlayable("ou_0.5", "under"))
        assertTrue(ForecastEngine.isPlayable("ou_4.5", "over"))
        assertTrue(ForecastEngine.isPlayable("ou_1.5", "over"))
        assertFalse(ForecastEngine.isPlayable("ht_ou_2.5", "under"))   // İlk Yarı 2.5 Alt hiçbir koşulda
        assertTrue(ForecastEngine.isPlayable("ht_ou_2.5", "over"))
        assertTrue(ForecastEngine.isPlayable("ht_ou_1.5", "under"))
        assertTrue(ForecastEngine.isPlayable("ht_ou_0.5", "under"))
    }
}

class MarketFiltersTest {
    private val all = ForecastEngine.generate("m1", AnalysisContext(ScoreModel(2.0, 1.8), 0.9, false, null), emptyList())

    @Test fun onlyGroupsWithRealForecastsAreOffered() {
        val ids = MarketFilters.availableGroups(all).map { it.id }
        listOf("1x2", "dc", "goals", "btts", "home", "away", "ht1x2", "htgoals", "htft", "hcp", "combo", "cs")
            .forEach { assertTrue(it, ids.contains(it)) }
        assertTrue(MarketFilters.availableGroups(emptyList()).isEmpty())
    }

    @Test fun goalLinesListOnlyTheMarketWinnerAndNeverUnplayableOnes() {
        val g = MarketFilters.group("goals")!!
        val opts = MarketFilters.options(g, all)
        assertFalse(opts.contains("ou_0.5" to "over"))
        assertFalse(opts.contains("ou_4.5" to "under"))
        // Her seçenek, kendi pazarının en yüksek olasılıklı seçeneğidir
        opts.forEach { (mk, sk) ->
            val mine = all.first { it.marketKey == mk && it.selectionKey == sk }.prob
            assertTrue(all.filter { it.marketKey == mk }.all { it.prob <= mine + 1e-12 })
        }
    }

    @Test fun selectingBttsYesListsOnlyWhenYesIsTheBestAlternative() {
        val g = MarketFilters.group("btts")!!
        val yes = MarketFilters.apply(all, g, "btts" to "yes")
        assertEquals(1, yes.size)
        assertEquals("yes", yes[0].selectionKey)
        // KG Yok daha düşük olasılıklı alternatif: listelenmez
        assertTrue(MarketFilters.apply(all, g, "btts" to "no").isEmpty())
        assertEquals(1, MarketFilters.apply(all, g, null).size)
    }

    @Test fun filteredListsHaveOneEntryPerMarket() {
        val g = MarketFilters.group("goals")!!
        val r = MarketFilters.apply(all, g, null)
        assertTrue(r.all { it.marketKey.startsWith("ou_") })
        assertEquals(r.size, r.map { it.marketKey }.distinct().size)
        assertFalse(r.any { it.marketKey == "ou_0.5" && it.selectionKey == "over" })
        assertFalse(r.any { it.marketKey == "ou_4.5" && it.selectionKey == "under" })
    }

    @Test fun shortLabels() {
        assertEquals("Üst 2.5", MarketFilters.shortLabel("ou_2.5", "over"))
        assertEquals("KG Var", MarketFilters.shortLabel("btts", "yes"))
        assertEquals("Ev Üst 1.5", MarketFilters.shortLabel("home_ou_1.5", "over"))
        assertEquals("Dep Üst 0.5", MarketFilters.shortLabel("away_ou_0.5", "over"))
        assertEquals("X", MarketFilters.shortLabel("1x2", "X"))
        assertEquals("İY 1X", MarketFilters.shortLabel("ht_dc", "1X"))
        assertEquals("1/2", MarketFilters.shortLabel("htft", "1/2"))
    }
}

class CriteriaTest {
    private fun input(
        model: Boolean = true, manual: Boolean = false, form: Boolean = true, rot: Boolean = false, hist: Boolean = false,
        news: Int = 1, derived: Boolean = false, src: String = "API-Football"
    ) = CriteriaInput(model, manual, form, rot, hist, src, 2026, derived, news)

    private fun status(list: List<Criterion>, name: String) = list.first { it.name == name }.status

    @Test fun usedCriteriaAreExactlyTheOnesTheModelUses() {
        val c = Criteria.build(input())
        assertEquals(CriterionStatus.USED, status(c, "İç saha / deplasman performansı"))
        assertEquals(CriterionStatus.USED, status(c, "Atılan ve yenilen goller (maç başı)"))
        assertEquals(CriterionStatus.USED, status(c, "Son 5 maç formu"))
        assertEquals(1.0, Criteria.coverage(input()), 1e-12)
    }

    @Test fun missingFormIsReportedNotInvented() {
        val c = Criteria.build(input(form = false))
        assertEquals(CriterionStatus.NO_DATA, status(c, "Son 5 maç formu"))
        assertEquals(2.0 / 3.0, Criteria.coverage(input(form = false)), 1e-12)
    }

    @Test fun neverClaimsDataThatIsNotFetched() {
        listOf(input(), input(form = false), input(model = false), input(manual = true), input(rot = true, hist = true)).forEach { i ->
            val c = Criteria.build(i)
            listOf("xG ve xGA", "Şut ve isabetli şut", "Korner istatistikleri").forEach { n ->
                assertEquals(n, CriterionStatus.NO_DATA, status(c, n))
            }
            assertEquals(CriterionStatus.NOT_USED, status(c, "Son 10 maç formu"))
            assertEquals(CriterionStatus.NOT_USED, status(c, "Sakat ve cezalı oyuncular"))   // haber yoksa kullanılmış gibi gösterilmez
            assertEquals(CriterionStatus.NOT_USED, status(c, "Karşılıklı maç geçmişi"))
        }
    }

    @Test fun noModelAndManualCases() {
        val none = Criteria.build(input(model = false, form = false))
        assertEquals(CriterionStatus.NO_DATA, status(none, "İç saha / deplasman performansı"))
        assertEquals(0.0, Criteria.coverage(input(model = false)), 1e-12)
        val manual = Criteria.build(input(manual = true, form = false))
        assertEquals(CriterionStatus.NOT_USED, status(manual, "İç saha / deplasman performansı"))
        assertEquals(0.0, Criteria.coverage(input(manual = true, form = false)), 1e-12)
    }

    @Test fun newsAndDerivedTableAreReportedHonestly() {
        val news = "Güncel haberler (teknik direktör, ilk 11, yorgunluk)"
        assertEquals(CriterionStatus.USED, status(Criteria.build(input(news = 3)), "Sakat ve cezalı oyuncular"))
        assertEquals(CriterionStatus.PARTIAL, status(Criteria.build(input(news = 2)), "Sakat ve cezalı oyuncular"))
        assertEquals(CriterionStatus.NOT_USED, status(Criteria.build(input(news = 1)), "Sakat ve cezalı oyuncular"))
        assertEquals(CriterionStatus.NOT_USED, status(Criteria.build(input(news = 0)), news))
        assertEquals(CriterionStatus.NO_DATA, status(Criteria.build(input(news = 1)), news))
        assertEquals(CriterionStatus.PARTIAL, status(Criteria.build(input(news = 3)), news))
        val d = Criteria.build(input(derived = true, src = "Football-Data.org" + ResultsTable.DERIVED_SUFFIX))
        assertTrue(d.first { it.name == "İç saha / deplasman performansı" }.note.contains("hesaplandı"))
    }

    @Test fun rotationAndHistoryOnlyAffectConfidenceWhenKnown() {
        assertEquals(CriterionStatus.NO_DATA, status(Criteria.build(input()), "Takım rotasyonu"))
        assertEquals(CriterionStatus.PARTIAL, status(Criteria.build(input(rot = true)), "Takım rotasyonu"))
        assertEquals(CriterionStatus.PARTIAL, status(Criteria.build(input(hist = true)), "Modelin geçmiş performansı"))
    }
}

class FormTest {
    private fun row(id: Int, played: Int, points: Int, hGf: Int, hGa: Int, aGf: Int, aGa: Int, form: String) =
        TeamRow(id, "T$id", id, points, SplitStats(played, hGf + aGf, hGa + aGa), SplitStats(played / 2, hGf, hGa), SplitStats(played / 2, aGf, aGa), form)

    @Test fun parsesFormStrings() {
        assertEquals(2.0, FormUtil.ppg("WWDLW")!!.first, 1e-12)
        assertEquals(5, FormUtil.ppg("WWDLW")!!.second)
        assertEquals(4.0 / 3.0, FormUtil.ppg("W,D,L")!!.first, 1e-12)
        assertNull(FormUtil.ppg("WW"))
        assertNull(FormUtil.ppg(""))
    }

    @Test fun formShiftsExpectedGoalsOnlySlightlyAndOnlyWhenAvailable() {
        val withForm = listOf(row(1, 10, 15, 10, 4, 8, 6, "WWWWW"), row(2, 10, 12, 7, 6, 5, 8, "LLLLL"))
        val noForm = withForm.map { it.copy(form = "") }
        val a = Strength.lambdas(withForm, 1, 2)!!
        val b = Strength.lambdas(noForm, 1, 2)!!
        assertTrue(a.formUsed)
        assertFalse(b.formUsed)
        assertTrue(a.home > b.home)
        assertTrue(a.away < b.away)
        assertTrue(a.home / b.home <= 1.0 + Strength.FORM_WEIGHT)
        assertTrue(a.away / b.away >= 1.0 - Strength.FORM_WEIGHT)
        assertEquals(b.dataQuality, a.dataQuality, 1e-12)
    }

    @Test fun oneSidedFormIsNotUsed() {
        val rows = listOf(row(1, 10, 15, 10, 4, 8, 6, "WWWWW"), row(2, 10, 12, 7, 6, 5, 8, ""))
        assertFalse(Strength.lambdas(rows, 1, 2)!!.formUsed)
    }
}

private fun mt(id: String) = Match(id, 39, "Premier League", "H$id", "A$id", 1000, "NS", null, null, null, null, "API-Football")

private fun fc(matchId: String, p: Double, conf: Confidence, mk: String = "ou_1.5", sk: String = "over") =
    Forecast(matchId, mk, sk, p, conf, when (conf) { Confidence.HIGH -> 90; Confidence.MEDIUM -> 65; Confidence.LOW -> 40 }, null, null, null, null, "t", 0.9)

private fun ev(matchId: String, mk: String, sk: String, odds: Double, adj: Double, ev: Double, q: Int, d: Decision = Decision.RECOMMEND) =
    Evaluation(matchId, mk, sk, odds, "Kaynak", "Manuel", 0L, adj, adj, 1 / odds, null, ev, q, null, d, "r", false)

class CouponLabTest {
    @Test fun onlyThreeCouponTypesAndNoValueCoupon() {
        assertEquals(listOf("BALANCED", "SURPRISE", "HIGH_RISK"), CouponType.values().map { it.name })
    }

    @Test fun balancedOddlessBuildsWithoutTotalOdds() {
        val c = CouponLab.build(
            CouponType.BALANCED,
            listOf("a", "b", "c").map { CouponPick(mt(it), fc(it, 0.70, Confidence.HIGH), null) }
        ).coupon!!
        assertEquals(3, c.picks.size)
        assertNull(c.totalOdds)
        assertEquals(3, c.unpricedCount)
        assertEquals(Confidence.HIGH, c.level)
        assertEquals(0.343, c.probability, 1e-9)
        assertEquals(0, c.relaxedTier)
    }

    @Test fun balancedDoesNotChaseVeryLowOddsFavorites() {
        val picks = listOf("a", "b", "c").map { CouponPick(mt(it), fc(it, 0.90, Confidence.HIGH), null) }
        assertNull(CouponLab.build(CouponType.BALANCED, picks).coupon)
    }

    @Test fun balancedPrefersTheSweetSpotOverTheSafestFavorite() {
        val picks = listOf(0.74 to "a", 0.64 to "b", 0.60 to "c", 0.52 to "d")
            .map { (p, id) -> CouponPick(mt(id), fc(id, p, Confidence.HIGH), null) }
        val c = CouponLab.build(CouponType.BALANCED, picks).coupon!!
        assertEquals("b", c.picks[0].match.id)
    }

    @Test fun lowPricedPickIsExcludedFromBalanced() {
        val priced = CouponPick(mt("a"), fc("a", 0.70, Confidence.HIGH), ev("a", "ou_1.5", "over", 1.20, 0.70, 0.04, 60))
        val others = listOf("b", "c").map { CouponPick(mt(it), fc(it, 0.66, Confidence.HIGH), null) }
        val c = CouponLab.build(CouponType.BALANCED, listOf(priced) + others).coupon!!
        assertFalse(c.picks.any { it.match.id == "a" })
    }

    @Test fun criteriaRelaxInControlledTiersAndAreFlagged() {
        val picks = listOf(
            CouponPick(mt("a"), fc("a", 0.70, Confidence.HIGH), null),
            CouponPick(mt("b"), fc("b", 0.66, Confidence.MEDIUM), null),
            CouponPick(mt("c"), fc("c", 0.64, Confidence.MEDIUM), null)
        )
        val out = CouponLab.build(CouponType.BALANCED, picks)
        val c = out.coupon!!
        assertEquals(3, c.picks.size)
        assertEquals(Confidence.MEDIUM, c.level)
        assertEquals(1, c.relaxedTier)
        assertTrue(out.notes.any { it.contains("esnetildi") })
    }

    @Test fun lowConfidenceOnlyStillMakesAFlaggedCoupon() {
        val picks = listOf("a", "b").map { CouponPick(mt(it), fc(it, 0.60, Confidence.LOW), null) }
        val c = CouponLab.build(CouponType.BALANCED, picks).coupon!!
        assertEquals(2, c.lowConfidenceCount)
        assertEquals(Confidence.LOW, c.level)
        assertEquals(2, c.relaxedTier)
    }

    @Test fun notEnoughMatchesGivesNoCouponAndExplains() {
        val out = CouponLab.build(CouponType.BALANCED, listOf(CouponPick(mt("a"), fc("a", 0.70, Confidence.HIGH), null)))
        assertNull(out.coupon)
        assertTrue(out.notes.any { it.contains("en az") })
        val empty = CouponLab.build(CouponType.SURPRISE, emptyList())
        assertNull(empty.coupon)
        assertTrue(empty.notes.isNotEmpty())
    }

    @Test fun unplayableMarketsAreKeptOutOfTheCouponPool() {
        val picks = listOf(
            CouponPick(mt("a"), fc("a", 0.72, Confidence.HIGH, "ou_0.5", "over"), null),
            CouponPick(mt("a"), fc("a", 0.65, Confidence.HIGH, "btts", "yes"), null),
            CouponPick(mt("b"), fc("b", 0.70, Confidence.HIGH, "ou_4.5", "under"), null),
            CouponPick(mt("b"), fc("b", 0.66, Confidence.HIGH), null)
        )
        val c = CouponLab.build(CouponType.BALANCED, picks).coupon!!
        assertEquals(2, c.picks.size)
        assertTrue(c.picks.none { (it.f.marketKey == "ou_0.5" && it.f.selectionKey == "over") || (it.f.marketKey == "ou_4.5" && it.f.selectionKey == "under") })
        val onlyBad = listOf(
            CouponPick(mt("a"), fc("a", 0.72, Confidence.HIGH, "ou_0.5", "over"), null),
            CouponPick(mt("b"), fc("b", 0.70, Confidence.HIGH, "ou_4.5", "under"), null)
        )
        assertNull(CouponLab.build(CouponType.BALANCED, onlyBad).coupon)
    }

    @Test fun onlyOnePickPerMatch() {
        val picks = listOf(
            CouponPick(mt("a"), fc("a", 0.72, Confidence.HIGH, "ou_1.5"), null),
            CouponPick(mt("a"), fc("a", 0.66, Confidence.HIGH, "btts", "yes"), null),
            CouponPick(mt("b"), fc("b", 0.65, Confidence.HIGH), null)
        )
        val c = CouponLab.build(CouponType.BALANCED, picks).coupon!!
        assertEquals(2, c.picks.size)
        assertEquals(2, c.picks.map { it.match.id }.distinct().size)
    }

    @Test fun surpriseTargetsAboutFivePointTwoFiveFairOdds() {
        val picks = listOf("a", "b", "c", "d").map { CouponPick(mt(it), fc(it, 0.45, Confidence.MEDIUM, "1x2", "2"), null) }
        val out = CouponLab.build(CouponType.SURPRISE, picks)
        val c = out.coupon!!
        assertEquals(2, c.picks.size)                       // 0.45*0.45 = 0.2025 ≈ 1/5.25
        assertTrue(c.probability in 0.15..0.25)
        assertNull(c.totalOdds)                             // gerçek oran yok -> oran gösterilmez
        assertTrue(out.notes.any { it.contains("Hedef") })
    }

    @Test fun highRiskIsBolderAndStillStatisticallySupported() {
        val picks = listOf("a", "b", "c", "d", "e").map { CouponPick(mt(it), fc(it, 0.40, Confidence.MEDIUM, "1x2", "2"), null) }
        val c = CouponLab.build(CouponType.HIGH_RISK, picks).coupon!!
        assertEquals(3, c.picks.size)                       // 0.4^3 = 0.064 ≈ hedef %6
        assertEquals("Çok yüksek", c.risk)
        assertTrue(c.picks.all { it.prob in 0.22..0.45 })
        // Aşırı düşük olasılıklı (rastgele) seçimler kullanılmaz
        val junk = listOf("a", "b", "c").map { CouponPick(mt(it), fc(it, 0.08, Confidence.HIGH, "cs", "3-3"), null) }
        assertNull(CouponLab.build(CouponType.HIGH_RISK, junk).coupon)
    }

    @Test fun threeTypesBuildDifferentCouponsFromTheSamePool() {
        val pool = listOf(
            CouponPick(mt("a"), fc("a", 0.66, Confidence.HIGH), null),
            CouponPick(mt("b"), fc("b", 0.62, Confidence.HIGH), null),
            CouponPick(mt("c"), fc("c", 0.45, Confidence.MEDIUM, "1x2", "2"), null),
            CouponPick(mt("d"), fc("d", 0.42, Confidence.MEDIUM, "1x2", "X"), null),
            CouponPick(mt("e"), fc("e", 0.30, Confidence.MEDIUM, "1x2", "2"), null),
            CouponPick(mt("f"), fc("f", 0.28, Confidence.MEDIUM, "1x2", "X"), null)
        )
        val b = CouponLab.build(CouponType.BALANCED, pool).coupon!!
        val s = CouponLab.build(CouponType.SURPRISE, pool).coupon!!
        val h = CouponLab.build(CouponType.HIGH_RISK, pool).coupon!!
        assertTrue(b.picks.all { it.prob in 0.50..0.75 })
        assertTrue(s.picks.all { it.prob in 0.35..0.55 })
        assertTrue(h.picks.all { it.prob in 0.22..0.45 })
        assertTrue(b.probability > s.probability)
        assertTrue(s.probability > h.probability)
    }

    @Test fun totalOddsOnlyWhenEveryPickHasARealOdd() {
        val priced = listOf(Triple("a", 1.5, 0.08), Triple("b", 1.6, 0.08), Triple("c", 1.7, 0.08)).map { (id, o, e) ->
            CouponPick(mt(id), fc(id, 0.70, Confidence.HIGH), ev(id, "ou_1.5", "over", o, 0.70, e, 70))
        }
        val c = CouponLab.build(CouponType.BALANCED, priced).coupon!!
        assertEquals(1.5 * 1.6 * 1.7, c.totalOdds!!, 1e-9)
        assertEquals(0, c.unpricedCount)

        val mixed = listOf(
            CouponPick(mt("a"), fc("a", 0.70, Confidence.HIGH), ev("a", "ou_1.5", "over", 1.5, 0.70, 0.08, 70)),
            CouponPick(mt("b"), fc("b", 0.66, Confidence.HIGH), null)
        )
        val m = CouponLab.build(CouponType.BALANCED, mixed).coupon!!
        assertNull(m.totalOdds)
        assertEquals(1, m.unpricedCount)
    }
}

class RecentStatsTest {
    private fun rec(i: Int) = PredictionRecord(
        "id$i", "m$i", "A - B", 39, "PL", 1000L + i, "ou_2.5", "over", 0L, 0.5, 0.5, null, null, null,
        "t", "poisson-v2", false, i % 2 == 0, i.toLong(), "1-0"
    )

    @Test fun lastTenFiftyHundred() {
        val r = Metrics.recentStats((0 until 12).map { rec(it) })
        assertEquals(listOf(10, 50, 100), r.map { it.window })
        assertEquals(10, r[0].n)
        assertEquals(12, r[1].n)
        assertEquals(12, r[2].n)
        assertEquals(0.5, r[0].hitRate!!, 1e-9)
        assertEquals(0.25, r[0].brier!!, 1e-9)
        val empty = Metrics.recentStats(emptyList())
        assertNull(empty[0].hitRate)
        assertEquals(0, empty[0].n)
    }

    @Test fun reportIncludesRecentWindows() {
        val rep = Metrics.report((0 until 12).map { rec(it) })
        assertEquals(3, rep.recent.size)
        assertEquals(12, rep.settled)
    }
}
