package com.savran.bahis

import org.json.JSONArray
import org.json.JSONObject
import java.io.File

/** Kalibrasyon kutusu: tahmin olasılığı aralığında kaç tahmin yapıldı, kaçı gerçekleşti. */
data class CalBin(val n: Int, val hits: Int)

data class CalGroup(
    val name: String,
    val n: Int,                    // öğrenmede kullanılan sonuçlanmış tahmin sayısı
    val bins: List<CalBin>,
    val adoptedAt: Long,
    val brierBefore: Double,       // doğrulama kümesinde ham modelin Brier skoru
    val brierAfter: Double         // doğrulama kümesinde kalibre modelin Brier skoru
)

data class LearningEvent(
    val at: Long, val group: String, val n: Int,
    val brierBefore: Double, val brierAfter: Double, val adopted: Boolean, val note: String
)

data class LearningState(
    val modelVersion: String,
    val groups: Map<String, CalGroup>,     // devreye alınmış kalibrasyonlar
    val events: List<LearningEvent>,       // model geliştirme geçmişi
    val weak: Set<String>,                 // yeterli veriyle "yetenek göstermeyen" pazar grupları
    val samples: Map<String, Int>,         // grup başına sonuçlanmış örnek sayısı
    val updatedAt: Long
) {
    companion object {
        fun empty(version: String) = LearningState(version, emptyMap(), emptyList(), emptySet(), emptyMap(), 0L)
    }
}

/**
 * Kontrollü kalibrasyon: ham model olasılığı -> gerçekleşme sıklığı eşlemesi.
 * Küçük örnekte kimlik eşlemesine (değişiklik yok) doğru büzülür; tek bir yanlış tahmin hiçbir şeyi değiştirmez.
 */
object Calibration {
    const val MIN_N = 60              // bir grup için gereken en az sonuçlanmış tahmin
    const val MIN_MATCHES = 20        // ... ve en az bu kadar farklı maç
    const val MIN_VALID = 15          // doğrulama kümesi en az bu kadar
    const val SHRINK_K = 40.0         // kutu başına büzülme gücü
    const val MIN_GAIN = 0.002        // doğrulamada Brier'in en az bu kadar düşmesi gerekir
    const val WEAK_MIN_N = 80
    const val WEAK_BRIER = 0.26       // bundan kötü Brier = yazı-turadan iyi olmayan pazar
    const val EVENT_STEP = 30         // yeniden değerlendirme için gereken yeni örnek sayısı
    private const val BINS = 10

    /** Kalibrasyon yapılabilen pazar grupları. Çakışan (dc, ilk yarı ÇŞ) veya çok seçenekli pazarlar hariç. */
    fun group(mk: String): String? = when {
        mk == "1x2" -> "1x2"
        mk == "btts" -> "btts"
        mk.startsWith("ou_") -> "total-gol"
        mk.startsWith("home_ou_") || mk.startsWith("away_ou_") -> "takim-gol"
        mk == "ht_1x2" || mk == "ht_btts" || mk.startsWith("ht_ou_") -> "ilk-yari"
        else -> null
    }

    fun groupLabel(g: String): String = when (g) {
        "1x2" -> "Maç sonucu"
        "btts" -> "Karşılıklı gol"
        "total-gol" -> "Toplam gol"
        "takim-gol" -> "Takım golü"
        "ilk-yari" -> "İlk yarı"
        else -> g
    }

    fun binOf(p: Double): Int = (p.coerceIn(0.0, 0.9999) * BINS).toInt()

    fun fit(samples: List<Pair<Double, Boolean>>): List<CalBin> {
        val n = IntArray(BINS)
        val h = IntArray(BINS)
        for ((p, y) in samples) {
            val b = binOf(p)
            n[b]++
            if (y) h[b]++
        }
        return (0 until BINS).map { CalBin(n[it], h[it]) }
    }

    fun map(p: Double, bins: List<CalBin>): Double {
        val b = bins[binOf(p)]
        if (b.n == 0) return p
        val w = b.n / (b.n + SHRINK_K)
        val observed = b.hits.toDouble() / b.n
        return (w * observed + (1 - w) * p).coerceIn(0.01, 0.99)
    }

    /** İki seçenekli pazarlarda tutarlılık için simetri: g(p) = (f(p) + 1 - f(1-p)) / 2. */
    fun mapSymmetric(p: Double, bins: List<CalBin>): Double =
        ((map(p, bins) + 1.0 - map(1.0 - p, bins)) / 2.0).coerceIn(0.01, 0.99)

    fun brier(samples: List<Pair<Double, Boolean>>, f: (Double) -> Double): Double {
        if (samples.isEmpty()) return 0.0
        return samples.sumOf { (p, y) ->
            val q = f(p)
            val t = if (y) 1.0 else 0.0
            (q - t) * (q - t)
        } / samples.size
    }
}

/** Geçmiş sonuçlanmış tahminlerden kalibrasyon öğrenir. Gelecek bilgisi kullanmaz (zaman sıralı bölme). */
object Learner {
    fun run(records: List<PredictionRecord>, prev: LearningState?, version: String, now: Long): LearningState {
        val base = if (prev != null && prev.modelVersion == version) prev else LearningState.empty(version)
        val settled = records.filter { it.result != null && it.modelVersion == version }
        val groups = base.groups.toMutableMap()
        val events = base.events.toMutableList()
        val weak = HashSet<String>()
        val samples = HashMap<String, Int>()

        val byGroup = settled.groupBy { Calibration.group(it.marketKey) }
        for ((g, recs) in byGroup) {
            if (g == null) continue
            samples[g] = recs.size
            // Ham model olasılığı (modelProb) ile gerçekleşme karşılaştırılır; zaman sırasına göre.
            val data = recs.sortedBy { it.settledAt ?: it.kickoff }.map { it.modelProb to (it.result == true) }
            if (data.size >= Calibration.WEAK_MIN_N && Calibration.brier(data) { it } >= Calibration.WEAK_BRIER) weak.add(g)

            val matches = recs.map { it.matchId }.distinct().size
            if (data.size < Calibration.MIN_N || matches < Calibration.MIN_MATCHES) continue
            val lastN = events.lastOrNull { it.group == g }?.n ?: 0
            if (events.any { it.group == g } && data.size - lastN < Calibration.EVENT_STEP) continue

            val split = (data.size * 0.75).toInt()
            val train = data.take(split)
            val valid = data.drop(split)
            if (valid.size < Calibration.MIN_VALID) continue
            val bins = Calibration.fit(train)
            val fn: (Double) -> Double = { p -> if (g == "1x2") Calibration.map(p, bins) else Calibration.mapSymmetric(p, bins) }
            val before = Calibration.brier(valid) { it }
            val after = Calibration.brier(valid, fn)
            val adopted = before - after >= Calibration.MIN_GAIN
            if (adopted) {
                groups[g] = CalGroup(g, data.size, Calibration.fit(data), now, before, after)
            }
            events.add(
                LearningEvent(
                    now, g, data.size, before, after, adopted,
                    if (adopted) "Doğrulama kümesinde Brier iyileşti; kalibrasyon devreye alındı."
                    else "Doğrulama kümesinde yeterli iyileşme yok; model değiştirilmedi."
                )
            )
        }
        return LearningState(version, groups, events.takeLast(200), weak, samples, now)
    }
}

/** Öğrenilmiş kalibrasyonu yeni tahminlere uygular. Olasılıklar pazar içinde tutarlı kalır (toplam 1). */
object Calibrator {
    fun apply(list: List<Forecast>, state: LearningState?): List<Forecast> {
        if (state == null || state.groups.isEmpty()) return list
        val adj = HashMap<String, Double>()
        for ((_, fs) in list.groupBy { it.matchId + "|" + it.marketKey }) {
            val mk = fs[0].marketKey
            val g = Calibration.group(mk) ?: continue
            val cg = state.groups[g] ?: continue
            if (fs.size == 2) {
                val first = MarketCatalog.find(mk)?.selections?.firstOrNull()?.key
                val a = fs.firstOrNull { it.selectionKey == first } ?: fs[0]
                val b = fs.first { it !== a }
                val pa = Calibration.mapSymmetric(a.rawProb, cg.bins)
                adj[a.matchId + "|" + mk + "|" + a.selectionKey] = pa
                adj[b.matchId + "|" + mk + "|" + b.selectionKey] = 1.0 - pa
            } else if (fs.size == 3 && (mk == "1x2" || mk == "ht_1x2")) {
                val raw = fs.map { Calibration.map(it.rawProb, cg.bins) }
                val s = raw.sum()
                for (i in fs.indices) adj[fs[i].matchId + "|" + mk + "|" + fs[i].selectionKey] = raw[i] / s
            }
        }
        if (adj.isEmpty()) return list
        return list.map { f -> adj[f.matchId + "|" + f.marketKey + "|" + f.selectionKey]?.let { f.copy(prob = it) } ?: f }
    }
}

class LearningStore(private val dir: File) {
    private val file = File(dir, "learning.json")

    @Synchronized
    fun read(): LearningState? {
        if (!file.exists()) return null
        return try {
            val o = JSONObject(file.readText())
            val groups = HashMap<String, CalGroup>()
            val ga = o.optJSONArray("groups") ?: JSONArray()
            for (i in 0 until ga.length()) {
                val g = ga.getJSONObject(i)
                val ba = g.getJSONArray("bins")
                val bins = (0 until ba.length()).map { CalBin(ba.getJSONArray(it).getInt(0), ba.getJSONArray(it).getInt(1)) }
                groups[g.getString("name")] = CalGroup(
                    g.getString("name"), g.getInt("n"), bins, g.getLong("at"), g.getDouble("bb"), g.getDouble("ba")
                )
            }
            val ea = o.optJSONArray("events") ?: JSONArray()
            val events = (0 until ea.length()).map {
                val e = ea.getJSONObject(it)
                LearningEvent(e.getLong("at"), e.getString("g"), e.getInt("n"), e.getDouble("bb"), e.getDouble("ba"), e.getBoolean("ok"), e.getString("note"))
            }
            val wa = o.optJSONArray("weak") ?: JSONArray()
            val weak = (0 until wa.length()).map { wa.getString(it) }.toSet()
            val so = o.optJSONObject("samples") ?: JSONObject()
            val samples = so.keys().asSequence().associateWith { so.getInt(it) }
            LearningState(o.getString("version"), groups, events, weak, samples, o.getLong("updatedAt"))
        } catch (e: Exception) {
            null
        }
    }

    @Synchronized
    fun write(s: LearningState) {
        val ga = JSONArray()
        for (g in s.groups.values) {
            val ba = JSONArray()
            g.bins.forEach { ba.put(JSONArray().put(it.n).put(it.hits)) }
            ga.put(JSONObject().put("name", g.name).put("n", g.n).put("bins", ba).put("at", g.adoptedAt).put("bb", g.brierBefore).put("ba", g.brierAfter))
        }
        val ea = JSONArray()
        for (e in s.events) {
            ea.put(JSONObject().put("at", e.at).put("g", e.group).put("n", e.n).put("bb", e.brierBefore).put("ba", e.brierAfter).put("ok", e.adopted).put("note", e.note))
        }
        val wa = JSONArray()
        s.weak.forEach { wa.put(it) }
        val so = JSONObject()
        s.samples.forEach { (k, v) -> so.put(k, v) }
        val root = JSONObject().put("version", s.modelVersion).put("groups", ga).put("events", ea)
            .put("weak", wa).put("samples", so).put("updatedAt", s.updatedAt)
        atomicWrite(file, root.toString())
    }
}
