@file:OptIn(ExperimentalMaterial3Api::class)

package com.savran.bahis

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.launch
import java.time.Instant
import java.time.format.DateTimeFormatter

private val testTimeFmt: DateTimeFormatter = DateTimeFormatter.ofPattern("d MMM HH:mm")

// ------------------------------------------------------------------ Ayarlar: 7 veri kaynağı

@Composable
fun SettingsScreen(repo: Repository, pop: () -> Unit) {
    val s = repo.settings
    var season by remember { mutableStateOf(s.season) }
    var note by remember { mutableStateOf<String?>(null) }

    Scaffold(topBar = { AppBar("API ve Veri Kaynakları", pop) }) { pad ->
        Column(
            Modifier.padding(pad).fillMaxSize().verticalScroll(rememberScrollState()).padding(12.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Text(
                "7 veri kaynağı ayrı yönetilir. Aktif olanlar birlikte çalışır; biri hata verirse diğerleri etkilenmez. " +
                    "Her kartta kaynağın gerçekten sunduğu ligler ve veriler yazar; olmayan veri varmış gibi gösterilmez.",
                fontSize = 12.sp, color = MutedText
            )
            SourceCatalog.all.forEach { info -> SourceCard(repo, info) }

            SectionTitle("Haber araştırması")
            var newsOn by remember { mutableStateOf(s.newsEnabled) }
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    "Maç ekranı açılınca takım haberleri (sakat, cezalı, ilk 11, teknik direktör) Google Haberler RSS'inden araştırılır. Anahtar gerekmez; sonuçlar tarih ve kaynakla saklanır.",
                    fontSize = 12.sp, color = MutedText, modifier = Modifier.weight(1f)
                )
                Switch(checked = newsOn, onCheckedChange = { newsOn = it; s.newsEnabled = it })
            }

            SectionTitle("Sezon")
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(onClick = { season -= 1; s.season = season }) { Text("−") }
                Text("$season", fontWeight = FontWeight.Bold, fontSize = 18.sp)
                OutlinedButton(onClick = { season += 1; s.season = season }) { Text("+") }
            }
            Text(
                "Sezon, başlangıç yılıyla seçilir (2026 = 2026-27). Puan durumu bu sezon için çekilir. " +
                    "Bir kaynak güncel sezonu vermezse hata mesajı o kaynağın kartında ve maç listesinde görünür; " +
                    "diğer aktif kaynaklar denenir.",
                fontSize = 11.sp, color = MutedText
            )

            SectionTitle("Veri")
            OutlinedButton(onClick = {
                repo.clearCache()
                note = "Önbellek temizlendi. Girdiğin oranlar ve tahmin geçmişi silinmedi."
            }) { Text("Önbelleği temizle") }
            val n = note
            if (n != null) InfoCard("Bilgi", n)

            SectionTitle("Hakkında")
            Text(
                "Reklam yok, hesap yok, bahis otomasyonu yok. Anahtarlar yalnızca bu telefonda şifreli saklanır; kaynak koda veya GitHub'a yazılmaz.\n" +
                    "Kesin kazanç veya garanti iddiası yoktur.",
                fontSize = 12.sp, color = MutedText
            )
        }
    }
}

@Composable
private fun SourceCard(repo: Repository, info: SourceInfo) {
    val id = info.id
    val s = repo.settings
    val scope = rememberCoroutineScope()
    var enabled by remember { mutableStateOf(s.isEnabled(id)) }
    var hasKey by remember { mutableStateOf(s.hasCustomKey(id)) }
    var keyInput by remember { mutableStateOf("") }
    var testing by remember { mutableStateOf(false) }
    var result by remember { mutableStateOf(s.lastTest(id)) }
    var open by remember { mutableStateOf(false) }
    var msg by remember { mutableStateOf<String?>(null) }

    val keyed = id.keyEditable
    val effectiveKey = hasKey || id.keyDefault != null
    val active = enabled && (!id.needsKey || hasKey)
    val statusText = when {
        !enabled -> "Pasif"
        id.needsKey && !hasKey -> "Aktif ama anahtar yok"
        else -> "Aktif"
    }
    val statusColor: Color = when {
        !enabled -> MutedText
        id.needsKey && !hasKey -> AmberWarn
        else -> GreenOk
    }

    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text(id.title, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                    Text(statusText, color = statusColor, fontSize = 12.sp)
                }
                Switch(checked = enabled, onCheckedChange = { enabled = it; s.setEnabled(id, it) })
            }
            Text(
                "Ligler: " + SourceCatalog.leagueNames(Leagues.supported.map { it.id }.filter { it in info.leagues }),
                fontSize = 12.sp
            )

            if (keyed) {
                val shownKey = s.rawKeyOf(id)
                Text(
                    when {
                        hasKey -> "Kayıtlı anahtar: ••••" + (shownKey?.takeLast(4) ?: "")
                        id.keyDefault != null -> "Varsayılan ortak anahtar kullanılıyor: ${id.keyDefault}"
                        else -> "Anahtar girilmedi. Kayıt: ${info.signup}"
                    },
                    fontSize = 12.sp, color = MutedText
                )
                OutlinedTextField(
                    keyInput, { keyInput = it },
                    label = { Text(if (id.keyDefault != null) "Kendi anahtarın (isteğe bağlı)" else "Yeni anahtar") },
                    singleLine = true,
                    visualTransformation = if (id.keyDefault != null) VisualTransformation.None else PasswordVisualTransformation(),
                    modifier = Modifier.fillMaxWidth()
                )
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(onClick = {
                        if (keyInput.isNotBlank()) {
                            s.setRawKey(id, keyInput)
                            keyInput = ""
                            hasKey = true
                            msg = "Anahtar bu telefonda şifreli kaydedildi."
                        }
                    }) { Text("Kaydet") }
                    OutlinedButton(onClick = {
                        s.setRawKey(id, null)
                        hasKey = false
                        msg = if (id.keyDefault != null) "Özel anahtar silindi; varsayılan (${id.keyDefault}) kullanılacak." else "Anahtar silindi."
                    }) { Text("Sil") }
                }
            } else {
                Text("Anahtar gerekmez (açık veri kaynağı).", fontSize = 12.sp, color = MutedText)
            }

            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(
                    enabled = !testing && (!id.needsKey || hasKey),
                    onClick = {
                        scope.launch {
                            testing = true
                            result = repo.testSource(id)
                            testing = false
                        }
                    }
                ) { Text("Bağlantıyı test et") }
                if (testing) CircularProgressIndicator(Modifier.padding(4.dp))
            }
            val m = msg
            if (m != null) Text(m, fontSize = 12.sp, color = GreenOk)
            val r = result
            if (r != null) {
                Text(
                    (if (r.ok) "✓ " else "✗ ") + r.message,
                    fontSize = 12.sp, color = if (r.ok) GreenOk else RedBad
                )
                Text(
                    "Son test: " + Instant.ofEpochMilli(r.at).atZone(repo.zone).format(testTimeFmt),
                    fontSize = 11.sp, color = MutedText
                )
            }
            val now = System.currentTimeMillis()
            if (id == SourceId.API_FOOTBALL) {
                val rem = s.remainingKnown(now)
                Text(
                    "Bugün yapılan istek: ${s.usedToday(now)}" + (rem?.let { " · Kalan: $it" } ?: "") +
                        " · Günlük sınır ${Quota.DAILY_LIMIT}, son ${Quota.RESERVE} istek yedekte.",
                    fontSize = 11.sp, color = MutedText
                )
            } else if (id == SourceId.ODDS_API) {
                Text("Kalan kredi: ${s.oddsApiRemaining ?: "bilinmiyor"} · Bugün yapılan istek: ${s.callsToday(id, now)}", fontSize = 11.sp, color = MutedText)
            } else {
                Text("Bugün yapılan istek: ${s.callsToday(id, now)}", fontSize = 11.sp, color = MutedText)
            }

            TextButton(onClick = { open = !open }) { Text(if (open) "Kapsamı gizle" else "Kapsamı göster") }
            if (open) {
                val missing = Leagues.supported.map { it.id }.filter { it !in info.leagues }
                Text("Kapsanan ligler: ${SourceCatalog.leagueNames(Leagues.supported.map { it.id }.filter { it in info.leagues })}", fontSize = 12.sp)
                Text("Kapsanmayan ligler: ${SourceCatalog.leagueNames(missing)}", fontSize = 12.sp)
                Text("Sağladığı veriler:", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                info.provides.forEach { Text("• $it", fontSize = 12.sp) }
                Text("Sağlamadığı / bu uygulamada kullanılmayan:", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                info.notProvided.forEach { Text("• $it", fontSize = 12.sp) }
                Text("Sezonlar: ${info.seasons}", fontSize = 12.sp)
                Text("Limitler: ${info.limits}", fontSize = 12.sp)
                Text("Uygulamadaki kullanımı: ${info.usedFor}", fontSize = 12.sp)
            }
        }
    }
}

// ------------------------------------------------------------------ Maç detayı: kaynak doğrulama

@Composable
fun VerificationCard(repo: Repository, match: Match) {
    val scope = rememberCoroutineScope()
    var checks by remember { mutableStateOf<List<SourceCheck>?>(null) }
    var busy by remember { mutableStateOf(false) }

    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Text("Bu maçı listeleyen kaynaklar: " + FixtureMerge.sources(match).joinToString(", ").ifEmpty { "-" }, fontSize = 13.sp)
            Text(
                "Takımların toplam istatistikleri (oynanan, atılan, yenilen gol) aktif kaynaklarda karşılaştırılır. " +
                    "Her kaynak için 1 istek harcanır; sonuç tahmini değiştirmez, tutarlılığı gösterir.",
                fontSize = 11.sp, color = MutedText
            )
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(enabled = !busy, onClick = {
                    scope.launch {
                        busy = true
                        checks = repo.verifyMatch(match)
                        busy = false
                    }
                }) { Text("Kaynakları karşılaştır") }
                if (busy) CircularProgressIndicator(Modifier.padding(4.dp))
            }
            checks?.forEach { c ->
                val color = when (c.status) {
                    CheckStatus.MATCH, CheckStatus.REFERENCE -> GreenOk
                    CheckStatus.DIFF, CheckStatus.NOT_FOUND, CheckStatus.NO_REF -> AmberWarn
                    CheckStatus.ERROR -> RedBad
                    else -> MutedText
                }
                Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                        Text(c.source.title, fontWeight = FontWeight.Bold, fontSize = 13.sp, modifier = Modifier.weight(1f))
                        Tag(c.status.tr, color)
                    }
                    Text(c.note, fontSize = 11.sp, color = MutedText)
                }
            }
        }
    }
}
